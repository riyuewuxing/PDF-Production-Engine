# 求职达人（qiuzhidaren）

面向多职业、多求职阶段的结构化求职业务与 Artifact 项目。

**当前状态唯一入口：`CURRENT_STATE.yaml`。** 底层架构见 `architecture/README.md` 与 `architecture/adr/`；模块生命周期/adapter 见 `production/contracts/module-registry-v1.yaml`。

## 固定底层架构

`qiuzhidaren` 是 Modular Monolith，仓库内分四层：

`Domain → Application → Artifact → Adapters`

只有两个架构级外部系统：

- Recruitment Intelligence：输出 `Validated Opportunity Package`；
- `riyuewuxing/PDF-Production-Engine`：公共、无状态、机械资源执行。

跨仓编排和 HUMAN 验收由 ChatGPT/session 完成。两个仓库不直接 checkout、持有 PAT、写回或保存对方业务状态。

## 项目本质

首要产品是可由不同获授权 AI 接手并复用的生产流程，而不是把少量样本反复磨到通过。具体 PDF/逐字稿/简历/题库既是用户交付物，也是流程验证样本。Process-as-Product 决策见 `ADR-009`，效率 authority 见 `production/resource-build-efficiency-policy-v1.yaml`。

## 教师方向

当前业务树：

```text
content/job-search/teacher/
├── interview/
│   ├── teaching-demo/
│   ├── structured/
│   └── defense/
├── self-introduction/
├── resume-materials/
├── written-exam/
└── position-research/   # historical reference only
```

具体 lifecycle 不在 README 重复定义，只从 module registry / CURRENT_STATE 读取。

实时岗位链固定为：

`Recruitment Intelligence → Validated Opportunity Package → Candidate Facts / Eligibility → Application / Preparation → Module deliverables`

仓库内 `position-research` 不再执行 current-source scan；历史资产只作为外部接口/研究参考。

## Unified Artifact Pipeline

所有新 PDF/DOCX/PPT/未来资源统一走：

`JOB_CREATED → INPUTS_LOCKED → BLOCKS_ACCEPTED → BUILT → MACHINE_VERIFIED → HUMAN_ACCEPTED → PUBLISHED`

模块差异只进入 Module Contract/data/adapter，不再为每个模块复制项目级状态机。

运行事实写入 append-only Execution Ledger；attempt/cycle/build/render/reject 数由 checker 从事件派生。文件 binding 统一使用 repository-relative path + SHA-256。

Machine verification 与 HUMAN acceptance 永久分离。可视最终文档必须真实全页 render 并由 ChatGPT 实际逐页查看。

## Delivery / Qualification

单个 Artifact Job 是否可发布属于 Delivery Acceptance。跨多个案例的连续质量/效率/warm-path/agent-portability 证明属于独立 System Qualification；qualification 不插入普通发布链，也不反向否定已接受的 immutable delivery。

## Resource Engine

固定资源链：

`qiuzhidaren → ChatGPT/session → Public PDF-Production-Engine → ChatGPT HUMAN review → qiuzhidaren`

私库 GitHub-hosted Actions 已不可作为正常生产资源；本仓库不依赖 private hosted runner 做 build/stage/transport/verification。

## Canonical machine gate

默认无 PDF foundation gate：

```bash
python tools/run_acceptance.py --scope foundation
```

正式模块 artifact/regression 需显式选择 scope，不会由 foundation gate 自动生成 PDF。

## Git

Architecture Foundation v1 已发布到 `main`。`main` 是唯一长期 Git authority；feature/fix branch 必须短生命周期，force update 永久禁止。

其他模块后续开发按短分支推进。试讲内容功能按用户要求只在 main 的 `production/process/teaching-demo-content/` 原地修改，禁止分支/日期/版本副本；从该目录 PROCESS 与 STATUS 接手。
