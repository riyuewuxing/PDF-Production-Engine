# Phase B Eval Harness First｜Source-Level Engineering Review

- Role: **PHASE B IMPLEMENTER / SOURCE-LEVEL REVIEW ONLY**
- Date: 2026-09-10
- Gate A authorization: `a548ddec430a84f7139b20f7d071238d685022b1` → **GATE_A_PASS** for `PHASE_B_EVAL_HARNESS_FIRST` only.
- Gate A review-start main: `0627e3aa03aa574e7526f338c02ff754ca55b487`.
- Phase-B source foundation reviewed head: `d742d694f406f3483f1e6e796a27316538f77e4b`.
- Durable state after that source head was rechecked through `c5e54fde46a5deaf1941a5d26cde3ad2ecbed385`; `d742d694... → c5e54fde...` changes only `PLAN.md` and `STATUS.yaml`.
- Runtime PASS claimed: **false**.
- Gate B claimed: **false**.
- CALIBRATED claimed: **false**.

## 1. Scope reviewed

This review covers the first Phase-B source foundation created after the independent Gate-A PASS. It does not reopen RRA5 and does not re-grade the frozen Round1/Round2 packages.

`a548ddec... → d742d694...` is 15 commits. The changed-file set is limited to Phase-B architecture/evaluation/provenance code plus Teaching Demo durable/handoff state:

- `architecture/README.md`
- `architecture/adr/ADR-017-teaching-demo-phase-b-semantic-controller-provenance.md`
- `production/process/teaching-demo-content/{HANDOFF.md,MEMORY.md,PLAN.md,STATUS.yaml}`
- `production/process/teaching-demo-content/validation/phase-a/GATE_A_HANDOFF.md`
- `production/process/teaching-demo-content/validation/phase-b/GOLD_CORPUS.yaml`
- `tools/check_teaching_demo_phase_b_eval.py`
- `tools/run_acceptance.py`
- `tools/tooling-manifest.yaml`
- `tools/verify_teaching_demo_semantic_provenance.py`

No Round1/Round2 first-complete frozen package, formal PDF output, Artifact execution output, or production Engine output is part of this source-foundation change set.

## 2. Source-level implementation facts established

1. ADR-017 defines the Phase-B problem as **Semantic Controller Producer Provenance**, rather than continuing unbounded Phase-A hardening. Repository-authored role/separation/runner strings do not establish producer identity.
2. `verify_teaching_demo_semantic_provenance.py` is a verifier, not a signer. Production signing authority/key material is not stored in the repository.
3. A trusted invocation must supply fresh `run_id + nonce` and expected controller/runtime, judge-runner, semantic-input and judge-output bindings. A correctly authenticated old receipt therefore cannot be replayed into a fresh invocation merely because its MAC and TTL remain valid.
4. `check_teaching_demo_phase_b_eval.py` is eval-only. Its HMAC key and synthetic controller Gold are test fixtures and explicitly have no production authority.
5. The harness consumes `validation/phase-b/GOLD_CORPUS.yaml` and recomputes the Git blob identity of immutable Round1/Round2 HUMAN REJECT evidence. The corpus cannot silently rewrite those historical decisions.
6. The source harness executes the permanent Gate-A/provenance mutant families already wired into code: RRA4 capability-removal mutants, `P1-RRA4-E`, repository-local Gate-B self-activation, M20/M21 release/formation controls, and provenance replay/wrong-runner/wrong-input/wrong-runtime/output-drift/expiry cases.
7. `run_acceptance.py` contains a Phase-B scope, while Gate B and accepted mode remain fail-closed. Tooling governance classifies the provenance verifier as a library and the Phase-B harness as an executable entry.

These are source-level implementation facts only. Source code containing selftests is not execution evidence.

## 3. Mandatory legal-path / false-positive review

The source foundation includes one synthetic provenance positive Gold so the provenance verifier cannot obtain an apparent 100% kill rate simply by rejecting every receipt. This fixture proves only that the verifier has a structurally satisfiable test path. It is **not** HUMAN-reviewed semantic Gold and has no production controller authority.

The currently registered semantic mutant catalog also must not be mistaken for a mutation score. M01–M15 are present in the corpus, but catalog presence by itself is not an executable kill. The remaining Phase-B work must wire each required mutant to the actual deterministic/semantic evaluation path and distinguish:

- machine mutants that can be killed deterministically in the repository harness;
- semantic mutants that can be materialized by the harness but require a trusted semantic judge/controller execution before a real kill can be credited;
- positive HUMAN-reviewed semantic Gold needed to measure false-positive behavior.

## 4. Evidence still missing / blocking Gate B

The following are deliberately **not** marked complete:

- executable coverage for all required M01–M15 mutants;
- HUMAN-reviewed positive semantic Gold;
- live trusted semantic-controller/judge producer-provenance receipt;
- exact private-checkout execution of `check_teaching_demo_content.py --selftest`, `check_tooling_routes.py`, `run_acceptance.py --scope foundation`, and `run_acceptance.py --scope phase-b`;
- deterministic grader report, semantic calibration report, mutation score report and full regression rerun evidence;
- Independent Gate B.

The current connector session has no exact private-repository checkout shell, so those shell commands remain `NOT_EXECUTED_NO_REPOSITORY_SHELL`. Git read-back and source inspection are not substituted for runtime evidence.

## 5. Current decision

**PHASE_B_SOURCE_FOUNDATION_IMPLEMENTED; EVIDENCE BUILDOUT IN PROGRESS.**

No new concrete source-level P0/P1 defect was found in the already-implemented Phase-B provenance/corpus foundation during this bookkeeping review. That is not a Gate-B PASS and it does not prove the unexecuted mutants or runtime path.

Next engineering action is bounded: wire M01–M15 into executable evaluation cases, curate a HUMAN-reviewed positive semantic Gold, obtain live trusted provenance/runtime evidence, generate the required reports, then request a genuinely independent Gate B. Only demonstrated Phase-B failures may trigger targeted repair of the responsible lower layer.

Fresh topics, automatic third topic, `CALIBRATED`, formal PDF, production Artifact/Engine and downstream QA remain blocked.

## 6. Semantic calibration packet follow-up

Mandatory Post-Write review continued after the M05/M07/M08/M09 differential-oracle batch. The remaining critical path was no longer “invent more machine mutants”; it was to make the external semantic calibration input exact and auditable without fabricating the missing external judge authority.

`SEMANTIC_CALIBRATION_CASES.yaml` now freezes M01–M04 and M21 as input-only calibration cases. Each case binds one exact semantic input object to a canonical JSON SHA-256, target SEMANTIC_JUDGE requirement and expected mutant outcome `REJECT`. The packet carries the trusted-invocation requirements from ADR-017 (fresh run/nonce, external controller/runtime identity, both judge runner identities, producer/session identity, exact judge-output bindings and external MAC authority). It explicitly contains no authored verdict, controller receipt or signing key.

The Phase-B harness now consumes this packet and fails closed on case-set drift, digest drift, requirement/enforcer drift, missing trusted-invocation constraints, or any forbidden authored result field. M21 is included in the same external calibration queue rather than being promoted from the existing fail-closed UNKNOWN probe to a fake semantic kill.

This is a source-level input-readiness improvement only. No trusted semantic judge/controller execution occurred in this connector environment, no HUMAN-reviewed positive semantic Gold was manufactured, and no exact private-checkout shell command was executed. Gate B and accepted mode therefore remain blocked.

## 7. Positive semantic Gold candidate follow-up

After freezing the negative semantic calibration packet, the next source-level preparation was the false-positive/legal-PASS side. A new `POSITIVE_SEMANTIC_GOLD_CANDIDATE.yaml` now defines `POS-GOLD-01`: a controlled electric-field-strength example whose visible data precede the student response, whose teacher prompt does not state the target relation, whose formation claim is explicitly bounded to the controlled conditions/data, and whose resource reveal, board addition and transfer practice occur after formation.

This file is intentionally **not** HUMAN Gold. Its authority is `CANDIDATE_ONLY_NOT_HUMAN_GOLD`, its HUMAN review status is `REQUIRED_NOT_YET_PERFORMED`, and Gate B remains blocking. The harness exact-binds its canonical semantic-input digest, target SEMANTIC_JUDGE requirements and expected enforcers, requires the independent-HUMAN review contract plus later trusted semantic execution, and rejects any authored HUMAN decision, judge outputs, controller receipt, authenticator or production key inside the candidate.

Mandatory Post-Write rereview found one useful tightening during this batch: checking only that the four target requirements remained `SEMANTIC_JUDGE` was insufficient for a calibration candidate intended to cover both judge roles. Commit `6a1f647b27c6261292b93b31d5187fe66222d101` therefore also exact-binds the expected enforcer for REQ-SCI-001 / REQ-STU-001 / REQ-STU-002 / REQ-REL-001. This is a source-binding repair, not evidence that the candidate deserves PASS.

No independent HUMAN review or live trusted judge/controller run has occurred. Therefore the project still has no HUMAN-reviewed positive semantic Gold, no false-positive PASS evidence, no Gate-B PASS and no accepted-mode unlock.

## 8. Positive candidate zero-trust rereview repair

After the prior candidate close-out, a fresh Mandatory Post-Write rereview attacked the candidate itself rather than treating `candidate prepared` as evidence. Two concrete weaknesses were found in the exact current bytes.

First, the original student response only stated that three `F/q` values were equal while the proportional-relation conclusion lived in a separate `formation_span` field. That is too close to the Round2/M01 sidecar-only failure mechanism for a positive legal-path fixture. The repaired candidate now places the bounded proportional conclusion as exact text inside `POS-E05 STUDENT_RESPONSE`, and the release claim binds the same visible span to that event.

Second, the original HUMAN review contract required `decision_required: PASS`, which would make rejection an invalid review result. The repaired contract now requires `PASS_OR_REJECT`: only an independent HUMAN PASS may promote the candidate, while REJECT must keep Gate B blocked and require revision.

The same repair broadens the candidate from a prose-only boundary sketch into an explicit legal-path fixture: realistic micro-unit q/F evidence, separated observation/inference and controlled boundary, independent-discovery formation followed by independent-transfer practice, explicit RESOURCE_SHOW -> STUDENT_RESPONSE -> RESOURCE_REVEAL -> FORMULA_ORALIZE -> BOARD_ADD -> PRACTICE ordering, and positive durations whose declared total is recomputed by the harness. Target SEMANTIC_JUDGE coverage now includes SCI/STU/REL/INT/RES/TIM requirements and their exact expected enforcers.

Source repair commits: candidate/legal-path repair `1942014fc583acec6dc66c47c1c528a4815acfda`, discovery/transfer split `972199bfcd5dac5331647837f818fa1b2d6b7bb0`, final harness binding `3d350b66181386723b7aa19e99015c1979a9db2c`.

This rereview still creates no HUMAN decision and executes no trusted semantic controller/judge or exact private checkout. Therefore the fixture remains `CANDIDATE_ONLY_NOT_HUMAN_GOLD`; false-positive PASS evidence, live provenance, runtime PASS and Gate B all remain unproven.

## 9. Canonical-mode and YAML-structure follow-up

A second read-through of the repaired positive candidate found that `independent_discovery` was not a canonical Teaching Demo instruction mode at all. The current core defines `INSTRUCTION_MODES = {teacher_explanation, teacher_demonstration, scaffolded_formation, independent_transfer, evaluation}` and `INTERACTIVE_MODES = {scaffolded_formation, independent_transfer, evaluation}`. Therefore a candidate intended to exercise the legal production vocabulary cannot invent `independent_discovery` merely because the phrase is semantically attractive.

Commit `f5c8bf6bddb902c39577b79b811bd49c9f2fa878` moved the formation cycle to canonical `scaffolded_formation` while retaining `independent_transfer` for the post-formation practice. Commit `ffaea5671fae50bc8800534f5961eb9dda1a54c5` then bound both values directly to the core instruction/interactivity registries in the Phase-B harness.

Mandatory byte read-back after those commits caught another concrete defect: one `candidate_design_claims` list item lost its two-space YAML indentation and became a top-level sequence item. Commit `5779557cf7b72563096c8525aabf2ce096957103` repaired the exact bytes. This is precisely why source-closeout cannot stop at a successful GitHub write.

Current source conclusion remains bounded: the positive candidate now has exact in-response formation, canonical scaffolded-formation / independent-transfer modes, typed event/timing bindings and an independently rejectable HUMAN-review contract. It is still not HUMAN Gold, no live trusted semantic run has occurred, and no exact private-checkout command has been executed.

## 10. External HUMAN review packet readiness

With the positive candidate source-bound, one independent critical-path task still available to the implementer was to remove ambiguity from the external HUMAN handoff without fabricating a review. `POSITIVE_SEMANTIC_GOLD_HUMAN_REVIEW_PACKET.yaml` now freezes only review inputs: current candidate path/blob `54e077a85e9c1e3adbc8da49f1edc1cd69ea5ae0`, semantic-input digest `b68a06a2...`, ten explicit review checks and a `PASS|REJECT` decision domain. Its authority is `REVIEW_INPUT_ONLY_NO_DECISION`; Gate-B/accepted/CALIBRATED/HUMAN-Gold claims are all false.

The Phase-B harness source-binds that packet to the exact candidate Git blob and recomputed canonical semantic digest, rejects authored HUMAN/judge/controller result fields, exact-binds the check set and output schema, and requires external reviewer identity plus reviewer attestation in the future review result. This closes a practical ambiguity: a role string alone is not enough for later independence audit.

This packet is not a review receipt. No reviewer identity, decision, findings, notes or timestamp has been authored by the implementer, and no HUMAN review has occurred. A future HUMAN result must bind the same candidate blob/digest and may legitimately be either PASS or REJECT; only PASS can promote the candidate, while REJECT must keep Gate B blocked.

Packet source sequence: create `be1b0a5e0a2bdfedf2fec483bfbd877dc22931ac`; initial harness binding `876b85c9ec5c0cedc7bc604587f162749c3573c7`; reviewer identity/attestation contract `2f26ab6550cacd8dbcef4d39dcfbb203595dabfc`; final harness binding `a3cec1402a72e84f0981fec1a25160c24704a3f1`.

No live semantic controller/judge run and no exact private-checkout shell execution occurred. Therefore runtime PASS, false-positive PASS evidence, HUMAN Gold and Gate B remain unproven.


## 11. Rebound HUMAN review input close-out

Mandatory read-back after the original HUMAN review packet was prepared found a real stale-binding problem: the positive candidate later changed to canonical event-level release claims/cycle ids, so its Git blob and semantic digest no longer matched the old packet. Treating the old packet as current would have created a misleading second review-input route.

The current route is now singular. `POSITIVE_SEMANTIC_GOLD_HUMAN_REVIEW_INPUT.yaml` binds candidate blob `8a2f74a89ae9c1ace29fd6f5b55227f0b6168653` and semantic digest `0973826ca396cbca1abb4018f91b47a198ecba2251bd3cd5ece7bda70258af0b`. The canonical Phase-B harness switched to this input in `187feba220902f083ca02210cf8b3af9c764cf02`, GOLD_CORPUS registered the rebound input in `061aa246c2a02932df86dcb921eeac69721e36a7`, and the external result contract now requires reviewer reference plus independence attestation, exact candidate binding, PASS/REJECT, per-check findings and notes. The final harness binding for that contract is `c668395ec3a039c534e9ba64125b36ed64ee5a02`.

The superseded `POSITIVE_SEMANTIC_GOLD_HUMAN_REVIEW_PACKET.yaml` was removed from the current tree at `12a49762e09892d461a14f6739283bb5155faead`. This is current-route cleanup, not history deletion: Git history remains audit evidence. No HUMAN decision was authored, no live trusted semantic-controller/judge execution occurred, and no exact private-checkout shell command was executed. Therefore HUMAN Gold, false-positive PASS evidence, runtime PASS and Gate B remain unproven.


## 12. External HUMAN positive Gold PASS ingestion

The previously missing HUMAN-reviewed positive semantic Gold has now been supplied externally by the independent total-planner reviewer. The reviewer checked the exact current candidate bytes bound by the rebound review input: candidate Git blob `8a2f74a89ae9c1ace29fd6f5b55227f0b6168653`, semantic digest `0973826ca396cbca1abb4018f91b47a198ecba2251bd3cd5ece7bda70258af0b`. HR-POS-01 through HR-POS-10 were all reported PASS, with the explicit instruction to stop modifying this positive example and continue Phase B.

The user supplied the external review screenshot to the implementer; its SHA-256 is `961821d1afcaee8960beb12916f90d495aaf81a934d353ab7aad8d79b2857d52`. The implementer did not originate the decision. The external decision was transcribed into `POSITIVE_SEMANTIC_GOLD_HUMAN_REVIEW_RESULT.yaml` at `c9f67035fca4f2f29ed3d5cb13ad673436514323`; the result's Git blob is `9d683ebdb79e2f3b5344a8f37622f8b93930e576`. The Phase-B harness gained explicit result validation at `3bc96c1e336318aa2046904d07dac51e8f018a5a`, GOLD_CORPUS promoted the HUMAN lane at `3dfe08ba980c057593bbc1634efc29cec1c5bf53`, and `f60051d1151d9f1c93d7124c3ca92e23bfd4d601` bound the result blob/candidate/digest into corpus selftest.

This supersedes the earlier review sections that listed HUMAN-reviewed positive Gold as missing. It does **not** supersede the remaining external/runtime blockers: no live trusted semantic-controller/judge execution has occurred for M01-M04/M21 or the positive Gold; no production controller receipt exists; no exact private-checkout shell suite has executed. Gate B, CALIBRATED, accepted mode, fresh topics and formal PDF/Artifact/Engine therefore remain blocked.


## 13. Trusted semantic execution input freeze

After the external HUMAN positive Gold PASS, one remaining implementer-side task could still be completed without fabricating runtime evidence: freeze a single exact handoff for the external trusted semantic controller. `TRUSTED_SEMANTIC_EXECUTION_INPUT.yaml` was created at `695081da49977577f16863bf69b921f907352b92`, Git blob `a9fa3016db10af63fead6a6e6b30b1479c477aa2`.

The handoff exact-binds the frozen negative calibration packet blob `995507dc...` and its M01/M02/M03/M04/M21 semantic digests, plus the HUMAN-reviewed POS-GOLD-01 candidate blob `8a2f74...`, positive digest `0973826...`, external HUMAN result blob `9d683e...` and screenshot-evidence hash. It contains expected outcomes only: five REJECTs and one PASS.

The repository manifest deliberately does not define controller identity/source, runtime identity, judge runner identities, fresh run/nonce values, producer/session identities, output path/hash expectations or trusted signing authority. Those must come from the external trusted invocation as required by ADR-017. The Phase-B harness source-binds this contract in `aeaa71989bea4e4113fa80d3d17e3fe3670627a8`; GOLD_CORPUS registers it in `6e3f1976300aab33e87d67658bf893f0b49865d1`; corpus selftest binds its blob in `3e576a808686017bb1d9023b9e993af7f3176d02`.

This closes the repository-side input ambiguity for live semantic calibration. It does not create controller authority and no external run has occurred. Live provenance-bound judge outputs/receipts, exact-checkout runtime, reports and Independent Gate B remain outstanding.

## 14. Live semantic result consumer / Mandatory Post-Write rereview

在 `TRUSTED_SEMANTIC_EXECUTION_INPUT.yaml` 已冻结后继续执行 Blocked-Path 检查，发现一个真正的 legal-path completeness 缺口：仓库只有外部 execution input，却没有 canonical result consumer。若外部 runtime 当时返回 outputs/receipts，只能依赖会话人工解释，无法由 current repository route 对 trusted invocation、judge outputs 与 producer provenance做 deterministic ingestion。这意味着“repository-side critical path 已关闭”的旧结论过早。

`dfb94fc21de401063cdaf909950c3d6c37fadb88` 首次加入 `check_teaching_demo_phase_b_eval.py --verify-live-result`；`92a2c2f823a7d39c875a6808d0749aa31bb9d3c5` 将其接入 canonical `run_acceptance.py --scope phase-b --phase-b-live-result`。随后没有把首次 write 当完成，而是继续 zero-trust read-back。

rereview连续发现并关闭三类实际缺陷：第一，expected output path/SHA 不能从 repository result/current file反推，否则违反 ADR-017“expected values from trusted invocation”；已改成每 case trusted context exact-bind semantic digest + canonical expected outputs，再把这些 external expectations传给 provenance verifier。第二，首版 trusted-context schema 自己要求 `execution_input_git_blob_sha1`，field-set却未允许它，且一版 result/input contract把该字段误放到 result top-level；已在 `0b28aaafead75a4d91172ce7a31d7837cc91ae3b` / `a1505873b8a5f1f021965ea0a382265a2d26bb09` 修复。第三，external run若不 bind under-review verifier bytes，后续证据可能与被替换的 verifier混用；`d49b98a850db539384dd3ce29653a299c6f30372` 起让 execution input exact-bind provenance verifier / Phase-B eval verifier / acceptance router，external trusted context再 bind final execution-input blob。

该轮在加入 trusted verification-time 之前的 fail-closed source head 为 `616dbff0bf3799f1410d3162f98c7afe3ce53c59`，当时 harness Git blob `a1ba4d5fe71df7bb16a3152fe041c2110aa6f5e6`、execution-input blob `8148c72d7595d38d6eae0c9ce94bda94c420b798`、GOLD_CORPUS rebind head `d0dd5b2e64e4bb97793c2fae6cfa139a7faa742a`。这些值已由下节 durable receipt verification-time repair supersede；current 值以 §15 / STATUS / GOLD_CORPUS 为准。live result仍固定为 `TRUSTED_SEMANTIC_EXECUTION_RESULT.yaml`，judge outputs固定为 `runtime-semantic/{case_id}/{judge_id}.yaml`；result复制 external trusted context但不得包含 production MAC secret，Gate B / accepted-mode / calibrated字段必须保持 false/blocked。

本轮**没有** external trusted semantic-controller/judge run，也没有 exact private-checkout shell。故当前结论仅为 `LIVE_RESULT_CONSUMER_SOURCE_READY / RUNTIME_NOT_EXECUTED`。不得把 source verifier read-back写成 M01-M04/M21 kill PASS、POS-GOLD semantic PASS、runtime PASS、mutation score或 Gate B。


## 15. Durable receipt verification-time binding

A further zero-trust rereview of the now-canonical live consumer found one durable-evidence defect. Controller receipts intentionally have a short validity window, but the live verifier previously omitted the provenance verifier's `now` argument. That made verification depend on the machine's current wall clock: a receipt could pass during the trusted run and then become impossible to deterministically re-verify minutes later solely because time advanced.

The repair does not weaken freshness. The external trusted context must now provide `trusted_now` alongside the execution-input blob, case digests, fresh run/nonce, controller/runtime/runner identities and expected output bindings. The result must copy the same non-secret context, and `verify_live_semantic_execution_result` passes `trusted_now` to `verify_controller_receipt(..., now=...)`. Repository-authored result data still cannot choose or infer trusted time.

Verifier repair commit: `7a2e20b29d8f28a37fd46ba5889ce9a53dc34b7a`, verifier blob `59084ad79f73049cb8d5754903439eef15603bb9`. Execution-input contract repair: `e423ddd9d00964fef83205906c3a8c581914cb28`, current input blob `5aa7aa2bd5ce7fc200f3dc0cebb1d82beba19787`. GOLD_CORPUS rebind: `a36290c6e71df1f0ff90fe50cd6137478fc15168`.

This closes deterministic re-verification of future short-lived receipts at source level. It still creates no live semantic execution evidence: no trusted context/MAC was available in this session, no judge outputs or controller receipts were materialized, and Gate B remains blocked.


## 16. Runtime-backed targeted repair close-out

Three real exact-checkout diagnostic runs were executed and all retained their FAIL result. They exposed concrete defects rather than speculative hardening targets: missing tempfile import, missing source-lock input in the Phase-B mutant fixture, YAML source_commit typing in the artifact-plan selftest, a stale planner provenance token check, a missing module-registry reference in the scoped rule, and stale trusted verifier/input bindings. Each was repaired only after the corresponding runtime failure existed.

The temporary diagnostic runner was removed after the project-state gate showed that this runner class is not an admissible normal dependency. Therefore the runs are valid failure/repair evidence but have no final Gate-B runtime-PASS authority.

Current exact source bindings are Phase-B verifier blob `1db2615d50421b2a2dcba89cdc82b20c3bba76bf`, acceptance router blob `0ffd2063e954c3b8b83648d9fe5b00305dfb0dcd`, trusted execution input blob `496d854eaf0a88234972111a9050ecdc6ec0f679`. GOLD_CORPUS is rebound to the current execution input.

No further open-ended source review is authorized. The next valid evidence is a policy-admissible post-repair shell rerun plus the independent trusted semantic-controller/judge execution. Until those real executions exist, Gate B remains blocked.
