# Declarative figure components

这里存放教师试讲 PDF 的**声明式图形资产**。目标是让课题差异停留在数据/组件层，不进入 Python 执行逻辑。

## Contract

- `registry.yaml` 只负责 `marker -> .tex asset` 映射。
- 每个 `.tex` 资产必须完整产生一个 `figurepanel`，并依赖共享 TikZ/CircuiTikZ/PGFPlots 等基础环境。
- publisher 只消费 `[[FIGURE:<marker>]]`；`tools/physics_figures.py` 只负责通用加载、路径安全、marker 校验和 Hard Fail。
- **新增或修复某课题图形时，不得修改 publisher/checker/renderer，也不得在 Python 中增加 `if title == ...`、`if marker == ...` 的课题分支。**
- 新图形的正常路径是：新增 `.tex` 组件 -> 在 `registry.yaml` 注册 marker -> 运行通用 figure toolchain -> 编译受影响 regression/current-run -> 约200dpi 实际逐页查看。
- 图形内容可以具体，因为它是组件资产；修复规则必须通用，例如统一 label clearance、统一几何语义、统一源/目标坐标约束，而不是只把某一张图“挪到看起来没重叠”。

## QA

```bash
python tools/check_figure_toolchain.py
```

该命令必须自动发现并编译全部已注册组件。编译成功只表示可渲染；涉及视觉改动后仍必须把实际 PDF 渲染到约200dpi并逐页查看。
