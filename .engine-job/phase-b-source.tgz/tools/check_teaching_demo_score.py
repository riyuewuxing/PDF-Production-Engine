#!/usr/bin/env python3
"""Formal score checker for the independent FINAL_CLOSURE_QUALIFICATION lane."""
from __future__ import annotations
import argparse, hashlib, tempfile
from pathlib import Path
import yaml
ROOT=Path(__file__).resolve().parents[1]
STAGES=["JOB_INITIALIZED","SOURCE_IDENTITY_LOCKED","SOURCE_PIXELS_REVIEW_PASS","TEACHING_BOUNDARY_REVIEW_PASS","POINT_CHAIN_REVIEW_PASS","BOARD_PLAN_REVIEW_PASS","EXAM_SKELETON_REVIEW_PASS","TRIAL_SCRIPT_REVIEW_PASS","CONTENT_PACKAGE_REVIEW_PASS","FIGURE_BLOCKS_REVIEW_PASS","SOURCE_PAGES_BLOCK_REVIEW_PASS","COMPOSITION_MACHINE_PASS","FINAL_PDF_MACHINE_PASS","FINAL_PDF_REVIEW_PASS","PUBLISHED"]
def digest(p):
 h=hashlib.sha256()
 with p.open("rb") as f:
  for c in iter(lambda:f.read(1<<20),b""): h.update(c)
 return h.hexdigest()
def validate(card,root=ROOT):
 e=[]
 if card.get("lane")!="FINAL_CLOSURE_QUALIFICATION": e.append("scorecard must use closure lane")
 if card.get("reviewer")!="ChatGPT" or card.get("reviewer_role")!="HUMAN": e.append("scorecard reviewer must be ChatGPT/HUMAN")
 if card.get("quality_pass") is not True or card.get("efficiency_pass") is not True: e.append("closure requires quality_pass && efficiency_pass")
 if (card.get("total_score") or 0)<90: e.append("quality score must be >=90")
 fps=card.get("final_pdfs") or []
 if len(fps)!=2: e.append("scorecard must bind exactly two final PDFs")
 for item in fps:
  p=root/str(item.get("path") or "")
  if not p.is_file(): e.append(f"final PDF missing: {item.get('path')}")
  elif item.get("sha256")!=digest(p): e.append(f"final PDF hash mismatch: {item.get('path')}")
 snap=card.get("delivery_job_snapshot") or {}
 if snap.get("stage_count")!=15: e.append("delivery snapshot must be 15-stage normal delivery")
 sp=root/str(snap.get("path") or "")
 if not sp.is_file(): e.append("delivery_job_snapshot missing")
 else:
  job=yaml.safe_load(sp.read_text(encoding="utf-8")) or {}
  if job.get("stage_sequence")!=STAGES: e.append("delivery snapshot does not bind exact 15-stage sequence")
 eff=card.get("efficiency_record") or {}; ep=root/str(eff.get("path") or "")
 if not ep.is_file(): e.append("efficiency record missing")
 else:
  record=yaml.safe_load(ep.read_text(encoding="utf-8")) or {}
  if record.get("status") not in {"BASELINE_RECORDED","EARLY_STOPPED","STOPPED_AWAITING_USER_REVIEW"}: e.append("efficiency record status not closure-eligible")
 return e
def selftest():
 with tempfile.TemporaryDirectory() as d:
  root=Path(d); (root/"a.pdf").write_bytes(b"%PDF-test-a"); (root/"b.pdf").write_bytes(b"%PDF-test-b"); (root/"job.yaml").write_text(yaml.safe_dump({"stage_sequence":STAGES}),encoding="utf-8"); (root/"eff.yaml").write_text(yaml.safe_dump({"status":"EARLY_STOPPED"}),encoding="utf-8")
  good={"lane":"FINAL_CLOSURE_QUALIFICATION","reviewer":"ChatGPT","reviewer_role":"HUMAN","quality_pass":True,"efficiency_pass":True,"total_score":90,"final_pdfs":[{"path":"a.pdf","sha256":digest(root/"a.pdf")},{"path":"b.pdf","sha256":digest(root/"b.pdf")}],"delivery_job_snapshot":{"path":"job.yaml","stage_count":15},"efficiency_record":{"path":"eff.yaml"}}
  if validate(good,root): print("FAIL: score selftest good fixture rejected"); return 1
  bad=dict(good); bad["lane"]="NORMAL_DELIVERY"; (bad_path:=root/"bad.yaml").write_text(yaml.safe_dump(bad),encoding="utf-8")
  if not validate(bad,root): print("FAIL: score selftest bad fixture accepted"); return 1
 print("PASS: teaching-demo score checker selftest"); return 0
def main():
 ap=argparse.ArgumentParser(); ap.add_argument("--scorecard",type=Path); ap.add_argument("--root",type=Path,default=ROOT); ap.add_argument("--selftest",action="store_true"); a=ap.parse_args()
 if a.selftest:return selftest()
 if not a.scorecard: ap.error("--scorecard or --selftest is required")
 e=validate(yaml.safe_load(a.scorecard.read_text(encoding="utf-8")) or {},a.root.resolve())
 if e: print("FAIL: closure scorecard"); [print("- "+x) for x in e]; return 1
 print("PASS: closure scorecard (quality + efficiency)"); return 0
if __name__=="__main__": raise SystemExit(main())
