#!/usr/bin/env python3
"""Deterministic validator for teacher resume/application material assets.

No LLM/API. Validates identity/source relationships and anti-fabrication rules.
"""
from __future__ import annotations

from pathlib import Path
import sys
import yaml

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "content/job-search/teacher/resume-materials"


def load_yaml(path: Path):
    with path.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def require(condition: bool, message: str, errors: list[str]) -> None:
    if not condition:
        errors.append(message)


def main() -> int:
    errors: list[str] = []

    source_registry = load_yaml(BASE / "sources/source-registry.yaml")
    source_ids = set((source_registry or {}).get("sources", {}).keys())
    require(bool(source_ids), "source registry is empty", errors)

    fixtures_dir = BASE / "materials/yunnan/r1/source-fixtures"
    requirement_ids: set[str] = set()
    fixture_modes: set[str] = set()

    for path in sorted(fixtures_dir.glob("*.yaml")):
        data = load_yaml(path) or {}
        sid = data.get("source_id")
        require(sid in source_ids, f"{path.name}: unresolved source_id {sid}", errors)
        fixture_modes.add(str(data.get("recruitment_mode")))
        reqs = data.get("requirements") or []
        require(bool(reqs), f"{path.name}: no requirements", errors)
        for req in reqs:
            rid = req.get("requirement_id")
            require(bool(rid), f"{path.name}: requirement missing id", errors)
            if rid:
                require(rid not in requirement_ids, f"duplicate requirement_id {rid}", errors)
                requirement_ids.add(rid)
            require(req.get("source_id") == sid, f"{rid}: source mismatch", errors)
            require(bool(req.get("source_locator")), f"{rid}: missing source_locator", errors)
            requiredness = req.get("requiredness")
            require(requiredness in {"required", "conditional", "optional", "unknown"}, f"{rid}: bad requiredness", errors)
            if requiredness == "conditional":
                require(bool(req.get("condition")), f"{rid}: conditional requirement missing condition", errors)
            stage = req.get("stage")
            require(stage in {"initial-application", "qualification-review", "interview-entry", "signing", "onboarding", "later-stage", "unknown"}, f"{rid}: invalid stage {stage}", errors)

    # Heterogeneous fixture gate: at least campus, public institution and in-service selection.
    require("campus-recruitment" in fixture_modes, "missing campus recruitment fixture", errors)
    require("public-institution" in fixture_modes, "missing public institution fixture", errors)
    require("public-selection-in-service" in fixture_modes, "missing in-service selection fixture", errors)

    profile = load_yaml(BASE / "materials/yunnan/r1/templates/candidate-master-profile-v1.yaml") or {}
    fact_ids: set[str] = set()
    for fact in profile.get("facts") or []:
        fid = fact.get("candidate_fact_id")
        require(bool(fid), "candidate fact missing ID", errors)
        if fid:
            require(fid not in fact_ids, f"duplicate candidate_fact_id {fid}", errors)
            fact_ids.add(fid)
        # Public template must stay placeholder/unknown rather than fake completed facts.
        require(fact.get("value_status") in {"unknown", "not-applicable", "withheld"}, f"{fid}: public template contains completed fact", errors)
        if fact.get("sensitivity") == "sensitive":
            require("internal-only" in (fact.get("allowed_outputs") or []), f"{fid}: sensitive fact not limited", errors)

    evidence = load_yaml(BASE / "materials/yunnan/r1/templates/evidence-bank-template-v1.yaml") or {}
    evidence_ids: set[str] = set()
    for asset in evidence.get("assets") or []:
        eid = asset.get("evidence_asset_id")
        require(bool(eid), "evidence asset missing ID", errors)
        if eid:
            require(eid not in evidence_ids, f"duplicate evidence_asset_id {eid}", errors)
            evidence_ids.add(eid)
        for fid in asset.get("candidate_fact_ids") or []:
            require(fid in fact_ids, f"{eid}: unresolved candidate fact {fid}", errors)
        if asset.get("contains_sensitive_data"):
            require(asset.get("redaction_policy") in {"internal-only", "redact-before-sharing"}, f"{eid}: sensitive asset lacks privacy policy", errors)

    variants = load_yaml(BASE / "materials/yunnan/r1/templates/resume-variant-template-v1.yaml") or {}
    variant_ids: set[str] = set()
    for variant in variants.get("variants") or []:
        vid = variant.get("resume_variant_id")
        require(bool(vid), "resume variant missing ID", errors)
        if vid:
            require(vid not in variant_ids, f"duplicate resume_variant_id {vid}", errors)
            variant_ids.add(vid)
        require(bool(variant.get("section_order")), f"{vid}: no section order", errors)
        for fid in variant.get("included_candidate_fact_ids") or []:
            require(fid in fact_ids, f"{vid}: unresolved candidate fact {fid}", errors)

    contract = load_yaml(BASE / "contracts/teacher-resume-material-pack-v1.yaml") or {}
    require(contract.get("fact_policy", {}).get("invented_metrics_forbidden") is True, "contract must forbid invented metrics", errors)
    require(contract.get("fact_policy", {}).get("claim_strength_increase_forbidden") is True, "contract must forbid claim strengthening", errors)
    require(contract.get("requirement_policy", {}).get("stage_isolation_required") is True, "contract must require stage isolation", errors)

    if errors:
        print("FAIL: teacher resume materials validation")
        for error in errors:
            print(f"- {error}")
        return 1

    print("PASS: teacher resume materials validation")
    print(f"sources={len(source_ids)} requirements={len(requirement_ids)} facts={len(fact_ids)} evidence={len(evidence_ids)} variants={len(variant_ids)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
