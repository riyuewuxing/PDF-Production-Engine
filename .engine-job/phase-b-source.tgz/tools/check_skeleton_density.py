"""Generic CLI gate for the exam-skeleton handwriting-density contract.

The selected shared product contract decides which section is the exam skeleton
and supplies the density profile. This tool never switches on lesson title/case.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import sys
import yaml

import publisher_core as product
from skeleton_density import selftest as density_selftest, to_json, validate

ROOT = Path(__file__).resolve().parents[1]


def _resolve(cfg: dict, base: Path, *, contract_root: Path = ROOT):
    contract = product.load_product_contract(cfg, root=contract_root)
    qa = contract.get('qa') or {}
    section_role = qa.get('skeleton_section_role')
    if not section_role:
        raise SystemExit('product contract qa.skeleton_section_role missing')
    section = product.contract_section(contract, str(section_role))
    source_role = section.get('source_role')
    if not source_role:
        raise SystemExit('skeleton section is not source-backed')
    rel = (cfg.get('source') or {}).get(source_role)
    if not rel:
        raise SystemExit(f'manifest source role missing for skeleton: {source_role}')
    path = base / str(rel)
    if not path.exists():
        raise SystemExit(f'skeleton source missing: {path}')
    profile = qa.get('skeleton_density') or {}
    if not isinstance(profile, dict):
        raise SystemExit('qa.skeleton_density must be a mapping')
    return path, profile


def check_current() -> int:
    cfg_path = ROOT / 'production/current-run.yaml'
    cfg = yaml.safe_load(cfg_path.read_text(encoding='utf-8')) or {}
    base = ROOT / str(cfg.get('workspace') or '')
    path, profile = _resolve(cfg, base)
    metrics, issues = validate(path.read_text(encoding='utf-8'), profile)
    print(to_json(metrics, issues))
    if issues:
        for issue in issues:
            print(f'{issue.code}: {path.name}: {issue.detail}', file=sys.stderr)
        return 1
    print(f'skeleton handwriting-density gate: PASS: {path.relative_to(ROOT)}')
    return 0


def check_case(case_arg: str) -> int:
    manifest = Path(case_arg)
    if not manifest.is_absolute():
        manifest = ROOT / manifest
    if manifest.is_dir():
        manifest = manifest / 'case.yaml'
    cfg = yaml.safe_load(manifest.read_text(encoding='utf-8')) or {}
    path, profile = _resolve(cfg, manifest.parent)
    metrics, issues = validate(path.read_text(encoding='utf-8'), profile)
    print(to_json(metrics, issues))
    if issues:
        for issue in issues:
            print(f'{issue.code}: {path.name}: {issue.detail}', file=sys.stderr)
        return 1
    print(f'skeleton handwriting-density gate: PASS: {manifest.parent.name}')
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--case', help='regression case.yaml or directory')
    parser.add_argument('--selftest', action='store_true')
    args = parser.parse_args()
    density_selftest()
    if args.selftest:
        print('skeleton density selftest: PASS')
        return 0
    return check_case(args.case) if args.case else check_current()


if __name__ == '__main__':
    raise SystemExit(main())
