#!/usr/bin/env python3
"""Build an inspectable PDF for declarative figure components.

This is a consumer-side adapter only: figure semantics live in registry/TeX data,
and the public PDF engine owns the XeLaTeX runtime, PDF preflight and pixel render.
The adapter never branches on lesson title, case id or marker meaning.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import yaml

MARKER_RE = re.compile(r"^[a-z0-9][a-z0-9-]*$")


class FigureReviewError(ValueError):
    pass


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def load_assets(registry: Path) -> list[tuple[str, Path]]:
    data = yaml.safe_load(registry.read_text(encoding="utf-8")) or {}
    if data.get("version") != 1:
        raise FigureReviewError("figure registry must use version: 1")
    raw = data.get("figures")
    if not isinstance(raw, dict) or not raw:
        raise FigureReviewError("figure registry requires non-empty figures mapping")
    base = registry.parent.resolve()
    assets: list[tuple[str, Path]] = []
    used: set[Path] = set()
    for marker, spec in raw.items():
        if not isinstance(marker, str) or not MARKER_RE.fullmatch(marker):
            raise FigureReviewError(f"invalid figure marker: {marker!r}")
        rel = spec.get("tex") if isinstance(spec, dict) else spec
        if not isinstance(rel, str) or not rel.endswith(".tex"):
            raise FigureReviewError(f"{marker}: tex asset must be a .tex path")
        p = Path(rel)
        if p.is_absolute() or ".." in p.parts:
            raise FigureReviewError(f"{marker}: escaped asset path")
        path = (base / p).resolve()
        if path.parent != base or not path.is_file():
            raise FigureReviewError(f"{marker}: asset missing/outside registry root")
        if path in used:
            raise FigureReviewError(f"{marker}: asset path reused")
        used.add(path)
        text = path.read_text(encoding="utf-8")
        if "\\begin{figurepanel}" not in text or "\\end{figurepanel}" not in text:
            raise FigureReviewError(f"{marker}: component must contain exactly one figurepanel contract")
        assets.append((marker, path))
    return assets


def make_document(assets: list[tuple[str, Path]]) -> str:
    pages = []
    for index, (marker, path) in enumerate(assets):
        component = path.read_text(encoding="utf-8").strip()
        prefix = "" if index == 0 else "\\clearpage\n"
        pages.append(prefix + f"\\section*{{Figure marker: {marker}}}\n" + component)
    return r"""\documentclass[UTF8,10pt]{article}
\usepackage{ctex}
\usepackage{geometry,xcolor,tcolorbox}
\usepackage{tikz}
\usepackage{pgfplots}
\usepackage[american]{circuitikz}
\usepackage{tkz-euclide}
\usepackage{tikz-3dplot}
\usetikzlibrary{arrows.meta,positioning,calc,decorations.pathmorphing,patterns}
\tcbuselibrary{skins,breakable}
\pgfplotsset{compat=1.18}
\geometry{a4paper,margin=2cm}
\pagestyle{empty}
\newtcolorbox{figurepanel}[1]{enhanced,colback=white,colframe=black!18,boxrule=.55pt,arc=2mm,left=9pt,right=9pt,top=6pt,bottom=7pt,title=\sffamily\bfseries #1,colbacktitle=black!5,coltitle=black,fonttitle=\small,before skip=7pt,after skip=8pt}
\tikzset{qzvector/.style={-{Latex[length=2.6mm]},line width=.8pt},qzsurface/.style={line width=.75pt},qzobject/.style={draw=black!75,fill=black!5,line width=.75pt},qzlabel/.style={fill=white,fill opacity=.9,text opacity=1,inner sep=1.5pt}}
\begin{document}
""" + "\n".join(pages) + r"""
\end{document}
"""


def build(registry: Path, out_dir: Path) -> Path:
    if not shutil.which("xelatex"):
        raise FigureReviewError("xelatex is required from the resource engine runtime")
    assets = load_assets(registry)
    out_dir.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="qz-figure-review-") as tmp:
        tmpdir = Path(tmp)
        tex = tmpdir / "figure-review.tex"
        tex.write_text(make_document(assets), encoding="utf-8")
        proc = subprocess.run(
            ["xelatex", "-interaction=nonstopmode", "-halt-on-error", tex.name],
            cwd=tmpdir,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
        )
        if proc.returncode:
            raise FigureReviewError("xelatex failed:\n" + (proc.stdout or "")[-6000:])
        built = tmpdir / "figure-review.pdf"
        if not built.is_file() or built.stat().st_size < 1000:
            raise FigureReviewError("figure review PDF missing or suspiciously small")
        target = out_dir / "figure-review.pdf"
        shutil.copy2(built, target)

    evidence = {
        "adapter": "qiuzhidaren-generic-figure-review-v1",
        "status": "MACHINE_BUILD_COMPLETE",
        "review_status": "REVIEW_REQUIRED",
        "markers": [marker for marker, _ in assets],
        "output": {
            "filename": "figure-review.pdf",
            "sha256": _sha256(target),
            "size_bytes": target.stat().st_size,
        },
    }
    evidence_path = out_dir / "figure-adapter-evidence.json"
    evidence_path.write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return evidence_path


def selftest() -> None:
    with tempfile.TemporaryDirectory(prefix="qz-figure-review-selftest-") as tmp:
        root = Path(tmp)
        (root / "shape.tex").write_text(
            "\\begin{figurepanel}{Synthetic}\\centering\\begin{tikzpicture}\\draw (0,0)--(1,0);\\end{tikzpicture}\\end{figurepanel}\n",
            encoding="utf-8",
        )
        registry = root / "registry.yaml"
        registry.write_text(
            "version: 1\nfigures:\n  synthetic-shape:\n    tex: shape.tex\n",
            encoding="utf-8",
        )
        assets = load_assets(registry)
        assert [x[0] for x in assets] == ["synthetic-shape"]
        doc = make_document(assets)
        assert "Figure marker: synthetic-shape" in doc
        assert "Synthetic" in doc
        registry.write_text(
            "version: 1\nfigures:\n  escaped:\n    tex: ../escape.tex\n",
            encoding="utf-8",
        )
        try:
            load_assets(registry)
        except FigureReviewError:
            pass
        else:
            raise AssertionError("escaped figure path must fail")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--registry", type=Path)
    parser.add_argument("--out", type=Path)
    parser.add_argument("--selftest", action="store_true")
    args = parser.parse_args(argv)
    try:
        if args.selftest:
            selftest()
            print("generic figure review adapter selftest: PASS")
            if not args.registry:
                return 0
        if not args.registry or not args.out:
            parser.error("--registry and --out are required unless --selftest is used alone")
        evidence = build(args.registry, args.out)
        print(f"FIGURE_ADAPTER_MACHINE_BUILD_COMPLETE evidence={evidence}")
        print("REVIEW_REQUIRED: PDF engine must preflight/render and ChatGPT must inspect pixels")
        return 0
    except (OSError, FigureReviewError, yaml.YAMLError) as exc:
        print(f"FIGURE_ADAPTER_FAIL: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
