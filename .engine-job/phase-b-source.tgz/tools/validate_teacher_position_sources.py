#!/usr/bin/env python3
"""Deterministic teacher position source-acquisition and finalization-Round1 validator. No network/LLM calls."""
from __future__ import annotations

from pathlib import Path
import sys
import yaml

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "content/job-search/teacher/position-research"

PREFECTURES = {
    "昆明市", "曲靖市", "玉溪市", "保山市", "昭通市", "丽江市", "普洱市", "临沧市",
    "楚雄州", "红河州", "文山州", "西双版纳州", "大理州", "德宏州", "怒江州", "迪庆州",
}


def load_yaml(path: Path):
    with path.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def req(ok: bool, message: str, errors: list[str]) -> None:
    if not ok:
        errors.append(message)


def main() -> int:
    errors: list[str] = []

    registry = load_yaml(BASE / "sources/yunnan-source-registry.yaml") or {}
    sources = registry.get("sources") or {}
    gaps = registry.get("discovery_gaps") or []
    req(bool(sources), "source registry is empty", errors)

    authority_levels = {"A0", "A1", "B", "C", "D"}
    valid_status = {"verified-official", "verified-entry", "candidate", "degraded", "failed", "unknown"}
    covered_geographies: set[str] = set()
    verified_sources = 0
    for sid, src in sources.items():
        req(bool(sid), "empty source_id", errors)
        req(src.get("authority_level") in authority_levels, f"{sid}: invalid authority level", errors)
        req(src.get("verification_status") in valid_status, f"{sid}: invalid verification status", errors)
        req(bool(src.get("entry_url")), f"{sid}: missing entry_url", errors)
        req(bool(src.get("geography")), f"{sid}: missing geography", errors)
        geo = src.get("geography")
        if geo:
            covered_geographies.add(str(geo))
        if src.get("verification_status") in {"verified-official", "verified-entry"}:
            verified_sources += 1
            req(src.get("authority_level") in {"A0", "A1"}, f"{sid}: verified source must be A0/A1", errors)
            req(str(src.get("entry_url", "")).startswith("http"), f"{sid}: verified source URL must be http(s)", errors)

    gap_geographies = {str(g.get("geography")) for g in gaps}
    explicit_coverage = covered_geographies | gap_geographies
    missing_prefectures = PREFECTURES - explicit_coverage
    req(not missing_prefectures, f"prefecture source universe missing: {sorted(missing_prefectures)}", errors)

    fixtures = load_yaml(BASE / "fixtures/acquisition-fixtures-v1.yaml") or {}
    fixture_list = fixtures.get("fixtures") or []
    req(len(fixture_list) >= 5, "need at least five heterogeneous official fixtures", errors)
    fixture_ids: set[str] = set()
    has_list = False
    has_attachment_fixture = False
    has_followup_fixture = False
    for fx in fixture_list:
        fid = fx.get("fixture_id")
        req(bool(fid), "fixture missing id", errors)
        if fid:
            req(fid not in fixture_ids, f"duplicate fixture id {fid}", errors)
            fixture_ids.add(fid)
        sid = fx.get("source_id")
        req(sid in sources, f"{fid}: unresolved source {sid}", errors)
        if sid in sources:
            req(sources[sid].get("authority_level") in {"A0", "A1"}, f"{fid}: fixture source is not official", errors)
        req(fx.get("authority_level") in {"A0", "A1"}, f"{fid}: fixture authority not official", errors)
        req(bool(fx.get("url")), f"{fid}: missing url", errors)
        if fx.get("document_type") == "list-page":
            has_list = True
        expected = fx.get("expected") or {}
        if (expected.get("attachment_count_min") or 0) > 0:
            has_attachment_fixture = True
        if expected.get("same_event_followup_possible") or expected.get("later_notice_expected") or expected.get("followup_channel_same_source"):
            has_followup_fixture = True
    req(has_list, "fixtures need a list-page discovery case", errors)
    req(has_attachment_fixture, "fixtures need attachment cases", errors)
    req(has_followup_fixture, "fixtures need followup/version cases", errors)

    contract = load_yaml(BASE / "contracts/phase9-source-acquisition-v1.yaml") or {}
    hard = contract.get("hard_rules") or {}
    req(hard.get("search_engine_is_supplement_only") is True, "contract must make search supplemental", errors)
    req(hard.get("attachments_are_first_class") is True, "contract must make attachments first-class", errors)
    req(hard.get("acquisition_failure_is_not_empty_result") is True, "contract must expose acquisition failures", errors)
    req(hard.get("source_locator_required_for_claims") is True, "contract must require source locators", errors)
    req(hard.get("no_login_or_captcha_bypass") is True, "contract must forbid access-control bypass", errors)

    benchmark = load_yaml(BASE / "benchmarks/phase9-acquisition-benchmark-v1.yaml") or {}
    metrics = benchmark.get("metrics") or {}
    for key in ["event_yield", "official_source_ratio", "attachment_capture_rate", "followup_link_rate", "silent_failure_rate", "gap_visibility"]:
        req(key in metrics, f"benchmark missing metric {key}", errors)
    req((benchmark.get("success_gate") or {}).get("required"), "benchmark success gate is empty", errors)

    for schema in [
        "source-endpoint-v1.yaml", "acquired-document-v1.yaml", "recruitment-event-v1.yaml", "acquisition-observation-v1.yaml"
    ]:
        path = BASE / "schemas" / schema
        req(path.exists(), f"missing schema {schema}", errors)
        if path.exists():
            data = load_yaml(path) or {}
            req(bool(data.get("required")), f"{schema}: no required fields", errors)
            req(bool(data.get("rules")), f"{schema}: no rules", errors)

    # Teacher finalization Round1: school-universe + campus-recruitment coverage.
    final_contract = load_yaml(BASE / "contracts/teacher-finalization-two-round-v1.yaml") or {}
    final_hard = final_contract.get("hard_rules") or {}
    req(final_contract.get("rounds_total") == 2, "teacher finalization must be exactly two rounds", errors)
    req(final_hard.get("no_round3") is True, "teacher finalization must forbid Round3", errors)
    req(final_hard.get("school_roster_is_coverage_denominator") is True,
        "school roster must be the coverage denominator", errors)
    req(final_hard.get("school_and_campus_recruitment_are_first_class") is True,
        "school/campus recruitment must be first-class", errors)
    req(final_hard.get("B_C_D_are_discovery_only_for_job_assertions") is True,
        "B/C/D must remain discovery-only for job assertions", errors)

    school_schema = load_yaml(BASE / "schemas/school-source-coverage-v1.yaml") or {}
    req(bool(school_schema.get("required")), "school-source coverage schema missing required fields", errors)
    req(bool(school_schema.get("rules")), "school-source coverage schema missing rules", errors)
    required_school_fields = set(school_schema.get("required") or [])
    for key in ["school_id", "canonical_name", "roster_source", "recruitment_surface_status", "campus_surface_status"]:
        req(key in required_school_fields, f"school-source schema missing {key}", errors)

    school_registry = load_yaml(BASE / "sources/school-campus-coverage-registry-v1.yaml") or {}
    req((school_registry.get("coverage_denominator") or {}).get("kind") == "authoritative-school-roster",
        "school/campus registry denominator must be authoritative-school-roster", errors)
    slots = school_registry.get("round2_real_registry_slots") or {}
    for key in ["official_school_rosters", "school_recruitment_surfaces", "governing_authority_fallbacks", "university_career_centers", "campus_job_fairs"]:
        req(key in slots, f"school/campus registry missing Round2 slot {key}", errors)
    explicit_gap_ids = {g.get("gap_id") for g in (school_registry.get("explicit_gaps") or [])}
    for gap_id in ["SCHOOL-ROSTER-YUNNAN", "SCHOOL-OFFICIAL-SURFACES", "CAMPUS-CAREER-CENTERS", "CAMPUS-JOB-FAIRS"]:
        req(gap_id in explicit_gap_ids, f"school/campus registry missing explicit gap {gap_id}", errors)

    discovery_rules = load_yaml(BASE / "sources/source-discovery-rules-v1.yaml") or {}
    req((discovery_rules.get("coverage_model") or {}).get("denominator") == "authoritative-school-roster",
        "discovery rules must use authoritative school roster denominator", errors)
    seed_terms = set((discovery_rules.get("seed_terms") or {}).get("positive") or [])
    for term in ["校园招聘", "校招", "双选会", "宣讲会", "应届毕业生"]:
        req(term in seed_terms, f"campus discovery term missing: {term}", errors)
    order = discovery_rules.get("preferred_discovery_order") or []
    for item in ["authoritative-school-roster", "school-official-recruitment-page", "university-career-center", "university-job-fair"]:
        req(item in order, f"preferred discovery order missing {item}", errors)

    synthetic = load_yaml(BASE / "fixtures/synthetic-campus-recruitment-round1-v1.yaml") or {}
    req(synthetic.get("synthetic") is True, "synthetic campus fixture must be explicitly synthetic", errors)
    req(len(synthetic.get("schools") or []) >= 6, "synthetic campus fixture needs at least six schools", errors)
    documents = synthetic.get("documents") or []
    req(len(documents) >= 8, "synthetic campus fixture needs heterogeneous documents", errors)
    levels = {d.get("authority_level") for d in documents}
    req({"A0", "B", "C"}.issubset(levels), "synthetic fixture must cover A0/B/C authority classes", errors)
    roles = {d.get("document_role") for d in documents}
    req("correction" in roles and "discovery" in roles and "announcement" in roles,
        "synthetic fixture must cover announcement/correction/discovery roles", errors)
    modes = {d.get("recruitment_mode") for d in documents}
    req("campus-recruitment" in modes and "school-direct" in modes,
        "synthetic fixture must cover campus and school-direct modes", errors)
    expected = synthetic.get("expected") or {}
    for key in ["current_physics_actionable", "attachment_blocked_current", "discovery_pending_official_closure", "closed_official_events"]:
        req(key in expected, f"synthetic fixture expected gate missing {key}", errors)

    if errors:
        print("FAIL: teacher position source validation")
        for error in errors:
            print(f"- {error}")
        return 1

    print("PASS: teacher position source validation")
    print(
        f"sources={len(sources)} verified_sources={verified_sources} discovery_gaps={len(gaps)} "
        f"fixtures={len(fixture_list)} prefecture_surface={len(PREFECTURES)} "
        f"synthetic_schools={len(synthetic.get('schools') or [])} synthetic_docs={len(documents)}"
    )
    print("finalization_round1=school-roster+school-surfaces+campus-discovery+synthetic-e2e")
    return 0


if __name__ == "__main__":
    sys.exit(main())
