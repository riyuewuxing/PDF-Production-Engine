"""Compile a fully synthetic product through publisher primitives and attack ADR-015 routes."""
from __future__ import annotations
import base64
from pathlib import Path
import shutil
import subprocess
import tempfile
from pypdf import PdfReader
import build_current_run as builder
import publisher_core as core
import publisher_core_legacy as legacy_core
from latex_inline import selftest as inline_selftest
from physics_figures import selftest as figure_registry_selftest
from physics_notation import lint_text, selftest as notation_selftest

# 32x32 valid RGB white PNG. Keep this static so CI does not need Pillow.
SYNTHETIC_SOURCE_PNG = base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAIAAAD8GO2jAAAAKUlEQVR4nO3NMQEAAAjDMMC/52ECvlRA00nqs3m9AwAAAAAAAAAAgMMWx/EDPS4YA2MAAAAASUVORK5CYII=')


def protected_publisher_capability_selftest() -> None:
    """Prove old publisher routes are absent and canonical import is fail-closed.

    This is deliberately stronger than testing only the CLI.  The canonical
    complete operation is invoked as an imported Python function while the
    accepted-content prebuild is forced to fail.  No product-output cleanup may
    be reached.
    """
    for module, label in ((core, 'publisher_core'), (legacy_core, 'publisher_core_legacy')):
        if hasattr(module, 'main'):
            raise AssertionError(f'{label} regained complete main capability')

    original_gate = builder.validate_teaching_demo_inputs
    original_record = builder.telemetry.record
    original_clean = core.clean_outputs
    touched = {'product_output': False}

    def forbidden_clean_outputs():
        touched['product_output'] = True
        raise AssertionError('canonical builder reached product output while accepted content was locked')

    try:
        builder.validate_teaching_demo_inputs = lambda *_args, **_kwargs: ['SYNTHETIC_ACCEPTED_CONTENT_LOCK']
        builder.telemetry.record = lambda *_args, **_kwargs: None
        core.clean_outputs = forbidden_clean_outputs
        try:
            builder.build_product('synthetic-does-not-need-to-exist.yaml')
        except SystemExit as exc:
            if 'prebuild input gate failed before composition' not in str(exc):
                raise AssertionError(f'canonical builder failed for the wrong reason: {exc}') from exc
        else:
            raise AssertionError('canonical builder import invocation escaped accepted-content lock')
        if touched['product_output']:
            raise AssertionError('product-output side effect occurred before accepted-content gate')
    finally:
        builder.validate_teaching_demo_inputs = original_gate
        builder.telemetry.record = original_record
        core.clean_outputs = original_clean


def synthetic_contract():
    return {
        'version': 1, 'id': 'synthetic-product-v1',
        'documents': {
            'primary-doc': {
                'deliverable_role': 'alpha', 'tex_filename': 'alpha.tex', 'header_kind': '合成训练', 'title_suffix': '合成训练', 'subtitle': '题面 → 参考 → 骨架 → 展开 → 问答',
                'sections': [
                    {'role': 'source', 'heading': '一、合成题面', 'renderer': 'source_pages'},
                    {'role': 'reference', 'heading': '二、合成参考', 'renderer': 'markdown', 'source_role': 'reference_plan', 'include_total_board': True},
                    {'role': 'skeleton', 'heading': '三、合成骨架', 'renderer': 'markdown', 'source_role': 'exam_skeleton', 'include_total_board': True},
                    {'role': 'spoken', 'heading': '四、合成展开', 'renderer': 'markdown', 'source_role': 'trial', 'consume_board_markers': True, 'include_total_board': True},
                    {'role': 'questions', 'heading': '五、合成问答', 'renderer': 'markdown', 'source_role': 'defense'},
                ],
            },
            'secondary-doc': {'deliverable_role': 'beta', 'tex_filename': 'beta.tex', 'header_kind': '合成解析', 'title_suffix': '合成解析', 'subtitle': '证据 → 结构', 'renderer': 'markdown', 'source_role': 'analysis'},
        },
        'render': {'dpi': 200},
        'publication': {'publisher': 'XeLaTeX', 'require_global_typography': True, 'require_symbol_notation_lint': True, 'forbid_case_id_leak': True, 'forbidden_engineering_regexes': [r'\bP\d+\b', r'\bB\d+\b']},
        'source_policy': {'require_source_pages': True, 'require_locked_identity': True, 'require_resilient_transport': True},
        'manifest_constraints': {'allowed': ['board_sections_min', 'figure_count_min'], 'required': ['board_sections_min', 'figure_count_min']},
        'qa': {
            'training_deliverable_role': 'alpha', 'extraction_deliverable_role': 'beta', 'require_training_section_new_page': True,
            'skeleton_section_role': 'skeleton', 'trial_section_role': 'spoken', 'defense_section_role': 'questions', 'homework_solution_section_role': 'reference',
            'exam_skeleton_section_pages_max': 1,
            'skeleton_density': {'max_nonspace_chars': 800, 'min_content_lines': 7, 'max_content_lines': 28, 'max_avg_visible_chars_per_line': 46, 'max_single_line_visible_chars': 96, 'max_full_sentence_ratio': .3, 'min_cue_line_ratio': .6, 'max_long_prose_lines': 2},
            'defense_questions': {'heading_regex': r'^##\s+\d+\.', 'min': 1, 'max': 3},
            'homework_solution': {'required': True, 'token': '解析'},
            'required_training_section_roles': ['source', 'questions'], 'required_extraction_sections': ['证据'],
        },
    }


def main() -> int:
    protected_publisher_capability_selftest()
    inline_selftest(); notation_selftest(); figure_registry_selftest(); core.product_contract_selftest()
    if not shutil.which('xelatex') or not shutil.which('pdftoppm'):
        raise SystemExit('publisher smoke requires xelatex + pdftoppm')
    with tempfile.TemporaryDirectory(prefix='qz-publisher-generic-') as tmp:
        root = Path(tmp); workspace = root/'workspace'; workspace.mkdir(); page = root/'page.png'; page.write_bytes(SYNTHETIC_SOURCE_PNG)
        sources = {
            '01.md': '# 合成教案\n\n## 目标\n- 使用 `$F=ma$` 验证数学模式。\n\n[[FIGURE:synthetic-shape]]\n\n## 作业参考解析\n- 已给出。\n',
            '02.md': '# 合成骨架\n\n## 过程\n- 问题 → 关系 → 小结\n- 式：$F=ma$\n- 检：方向？\n- 作：一题\n',
            '03.md': '# 合成逐字稿\n\n## 讲授\n先提出问题。\n\n[[BOARD:P0]]\n',
            '04.md': '# 合成答辩\n\n## 1. 为什么这样组织？\n因为点链连续。\n',
            '05.md': '# 合成提炼解析\n\n## 证据\n题面 → Point → Edge → 骨架。\n',
        }
        for name,text in sources.items():
            issues=lint_text(text,require_math_mode=True)
            if issues: raise AssertionError(f'synthetic source notation issue {name}: {issues}')
            (workspace/name).write_text(text,encoding='utf-8')
        synthetic_figures={'synthetic-shape':r'''\begin{figurepanel}{Synthetic figure stack}
\centering
\begin{tikzpicture}\begin{axis}[width=4.5cm,height=2.8cm,axis lines=middle,samples=8]\addplot[domain=0:1] {x};\end{axis}\end{tikzpicture}\par
\begin{tikzpicture}\tkzDefPoints{0/0/A,1.2/0/B,.6/.8/C}\tkzDrawPolygon(A,B,C)\end{tikzpicture}\par
\tdplotsetmaincoords{60}{110}\begin{tikzpicture}[tdplot_main_coords]\draw[-latex] (0,0,0)--(.8,0,0);\draw[-latex] (0,0,0)--(0,.8,0);\draw[-latex] (0,0,0)--(0,0,.8);\end{tikzpicture}
\end{figurepanel}
'''}
        core.registered_figure_tex=synthetic_figures.__getitem__
        board={'id':'SYNTH-PUBLISHER','layout':'route-numbered','route':['问题','关系','小结'],'sections':[{'number':1,'title':'问题','lines':['观察与提问']},{'number':2,'title':'关系','lines':[r'$F=ma$']},{'number':3,'title':'小结','lines':['回到核心问题']}],'increments':{'P0':{'label':'2. 关系','text':r'$F=ma$'}}}
        contract=synthetic_contract(); errors=core.validate_product_contract(contract,expected_id='synthetic-product-v1')
        if errors: raise AssertionError('synthetic product contract rejected: '+repr(errors))
        cfg={'case_id':'SYNTH-PUBLISHER','title':'合成发布样例','input':{'book':'合成材料','printed_pages':[1]},'source':{'reference_plan':'01.md','exam_skeleton':'02.md','trial':'03.md','defense':'04.md','analysis':'05.md'},'deliverables':{'alpha':'alpha.pdf','beta':'beta.pdf'},'constraints':{'board_sections_min':3,'figure_count_min':1}}
        binding=core.validate_manifest_binding(cfg,contract)
        if binding: raise AssertionError('synthetic product binding rejected: '+repr(binding))
        training=core.document_tex(cfg,contract,'primary-doc',workspace,board,[page]); analysis=core.document_tex(cfg,contract,'secondary-doc',workspace,board,[page])
        for heading in ['二、合成参考','三、合成骨架','四、合成展开','五、合成问答']:
            if r'\newpage'+'\n'+r'\qzsection{'+heading+'}' not in training: raise AssertionError('contract section did not receive its own page: '+heading)
        out=root/'out'; texdir=root/'tex'; tpdf=out/'alpha.pdf'; apdf=out/'beta.pdf'
        core.compile_tex(training,texdir/'alpha.tex',tpdf); core.compile_tex(analysis,texdir/'beta.tex',apdf)
        if len(PdfReader(str(tpdf)).pages)<5 or len(PdfReader(str(apdf)).pages)<1: raise AssertionError('synthetic product page structure failed')
        render=root/'render'; render.mkdir(); dpi=core.render_dpi(contract)
        proc=subprocess.run(['pdftoppm','-png','-r',str(dpi),str(tpdf),str(render/'training')],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
        if proc.returncode or not list(render.glob('training-*.png')): raise AssertionError('publisher smoke PDF could not be rendered')
    print('generic publisher + protected-capability integration smoke: PASS')
    return 0

if __name__=='__main__': raise SystemExit(main())
