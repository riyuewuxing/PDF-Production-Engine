#!/usr/bin/env python3
from pathlib import Path
import json
import yaml

ROOT = Path(__file__).resolve().parents[1]
SCOPE = ROOT / "production/process-development/teaching-demo-quality-v2"
ATLAS = SCOPE / "textbook-topic-atlas"
GEN = ATLAS / "generated"


def req(cond, msg):
    if not cond:
        raise SystemExit("FAIL: " + msg)

build = json.loads((GEN / "build-report.json").read_text(encoding="utf-8"))
retr = json.loads((GEN / "retrieval-benchmark-report.json").read_text(encoding="utf-8"))
contract = yaml.safe_load((ATLAS / "CONTRACT.yaml").read_text(encoding="utf-8"))
rounds = yaml.safe_load((ATLAS / "FOUR_ROUND_PLAN.yaml").read_text(encoding="utf-8"))

req(build["status"] == "PASS", "raw atlas build did not pass")
req(build["canonical_books_verified"] == 6, "six canonical books not verified")
req(build["pages_indexed"] >= 786, "unexpected page index shrink")
req(build["atoms"] > 0 and build["ttu_candidates"] > 0, "atoms/TTUs missing")
req(build["product_pdf_generated"] is False, "Round 2 must not generate product PDF")
req(build["source_lock_claimed"] is False, "Round 2 must not claim SOURCE LOCK")
req(retr["pass"] is True, "curated retrieval benchmark failed")
req(retr["pass_count"] == retr["query_count"] == 15, "Round 2 requires 15/15 benchmark")
req(retr["pass_rate"] == 1.0, "retrieval pass rate must be 1.0")
req(retr["slot_2_exact_top3_pass"] is True, "Slot 2 exact query must be Top 3")
req(retr["max_equivalent_page_coverage"] <= 2.0, "TTU exceeds two-page project upper bound")
req(retr["frontmatter_ttu_removed"] > 0, "front-matter curation did not run")
req((GEN / "retrieval-ttus.jsonl").exists(), "formal retrieval TTU index missing")
req(not list(GEN.rglob("*.pdf")), "generated Atlas directory must not contain PDFs")
req(contract["page_policy"]["page_count_is_input_boundary"] is False, "page count became topic boundary")
req(contract["retrieval"]["main_ai_must_inspect_source_before_source_lock"] is True, "main-AI source inspection gate missing")
req(rounds["process_evaluation_slot_2_not_consumed_before_round_4_composition_start"] is True, "Slot 2 budget separation missing")

# Verify Slot 2's top retrieval is no longer a detected front-matter page.
slot = next(x for x in retr["rows"] if x["query"] == "分子动理论的基本内容")
req(slot["top3"][0]["book_id"] == "pep-physics-selective-3", "Slot 2 top hit wrong book")
req(slot["top3"][0]["first_physical_page"] > 4, "Slot 2 top hit still points to front matter")

print("PASS: textbook topic atlas round 2")
print(f"books={build['canonical_books_verified']} pages={build['pages_indexed']} atoms={build['atoms']} raw_ttus={retr['raw_ttu_count']} retrieval_ttus={retr['retrieval_ttu_count']} benchmark={retr['pass_count']}/{retr['query_count']} slot2_top_page={slot['top3'][0]['first_physical_page']}")
