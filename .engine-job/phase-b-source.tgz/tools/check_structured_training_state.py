"""Validate teacher structured-interview persistent training state files.

No business question identities are embedded here. State files are discovered from the
structured training/state directory and checked against generic invariants.
"""
from __future__ import annotations
from pathlib import Path
import sys, yaml

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'content/job-search/teacher/interview/structured'
STATE_DIR=BASE/'training/state'
TAXONOMY=BASE/'question-taxonomy.md'
DIMS={'target_hit','structure','actionability','educational_role','communication','expression','risk_compliance'}
TYPES={f'T{i}' for i in range(1,10)}

class StateError(ValueError): pass

def load(path):
    data=yaml.safe_load(path.read_text(encoding='utf-8'))
    if not isinstance(data,dict): raise StateError(f'{path.name}: state must be mapping')
    return data

def nonneg(value,name):
    try: n=int(value)
    except Exception as exc: raise StateError(f'{name}: not integer') from exc
    if n<0: raise StateError(f'{name}: must be >=0')
    return n

def validate(path,state):
    for key in ('state_id','updated_at','sessions','question_history','dimension_trends','type_coverage','failure_mode_counts','hint_dependency','next_drill'):
        if key not in state: raise StateError(f'{path.name}: missing {key}')
    if not isinstance(state.get('user_fact_refs',[]),list): raise StateError(f'{path.name}: user_fact_refs must be list')
    trends=state['dimension_trends'] or {}
    if set(trends)!=DIMS: raise StateError(f'{path.name}: dimension_trends must exactly cover project dimensions')
    for dim,rec in trends.items():
        nonneg(rec.get('attempts'),f'{path.name}/{dim}/attempts')
        if rec.get('direction') not in {'improving','flat','declining','insufficient-data'}:
            raise StateError(f'{path.name}/{dim}: invalid direction')
    coverage=state['type_coverage'] or {}
    if set(coverage)!=TYPES: raise StateError(f'{path.name}: type_coverage must exactly cover T1-T9')
    for typ,rec in coverage.items():
        attempts=nonneg(rec.get('attempts'),f'{path.name}/{typ}/attempts')
        unaided=nonneg(rec.get('unaided_attempts'),f'{path.name}/{typ}/unaided_attempts')
        if unaided>attempts: raise StateError(f'{path.name}/{typ}: unaided_attempts > attempts')
    hints=state['hint_dependency'] or {}
    total=nonneg(hints.get('total_attempts'),f'{path.name}/hints/total')
    buckets=[nonneg(hints.get(k),f'{path.name}/hints/{k}') for k in ('level_0_attempts','level_1_2_attempts','level_3_4_attempts')]
    if sum(buckets)!=total: raise StateError(f'{path.name}: hint buckets must sum to total_attempts')
    history=state['question_history'] or []
    if not isinstance(history,list): raise StateError(f'{path.name}: question_history must be list')
    for i,rec in enumerate(history):
        prefix=f'{path.name}/history[{i}]'
        for key in ('question_id','primary_type','asked_at','mode','hint_level','followup_depth','scores','failure_modes'):
            if key not in rec: raise StateError(f'{prefix}: missing {key}')
        if rec['primary_type'] not in TYPES: raise StateError(f'{prefix}: invalid primary_type')
        if rec['mode'] not in {'mock','drill','review'}: raise StateError(f'{prefix}: invalid mode')
        level=nonneg(rec['hint_level'],f'{prefix}/hint_level')
        if level>4: raise StateError(f'{prefix}: hint_level >4')
        nonneg(rec['followup_depth'],f'{prefix}/followup_depth')
        if not isinstance(rec['scores'],dict): raise StateError(f'{prefix}: scores must be mapping')
    next_drill=state['next_drill'] or {}
    if not str(next_drill.get('reason') or '').strip(): raise StateError(f'{path.name}: next_drill.reason required')
    if next_drill.get('target_primary_type') not in TYPES|{None}: raise StateError(f'{path.name}: next_drill invalid type')
    if next_drill.get('target_dimension') not in DIMS|{None}: raise StateError(f'{path.name}: next_drill invalid dimension')
    if not isinstance(next_drill.get('allow_spaced_retest'),bool): raise StateError(f'{path.name}: allow_spaced_retest must be bool')

def selftest():
    bad={'state_id':'x'}
    try: validate(Path('bad.yaml'),bad)
    except StateError: return
    raise AssertionError('selftest failed: incomplete state accepted')

def main():
    selftest()
    paths=sorted(STATE_DIR.glob('*.yaml')) if STATE_DIR.exists() else []
    if not paths: raise StateError('no structured training state/template found')
    for p in paths: validate(p,load(p))
    print(f'structured-interview training state: PASS files={len(paths)}')
    return 0

if __name__=='__main__':
    try: raise SystemExit(main())
    except StateError as exc:
        print(f'STRUCTURED_STATE_FAIL: {exc}',file=sys.stderr); raise SystemExit(1)
