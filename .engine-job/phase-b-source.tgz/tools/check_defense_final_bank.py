#!/usr/bin/env python3
from __future__ import annotations

import argparse
from collections import Counter
from pathlib import Path
import re

import yaml

REQUIRED = {
    'id', 'status', 'source_identity', 'source_basis', 'defense_type', 'topic_dependency',
    'material_file', 'question', 'examiner_intent', 'evidence_anchor', 'knowledge_cluster',
    'training_tier', 'answer_time_seconds', 'compact_skeleton', 'answer_points', 'followups',
    'red_flags', 'self_score_dimensions', 'volume', 'views'
}
VOLUMES = {
    'teaching-design-upper', 'teaching-implementation-lower',
    'physics-mechanics-thermal', 'physics-em-optics-modern-experiment'
}


def norm(text: str) -> str:
    return re.sub(r'[\W_]+', '', text, flags=re.UNICODE).lower()


def split_skeleton(raw: str) -> list[str]:
    parts = [x.strip() for x in re.split(r'\s*(?:->|→)\s*', raw) if x.strip()]
    if len(parts) < 3:
        parts = [x.strip() for x in re.split(r'[；;，,]', raw) if x.strip()]
    return parts[:5]


def fail(msg: str) -> None:
    raise SystemExit(f'DEFENSE_FINAL_BANK_FAIL: {msg}')


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser()
    p.add_argument('bank', type=Path)
    args = p.parse_args(argv)
    data = yaml.safe_load(args.bank.read_text(encoding='utf-8'))
    if not isinstance(data, dict): fail('bank is not mapping')
    cards = data.get('cards') or []
    if len(cards) != 120: fail(f'expected 120 cards, got {len(cards)}')
    metrics = data.get('metrics') or {}
    if int(metrics.get('effective_training_prompt_count') or 0) != 360:
        fail('effective training prompt count must be 360')
    if int(metrics.get('followup_prompt_count') or 0) != 240:
        fail('followup prompt count must be 240')
    if int(metrics.get('unique_followup_prompt_count') or 0) != 240:
        fail('unique followup prompt count must be 240')

    ids = [c.get('id') for c in cards]
    if len(set(ids)) != 120: fail('duplicate card ids')
    qnorm = [norm(c.get('question') or '') for c in cards]
    dupq = [q for q,n in Counter(qnorm).items() if q and n > 1]
    if dupq: fail(f'duplicate normalized primary questions: {dupq[:3]}')

    dcount = Counter()
    vcount = Counter()
    followup_total = 0
    all_followup_norms: list[str] = []
    teaching_answer_signatures: list[str] = []
    for c in cards:
        missing = sorted(REQUIRED - set(c))
        if missing: fail(f"{c.get('id')}: missing {missing}")
        if c['status'] != 'mother-template': fail(f"{c['id']}: final generic card must remain mother-template")
        if c['source_identity'] != 'derived-defense-question': fail(f"{c['id']}: provenance drift")
        if c['training_tier'] not in {'core','frequent','stretch'}: fail(f"{c['id']}: tier")
        if c['answer_time_seconds'] not in {30,60,90}: fail(f"{c['id']}: time")
        if c['volume'] not in VOLUMES: fail(f"{c['id']}: volume {c['volume']}")
        if set(c['views']) != {'detail','practice','quick-reference'}: fail(f"{c['id']}: views")
        if not 3 <= len(c['answer_points']) <= 5: fail(f"{c['id']}: answer_points")
        if len(c['followups']) != 2: fail(f"{c['id']}: must have exactly 2 followups")
        if not 1 <= len(c['red_flags']) <= 4: fail(f"{c['id']}: red_flags")
        if len(c['self_score_dimensions']) < 3: fail(f"{c['id']}: self score dims")
        if any(norm(f) == norm(c['question']) for f in c['followups']): fail(f"{c['id']}: synonym/equal followup")

        if c['defense_type'] == 'D7':
            if not c.get('subject_fact_source'): fail(f"{c['id']}: D7 missing subject source")
            if c['topic_dependency'] != 'topic-adaptable': fail(f"{c['id']}: D7 topic dependency")
        else:
            if c['topic_dependency'] != 'lesson-bound': fail(f"{c['id']}: teaching card must be lesson-bound")
            if c.get('current_lesson_reference') is not None: fail(f"{c['id']}: mother card must not fabricate current lesson ref")
            if not any(x in c['evidence_anchor'] for x in ['当前课','当前课题','本课','当前试讲','刚才试讲','刚才课堂']):
                fail(f"{c['id']}: teaching evidence anchor lacks current-lesson requirement")
            steps = split_skeleton(c['compact_skeleton'])
            joined_points = norm('\n'.join(c['answer_points']))
            matched = sum(1 for token in steps if norm(token) and norm(token) in joined_points)
            if matched < min(2, len(steps)):
                fail(f"{c['id']}: teaching answer points are not sufficiently card-specific ({matched}/{len(steps)} skeleton tokens)")
            follow_joined = norm('\n'.join(c['followups']))
            follow_matched = sum(1 for token in steps if norm(token) and norm(token) in follow_joined)
            if follow_matched < min(2, len(steps)):
                fail(f"{c['id']}: teaching followups are not sufficiently bound to card skeleton ({follow_matched}/{len(steps)})")
            if steps and norm(steps[0]) not in norm(c['examiner_intent']):
                fail(f"{c['id']}: examiner intent lacks card-specific focus")
            teaching_answer_signatures.append(norm('\n'.join(c['answer_points'])))

        forbidden = ['云南真题','历年真题','必考','每年都考','高频真题']
        text = '\n'.join([c['question'], c['examiner_intent'], *c['answer_points'], *c['followups'], *c['red_flags']])
        if any(x in text for x in forbidden): fail(f"{c['id']}: forbidden provenance/frequency claim")
        dcount[c['defense_type']] += 1
        vcount[c['volume']] += 1
        followup_total += len(c['followups'])
        all_followup_norms.extend(norm(x) for x in c['followups'])

    expected_d = {'D1':10,'D2':10,'D3':12,'D4':12,'D5':10,'D6':10,'D7':48,'D8':8}
    if dict(dcount) != expected_d: fail(f'taxonomy drift {dict(dcount)}')
    if followup_total != 240: fail(f'followup total {followup_total}')
    if len(set(all_followup_norms)) != 240:
        dup = [text for text, count in Counter(all_followup_norms).items() if count > 1]
        fail(f'duplicate followups remain: {len(dup)} duplicate normalized forms')
    if len(set(teaching_answer_signatures)) != 72:
        fail('teaching answer-point sets must be card-specific; duplicate normalized sets detected')

    expected_v = {
        'teaching-design-upper': 32,
        'teaching-implementation-lower': 40,
        'physics-mechanics-thermal': 17,
        'physics-em-optics-modern-experiment': 31,
    }
    if dict(vcount) != expected_v: fail(f'volume count drift {dict(vcount)}')
    print('DEFENSE_FINAL_BANK_PASS cards=120 followups=240 unique_followups=240 effective_prompts=360 source_bound_special=18')
    print(f'taxonomy={dict(dcount)}')
    print(f'volumes={dict(vcount)}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
