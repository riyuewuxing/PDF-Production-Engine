#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
import tempfile
import zipfile
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable
from urllib.parse import unquote, urljoin, urlparse

import httpx
import yaml
from bs4 import BeautifulSoup

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36"
)
ALLOWED_EXTENSIONS = {".pdf", ".xls", ".xlsx", ".doc", ".docx", ".zip"}
OLE_MAGIC = bytes.fromhex("D0CF11E0A1B11AE1")
ZIP_MAGIC_PREFIXES = (b"PK\x03\x04", b"PK\x05\x06", b"PK\x07\x08")
HTML_PREFIXES = (b"<!doctype html", b"<html", b"<?xml")


@dataclass
class AttachmentCandidate:
    article_id: str
    event_id: str
    article_url: str
    attachment_url: str
    anchor_text: str
    source_class: str
    expected_extension: str | None


@dataclass
class DownloadRecord:
    article_id: str
    event_id: str
    article_url: str
    attachment_url: str
    final_url: str | None
    anchor_text: str
    source_class: str
    backend: str | None
    filename: str | None
    expected_extension: str | None
    content_type: str | None
    size_bytes: int
    sha256: str | None
    validation_ok: bool
    validation_kind: str | None
    failure_class: str | None
    failure_detail: str | None
    captured_at: str


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def clean_filename(value: str) -> str:
    value = unquote(value).strip().replace("\x00", "")
    value = re.sub(r"[\\/:*?\"<>|]+", "_", value)
    value = re.sub(r"\s+", " ", value).strip(" .")
    return value[:180] or "attachment.bin"


def infer_extension(url: str, text: str = "") -> str | None:
    for source in (urlparse(url).path, text):
        lower = unquote(source).lower()
        for ext in sorted(ALLOWED_EXTENSIONS, key=len, reverse=True):
            if ext in lower:
                return ext
    match = re.search(r"[?&]e=(\.[a-z0-9]+)", url, flags=re.I)
    if match:
        ext = match.group(1).lower()
        if ext in ALLOWED_EXTENSIONS:
            return ext
    return None


def classify_source(url: str) -> str:
    return "virtual-vsb" if "virtual_attach_file.vsb" in url else "static-file"


def is_attachment_anchor(href: str, text: str) -> bool:
    if not href or href.startswith(("javascript:", "mailto:", "#")):
        return False
    decoded = unquote(href).lower()
    if "virtual_attach_file.vsb" in decoded:
        ext = infer_extension(href, text)
        return ext in ALLOWED_EXTENSIONS or "附件" in text
    return infer_extension(href, text) in ALLOWED_EXTENSIONS


def discover_from_html(article: dict, html: str) -> list[AttachmentCandidate]:
    soup = BeautifulSoup(html, "html.parser")
    seen: set[str] = set()
    out: list[AttachmentCandidate] = []
    for a in soup.find_all("a"):
        href = (a.get("href") or "").strip()
        text = " ".join(a.stripped_strings)
        if not is_attachment_anchor(href, text):
            continue
        absolute = urljoin(article["article_url"], href)
        if absolute in seen:
            continue
        seen.add(absolute)
        out.append(
            AttachmentCandidate(
                article_id=article["article_id"],
                event_id=article["event_id"],
                article_url=article["article_url"],
                attachment_url=absolute,
                anchor_text=text,
                source_class=classify_source(absolute),
                expected_extension=infer_extension(absolute, text),
            )
        )
    return out


def _zip_validation(path: Path, expected_ext: str | None) -> tuple[bool, str]:
    try:
        with zipfile.ZipFile(path) as zf:
            names = set(zf.namelist())
            if "[Content_Types].xml" not in names:
                return True, "zip"
            if expected_ext == ".xlsx" and any(n.startswith("xl/") for n in names):
                return True, "xlsx-ooxml"
            if expected_ext == ".docx" and any(n.startswith("word/") for n in names):
                return True, "docx-ooxml"
            if expected_ext in {".xlsx", ".docx"}:
                return False, "ooxml-kind-mismatch"
            return True, "ooxml"
    except zipfile.BadZipFile:
        return False, "bad-zip"


def validate_binary(path: Path, expected_ext: str | None, content_type: str | None) -> tuple[bool, str]:
    if path.stat().st_size == 0:
        return False, "empty"
    head = path.read_bytes()[:64]
    lower_head = head.lower().lstrip()
    if any(lower_head.startswith(p) for p in HTML_PREFIXES):
        return False, "html-error-page"
    if content_type and "text/html" in content_type.lower():
        return False, "html-content-type"
    if expected_ext == ".pdf":
        return (head.startswith(b"%PDF-"), "pdf" if head.startswith(b"%PDF-") else "pdf-magic-mismatch")
    if expected_ext in {".xls", ".doc"}:
        return (head.startswith(OLE_MAGIC), "ole" if head.startswith(OLE_MAGIC) else "ole-magic-mismatch")
    if expected_ext in {".xlsx", ".docx", ".zip"}:
        if not head.startswith(ZIP_MAGIC_PREFIXES):
            return False, "zip-magic-mismatch"
        return _zip_validation(path, expected_ext)
    if head.startswith(b"%PDF-"):
        return True, "pdf"
    if head.startswith(OLE_MAGIC):
        return True, "ole"
    if head.startswith(ZIP_MAGIC_PREFIXES):
        return _zip_validation(path, expected_ext)
    return False, "unknown-binary-signature"


def filename_from_response(candidate: AttachmentCandidate, response: httpx.Response) -> str:
    cd = response.headers.get("content-disposition", "")
    match = re.search(r"filename\*=UTF-8''([^;]+)", cd, re.I)
    if match:
        return clean_filename(unquote(match.group(1)))
    match = re.search(r'filename="?([^";]+)"?', cd, re.I)
    if match:
        return clean_filename(match.group(1))
    if candidate.anchor_text and candidate.expected_extension:
        text = candidate.anchor_text
        if candidate.expected_extension not in text.lower():
            text += candidate.expected_extension
        return clean_filename(text)
    base = Path(urlparse(str(response.url)).path).name or Path(urlparse(candidate.attachment_url).path).name
    if base:
        return clean_filename(base)
    return clean_filename(candidate.article_id + (candidate.expected_extension or ".bin"))


def _http_headers(article_url: str) -> dict[str, str]:
    return {
        "User-Agent": USER_AGENT,
        "Accept": "*/*",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.6",
        "Referer": article_url,
        "Cache-Control": "no-cache",
    }


def stream_http_download(client: httpx.Client, candidate: AttachmentCandidate, dest_dir: Path) -> DownloadRecord:
    tmp_path: Path | None = None
    try:
        with client.stream(
            "GET", candidate.attachment_url, headers=_http_headers(candidate.article_url), follow_redirects=True
        ) as resp:
            resp.raise_for_status()
            filename = filename_from_response(candidate, resp)
            tmp_fd, tmp_name = tempfile.mkstemp(prefix=".part-", dir=dest_dir)
            os.close(tmp_fd)
            tmp_path = Path(tmp_name)
            hasher = hashlib.sha256()
            size = 0
            with tmp_path.open("wb") as f:
                for chunk in resp.iter_bytes(1024 * 256):
                    if not chunk:
                        continue
                    f.write(chunk)
                    hasher.update(chunk)
                    size += len(chunk)
            ok, kind = validate_binary(tmp_path, candidate.expected_extension, resp.headers.get("content-type"))
            if not ok:
                tmp_path.unlink(missing_ok=True)
                return DownloadRecord(
                    **asdict(candidate), final_url=str(resp.url), backend="httpx", filename=filename,
                    content_type=resp.headers.get("content-type"), size_bytes=size,
                    sha256=hasher.hexdigest() if size else None, validation_ok=False,
                    validation_kind=kind, failure_class="binary-validation-failed",
                    failure_detail=kind, captured_at=utc_now(),
                )
            final_path = dest_dir / filename
            if final_path.exists():
                final_path = dest_dir / f"{Path(filename).stem}-{hasher.hexdigest()[:10]}{Path(filename).suffix}"
            tmp_path.replace(final_path)
            return DownloadRecord(
                **asdict(candidate), final_url=str(resp.url), backend="httpx", filename=final_path.name,
                content_type=resp.headers.get("content-type"), size_bytes=size,
                sha256=hasher.hexdigest(), validation_ok=True, validation_kind=kind,
                failure_class=None, failure_detail=None, captured_at=utc_now(),
            )
    except Exception as exc:
        if tmp_path:
            tmp_path.unlink(missing_ok=True)
        return DownloadRecord(
            **asdict(candidate), final_url=None, backend="httpx", filename=None,
            content_type=None, size_bytes=0, sha256=None, validation_ok=False,
            validation_kind=None, failure_class="http-download-failed",
            failure_detail=f"{type(exc).__name__}: {exc}", captured_at=utc_now(),
        )


def _playwright_available() -> bool:
    try:
        import playwright.sync_api  # noqa: F401
        return True
    except Exception:
        return False


def browser_discover_and_download(article: dict, dest_dir: Path, existing: set[str]) -> tuple[list[AttachmentCandidate], list[DownloadRecord]]:
    from playwright.sync_api import sync_playwright

    discovered: list[AttachmentCandidate] = []
    records: list[DownloadRecord] = []
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        context = browser.new_context(user_agent=USER_AGENT, accept_downloads=True)
        page = context.new_page()
        page.goto(article["article_url"], wait_until="domcontentloaded", timeout=45000)
        anchors = page.locator("a").all()
        for anchor in anchors:
            href = anchor.get_attribute("href") or ""
            text = (anchor.inner_text(timeout=2000) or "").strip()
            if not is_attachment_anchor(href, text):
                continue
            absolute = urljoin(article["article_url"], href)
            if absolute in existing:
                continue
            existing.add(absolute)
            discovered.append(AttachmentCandidate(
                article_id=article["article_id"], event_id=article["event_id"],
                article_url=article["article_url"], attachment_url=absolute,
                anchor_text=text, source_class=classify_source(absolute),
                expected_extension=infer_extension(absolute, text),
            ))

        targets = [AttachmentCandidate(
            article_id=article["article_id"], event_id=article["event_id"], article_url=article["article_url"],
            attachment_url=url, anchor_text="", source_class=classify_source(url), expected_extension=infer_extension(url)
        ) for url in sorted(existing)]
        for candidate in targets:
            try:
                response = context.request.get(candidate.attachment_url, headers=_http_headers(candidate.article_url), timeout=45000)
                if not response.ok:
                    raise RuntimeError(f"HTTP {response.status}")
                body = response.body()
                filename = clean_filename(Path(urlparse(candidate.attachment_url).path).name or candidate.article_id + (candidate.expected_extension or ".bin"))
                if candidate.expected_extension and candidate.expected_extension not in filename.lower():
                    filename += candidate.expected_extension
                tmp = dest_dir / (".pw-" + filename)
                tmp.write_bytes(body)
                ok, kind = validate_binary(tmp, candidate.expected_extension, response.headers.get("content-type"))
                digest = hashlib.sha256(body).hexdigest() if body else None
                if ok:
                    final_path = dest_dir / filename
                    if final_path.exists():
                        final_path = dest_dir / f"{Path(filename).stem}-{digest[:10]}{Path(filename).suffix}"
                    tmp.replace(final_path)
                    records.append(DownloadRecord(
                        **asdict(candidate), final_url=response.url, backend="playwright-request",
                        filename=final_path.name, content_type=response.headers.get("content-type"),
                        size_bytes=len(body), sha256=digest, validation_ok=True, validation_kind=kind,
                        failure_class=None, failure_detail=None, captured_at=utc_now(),
                    ))
                else:
                    tmp.unlink(missing_ok=True)
                    records.append(DownloadRecord(
                        **asdict(candidate), final_url=response.url, backend="playwright-request",
                        filename=filename, content_type=response.headers.get("content-type"), size_bytes=len(body),
                        sha256=digest, validation_ok=False, validation_kind=kind,
                        failure_class="binary-validation-failed", failure_detail=kind, captured_at=utc_now(),
                    ))
            except Exception as exc:
                records.append(DownloadRecord(
                    **asdict(candidate), final_url=None, backend="playwright-request", filename=None,
                    content_type=None, size_bytes=0, sha256=None, validation_ok=False,
                    validation_kind=None, failure_class="browser-download-failed",
                    failure_detail=f"{type(exc).__name__}: {exc}", captured_at=utc_now(),
                ))
        context.close()
        browser.close()
    return discovered, records


def choose_best(records: Iterable[DownloadRecord]) -> list[DownloadRecord]:
    best: dict[str, DownloadRecord] = {}
    for rec in records:
        old = best.get(rec.attachment_url)
        if old is None or (not old.validation_ok and rec.validation_ok):
            best[rec.attachment_url] = rec
    return list(best.values())


def article_fetch(client: httpx.Client, article_url: str) -> str:
    response = client.get(article_url, headers={"User-Agent": USER_AGENT, "Accept": "text/html,*/*"}, follow_redirects=True)
    response.raise_for_status()
    return response.text


def run(manifest_path: Path, out_dir: Path, use_browser_fallback: bool) -> int:
    manifest = yaml.safe_load(manifest_path.read_text(encoding="utf-8"))
    articles = manifest.get("articles") or []
    policy = manifest.get("policy") or {}
    out_dir.mkdir(parents=True, exist_ok=True)
    files_dir = out_dir / "files"
    files_dir.mkdir(exist_ok=True)

    all_candidates: list[AttachmentCandidate] = []
    all_records: list[DownloadRecord] = []
    article_results: list[dict] = []

    limits = httpx.Limits(max_keepalive_connections=10, max_connections=20)
    timeout = httpx.Timeout(30.0, connect=20.0)
    with httpx.Client(limits=limits, timeout=timeout, follow_redirects=True) as client:
        for article in articles:
            discovered: list[AttachmentCandidate] = []
            article_error = None
            try:
                html = article_fetch(client, article["article_url"])
                discovered = discover_from_html(article, html)
            except Exception as exc:
                article_error = f"{type(exc).__name__}: {exc}"

            all_candidates.extend(discovered)
            per_records: list[DownloadRecord] = []
            for candidate in discovered:
                record = stream_http_download(client, candidate, files_dir)
                per_records.append(record)
                all_records.append(record)

            needs_browser = bool(article_error) or any(not r.validation_ok for r in per_records) or len(discovered) < int(article.get("expected_attachment_count", 0))
            browser_note = None
            if use_browser_fallback and needs_browser and _playwright_available():
                try:
                    existing = {c.attachment_url for c in discovered}
                    new_candidates, browser_records = browser_discover_and_download(article, files_dir, existing)
                    all_candidates.extend(new_candidates)
                    all_records.extend(browser_records)
                except Exception as exc:
                    browser_note = f"{type(exc).__name__}: {exc}"
            article_results.append({
                "article_id": article["article_id"], "event_id": article["event_id"],
                "article_url": article["article_url"],
                "expected_attachment_count": int(article.get("expected_attachment_count", 0)),
                "http_discovered": len(discovered), "article_fetch_error": article_error,
                "browser_fallback_error": browser_note,
            })

    final_records = choose_best(all_records)
    valid = [r for r in final_records if r.validation_ok]
    failed = [r for r in final_records if not r.validation_ok]
    source_classes = sorted({r.source_class for r in valid})
    expected_total = int(policy.get("expected_total_attachments", 0))
    classes_required = set(policy.get("source_class_coverage_required") or [])
    discovered_unique = len({c.attachment_url for c in all_candidates})

    result = {
        "version": 1,
        "id": "phase9-attachment-live-regression-result",
        "executed_at": utc_now(),
        "manifest": str(manifest_path),
        "summary": {
            "articles": len(articles), "expected_attachments": expected_total,
            "discovered_unique_attachments": discovered_unique, "binary_validated": len(valid),
            "binary_failed": len(failed), "source_classes_validated": source_classes,
            "strong_pass_13_of_13": len(valid) == expected_total and discovered_unique >= expected_total,
            "minimum_pass": bool(valid) and classes_required.issubset(set(source_classes)),
        },
        "articles": article_results,
        "records": [asdict(r) for r in sorted(final_records, key=lambda x: (x.article_id, x.attachment_url))],
    }
    (out_dir / "attachment-capture-manifest.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result["summary"], ensure_ascii=False, indent=2))
    return 0 if result["summary"]["minimum_pass"] else 2


def self_test() -> int:
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        pdf = root / "a.pdf"; pdf.write_bytes(b"%PDF-1.7\nhello")
        assert validate_binary(pdf, ".pdf", "application/pdf")[0]
        ole = root / "a.xls"; ole.write_bytes(OLE_MAGIC + b"0" * 64)
        assert validate_binary(ole, ".xls", "application/vnd.ms-excel")[0]
        xlsx = root / "a.xlsx"
        with zipfile.ZipFile(xlsx, "w") as z:
            z.writestr("[Content_Types].xml", "<Types/>"); z.writestr("xl/workbook.xml", "<workbook/>")
        ok, kind = validate_binary(xlsx, ".xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        assert ok and kind == "xlsx-ooxml"
        docx = root / "a.docx"
        with zipfile.ZipFile(docx, "w") as z:
            z.writestr("[Content_Types].xml", "<Types/>"); z.writestr("word/document.xml", "<document/>")
        ok, kind = validate_binary(docx, ".docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
        assert ok and kind == "docx-ooxml"
        html = root / "bad.xls"; html.write_bytes(b"<!doctype html><html>error</html>")
        assert not validate_binary(html, ".xls", "text/html")[0]
        article = {"article_id": "A", "event_id": "E", "article_url": "https://example.gov/a.html"}
        sample = '<a href="/files/a.xlsx">附件1</a><a href="/virtual_attach_file.vsb?e=.docx&x=1">附件2</a>'
        found = discover_from_html(article, sample)
        assert len(found) == 2 and {f.source_class for f in found} == {"static-file", "virtual-vsb"}
    print("PASS: attachment fetcher self-test")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path)
    parser.add_argument("--out", type=Path, default=Path("production/phase9-attachments"))
    parser.add_argument("--no-browser-fallback", action="store_true")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        return self_test()
    if not args.manifest:
        parser.error("--manifest is required unless --self-test is used")
    return run(args.manifest, args.out, not args.no_browser_fallback)


if __name__ == "__main__":
    sys.exit(main())
