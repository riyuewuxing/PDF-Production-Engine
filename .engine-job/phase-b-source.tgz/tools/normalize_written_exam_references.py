"""Normalize staged teacher written-exam reference records.

The normalizer standardizes text/question-type/source-usage fields and creates deterministic
exact keys. It never infers an exam family, stage, subject, answer or source identity from style.
Missing provenance remains unresolved so the validator can reject it instead of silently calling
external material user-provided.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import unicodedata

QUESTION_TYPE_ALIASES = {
    "单选": "single-choice",
    "单选题": "single-choice",
    "multiple-choice": "multiple-choice",
    "多选": "multiple-choice",
    "多选题": "multiple-choice",
    "判断": "true-false",
    "判断题": "true-false",
    "填空": "fill-blank",
    "填空题": "fill-blank",
    "简答": "short-answer",
    "简答题": "short-answer",
    "辨析": "discrimination",
    "辨析题": "discrimination",
    "案例分析": "case-analysis",
    "案例分析题": "case-analysis",
    "教育方案设计": "education-design",
    "教育方案设计题": "education-design",
    "应用文": "application-writing",
    "应用文写作": "application-writing",
    "教育写作": "application-writing",
    "倡议书": "application-writing",
    "计算": "calculation",
    "计算题": "calculation",
    "证明": "proof",
    "证明题": "proof",
    "实验": "experiment",
    "实验题": "experiment",
}
SOURCE_USAGE_ALIASES = {
    "official": "official-question",
    "official-question": "official-question",
    "recalled": "public-recalled-question",
    "public-recalled-question": "public-recalled-question",
    "training": "public-training",
    "public-training": "public-training",
    "derived": "derived-practice",
    "derived-practice": "derived-practice",
    "user": "user-provided",
    "user-provided": "user-provided",
}


def normalize_text(value: str) -> str:
    text = unicodedata.normalize("NFKC", value or "")
    text = text.replace("\u3000", " ")
    text = re.sub(r"\s+", " ", text).strip()
    return text


def exact_key(normalized_stem: str) -> str:
    compact = re.sub(r"[\s\W_]+", "", normalized_stem, flags=re.UNICODE).lower()
    return hashlib.sha256(compact.encode("utf-8")).hexdigest()[:16]


def clean_list(value):
    if value is None:
        return []
    if isinstance(value, list):
        return [str(x).strip() for x in value if str(x).strip()]
    if isinstance(value, str):
        parts = re.split(r"[;,；，]\s*", value)
        return [x.strip() for x in parts if x.strip()]
    return [str(value).strip()]


def normalize_record(row: dict, index: int) -> dict:
    out = dict(row)
    stem = normalize_text(str(out.get("stem") or ""))
    if not stem:
        raise ValueError(f"row {index}: stem missing")
    out["stem"] = stem
    out["normalized_stem"] = stem
    out["exact_key"] = exact_key(stem)
    if not out.get("id"):
        out["id"] = f"WE-STAGE-{out['exact_key'].upper()}"
    out.setdefault("status", "partial")
    out.setdefault("profile_family", "")
    out.setdefault("profile_id", None)
    out.setdefault("stage", None)
    out.setdefault("subject", None)
    out.setdefault("paper", None)
    out.setdefault("module", "UNRESOLVED")
    out.setdefault("subtype", None)
    qtype = str(out.get("question_type") or "other-subjective").strip()
    out["question_type"] = QUESTION_TYPE_ALIASES.get(qtype, qtype)
    out.setdefault("options", None)
    out.setdefault("answer", None)
    out["answer_points"] = clean_list(out.get("answer_points"))
    out["rubric"] = clean_list(out.get("rubric"))
    out.setdefault("analysis", None)
    out["reasoning_path"] = clean_list(out.get("reasoning_path"))
    out["knowledge_tags"] = clean_list(out.get("knowledge_tags"))
    out["error_tags"] = clean_list(out.get("error_tags"))
    out.setdefault("difficulty", None)
    out.setdefault("source_id", None)
    usage = str(out.get("source_usage") or "").strip()
    out["source_usage"] = SOURCE_USAGE_ALIASES.get(usage, usage)
    out.setdefault("source_locator", None)
    out.setdefault("source_path", None)
    out.setdefault("risk", "medium")
    out.setdefault("notes", None)
    return out


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()

    rows = []
    for line_no, line in enumerate(args.input.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        value = json.loads(line)
        if not isinstance(value, dict):
            raise ValueError(f"line {line_no}: JSONL row must be object")
        rows.append(normalize_record(value, line_no))

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as fh:
        for row in rows:
            fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
    print(f"normalized={len(rows)} output={args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
