"""Pure verifier for Teaching Demo Phase-B semantic controller provenance.

This module verifies a controller-attested execution receipt. It intentionally
contains no production signing capability and no CLI. The live MAC key must be
owned by the trusted controller runtime and supplied by that runtime only while
verifying exact, independently reviewed repository bytes.

The receipt proves controller/runtime execution facts around the two semantic
judge payloads. It does not replace the semantic evidence checks inside those
payloads and it does not itself activate Gate B or accepted mode.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import hmac
import json
from pathlib import PurePosixPath
import re
from typing import Any

SCHEMA_ID = "teaching-demo-semantic-controller-receipt-v1"
AUTH_ALGORITHM = "HMAC-SHA256"
SCIENCE_JUDGE_ID = "science_evidence"
ENACTMENT_JUDGE_ID = "enactment_student"
REQUIRED_JUDGE_IDS = (SCIENCE_JUDGE_ID, ENACTMENT_JUDGE_ID)
DEFAULT_MAX_LIFETIME_SECONDS = 15 * 60
HEX64 = re.compile(r"^[0-9a-f]{64}$")


def canonical_receipt_bytes(receipt: dict[str, Any]) -> bytes:
    """Return canonical bytes covered by the controller authenticator."""
    payload = dict(receipt)
    payload.pop("authenticator", None)
    return json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    ).encode("utf-8")


def _nonempty(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def _sha256(value: Any) -> bool:
    return isinstance(value, str) and bool(HEX64.fullmatch(value))


def _safe_relative_path(value: Any) -> bool:
    if not _nonempty(value) or "\\" in value:
        return False
    path = PurePosixPath(value)
    return not path.is_absolute() and ".." not in path.parts and "." not in path.parts


def _parse_time(value: Any) -> datetime | None:
    if not _nonempty(value):
        return None
    raw = value[:-1] + "+00:00" if value.endswith("Z") else value
    try:
        parsed = datetime.fromisoformat(raw)
    except ValueError:
        return None
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        return None
    return parsed.astimezone(timezone.utc)


def _expected_now(value: datetime | str | None) -> datetime | None:
    if value is None:
        return datetime.now(timezone.utc)
    if isinstance(value, datetime):
        if value.tzinfo is None or value.utcoffset() is None:
            return None
        return value.astimezone(timezone.utc)
    return _parse_time(value)


def _validate_expected_output(binding: Any, label: str) -> list[str]:
    errors: list[str] = []
    if not isinstance(binding, dict):
        return [f"PHASE_B_PROVENANCE_EXPECTED_OUTPUT_INVALID:{label}"]
    if not _safe_relative_path(binding.get("path")):
        errors.append(f"PHASE_B_PROVENANCE_EXPECTED_OUTPUT_PATH_INVALID:{label}")
    if not _sha256(binding.get("sha256")):
        errors.append(f"PHASE_B_PROVENANCE_EXPECTED_OUTPUT_SHA_INVALID:{label}")
    return errors


def verify_controller_receipt(
    receipt: dict[str, Any],
    *,
    mac_key: bytes,
    expected_key_id: str,
    expected_run_id: str,
    expected_nonce: str,
    expected_case_id: str,
    expected_semantic_input_digest: str,
    expected_controller_id: str,
    expected_controller_source_sha256: str,
    expected_runtime: dict[str, str],
    expected_judge_runners: dict[str, str],
    expected_outputs: dict[str, dict[str, str]],
    now: datetime | str | None = None,
    max_lifetime_seconds: int = DEFAULT_MAX_LIFETIME_SECONDS,
) -> list[str]:
    """Verify one exact semantic-controller execution receipt.

    All expected authority values, including the fresh run/challenge identity,
    are supplied by the trusted invocation rather than learned from the receipt.
    Returning an empty list means only that this provenance envelope matches
    those expected values; it is not Gate-B PASS.
    """
    errors: list[str] = []
    if not isinstance(receipt, dict):
        return ["PHASE_B_PROVENANCE_RECEIPT_NOT_MAPPING"]
    if not isinstance(mac_key, (bytes, bytearray)) or not mac_key:
        return ["PHASE_B_PROVENANCE_TRUSTED_MAC_KEY_MISSING"]
    if not _nonempty(expected_key_id):
        errors.append("PHASE_B_PROVENANCE_EXPECTED_KEY_ID_INVALID")
    if not _nonempty(expected_run_id):
        errors.append("PHASE_B_PROVENANCE_EXPECTED_RUN_ID_INVALID")
    if not _nonempty(expected_nonce):
        errors.append("PHASE_B_PROVENANCE_EXPECTED_NONCE_INVALID")
    if not _nonempty(expected_case_id):
        errors.append("PHASE_B_PROVENANCE_EXPECTED_CASE_ID_INVALID")
    if not _sha256(expected_semantic_input_digest):
        errors.append("PHASE_B_PROVENANCE_EXPECTED_INPUT_DIGEST_INVALID")
    if not _nonempty(expected_controller_id):
        errors.append("PHASE_B_PROVENANCE_EXPECTED_CONTROLLER_ID_INVALID")
    if not _sha256(expected_controller_source_sha256):
        errors.append("PHASE_B_PROVENANCE_EXPECTED_CONTROLLER_SOURCE_INVALID")
    if not isinstance(expected_runtime, dict) or not all(
        _nonempty(expected_runtime.get(k)) for k in ("name", "version")
    ):
        errors.append("PHASE_B_PROVENANCE_EXPECTED_RUNTIME_INVALID")
    if set(expected_judge_runners or {}) != set(REQUIRED_JUDGE_IDS):
        errors.append("PHASE_B_PROVENANCE_EXPECTED_RUNNER_SET_INVALID")
    elif not all(_nonempty(expected_judge_runners.get(k)) for k in REQUIRED_JUDGE_IDS):
        errors.append("PHASE_B_PROVENANCE_EXPECTED_RUNNER_ID_INVALID")
    if set(expected_outputs or {}) != set(REQUIRED_JUDGE_IDS):
        errors.append("PHASE_B_PROVENANCE_EXPECTED_OUTPUT_SET_INVALID")
    else:
        for judge_id in REQUIRED_JUDGE_IDS:
            errors.extend(_validate_expected_output(expected_outputs.get(judge_id), judge_id))
    if not isinstance(max_lifetime_seconds, int) or isinstance(max_lifetime_seconds, bool) or max_lifetime_seconds <= 0:
        errors.append("PHASE_B_PROVENANCE_MAX_LIFETIME_INVALID")
    expected_now = _expected_now(now)
    if expected_now is None:
        errors.append("PHASE_B_PROVENANCE_TRUSTED_NOW_INVALID")
    if errors:
        return errors

    if receipt.get("schema_id") != SCHEMA_ID:
        errors.append("PHASE_B_PROVENANCE_SCHEMA_INVALID")

    controller = receipt.get("controller")
    if not isinstance(controller, dict):
        errors.append("PHASE_B_PROVENANCE_CONTROLLER_INVALID")
        controller = {}
    if controller.get("controller_id") != expected_controller_id:
        errors.append("PHASE_B_PROVENANCE_CONTROLLER_ID_MISMATCH")
    if controller.get("controller_source_sha256") != expected_controller_source_sha256:
        errors.append("PHASE_B_PROVENANCE_CONTROLLER_SOURCE_MISMATCH")
    runtime = controller.get("runtime")
    if not isinstance(runtime, dict):
        errors.append("PHASE_B_PROVENANCE_RUNTIME_INVALID")
        runtime = {}
    if runtime.get("name") != expected_runtime.get("name"):
        errors.append("PHASE_B_PROVENANCE_RUNTIME_NAME_MISMATCH")
    if runtime.get("version") != expected_runtime.get("version"):
        errors.append("PHASE_B_PROVENANCE_RUNTIME_VERSION_MISMATCH")

    run = receipt.get("run")
    if not isinstance(run, dict):
        errors.append("PHASE_B_PROVENANCE_RUN_INVALID")
        run = {}
    if run.get("run_id") != expected_run_id:
        errors.append("PHASE_B_PROVENANCE_RUN_ID_MISMATCH")
    if run.get("nonce") != expected_nonce:
        errors.append("PHASE_B_PROVENANCE_NONCE_MISMATCH")
    if run.get("case_id") != expected_case_id:
        errors.append("PHASE_B_PROVENANCE_CASE_ID_MISMATCH")
    if run.get("semantic_input_digest") != expected_semantic_input_digest:
        errors.append("PHASE_B_PROVENANCE_INPUT_DIGEST_MISMATCH")

    issued = _parse_time(run.get("issued_at"))
    expires = _parse_time(run.get("expires_at"))
    if issued is None:
        errors.append("PHASE_B_PROVENANCE_ISSUED_AT_INVALID")
    if expires is None:
        errors.append("PHASE_B_PROVENANCE_EXPIRES_AT_INVALID")
    if issued is not None and expires is not None:
        lifetime = (expires - issued).total_seconds()
        if lifetime <= 0 or lifetime > max_lifetime_seconds:
            errors.append("PHASE_B_PROVENANCE_LIFETIME_INVALID")
        if issued > expected_now:
            errors.append("PHASE_B_PROVENANCE_NOT_YET_VALID")
        if expires < expected_now:
            errors.append("PHASE_B_PROVENANCE_EXPIRED")

    judge_runs = receipt.get("judge_runs")
    if not isinstance(judge_runs, list):
        errors.append("PHASE_B_PROVENANCE_JUDGE_RUNS_INVALID")
        judge_runs = []
    by_id: dict[str, dict[str, Any]] = {}
    duplicate_ids: set[str] = set()
    for item in judge_runs:
        if not isinstance(item, dict):
            errors.append("PHASE_B_PROVENANCE_JUDGE_RUN_NOT_MAPPING")
            continue
        judge_id = item.get("judge_id")
        if not _nonempty(judge_id):
            errors.append("PHASE_B_PROVENANCE_JUDGE_ID_MISSING")
            continue
        if judge_id in by_id:
            duplicate_ids.add(judge_id)
        else:
            by_id[judge_id] = item
    for judge_id in sorted(duplicate_ids):
        errors.append(f"PHASE_B_PROVENANCE_JUDGE_DUPLICATE:{judge_id}")
    if set(by_id) != set(REQUIRED_JUDGE_IDS):
        errors.append(
            "PHASE_B_PROVENANCE_JUDGE_SET_MISMATCH:"
            f"expected={sorted(REQUIRED_JUDGE_IDS)}:actual={sorted(by_id)}"
        )

    for judge_id in REQUIRED_JUDGE_IDS:
        item = by_id.get(judge_id)
        if not isinstance(item, dict):
            continue
        if item.get("runner_id") != expected_judge_runners[judge_id]:
            errors.append(f"PHASE_B_PROVENANCE_JUDGE_RUNNER_MISMATCH:{judge_id}")
        if not _nonempty(item.get("producer_id")):
            errors.append(f"PHASE_B_PROVENANCE_JUDGE_PRODUCER_MISSING:{judge_id}")
        if not _nonempty(item.get("session_id")):
            errors.append(f"PHASE_B_PROVENANCE_JUDGE_SESSION_MISSING:{judge_id}")
        if item.get("semantic_input_digest") != expected_semantic_input_digest:
            errors.append(f"PHASE_B_PROVENANCE_JUDGE_INPUT_DIGEST_MISMATCH:{judge_id}")
        output = item.get("output")
        if output != expected_outputs[judge_id]:
            errors.append(f"PHASE_B_PROVENANCE_JUDGE_OUTPUT_BINDING_MISMATCH:{judge_id}")
        elif not _safe_relative_path(output.get("path")) or not _sha256(output.get("sha256")):
            errors.append(f"PHASE_B_PROVENANCE_JUDGE_OUTPUT_INVALID:{judge_id}")

    authenticator = receipt.get("authenticator")
    if not isinstance(authenticator, dict):
        errors.append("PHASE_B_PROVENANCE_AUTHENTICATOR_MISSING")
        authenticator = {}
    if authenticator.get("algorithm") != AUTH_ALGORITHM:
        errors.append("PHASE_B_PROVENANCE_AUTH_ALGORITHM_INVALID")
    if authenticator.get("key_id") != expected_key_id:
        errors.append("PHASE_B_PROVENANCE_KEY_ID_MISMATCH")
    declared_mac = authenticator.get("mac_hex")
    if not _sha256(declared_mac):
        errors.append("PHASE_B_PROVENANCE_MAC_INVALID_FORMAT")
    else:
        expected_mac = hmac.new(
            bytes(mac_key),
            canonical_receipt_bytes(receipt),
            hashlib.sha256,
        ).hexdigest()
        if not hmac.compare_digest(declared_mac, expected_mac):
            errors.append("PHASE_B_PROVENANCE_MAC_MISMATCH")

    return errors
