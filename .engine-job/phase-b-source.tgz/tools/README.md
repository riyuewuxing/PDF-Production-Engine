# tools/ — Execution Adapters and Governance Gates

本文件只提供操作入口，不复制 machine contract。Authority：`CURRENT_STATE.yaml`、Module Registry、Artifact Job、Execution Ledger、Repository Provenance Snapshot、当前 Module Contract、`tools/tooling-manifest.yaml`。

## 1. Foundation

默认无产品 PDF gate：

```bash
python tools/run_acceptance.py --scope foundation
```

核心共享工具：

- `provenance_snapshot.py` — 生成/验证 exact-source-commit Repository Snapshot；
- `init_artifact_job.py` — 初始化 Job + ledger；
- `manage_artifact_job.py` — lifecycle/attempt 操作；
- `lock_artifact_input_plan.py` — plan + snapshot live 校验后锁定 inputs；
- `check_artifact_job.py` — **live** Job/current-package fail closed；
- `check_artifact_provenance.py` — **historical** repository provenance 审计；
- `check_execution_ledger.py` — attempt 顺序与派生指标；
- `check_project_state.py` / `check_tooling_routes.py` — authority/routing gate。

## 2. Teaching Demo：从 READY Case 到可复现 Job

### 2.1 无产品 PDF preflight

```bash
python tools/run_acceptance.py --scope preflight --manifest <case-manifest>
```

只执行 foundation + case/readiness + cheap content/font gate；不调用产品 build/check/render。

### 2.2 生成 durable Artifact plan

接手 AI 不再自己猜“哪些文件算输入”。必须指定 exact source commit：

```bash
python tools/plan_teaching_demo_artifact_job.py \
  --manifest <case-manifest> \
  --source-commit <40-hex-commit> \
  --write
```

Planner 自动收集 case manifest、7 个标准 source roles、Golden Path/publisher/governance 依赖和实际使用的 `[[FIGURE:<id>]]` 组件，并生成：

```text
production/provenance/repository-snapshots/<snapshot_identity_sha256>.yaml
production/teaching-demo-artifact-plans/<case_id>/<plan_identity_sha256>.yaml
```

Snapshot 对 source repository bytes 记录 `path + kind + SHA-256 + git_blob_sha1`，另记录 exact `source_commit`。Planner 不生成内容、不接受 block、不启动 PDF build。

### 2.3 初始化并锁定

```bash
python tools/init_artifact_job.py \
  --module-id teacher_teaching_demo \
  --job-id <job-id> \
  --job <job.yaml> \
  --ledger <ledger.yaml>

python tools/lock_artifact_input_plan.py \
  --job <job.yaml> \
  --plan <content-addressed-plan.yaml> \
  --runtime-name <runtime> \
  --runtime-version <version>
```

Locker 会验证 plan identity、snapshot identity、snapshot coverage 与**当前 materialized repository bytes**；plan 自身以 exact `input_plan` binding 保留。`source_snapshot_binding` 作为 mandatory durable audit provenance 写入 Job，但 reusable `input_fingerprint` 只由 execution-relevant dependency bytes + runtime 推导；`input_plan`、source commit、snapshot record hash 都不是 cache key。

底层 `manage_artifact_job.py lock-inputs` 若直接使用，必须显式提供 `--snapshot`。

## 3. Live / Historical / Reuse 三种问题分开

Live execution：

```bash
python tools/check_artifact_job.py --job <job.yaml>
```

当前 package 的 repository bytes 与 snapshot 不同即失败。它回答“现在这包东西能不能执行”。

Historical structure audit：

```bash
python tools/check_artifact_provenance.py --job <job.yaml> --mode structure
```

Git-aware historical audit：

```bash
python tools/check_artifact_provenance.py --job <job.yaml> --mode git-history
```

Historical 模式不拿旧 Job 去对比当前同路径 bytes；`git-history` 从记录的 source commit 解析每个 snapshot path，核验 SHA-256 + Git blob identity。旧 Job 没有 snapshot 时不得事后 backfill。

Reuse 则只看 `input_fingerprint` 与已有 HUMAN-accepted output 条件。无关 Git commit 不应改变 fingerprint；真正 input/module contract/builder/runtime bytes 改变必须改变 fingerprint。

## 4. Attempt / Retry

首次视觉 attempt：

```text
start-attempt a1
→ BUILD_COMPLETED(a1)
→ BUILT
→ MACHINE_VERIFICATION_PASSED(a1)
→ MACHINE_VERIFIED
→ FINAL_RENDER_COMPLETED(a1)
→ HUMAN review
```

HUMAN reject 不回退 lifecycle：

```text
HUMAN_REVIEW_REJECTED(a1)
→ start-attempt a2
→ BUILD_COMPLETED(a2)
→ MACHINE_VERIFICATION_PASSED(a2)
→ activate-attempt a2
→ FINAL_RENDER_COMPLETED(a2)
→ HUMAN_REVIEW_ACCEPTED(a2) | REJECTED(a2)
```

Changed retry 必须使用新 attempt-specific/content-addressed path，不能覆盖旧 attempt binding 后写不同 bytes。

通过后：

```bash
python tools/manage_artifact_job.py human-accept --job <job.yaml> --attempt-id a2
python tools/manage_artifact_job.py publish --job <job.yaml>
```

## 5. Process metrics

```bash
python tools/check_execution_ledger.py --ledger <ledger.yaml> --report
```

`generation_review_cycles / build_count / final_render_count / review_reject_count` 均从 ledger 派生。`build_count` 从 `BUILD_STARTED` 计数，所以失败 build 也算真实成本。

## 6. Engine 是机械执行资源

Public Stateless `PDF-Production-Engine` 是实际 build/render/selftest 等机械执行资源。私库没有 hosted runner 不代表没有执行资源。

标准边界：

```text
qiuzhidaren exact source commit
→ ChatGPT/orchestrator materialize / seal hash-bound Execution Package
→ PDF-Production-Engine
→ machine evidence
→ ChatGPT verify / HUMAN review
→ writeback qiuzhidaren
```

Engine 不获得私库 PAT、不 checkout 私库、不写回私库、不产生 HUMAN `REVIEW_PASS`。Repository source-commit 证明由 orchestrator/Git-aware source materialization 完成；Engine 只处理明确物化给它的 package。

## 7. 正式 Teaching Demo 产品链

只有 READY + preflight 通过 + inputs/provenance 已锁定，且获得产品 PDF 执行授权时，才进入：

```bash
python tools/run_acceptance.py --scope formal --manifest <case-manifest>
```

顺序：`case gate → prebuild → composition → formal check → full render/occupancy evidence → HUMAN page review`。Machine PASS 永远不等于 HUMAN `REVIEW_PASS`。

旧 Teaching Demo 15-stage/score/efficiency checker 为 compatibility-only；历史 mechanical-energy `STOP_LIMIT` 不重跑、不补造 event。Written Exam / Resume DEFERRED；Position Research RETIRED；Recruitment Intelligence 与 PDF Engine EXTERNAL。
