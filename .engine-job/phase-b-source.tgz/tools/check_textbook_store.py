#!/usr/bin/env python3
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "assets/textbooks/physics/pep/MANIFEST.json"
EXPECTED_IDS = {
    "pep-physics-compulsory-1", "pep-physics-compulsory-2", "pep-physics-compulsory-3",
    "pep-physics-selective-1", "pep-physics-selective-2", "pep-physics-selective-3",
}

def git_blob_sha1(path: Path) -> str:
    return subprocess.check_output(["git", "hash-object", str(path)], text=True).strip()

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def main() -> int:
    data = json.loads(MANIFEST.read_text(encoding="utf-8"))
    books = data.get("books") or []
    errors: list[str] = []
    ids = {x.get("id") for x in books if isinstance(x, dict)}
    if ids != EXPECTED_IDS:
        errors.append(f"TEXTBOOK_IDS_DRIFT expected={sorted(EXPECTED_IDS)} actual={sorted(ids)}")
    total = 0
    seen_paths: set[str] = set()
    for item in books:
        raw = item.get("repository_path")
        if not isinstance(raw, str) or not raw or Path(raw).is_absolute() or ".." in Path(raw).parts:
            errors.append(f"TEXTBOOK_PATH_INVALID {raw!r}")
            continue
        if raw in seen_paths:
            errors.append(f"TEXTBOOK_PATH_DUPLICATE {raw}")
            continue
        seen_paths.add(raw)
        path = (ROOT / raw).resolve()
        try:
            path.relative_to(ROOT.resolve())
        except ValueError:
            errors.append(f"TEXTBOOK_PATH_ESCAPES_ROOT {raw}")
            continue
        if not path.is_file():
            errors.append(f"TEXTBOOK_MISSING {raw}")
            continue
        size = path.stat().st_size
        total += size
        if size != item.get("size_bytes"):
            errors.append(f"TEXTBOOK_SIZE_DRIFT {raw}")
        if git_blob_sha1(path) != item.get("git_blob_sha1"):
            errors.append(f"TEXTBOOK_GIT_BLOB_DRIFT {raw}")
        if sha256(path) != item.get("sha256"):
            errors.append(f"TEXTBOOK_SHA256_DRIFT {raw}")
    if total != data.get("total_size_bytes"):
        errors.append(f"TEXTBOOK_TOTAL_SIZE_DRIFT expected={data.get('total_size_bytes')} actual={total}")
    if data.get("formal_build_external_fetch_required") is not False:
        errors.append("TEXTBOOK_STORE_EXTERNAL_FETCH_POLICY_DRIFT")
    if errors:
        print("FAIL: canonical textbook store")
        for error in errors:
            print("- " + error)
        return 1
    print(f"PASS: canonical textbook store books={len(books)} total_size_bytes={total}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
