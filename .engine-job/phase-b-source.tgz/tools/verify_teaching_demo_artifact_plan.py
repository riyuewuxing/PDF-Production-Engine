"""Live consumer verifier for Teaching Demo Artifact input plans.

This module is intentionally non-executable. The generic Artifact live checker invokes
``verify_live_job_input_plan`` only after this file's exact bytes are bound and live-hash
verified.

RRA5 authority rules:
- verifier bootstrap primitives (safe repo path, YAML mapping load, SHA-256, canonical
  identity, binding validation) are self-contained here and do not execute another
  repository-local helper before authority is established;
- canonical plan reconstruction runs in an isolated fresh Python child which explicitly
  executes the exact profile-declared planner file;
- the accepted-content evidence capsule (freeze, independent review, HUMAN receipt) is
  exact-bound and must agree on case/source_commit/current hashes.
"""
from __future__ import annotations

import ast
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import types
from typing import Any

import yaml

HEX64 = re.compile(r"^[0-9a-f]{64}$")
HEX40 = re.compile(r"^[0-9a-f]{40}$")
REBUILD_MARKER = "NO_PRODUCT_PDF_COMPOSITION_PERFORMED"
CALLBACK_NAME = "verify_live_job_input_plan"
RECONSTRUCTION_MODE = "isolated-fresh-python-file-subprocess-v1"
VERIFIER_BOOTSTRAP_MODE = "self-contained-no-repository-imports-v1"


def _load_yaml(path: Path) -> dict[str, Any]:
    value = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    if not isinstance(value, dict):
        raise ValueError(f"{path}: top-level YAML must be a mapping")
    return value


def _safe_repo_path(root: Path, raw: Any, *, must_exist: bool = False) -> Path:
    if not isinstance(raw, str) or not raw:
        raise ValueError("path must be a non-empty repository-relative string")
    rel = Path(raw)
    if rel.is_absolute() or ".." in rel.parts:
        raise ValueError(f"absolute/traversal path forbidden: {raw!r}")
    path = (root / rel).resolve()
    try:
        path.relative_to(root.resolve())
    except ValueError as exc:
        raise ValueError(f"path escapes repository root: {raw!r}") from exc
    if must_exist and not path.exists():
        raise ValueError(f"path does not exist: {raw}")
    return path


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _canonical_sha256(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _is_sha256(value: Any) -> bool:
    return isinstance(value, str) and bool(HEX64.fullmatch(value))


def _binding_key(binding: dict[str, Any]) -> tuple[str, str, str]:
    return (
        str(binding.get("path") or ""),
        str(binding.get("sha256") or ""),
        str(binding.get("kind") or ""),
    )


def _validate_binding(root: Path, binding: Any, label: str, *, require_file: bool = True) -> list[str]:
    errors: list[str] = []
    if not isinstance(binding, dict):
        return [f"{label}: binding must be a mapping"]
    raw = binding.get("path")
    digest = binding.get("sha256")
    kind = binding.get("kind")
    if not isinstance(kind, str) or not kind:
        errors.append(f"{label}: kind is required")
    try:
        path = _safe_repo_path(root, raw)
    except ValueError as exc:
        errors.append(f"{label}: {exc}")
        return errors
    if not _is_sha256(digest):
        errors.append(f"{label}: sha256 must be lowercase 64-char SHA-256")
        return errors
    if require_file:
        if not path.is_file():
            errors.append(f"{label}: bound file missing: {raw}")
        else:
            actual = _sha256_file(path)
            if actual != digest:
                errors.append(f"{label}: hash mismatch for {raw}: declared={digest} actual={actual}")
    return errors


def _binding_set(items: Any) -> set[tuple[str, str, str]]:
    return {_binding_key(item) for item in (items or []) if isinstance(item, dict)}


def _plan_identity_errors(path: Path, plan: dict[str, Any]) -> list[str]:
    declared = plan.get("plan_identity_sha256")
    if not isinstance(declared, str) or not HEX64.fullmatch(declared):
        return ["TEACHING_DEMO_INPUT_PLAN_IDENTITY_INVALID"]
    payload = deepcopy(plan)
    payload.pop("plan_identity_sha256", None)
    actual = _canonical_sha256(payload)
    errors: list[str] = []
    if actual != declared:
        errors.append(f"TEACHING_DEMO_INPUT_PLAN_IDENTITY_MISMATCH:declared={declared}:actual={actual}")
    if HEX64.fullmatch(path.stem) and path.stem != declared:
        errors.append("TEACHING_DEMO_INPUT_PLAN_FILENAME_IDENTITY_MISMATCH")
    return errors


def _contract_profile(root: Path, job: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    raw = job.get("module_contract")
    if not isinstance(raw, str) or not raw:
        raise ValueError("job module_contract missing")
    contract = _load_yaml(_safe_repo_path(root, raw, must_exist=True))
    profile = contract.get("artifact_job_profile")
    if not isinstance(profile, dict):
        raise ValueError("module contract artifact_job_profile missing")
    return contract, profile


def _consumer_contract_errors(root: Path, contract: dict[str, Any], profile: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    policy = profile.get("input_lock_verification")
    if not isinstance(policy, dict):
        return ["TEACHING_DEMO_INPUT_LOCK_POLICY_MISSING"]
    verifier = policy.get("verifier")
    if not isinstance(verifier, dict):
        return ["TEACHING_DEMO_INPUT_LOCK_VERIFIER_POLICY_MISSING"]
    verifier_path = verifier.get("path")
    callback = verifier.get("function")
    binding_kind = verifier.get("binding_kind")
    bootstrap = verifier.get("repository_bootstrap")
    try:
        self_rel = Path(__file__).resolve().relative_to(root.resolve()).as_posix()
    except Exception:
        self_rel = ""
    if verifier_path != self_rel:
        errors.append(f"TEACHING_DEMO_INPUT_LOCK_VERIFIER_SELF_PATH_DRIFT:{verifier_path!r}!={self_rel!r}")
    if callback != CALLBACK_NAME:
        errors.append(f"TEACHING_DEMO_INPUT_LOCK_VERIFIER_CALLBACK_DRIFT:{callback!r}")
    if not isinstance(binding_kind, str) or not binding_kind:
        errors.append("TEACHING_DEMO_INPUT_LOCK_VERIFIER_BINDING_KIND_INVALID")
    if bootstrap != VERIFIER_BOOTSTRAP_MODE:
        errors.append("TEACHING_DEMO_INPUT_LOCK_VERIFIER_BOOTSTRAP_MODE_DRIFT")

    reconstruction = policy.get("canonical_reconstruction_execution")
    if not isinstance(reconstruction, dict):
        errors.append("TEACHING_DEMO_RECONSTRUCTION_EXECUTION_POLICY_MISSING")
    else:
        if reconstruction.get("mode") != RECONSTRUCTION_MODE:
            errors.append("TEACHING_DEMO_RECONSTRUCTION_EXECUTION_MODE_DRIFT")
        if reconstruction.get("planner_path_from_profile") is not True:
            errors.append("TEACHING_DEMO_RECONSTRUCTION_PLANNER_PATH_NOT_PROFILE_BOUND")
        if reconstruction.get("planner_binding_required") is not True:
            errors.append("TEACHING_DEMO_RECONSTRUCTION_PLANNER_BINDING_NOT_REQUIRED")
        if reconstruction.get("current_process_module_alias_is_authority") is not False:
            errors.append("TEACHING_DEMO_CURRENT_PROCESS_MODULE_ALIAS_GRANTED_AUTHORITY")
        if reconstruction.get("isolated_interpreter_required") is not True:
            errors.append("TEACHING_DEMO_RECONSTRUCTION_ISOLATED_INTERPRETER_NOT_REQUIRED")
        if reconstruction.get("canonical_tools_path_inserted_first") is not True:
            errors.append("TEACHING_DEMO_RECONSTRUCTION_CANONICAL_TOOLS_PATH_NOT_FIRST")

    protected = contract.get("protected_operations") or {}
    consume = protected.get("artifact_input_lock_consume") if isinstance(protected, dict) else None
    if not isinstance(consume, dict):
        errors.append("TEACHING_DEMO_INPUT_LOCK_PROTECTED_CONSUMER_MISSING")
    else:
        libraries = consume.get("implementation_libraries")
        if libraries != [verifier_path]:
            errors.append(
                "TEACHING_DEMO_INPUT_LOCK_VERIFIER_PROTECTED_GRAPH_DRIFT:"
                f"policy={verifier_path!r}:libraries={libraries!r}"
            )
        if consume.get("verifier_callback") != callback:
            errors.append("TEACHING_DEMO_INPUT_LOCK_VERIFIER_CALLBACK_GRAPH_DRIFT")
        if consume.get("canonical_entry") != "tools/check_artifact_job.py":
            errors.append("TEACHING_DEMO_INPUT_LOCK_CONSUMER_GATE_DRIFT")
        if consume.get("canonical_plan_reconstruction_required") is not True:
            errors.append("TEACHING_DEMO_INPUT_LOCK_RECONSTRUCTION_POLICY_DISABLED")
    plan_op = protected.get("artifact_plan_write") if isinstance(protected, dict) else None
    planner_raw = profile.get("planner")
    if not isinstance(plan_op, dict) or plan_op.get("canonical_entry") != planner_raw:
        errors.append("TEACHING_DEMO_CANONICAL_PLANNER_PROTECTED_GRAPH_DRIFT")
    if policy.get("direct_generic_lock_without_verified_plan") != "forbidden":
        errors.append("TEACHING_DEMO_DIRECT_GENERIC_LOCK_POLICY_NOT_FORBIDDEN")
    return errors


def _canonical_plan_path(root: Path, profile: dict[str, Any], plan: dict[str, Any]) -> Path | None:
    output_root = profile.get("output_root")
    case_id = plan.get("case_id")
    identity = plan.get("plan_identity_sha256")
    if not isinstance(output_root, str) or not output_root:
        return None
    if not isinstance(case_id, str) or not case_id:
        return None
    if not isinstance(identity, str) or not HEX64.fullmatch(identity):
        return None
    base = (root / output_root).resolve()
    base.relative_to(root.resolve())
    target_dir = (base / case_id).resolve()
    target_dir.relative_to(base)
    return (target_dir / f"{identity}.yaml").resolve()


def _planner_binding_errors(root: Path, profile: dict[str, Any], job_inputs: list[dict[str, Any]]) -> tuple[str | None, list[str]]:
    planner_raw = profile.get("planner")
    if not isinstance(planner_raw, str) or not planner_raw.startswith("tools/"):
        return None, [f"TEACHING_DEMO_CANONICAL_PLANNER_PATH_INVALID:{planner_raw!r}"]
    matches = [
        item for item in job_inputs
        if isinstance(item, dict)
        and item.get("path") == planner_raw
        and item.get("kind") == "input_planner"
    ]
    if len(matches) != 1:
        return planner_raw, [f"TEACHING_DEMO_CANONICAL_PLANNER_BINDING_COUNT:{len(matches)}"]
    return planner_raw, _validate_binding(root, matches[0], "teaching_demo_canonical_planner")


def _acceptance_capsule_errors(
    root: Path,
    profile: dict[str, Any],
    plan: dict[str, Any],
    plan_inputs: list[dict[str, Any]],
) -> list[str]:
    errors: list[str] = []
    policy = profile.get("content_acceptance_capsule")
    if not isinstance(policy, dict) or policy.get("required") is not True:
        return ["TEACHING_DEMO_CONTENT_ACCEPTANCE_CAPSULE_POLICY_MISSING"]
    specs = policy.get("bindings")
    required_keys = {
        "submission_freeze",
        "independent_content_review",
        "human_acceptance_receipt",
    }
    if not isinstance(specs, dict) or set(specs) != required_keys:
        return ["TEACHING_DEMO_CONTENT_ACCEPTANCE_CAPSULE_BINDING_POLICY_DRIFT"]

    gate = plan.get("content_acceptance_gate")
    if not isinstance(gate, dict):
        return ["TEACHING_DEMO_CONTENT_ACCEPTANCE_GATE_MISSING"]
    if "downstream_released" in gate:
        errors.append("TEACHING_DEMO_SELF_DECLARED_DOWNSTREAM_RELEASE_FORBIDDEN")
    if gate.get("case_id") != plan.get("case_id"):
        errors.append("TEACHING_DEMO_CONTENT_ACCEPTANCE_GATE_CASE_DRIFT")
    if gate.get("source_commit") != plan.get("source_commit"):
        errors.append("TEACHING_DEMO_CONTENT_ACCEPTANCE_GATE_SOURCE_COMMIT_DRIFT")
    if gate.get("decision") != "INDEPENDENT_CONTENT_HUMAN_PASS":
        errors.append("TEACHING_DEMO_CONTENT_ACCEPTANCE_GATE_DECISION_DRIFT")
    canonical_contracts = [
        item.get("path") for item in (profile.get("repository_dependencies") or [])
        if isinstance(item, dict) and item.get("kind") == "canonical_content_contract"
    ]
    if len(canonical_contracts) != 1 or gate.get("contract") != canonical_contracts[0]:
        errors.append("TEACHING_DEMO_CONTENT_ACCEPTANCE_CONTRACT_DRIFT")

    capsule = gate.get("evidence_capsule")
    if not isinstance(capsule, dict) or set(capsule) != required_keys:
        return errors + ["TEACHING_DEMO_CONTENT_ACCEPTANCE_EVIDENCE_CAPSULE_DRIFT"]

    resolved: dict[str, dict[str, Any]] = {}
    for key in sorted(required_keys):
        spec = specs.get(key)
        binding = capsule.get(key)
        if not isinstance(spec, dict) or not isinstance(binding, dict):
            errors.append(f"TEACHING_DEMO_CONTENT_ACCEPTANCE_CAPSULE_ITEM_INVALID:{key}")
            continue
        filename, kind = spec.get("filename"), spec.get("kind")
        if not isinstance(filename, str) or not filename or Path(filename).name != filename:
            errors.append(f"TEACHING_DEMO_CONTENT_ACCEPTANCE_CAPSULE_FILENAME_POLICY_INVALID:{key}")
            continue
        if not isinstance(kind, str) or not kind:
            errors.append(f"TEACHING_DEMO_CONTENT_ACCEPTANCE_CAPSULE_KIND_POLICY_INVALID:{key}")
            continue
        if binding.get("kind") != kind or Path(str(binding.get("path") or "")).name != filename:
            errors.append(f"TEACHING_DEMO_CONTENT_ACCEPTANCE_CAPSULE_BINDING_DRIFT:{key}")
            continue
        matches = [item for item in plan_inputs if isinstance(item, dict) and _binding_key(item) == _binding_key(binding)]
        if len(matches) != 1:
            errors.append(f"TEACHING_DEMO_CONTENT_ACCEPTANCE_CAPSULE_INPUT_COUNT:{key}:{len(matches)}")
            continue
        errors.extend(
            f"TEACHING_DEMO_CONTENT_ACCEPTANCE_CAPSULE_LIVE_BINDING:{key}:{item}"
            for item in _validate_binding(root, binding, f"content_acceptance_capsule.{key}")
        )
        resolved[key] = binding

    if errors or set(resolved) != required_keys:
        return errors
    if policy.get("human_receipt_case_id_must_equal_manifest_case_id") is not True:
        errors.append("TEACHING_DEMO_CONTENT_ACCEPTANCE_CASE_POLICY_DISABLED")
    if policy.get("human_receipt_source_commit_must_equal_plan_source_commit") is not True:
        errors.append("TEACHING_DEMO_CONTENT_ACCEPTANCE_SOURCE_COMMIT_POLICY_DISABLED")
    if policy.get("human_receipt_must_bind_current_freeze_and_review") is not True:
        errors.append("TEACHING_DEMO_CONTENT_ACCEPTANCE_RECEIPT_BINDING_POLICY_DISABLED")
    if errors:
        return errors

    try:
        freeze = _load_yaml(_safe_repo_path(root, resolved["submission_freeze"]["path"], must_exist=True))
        human = _load_yaml(_safe_repo_path(root, resolved["human_acceptance_receipt"]["path"], must_exist=True))
    except Exception as exc:
        return [f"TEACHING_DEMO_CONTENT_ACCEPTANCE_CAPSULE_LOAD_FAILED:{exc}"]
    if freeze.get("case_id") != plan.get("case_id") or human.get("case_id") != plan.get("case_id"):
        errors.append("TEACHING_DEMO_CONTENT_ACCEPTANCE_CAPSULE_CASE_DRIFT")
    if freeze.get("source_commit") != plan.get("source_commit") or human.get("source_commit") != plan.get("source_commit"):
        errors.append("TEACHING_DEMO_CONTENT_ACCEPTANCE_CAPSULE_SOURCE_COMMIT_DRIFT")
    expected_human_bindings = {
        "submission_freeze": {
            "path": specs["submission_freeze"]["filename"],
            "sha256": resolved["submission_freeze"]["sha256"],
        },
        "independent_content_review": {
            "path": specs["independent_content_review"]["filename"],
            "sha256": resolved["independent_content_review"]["sha256"],
        },
    }
    if human.get("bindings") != expected_human_bindings:
        errors.append("TEACHING_DEMO_CONTENT_ACCEPTANCE_HUMAN_RECEIPT_BINDINGS_DRIFT")
    return errors


def _rebuild_in_fresh_process(root: Path, planner_raw: str, manifest_raw: str, source_commit: str) -> dict[str, Any]:
    planner = _safe_repo_path(root, planner_raw, must_exist=True)
    tools_dir = (root / "tools").resolve()
    planner.resolve().relative_to(tools_dir)
    runner = (
        "import pathlib,runpy,sys;"
        "root=pathlib.Path(sys.argv[1]).resolve();"
        "planner=pathlib.Path(sys.argv[2]).resolve();"
        "tools=(root/'tools').resolve();planner.relative_to(tools);"
        "sys.path.insert(0,str(tools));"
        "sys.argv=[str(planner),'--manifest',sys.argv[3],'--source-commit',sys.argv[4]];"
        "runpy.run_path(str(planner),run_name='__main__')"
    )
    proc = subprocess.run(
        [sys.executable, "-I", "-c", runner, str(root.resolve()), str(planner), manifest_raw, source_commit],
        cwd=root,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        timeout=180,
        check=False,
    )
    stdout = proc.stdout or ""
    if proc.returncode != 0:
        tail = " | ".join(line.strip() for line in stdout.splitlines()[-10:] if line.strip())
        raise ValueError(f"canonical planner isolated subprocess rejected: exit={proc.returncode}: {tail}")
    lines = stdout.splitlines()
    if not lines or lines[-1].strip() != REBUILD_MARKER:
        raise ValueError("canonical planner subprocess output marker missing")
    payload = "\n".join(lines[:-1]).strip()
    rebuilt = yaml.safe_load(payload) or {}
    if not isinstance(rebuilt, dict):
        raise ValueError("canonical planner subprocess did not emit one YAML mapping")
    return rebuilt


def verify_live_job_input_plan(*, root: Path, job: dict[str, Any], plan_binding: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    errors.extend(_validate_binding(root, plan_binding, "teaching_demo_input_plan"))
    if plan_binding.get("kind") != "input_plan":
        errors.append("TEACHING_DEMO_INPUT_PLAN_BINDING_KIND_INVALID")
    raw = plan_binding.get("path")
    if not isinstance(raw, str) or not raw:
        return errors + ["TEACHING_DEMO_INPUT_PLAN_PATH_MISSING"]

    try:
        path = _safe_repo_path(root, raw, must_exist=True)
        if not path.is_file():
            return errors + ["TEACHING_DEMO_INPUT_PLAN_NOT_FILE"]
        plan = _load_yaml(path)
        contract, profile = _contract_profile(root, job)
    except Exception as exc:
        return errors + [f"TEACHING_DEMO_INPUT_PLAN_LOAD_FAILED:{exc}"]
    if not isinstance(plan, dict):
        return errors + ["TEACHING_DEMO_INPUT_PLAN_TOP_LEVEL_INVALID"]

    errors.extend(_consumer_contract_errors(root, contract, profile))
    errors.extend(_plan_identity_errors(path, plan))
    try:
        expected_path = _canonical_plan_path(root, profile, plan)
    except Exception as exc:
        expected_path = None
        errors.append(f"TEACHING_DEMO_INPUT_PLAN_CANONICAL_PATH_RESOLUTION_FAILED:{exc}")
    if expected_path is None:
        errors.append("TEACHING_DEMO_INPUT_PLAN_CANONICAL_PATH_UNRESOLVED")
    elif path.resolve() != expected_path:
        try:
            actual_rel = path.resolve().relative_to(root.resolve()).as_posix()
            expected_rel = expected_path.relative_to(root.resolve()).as_posix()
        except Exception:
            actual_rel, expected_rel = str(path), str(expected_path)
        errors.append(f"TEACHING_DEMO_INPUT_PLAN_NONCANONICAL_PATH:actual={actual_rel}:expected={expected_rel}")

    if plan.get("module_id") != job.get("module_id"):
        errors.append("TEACHING_DEMO_INPUT_PLAN_MODULE_ID_DRIFT")
    provenance = job.get("build_provenance") or {}
    if not isinstance(provenance, dict):
        errors.append("TEACHING_DEMO_JOB_BUILD_PROVENANCE_INVALID")
        provenance = {}
    initializer = plan.get("bound_by_artifact_initializer") or {}
    if not isinstance(initializer, dict):
        errors.append("TEACHING_DEMO_INPUT_PLAN_INITIALIZER_BINDING_INVALID")
        initializer = {}
    for label in ("module_contract_binding", "builder_binding"):
        if initializer.get(label) != provenance.get(label):
            errors.append(f"TEACHING_DEMO_INPUT_PLAN_JOB_{label.upper()}_DRIFT")
    if plan.get("repository_snapshot_binding") != provenance.get("source_snapshot_binding"):
        errors.append("TEACHING_DEMO_INPUT_PLAN_JOB_SNAPSHOT_BINDING_DRIFT")

    plan_inputs = plan.get("input_bindings")
    if not isinstance(plan_inputs, list) or not plan_inputs:
        errors.append("TEACHING_DEMO_INPUT_PLAN_BINDINGS_INVALID")
        plan_inputs = []
    if len(_binding_set(plan_inputs)) != len(plan_inputs):
        errors.append("TEACHING_DEMO_INPUT_PLAN_BINDING_DUPLICATE")
    errors.extend(_acceptance_capsule_errors(root, profile, plan, plan_inputs))

    job_inputs_raw = job.get("input_bindings") or []
    if not isinstance(job_inputs_raw, list):
        errors.append("TEACHING_DEMO_JOB_INPUT_BINDINGS_INVALID")
        job_inputs: list[dict[str, Any]] = []
    else:
        job_inputs = [x for x in job_inputs_raw if isinstance(x, dict)]
    if len(job_inputs) != len(job_inputs_raw) or len(_binding_set(job_inputs)) != len(job_inputs):
        errors.append("TEACHING_DEMO_JOB_INPUT_BINDING_DUPLICATE_OR_INVALID")
    expected_job_inputs = _binding_set(plan_inputs) | {_binding_key(plan_binding)}
    actual_job_inputs = _binding_set(job_inputs)
    if actual_job_inputs != expected_job_inputs:
        errors.append(
            "TEACHING_DEMO_INPUT_PLAN_JOB_BINDING_SET_DRIFT:"
            f"missing={sorted(expected_job_inputs - actual_job_inputs)}:extra={sorted(actual_job_inputs - expected_job_inputs)}"
        )

    planner_raw, planner_errors = _planner_binding_errors(root, profile, job_inputs)
    errors.extend(planner_errors)
    manifest_raw, source_commit = plan.get("manifest"), plan.get("source_commit")
    if not isinstance(manifest_raw, str) or not manifest_raw:
        errors.append("TEACHING_DEMO_INPUT_PLAN_MANIFEST_MISSING")
    if not isinstance(source_commit, str) or not HEX40.fullmatch(source_commit):
        errors.append("TEACHING_DEMO_INPUT_PLAN_SOURCE_COMMIT_INVALID")
    if errors:
        return errors
    assert planner_raw is not None and isinstance(manifest_raw, str) and isinstance(source_commit, str)

    try:
        rebuilt = _rebuild_in_fresh_process(root, planner_raw, manifest_raw, source_commit)
    except Exception as exc:
        return [f"TEACHING_DEMO_CANONICAL_PLAN_RECONSTRUCTION_FAILED:{type(exc).__name__}:{exc}"]
    if rebuilt != plan:
        return ["TEACHING_DEMO_CONSUMED_PLAN_DIFFERS_FROM_FRESH_CANONICAL_RECONSTRUCTION"]
    return []


def _repo_local_imports_in_verifier() -> list[str]:
    root = Path(__file__).resolve().parents[1]
    tools = root / "tools"
    tree = ast.parse(Path(__file__).read_text(encoding="utf-8"), filename=__file__)
    imports: set[str] = set()
    for node in ast.walk(tree):
        modules: list[str] = []
        if isinstance(node, ast.Import):
            modules = [alias.name for alias in node.names]
        elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
            modules = [node.module]
        for module in modules:
            top = module.split(".", 1)[0]
            if (tools / f"{top}.py").is_file() or (tools / top / "__init__.py").is_file():
                imports.add(module)
    return sorted(imports)


def selftest() -> None:
    if _repo_local_imports_in_verifier():
        raise AssertionError(
            "Teaching Demo live verifier regained repository-local bootstrap imports: "
            + repr(_repo_local_imports_in_verifier())
        )

    fake_foundation = types.ModuleType("artifact_foundation")
    fake_foundation.binding_key = lambda _x: ("FAKE", "FAKE", "FAKE")
    previous_foundation = sys.modules.get("artifact_foundation")
    sys.modules["artifact_foundation"] = fake_foundation
    try:
        probe = {"path": "p", "sha256": "a" * 64, "kind": "k"}
        if _binding_key(probe) != ("p", "a" * 64, "k"):
            raise AssertionError("ambient artifact_foundation alias influenced self-contained verifier primitive")
    finally:
        if previous_foundation is None:
            sys.modules.pop("artifact_foundation", None)
        else:
            sys.modules["artifact_foundation"] = previous_foundation

    payload = {"version": 1, "module_id": "synthetic"}
    identity = _canonical_sha256(payload)
    plan = {**payload, "plan_identity_sha256": identity}
    assert _plan_identity_errors(Path(identity + ".yaml"), plan) == []
    assert _plan_identity_errors(Path(identity + ".yaml"), {**plan, "module_id": "changed"})

    with tempfile.TemporaryDirectory(prefix="qz-plan-rebuild-") as tmp:
        root = Path(tmp)
        (root / "tools").mkdir()
        planner = root / "tools/planner.py"
        planner.write_text(
            "print('version: 1')\n"
            "print('authority: isolated-fresh-process-file')\n"
            f"print({REBUILD_MARKER!r})\n",
            encoding="utf-8",
        )
        fake = types.ModuleType("plan_teaching_demo_artifact_job")
        fake.build_plan = lambda *_a, **_k: {"authority": "FAKE_SYS_MODULES"}
        previous = sys.modules.get("plan_teaching_demo_artifact_job")
        sys.modules["plan_teaching_demo_artifact_job"] = fake
        try:
            rebuilt = _rebuild_in_fresh_process(root, "tools/planner.py", "ignored.yaml", "0" * 40)
        finally:
            if previous is None:
                sys.modules.pop("plan_teaching_demo_artifact_job", None)
            else:
                sys.modules["plan_teaching_demo_artifact_job"] = previous
        if rebuilt != {"version": 1, "authority": "isolated-fresh-process-file"}:
            raise AssertionError(f"current-process planner alias influenced isolated reconstruction: {rebuilt!r}")

    with tempfile.TemporaryDirectory(prefix="qz-acceptance-capsule-") as tmp:
        root = Path(tmp)
        workspace = root / "case"
        workspace.mkdir()
        freeze = workspace / "SUBMISSION_FREEZE.yaml"
        review = workspace / "INDEPENDENT_CONTENT_REVIEW.yaml"
        human = workspace / "HUMAN_ACCEPTANCE_RECEIPT.yaml"
        freeze.write_text(
            yaml.safe_dump({"case_id": "c1", "source_commit": "1" * 40}, sort_keys=False),
            encoding="utf-8",
        )
        review.write_text("decision: PASS\n", encoding="utf-8")
        fsha = _sha256_file(freeze)
        rsha = _sha256_file(review)
        human.write_text(
            yaml.safe_dump({
                "case_id": "c1",
                "source_commit": "1" * 40,
                "bindings": {
                    "submission_freeze": {"path": "SUBMISSION_FREEZE.yaml", "sha256": fsha},
                    "independent_content_review": {"path": "INDEPENDENT_CONTENT_REVIEW.yaml", "sha256": rsha},
                },
            }, sort_keys=False),
            encoding="utf-8",
        )

        def bind(path: Path, kind: str) -> dict[str, str]:
            return {
                "path": path.relative_to(root).as_posix(),
                "sha256": _sha256_file(path),
                "kind": kind,
            }

        capsule = {
            "submission_freeze": bind(freeze, "content_submission_freeze"),
            "independent_content_review": bind(review, "independent_content_review"),
            "human_acceptance_receipt": bind(human, "content_human_acceptance_receipt"),
        }
        profile = {
            "content_acceptance_capsule": {
                "required": True,
                "bindings": {
                    "submission_freeze": {"filename": "SUBMISSION_FREEZE.yaml", "kind": "content_submission_freeze"},
                    "independent_content_review": {"filename": "INDEPENDENT_CONTENT_REVIEW.yaml", "kind": "independent_content_review"},
                    "human_acceptance_receipt": {"filename": "HUMAN_ACCEPTANCE_RECEIPT.yaml", "kind": "content_human_acceptance_receipt"},
                },
                "human_receipt_case_id_must_equal_manifest_case_id": True,
                "human_receipt_source_commit_must_equal_plan_source_commit": True,
                "human_receipt_must_bind_current_freeze_and_review": True,
            },
            "repository_dependencies": [
                {"path": "production/contracts/teaching-demo-content.yaml", "kind": "canonical_content_contract"}
            ],
        }
        synthetic = {
            "case_id": "c1",
            "source_commit": "1" * 40,
            "content_acceptance_gate": {
                "contract": "production/contracts/teaching-demo-content.yaml",
                "case_id": "c1",
                "source_commit": "1" * 40,
                "decision": "INDEPENDENT_CONTENT_HUMAN_PASS",
                "evidence_capsule": capsule,
            },
        }
        assert _acceptance_capsule_errors(root, profile, synthetic, list(capsule.values())) == []
        forged = deepcopy(synthetic)
        forged["content_acceptance_gate"]["downstream_released"] = True
        assert any(
            "SELF_DECLARED_DOWNSTREAM_RELEASE_FORBIDDEN" in e
            for e in _acceptance_capsule_errors(root, profile, forged, list(capsule.values()))
        )
