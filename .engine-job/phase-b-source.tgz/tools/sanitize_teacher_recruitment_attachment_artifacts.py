#!/usr/bin/env python3
"""Remove unvalidated attachment payloads and verify persisted validated files.

This is intentionally transport-agnostic. It trusts only the machine manifest's
validation_ok records, then rechecks file size/hash and binary signature before an
attachment directory may be uploaded as an artifact.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

from fetch_teacher_recruitment_attachments import validate_binary


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def run(out_dir: Path) -> int:
    manifest_path = out_dir / "attachment-capture-manifest.json"
    files_dir = out_dir / "files"
    if not manifest_path.exists():
        print("FAIL: attachment capture manifest missing")
        return 2

    data = json.loads(manifest_path.read_text(encoding="utf-8"))
    records = data.get("records") or []
    errors: list[str] = []
    removed: list[str] = []
    verified: list[str] = []

    valid_by_filename: dict[str, dict] = {}
    for rec in records:
        if rec.get("validation_ok") and rec.get("filename"):
            valid_by_filename[str(rec["filename"])] = rec

    if files_dir.exists():
        for path in sorted(p for p in files_dir.iterdir() if p.is_file()):
            rec = valid_by_filename.get(path.name)
            if rec is None:
                path.unlink(missing_ok=True)
                removed.append(path.name)
                continue

            actual_size = path.stat().st_size
            actual_hash = sha256_file(path)
            expected_size = int(rec.get("size_bytes") or 0)
            expected_hash = str(rec.get("sha256") or "")
            expected_ext = rec.get("expected_extension")
            content_type = rec.get("content_type")
            ok, kind = validate_binary(path, expected_ext, content_type)
            before = len(errors)
            if actual_size != expected_size:
                errors.append(f"{path.name}: size mismatch {actual_size} != {expected_size}")
            if actual_hash != expected_hash:
                errors.append(f"{path.name}: sha256 mismatch")
            if not ok:
                errors.append(f"{path.name}: revalidation failed: {kind}")
            if kind != rec.get("validation_kind"):
                errors.append(f"{path.name}: validation kind drift {kind} != {rec.get('validation_kind')}")
            if len(errors) == before:
                verified.append(path.name)

    for filename in valid_by_filename:
        path = files_dir / filename
        if not path.exists():
            errors.append(f"{filename}: validated manifest record has no persisted file")

    residual = []
    if files_dir.exists():
        residual = sorted(p.name for p in files_dir.iterdir() if p.is_file() and p.name not in valid_by_filename)
    if residual:
        errors.append(f"unvalidated residual files remain: {residual}")

    data["artifact_integrity"] = {
        "sanitized": True,
        "removed_unvalidated_files": removed,
        "persisted_validated_files": sorted(verified),
        "validated_manifest_files": sorted(valid_by_filename),
        "integrity_errors": errors,
    }
    manifest_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    if errors:
        print("FAIL: attachment artifact integrity")
        for error in errors:
            print(f"- {error}")
        return 2
    print(f"PASS: attachment artifact integrity; validated_files={len(verified)} removed={len(removed)}")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()
    return run(args.out)


if __name__ == "__main__":
    sys.exit(main())
