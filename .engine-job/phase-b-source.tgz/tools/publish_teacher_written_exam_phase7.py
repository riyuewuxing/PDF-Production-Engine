#!/usr/bin/env python3
"""Deterministic first-wave publisher for teacher written-exam Phase7.

Reads the frozen publication contract plus YAML/JSONL/Markdown assets from the repo.
No LLM/API calls. Product content stays source-driven; this module only handles layout.
"""
from __future__ import annotations
import argparse, json, re
from pathlib import Path
import yaml
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle, ListFlowable, ListItem

ROOT = Path(__file__).resolve().parents[1]
WE = ROOT / 'content/job-search/teacher/written-exam'
DEFAULT_CONTRACT = WE / 'contracts/phase7-first-wave-publication-v1.yaml'
REG = '/usr/share/fonts/truetype/arphic-gbsn00lp/gbsn00lp.ttf'
BOLD = '/usr/share/fonts/truetype/arphic-gkai00mp/gkai00mp.ttf'
pdfmetrics.registerFont(TTFont('WE-CJK', REG))
pdfmetrics.registerFont(TTFont('WE-CJK-Bold', BOLD))

PAGE_W, PAGE_H = A4
LM=17*mm; RM=17*mm; TM=18*mm; BM=17*mm
base=getSampleStyleSheet()
ST={
 'title': ParagraphStyle('title',fontName='WE-CJK-Bold',fontSize=24,leading=33,textColor=colors.HexColor('#15233C'),spaceAfter=10),
 'subtitle': ParagraphStyle('subtitle',fontName='WE-CJK',fontSize=10.5,leading=16,textColor=colors.HexColor('#526273'),spaceAfter=8),
 'h1': ParagraphStyle('h1',fontName='WE-CJK-Bold',fontSize=16,leading=22,textColor=colors.HexColor('#17365D'),spaceBefore=5,spaceAfter=7),
 'h2': ParagraphStyle('h2',fontName='WE-CJK-Bold',fontSize=12,leading=17,textColor=colors.HexColor('#1F4E79'),spaceBefore=5,spaceAfter=4),
 'body': ParagraphStyle('body',fontName='WE-CJK',fontSize=9.2,leading=14,textColor=colors.HexColor('#222222'),spaceAfter=4),
 'small': ParagraphStyle('small',fontName='WE-CJK',fontSize=7.6,leading=10.5,textColor=colors.HexColor('#66717D'),spaceAfter=2),
 'card': ParagraphStyle('card',fontName='WE-CJK',fontSize=8.5,leading=12.5,textColor=colors.HexColor('#222222')),
}

def esc(s):
    return str(s).replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
def P(s, style='body'): return Paragraph(esc(s), ST[style])
def bullets(items):
    return ListFlowable([ListItem(P(x),leftIndent=6) for x in items],bulletType='bullet',leftIndent=15,spaceAfter=5)
def box(title, lines):
    flows=[P(title,'h2')]+[P(x,'card') for x in lines if x]
    t=Table([[flows]],colWidths=[PAGE_W-LM-RM])
    t.setStyle(TableStyle([('BOX',(0,0),(-1,-1),0.5,colors.HexColor('#CCD6E0')),('BACKGROUND',(0,0),(-1,-1),colors.HexColor('#F8FAFC')),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5)]))
    return t

def parse_md(path):
    """Minimal deterministic markdown renderer: headings, bullets, paragraphs and pipe tables."""
    lines=path.read_text(encoding='utf-8').splitlines(); out=[]; i=0
    while i < len(lines):
        s=lines[i].strip()
        if not s or s=='---': i+=1; continue
        if s.startswith('> '): out.append(box('边界/说明',[s[2:]])); out.append(Spacer(1,3*mm)); i+=1; continue
        if s.startswith('# '): out += [P(s[2:],'h1')]; i+=1; continue
        if s.startswith('## '): out += [P(s[3:],'h2')]; i+=1; continue
        if s.startswith('### '): out += [P(s[4:],'h2')]; i+=1; continue
        if s.startswith('- '):
            arr=[]
            while i<len(lines) and lines[i].strip().startswith('- '): arr.append(lines[i].strip()[2:]); i+=1
            out.append(bullets(arr)); continue
        if s.startswith('|') and i+1<len(lines) and lines[i+1].strip().startswith('|'):
            rows=[]
            while i<len(lines) and lines[i].strip().startswith('|'):
                row=[x.strip() for x in lines[i].strip().strip('|').split('|')]
                if not all(re.fullmatch(r'[-: ]+',x or '-') for x in row): rows.append(row)
                i+=1
            if rows:
                n=max(len(r) for r in rows); rows=[r+['']*(n-len(r)) for r in rows]
                data=[[P(x,'small') for x in r] for r in rows]
                t=Table(data,colWidths=[(PAGE_W-LM-RM)/n]*n,repeatRows=1)
                t.setStyle(TableStyle([('GRID',(0,0),(-1,-1),0.35,colors.HexColor('#CBD5DF')),('BACKGROUND',(0,0),(-1,0),colors.HexColor('#E8F0F8')),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),4),('RIGHTPADDING',(0,0),(-1,-1),4),('TOPPADDING',(0,0),(-1,-1),3),('BOTTOMPADDING',(0,0),(-1,-1),3)]))
                out += [t,Spacer(1,3*mm)]
            continue
        para=[s]; i+=1
        while i<len(lines) and lines[i].strip() and not re.match(r'^(#|>|-|\|)',lines[i].strip()): para.append(lines[i].strip()); i+=1
        out.append(P(' '.join(para)))
    return out

def load_yaml(path): return yaml.safe_load(path.read_text(encoding='utf-8'))
def load_jsonl(path): return [json.loads(x) for x in path.read_text(encoding='utf-8').splitlines() if x.strip()]
def resolve(rel): return WE / rel

def render_cards(path, kind):
    data=load_yaml(path); out=[]
    cards=data.get('cards',[])
    out += [P(f'{kind} Cards · {len(cards)}','h1')]
    for c in cards:
        cid=c.get('knowledge_id') or c.get('method_id') or ''
        title=c.get('title',cid)
        if c.get('core') is not None:
            core=c['core']; core='；'.join(map(str,core)) if isinstance(core,list) else str(core)
            lines=[f'核心：{core}']
            bounds=c.get('boundaries') or []
            errs=c.get('common_confusions') or c.get('common_errors') or []
            if bounds: lines.append('边界：'+'；'.join(map(str,bounds)))
            if errs: lines.append('易错：'+'；'.join(map(str,errs)))
        else:
            steps=c.get('steps') or []
            sig=c.get('recognition_signals') or []
            lines=[]
            if sig: lines.append('识别：'+'；'.join(map(str,sig)))
            if steps: lines.append('路径：'+' → '.join(map(str,steps)))
            if c.get('transfer_notes'): lines.append('迁移边界：'+'；'.join(map(str,c['transfer_notes'])))
        out += [box(f'{cid}  {title}',lines),Spacer(1,3*mm)]
    return out

def render_questions(paths):
    items=[]
    for p in paths: items.extend(load_jsonl(p))
    items=sorted(items,key=lambda x:x['id'])
    out=[P(f'公开回忆 Ready Seed · {len(items)}题','h1'),box('身份说明',['public-recalled-question；题意经过压缩/改写；answer points / rubric / analysis 为项目独立整理，不是官方原题或官方答案。'])]
    for q in items:
        out += [PageBreak(),P(f"{q['id']} · {q.get('stage','')} · {q.get('question_type','')}",'h1'),box('题意（paraphrased）',[q.get('stem','')])]
        pts=q.get('answer_points') or []; rub=q.get('rubric') or []
        if pts: out += [P('项目独立 Answer Points','h2'),bullets(pts)]
        if rub: out += [P('Rubric 自检','h2'),bullets(rub)]
        if q.get('analysis'): out += [P('解析','h2'),P(q['analysis'])]
        out += [P('Provenance','h2'),P(f"source_id={q.get('source_id','UNKNOWN')}；source_usage={q.get('source_usage','UNKNOWN')}；locator={q.get('source_locator','UNKNOWN')}",'small')]
    return out

def add_cover(title, product):
    return [Spacer(1,20*mm),P(product['product_id'],'small'),P(title,'title'),P(f"type={product.get('type')} · readiness={product.get('readiness')}",'subtitle'),Spacer(1,5*mm),box('出版规则',['Source-aware / No fabrication / Artifact First','UNKNOWN保持UNKNOWN；training/derived不得冒充真实题；source-specific不跨年静默继承。']),PageBreak()]

def build_product(product, outdir):
    story=add_cover(product['title'],product)
    inputs=[resolve(x) for x in product.get('inputs',[])]
    if product['type']=='recalled-question-analysis-booklet':
        story += render_questions([p for p in inputs if p.suffix=='.jsonl'])
    else:
        for p in inputs:
            if not p.exists(): raise FileNotFoundError(p)
            if p.suffix=='.md': story += parse_md(p)+[PageBreak()]
            elif p.suffix in ('.yaml','.yml'):
                y=load_yaml(p)
                if isinstance(y,dict) and isinstance(y.get('cards'),list):
                    kind='Knowledge' if any('knowledge_id' in c for c in y['cards']) else 'Method'
                    story += render_cards(p,kind)+[PageBreak()]
    story += [P('Publication Boundary','h1'),bullets(['MUST SHOW: '+x for x in product.get('must_show',[])]),bullets(['MUST NOT: '+x for x in product.get('must_not_show',[])])]
    out=outdir/(product['product_id']+'_'+product['title']+'.pdf')
    doc=SimpleDocTemplate(str(out),pagesize=A4,leftMargin=LM,rightMargin=RM,topMargin=TM,bottomMargin=BM,title=product['title'],author='qiuzhidaren')
    doc.build(story)
    return out

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--contract',default=str(DEFAULT_CONTRACT)); ap.add_argument('--out-dir',default=str(WE/'materials/yunnan/r3/final'))
    args=ap.parse_args(); contract=load_yaml(Path(args.contract)); outdir=Path(args.out_dir); outdir.mkdir(parents=True,exist_ok=True)
    outputs=[build_product(p,outdir) for p in contract['first_wave_products']]
    print(json.dumps([str(x) for x in outputs],ensure_ascii=False,indent=2))
if __name__=='__main__': main()
