"""Generic checks for teacher-defense contracts, sources, materials, replays and closure.

No concrete lesson/topic/recruitment identity belongs in this checker. It does not parse
textbooks, call an LLM, or rewrite frozen teaching-demo regression assets.
"""
from __future__ import annotations

from collections import Counter
from pathlib import Path
import re
import sys
import yaml

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "content/job-search/teacher/interview/defense"
PATHS = {
    "contract": BASE / "contracts/teacher-defense-material-pack-v1.yaml",
    "scope": BASE / "scopes/yunnan-teacher-defense-v1.yaml",
    "schema": BASE / "schemas/defense-question-card-v1.yaml",
    "taxonomy": BASE / "question-taxonomy.md",
    "prior_art": BASE / "references/prior-art.md",
    "sources": BASE / "sources/source-registry.yaml",
    "bank": BASE / "materials/yunnan/r1/common-bank-index-v1.yaml",
    "replays": BASE / "materials/yunnan/r1/replays/replay-fixtures-v1.yaml",
    "final_manifest": BASE / "materials/yunnan/r2/final-manifest.yaml",
    "quick_reference": BASE / "materials/yunnan/r2/01_答辩速记框架.md",
    "recalled_scan": BASE / "sources/recalled-question-scan-2026-08-final.md",
    "publisher": ROOT / "tools/publish_yunnan_defense.py",
}
SOURCE_BOUND_DIR = BASE / "materials/yunnan/r1/source-bound"
TYPES = {f"D{i}" for i in range(1, 9)}
COMMON_DEPS = {"lesson-bound", "topic-adaptable", "generic-anchored"}
ALL_DEPS = COMMON_DEPS | {"source-bound"}
TRIAL_SOURCE_ROLES = {"evidence", "board", "exam_skeleton", "trial", "defense"}


class DefenseContractError(ValueError):
    pass


def yload(path: Path):
    if not path.exists():
        raise DefenseContractError(f"missing: {path.relative_to(ROOT)}")
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    if data is None:
        raise DefenseContractError(f"empty yaml: {path.relative_to(ROOT)}")
    return data


def check_taxonomy() -> None:
    text = PATHS["taxonomy"].read_text(encoding="utf-8")
    found = set(re.findall(r"^##\s+(D[1-8])\b", text, re.MULTILINE))
    if found != TYPES:
        raise DefenseContractError(f"taxonomy drift: {sorted(found)}")
    for token in ("先 source", "source-bound", "source-designated"):
        if token not in text:
            raise DefenseContractError(f"taxonomy source-aware routing missing: {token}")


def check_prior_art() -> int:
    text = PATHS["prior_art"].read_text(encoding="utf-8")
    repos = set(re.findall(r"Repository:\s*`([^`]+/[^`]+)`", text))
    if len(repos) < 3:
        raise DefenseContractError("prior-art must compare >=3 repositories")
    if len(re.findall(r"License:\s*", text)) < len(repos):
        raise DefenseContractError("prior-art license metadata incomplete")
    for phrase in ("Reuse decision", "Explicit rejection", "Code/text copying"):
        if phrase not in text:
            raise DefenseContractError(f"prior-art decision field missing: {phrase}")
    return len(repos)


def check_contract() -> None:
    c = yload(PATHS["contract"])
    if c.get("id") != "teacher-defense-material-pack-v1" or c.get("default_mode") != "material-production":
        raise DefenseContractError("material contract identity/default mode drift")
    if c.get("status") not in {"active", "stable-production"}:
        raise DefenseContractError("material contract status drift")
    if (c.get("scope") or {}).get("unified_exam_profile") is not False:
        raise DefenseContractError("Yunnan must not become a unified defense profile")
    layers = c.get("layers") or {}
    common = layers.get("common_bank") or {}
    lesson = layers.get("lesson_bound") or {}
    source_bound = layers.get("source_designated") or {}
    if common.get("template") is not True or set(common.get("topic_dependency_allowed") or []) != COMMON_DEPS:
        raise DefenseContractError("common mother-template layer drift")
    if common.get("defense_mode") != "lesson-linked":
        raise DefenseContractError("common bank must remain lesson-linked")
    if lesson.get("template") is not False or set(lesson.get("topic_dependency_allowed") or []) != {"lesson-bound", "topic-adaptable"}:
        raise DefenseContractError("instantiated lesson-bound layer drift")
    if source_bound.get("template") is not False or set(source_bound.get("topic_dependency_allowed") or []) != {"source-bound"}:
        raise DefenseContractError("source-designated layer drift")
    if source_bound.get("defense_mode") != "source-designated":
        raise DefenseContractError("source-designated defense mode missing")
    routing = c.get("routing") or {}
    if not routing.get("to_defense_when") or not routing.get("to_structured_when") or not routing.get("source_precedence"):
        raise DefenseContractError("defense/structured/source-precedence routing guard missing")
    if "official" not in str(routing.get("source_precedence") or "").lower():
        raise DefenseContractError("source precedence must require official recruitment evidence")
    base = c.get("common_bank_baseline") or {}
    if set(base.get("taxonomy") or []) != TYPES or int(base.get("initial_mother_question_target") or 0) != 32:
        raise DefenseContractError("32-card D1-D8 baseline drift")
    if (c.get("user_participation") or {}).get("required_for_material_production") is not False:
        raise DefenseContractError("user participation cannot gate material production")
    selection = str((c.get("lesson_bound_generation") or {}).get("selection_rule") or "")
    for token in ("5-8", "subject grounding", "learning evidence", "reflection/correction"):
        if token not in selection:
            raise DefenseContractError(f"lesson-bound selection rule missing: {token}")
    source_rule = str((c.get("source_designated_generation") or {}).get("generation_rule") or "")
    for token in ("derived-defense-question", "question count", "different county/year", "D7"):
        if token not in source_rule:
            raise DefenseContractError(f"source-designated generation guard missing: {token}")
    publication = c.get("publication") or {}
    if publication.get("publisher") != "tools/publish_yunnan_defense.py":
        raise DefenseContractError("final defense publisher route missing")


def check_scope() -> None:
    s = yload(PATHS["scope"])
    if s.get("id") != "yunnan-teacher-defense-v1" or s.get("region") != "云南省":
        raise DefenseContractError("scope identity drift")
    if s.get("unified_province_profile") is not False:
        raise DefenseContractError("scope allows a unified Yunnan profile")
    excluded = "\n".join(s.get("exclude_from_core_frequency") or [])
    for token in ("教师资格", "结构化", "纯试讲", "培训机构", "问答"):
        if token not in excluded:
            raise DefenseContractError(f"scope exclusion missing: {token}")
    policy = s.get("format_policy") or {}
    if not policy.get("source_precedence") or "source" not in str(policy.get("source_precedence") or "").lower():
        raise DefenseContractError("scope source precedence missing")
    layers = {x.get("id"): x for x in s.get("product_layers") or [] if isinstance(x, dict)}
    sb = layers.get("source-designated-defense") or {}
    if sb.get("defense_mode") != "source-designated":
        raise DefenseContractError("scope source-designated product layer missing")


def check_schema() -> None:
    s = yload(PATHS["schema"])
    if s.get("schema_id") != "teacher-defense-question-card-v1":
        raise DefenseContractError("card schema id drift")
    fields = s.get("fields") or {}
    required = {"id", "status", "source_identity", "source_basis", "defense_type", "topic_dependency", "material_file", "format_source_reference"}
    if required - set(fields):
        raise DefenseContractError(f"card schema fields missing: {sorted(required-set(fields))}")
    if set((fields.get("defense_type") or {}).get("values") or []) != TYPES:
        raise DefenseContractError("card schema D1-D8 mismatch")
    if set((fields.get("topic_dependency") or {}).get("values") or []) != ALL_DEPS:
        raise DefenseContractError("card schema topic dependency mismatch")
    hard = "\n".join(s.get("hard_rules") or [])
    for token in ("D7", "D8", "derived-defense-question", "NTCE", "source-bound", "Q&A"):
        if token not in hard:
            raise DefenseContractError(f"card schema hard rule missing: {token}")


def check_sources() -> dict[str, dict]:
    r = yload(PATHS["sources"])
    sources = r.get("sources") or {}
    if not isinstance(sources, dict) or len(sources) < 4:
        raise DefenseContractError("source registry unexpectedly small")
    scoped_official = 0
    for sid, src in sources.items():
        if not str(src.get("url") or "").startswith("https://") or not src.get("kind") or not src.get("authority"):
            raise DefenseContractError(f"invalid source: {sid}")
        if src.get("kind") == "official-format" and src.get("defense_content_scope"):
            scoped_official += 1
            stage = (src.get("stages") or {}).get("defense") or {}
            if not stage or not str(stage.get("label") or "").strip():
                raise DefenseContractError(f"{sid}: official defense content scope lacks a declared defense stage")
            duration = stage.get("duration_minutes")
            if duration is not None:
                try:
                    if float(duration) <= 0:
                        raise DefenseContractError(f"{sid}: non-positive defense duration")
                except (TypeError, ValueError):
                    raise DefenseContractError(f"{sid}: invalid defense duration")
            score = stage.get("score_scale")
            if score is not None:
                try:
                    if float(score) <= 0:
                        raise DefenseContractError(f"{sid}: non-positive defense score scale")
                except (TypeError, ValueError):
                    raise DefenseContractError(f"{sid}: invalid defense score scale")
            if not isinstance(src.get("defense_content_scope"), list):
                raise DefenseContractError(f"{sid}: defense_content_scope must be a list")
    if scoped_official < 3:
        raise DefenseContractError("final defense closure requires cross-source official content-scope evidence")
    rules = "\n".join(r.get("rules") or [])
    for token in ("unified", "NTCE", "public-format-mirror", "true-question", "year", "Q&A", "content scope"):
        if token not in rules:
            raise DefenseContractError(f"source guard missing: {token}")
    return sources


def card_section(text: str, cid: str) -> str:
    m = re.search(rf"^##\s+{re.escape(cid)}\b[\s\S]*?(?=^##\s+DEF-|\Z)", text, re.MULTILINE)
    if not m:
        raise DefenseContractError(f"Markdown card section missing: {cid}")
    return m.group(0)


def check_bank(sources: dict[str, dict]) -> Counter:
    source_ids = set(sources)
    index = yload(PATHS["bank"])
    cards = index.get("cards") or []
    if index.get("id") != "yunnan-defense-common-bank-index-v1" or index.get("status") != "active":
        raise DefenseContractError("common-bank identity/status drift")
    if len(cards) != 32 or int(index.get("count") or 0) != 32:
        raise DefenseContractError(f"common bank must contain 32 templates, got {len(cards)}")
    seen, cache, counts = set(), {}, Counter()
    for card in cards:
        cid = str(card.get("id") or "")
        if not re.fullmatch(r"DEF-COM-\d{3}", cid) or cid in seen:
            raise DefenseContractError(f"invalid/duplicate common id: {cid!r}")
        seen.add(cid)
        dtype, dep = card.get("defense_type"), card.get("topic_dependency")
        if dtype not in TYPES or dep not in COMMON_DEPS:
            raise DefenseContractError(f"{cid}: invalid common-bank type/dependency")
        counts[dtype] += 1
        if card.get("status") != "mother-template" or card.get("source_identity") != "derived-defense-question":
            raise DefenseContractError(f"{cid}: mother-template identity drift")
        basis = set(card.get("source_basis") or [])
        if not basis or basis - source_ids:
            raise DefenseContractError(f"{cid}: unresolved source basis {sorted(basis-source_ids)}")
        raw_path = str(card.get("material_file") or "").strip()
        if not raw_path:
            raise DefenseContractError(f"{cid}: material_file missing")
        path = ROOT / raw_path
        if not path.exists():
            raise DefenseContractError(f"{cid}: material file missing: {raw_path}")
        text = cache.setdefault(path, path.read_text(encoding="utf-8"))
        section = card_section(text, cid)
        if f"**topic_dependency**：{dep}" not in section:
            raise DefenseContractError(f"{cid}: index/Markdown dependency mismatch")
        if not re.search(rf"\*\*类型\*\*：{re.escape(dtype)}(?:\b|\s|/)", section):
            raise DefenseContractError(f"{cid}: index/Markdown type mismatch")
        for token in ("考官意图", "证据锚点", "骨架", "纠错路径", "追问", "失分点"):
            if token not in section:
                raise DefenseContractError(f"{cid}: Markdown missing {token}")
        if dtype == "D7" and "核验" not in section and "核验" not in text and "subject_fact_source" not in text:
            raise DefenseContractError(f"{cid}: D7 verification requirement missing")
        if dtype == "D8" and not any(t in section for t in ("本课", "刚才", "这节课", "试讲")):
            raise DefenseContractError(f"{cid}: D8 current-lesson anchor missing")
    expected = Counter({d: 4 for d in TYPES})
    if counts != expected:
        raise DefenseContractError(f"D1-D8 bank distribution drift: {dict(counts)}")
    return counts


def _compare_declared_format(pack_id: str, declared: dict, src: dict) -> None:
    stage = (src.get("stages") or {}).get("defense") or {}
    label = str(declared.get("stage_label") or "").strip()
    if label and label != str(stage.get("label") or "").strip():
        raise DefenseContractError(f"{pack_id}: official_scope.stage_label contradicts primary format source")
    for key in ("duration_minutes", "score_scale", "weight_percent", "question_count", "random_draw"):
        if key in declared and declared.get(key) != stage.get(key):
            raise DefenseContractError(f"{pack_id}: official_scope.{key} contradicts primary format source")
    declared_scope = set(declared.get("content_scope") or [])
    source_scope = set(src.get("defense_content_scope") or [])
    if not declared_scope or declared_scope != source_scope:
        raise DefenseContractError(f"{pack_id}: official content scope does not mirror primary source")


def check_source_bound_packs(sources: dict[str, dict]) -> tuple[int, int, dict[str, int]]:
    if not SOURCE_BOUND_DIR.exists() or not SOURCE_BOUND_DIR.is_dir():
        raise DefenseContractError("source-bound defense directory missing")
    paths = sorted(SOURCE_BOUND_DIR.glob("*.yaml"))
    if not paths:
        raise DefenseContractError("no source-bound defense pack exists")
    source_ids = set(sources)
    pack_count = card_count = 0
    counts_by_pack: dict[str, int] = {}
    seen_cards: set[str] = set()
    for path in paths:
        pack = yload(path)
        pid = str(pack.get("id") or "").strip()
        if not pid or pack.get("status") != "source-bound-training":
            raise DefenseContractError(f"{path.name}: invalid source-bound pack identity/status")
        refs = pack.get("format_sources") or {}
        primary = str(refs.get("primary") or "").strip()
        if primary not in sources:
            raise DefenseContractError(f"{pid}: unresolved primary format source {primary!r}")
        src = sources[primary]
        if src.get("kind") != "official-format" or not src.get("defense_content_scope"):
            raise DefenseContractError(f"{pid}: primary source must be official-format with defense_content_scope")
        corroborating = set(refs.get("corroborating") or [])
        if corroborating - source_ids:
            raise DefenseContractError(f"{pid}: unresolved corroborating sources {sorted(corroborating-source_ids)}")
        if not pack.get("not_valid_for"):
            raise DefenseContractError(f"{pid}: cross-year/cross-scope boundary missing")
        _compare_declared_format(pid, pack.get("official_scope") or {}, src)
        material_raw = str(pack.get("material_file") or "").strip()
        material_path = ROOT / material_raw
        if not material_raw or not material_path.exists():
            raise DefenseContractError(f"{pid}: material file missing")
        text = material_path.read_text(encoding="utf-8")
        if "derived-defense-question" not in text or "不是" not in text:
            raise DefenseContractError(f"{pid}: material must visibly disclaim exact/recalled question identity")
        cards = pack.get("cards") or []
        expected_count = int(((pack.get("qa") or {}).get("expected_card_count") or len(cards)))
        if not cards or len(cards) != expected_count:
            raise DefenseContractError(f"{pid}: source-bound card count mismatch")
        for card in cards:
            cid = str(card.get("id") or "").strip()
            if not re.fullmatch(r"DEF-[A-Z0-9-]+", cid) or cid in seen_cards:
                raise DefenseContractError(f"{pid}: invalid/duplicate card id {cid!r}")
            seen_cards.add(cid)
            if card.get("status") != "instantiated" or card.get("source_identity") != "derived-defense-question":
                raise DefenseContractError(f"{cid}: source-bound cards must be instantiated derived-defense-question")
            if card.get("topic_dependency") != "source-bound" or card.get("defense_type") not in TYPES:
                raise DefenseContractError(f"{cid}: source-bound routing metadata invalid")
            fmt_ref = str(card.get("format_source_reference") or "")
            if fmt_ref not in sources:
                raise DefenseContractError(f"{cid}: unresolved format_source_reference")
            fmt_src = sources[fmt_ref]
            if fmt_src.get("kind") != "official-format" or not fmt_src.get("defense_content_scope"):
                raise DefenseContractError(f"{cid}: format source lacks official defense content scope")
            basis = set(card.get("source_basis") or [])
            if not basis or basis - source_ids or fmt_ref not in basis:
                raise DefenseContractError(f"{cid}: source_basis must resolve and include format source")
            if not str(card.get("question") or "").strip():
                raise DefenseContractError(f"{cid}: question missing")
            if card.get("defense_type") == "D7" and not card.get("subject_fact_source"):
                raise DefenseContractError(f"{cid}: source-bound D7 card requires subject_fact_source")
            section = card_section(text, cid)
            for token in ("format_source_reference", "topic_dependency", "考官意图", "证据锚点", "骨架", "参考口语答案", "纠错路径", "追问", "失分点"):
                if token not in section:
                    raise DefenseContractError(f"{cid}: source-bound Markdown missing {token}")
            card_count += 1
        counts_by_pack[pid] = len(cards)
        pack_count += 1
    return pack_count, card_count, counts_by_pack


def check_trial_manifest(fixture_id: str, raw_path: str, defense_asset: str) -> None:
    manifest_path = ROOT / raw_path
    manifest = yload(manifest_path)
    if manifest.get("product_contract") != "teacher-trial-two-pdf-v1":
        raise DefenseContractError(f"{fixture_id}: replay manifest is not a teaching-demo contract")
    source = manifest.get("source") or {}
    missing = TRIAL_SOURCE_ROLES - set(source)
    if missing:
        raise DefenseContractError(f"{fixture_id}: trial manifest missing source roles {sorted(missing)}")
    workspace_raw = str(manifest.get("workspace") or "").strip()
    workspace = (ROOT / workspace_raw) if workspace_raw else manifest_path.parent
    if not workspace.exists() or not workspace.is_dir():
        raise DefenseContractError(f"{fixture_id}: unresolved trial workspace {workspace_raw!r}")
    for role in TRIAL_SOURCE_ROLES:
        rel = str(source.get(role) or "").strip()
        if not rel or not (workspace / rel).exists():
            raise DefenseContractError(f"{fixture_id}: unresolved trial source role {role}={rel!r}")
    manifest_defense = (workspace / str(source["defense"])).resolve()
    declared_defense = (ROOT / defense_asset).resolve()
    if manifest_defense != declared_defense:
        raise DefenseContractError(f"{fixture_id}: replay defense asset does not match trial manifest source.defense")


def check_replays() -> int:
    data = yload(PATHS["replays"])
    fixtures = data.get("fixtures") or []
    if data.get("status") != "non-formal" or len(fixtures) < 3:
        raise DefenseContractError("replay suite must remain non-formal with >=3 fixtures")
    required, seen, families = {"D4", "D5", "D6", "D7"}, set(), set()
    for f in fixtures:
        fid = str(f.get("id") or "")
        if not fid or fid in seen:
            raise DefenseContractError(f"invalid/duplicate replay id: {fid!r}")
        seen.add(fid)
        family = str(f.get("topic_family") or "").strip()
        if not family:
            raise DefenseContractError(f"{fid}: topic_family missing")
        families.add(family)
        count = int(f.get("recommended_final_count") or 0)
        if not 5 <= count <= 8:
            raise DefenseContractError(f"{fid}: final count outside 5-8")
        coverage = set(f.get("coverage") or [])
        if coverage - TYPES or not required.issubset(coverage):
            raise DefenseContractError(f"{fid}: complementary D4/D5/D6/D7 coverage missing")
        if set(f.get("required_coverage") or []) != required:
            raise DefenseContractError(f"{fid}: required_coverage drift")
        for key in ("trial_manifest", "existing_defense_asset", "replay_analysis"):
            raw_path = str(f.get(key) or "").strip()
            if not raw_path or not (ROOT / raw_path).exists():
                raise DefenseContractError(f"{fid}: missing {key}: {raw_path!r}")
        check_trial_manifest(fid, str(f["trial_manifest"]), str(f["existing_defense_asset"]))
    if len(families) < 3:
        raise DefenseContractError("replay fixtures are not heterogeneous")
    return len(fixtures)


def check_final_manifest(common_count: int, pack_count: int, card_count: int, counts_by_pack: dict[str, int]) -> None:
    m = yload(PATHS["final_manifest"])
    if m.get("id") != "yunnan-teacher-defense-final-v1" or m.get("status") != "final-content-closed":
        raise DefenseContractError("final manifest identity/status drift")
    if int(m.get("content_round") or 0) != 2 or int(m.get("content_rounds_total") or 0) != 2:
        raise DefenseContractError("defense content must close in round 2 of 2")
    if int((m.get("common_bank") or {}).get("count") or 0) != common_count:
        raise DefenseContractError("final manifest common-bank count drift")
    sb = m.get("source_bound_packs") or {}
    packs = sb.get("packs") or []
    if int(sb.get("pack_count") or 0) != pack_count or int(sb.get("total_cards") or 0) != card_count:
        raise DefenseContractError("final manifest source-bound totals drift")
    if len(packs) != pack_count:
        raise DefenseContractError("final manifest source-bound pack list drift")
    declared = {str(x.get("id")): int(x.get("count") or 0) for x in packs if isinstance(x, dict)}
    if declared != counts_by_pack:
        raise DefenseContractError("final manifest per-pack counts drift")
    recalled = m.get("recalled_question_layer") or {}
    admitted = int(recalled.get("admitted_count") or 0)
    if admitted < 0:
        raise DefenseContractError("invalid recalled-question count")
    if admitted == 0:
        scan = PATHS["recalled_scan"].read_text(encoding="utf-8")
        if "provenance" not in scan.lower() or "admitted_count = 0" not in scan:
            raise DefenseContractError("zero recalled-question closure lacks provenance report")
    closure = m.get("closure") or {}
    if closure.get("content_complete") is not True or closure.get("no_third_content_round") is not True:
        raise DefenseContractError("defense final content closure missing")
    if closure.get("future_mode") != "stable-production":
        raise DefenseContractError("defense future mode must be stable-production")
    publication = m.get("publication_policy") or {}
    if publication.get("publisher") != "tools/publish_yunnan_defense.py" or publication.get("runtime_llm_api") is not False:
        raise DefenseContractError("final publication policy drift")
    if not PATHS["publisher"].exists() or not PATHS["quick_reference"].exists():
        raise DefenseContractError("final publisher/quick-reference artifact missing")


def selftest(sources: dict[str, dict]) -> None:
    if "DX" in TYPES or "source-bound" not in ALL_DEPS or not sources:
        raise AssertionError("defense checker selftest failed")


def main() -> int:
    for path in PATHS.values():
        if not path.exists():
            raise DefenseContractError(f"missing routed asset: {path.relative_to(ROOT)}")
    check_taxonomy()
    prior_count = check_prior_art()
    check_contract()
    check_scope()
    check_schema()
    sources = check_sources()
    counts = check_bank(sources)
    source_packs, source_cards, counts_by_pack = check_source_bound_packs(sources)
    replay_count = check_replays()
    check_final_manifest(sum(counts.values()), source_packs, source_cards, counts_by_pack)
    selftest(sources)
    print("teacher-defense contract/source/common-bank/source-bound/replay/final checks: PASS")
    print(
        f"prior_art={prior_count} sources={len(sources)} mother_templates={sum(counts.values())} "
        f"source_bound_packs={source_packs} source_bound_cards={source_cards} replays={replay_count}"
    )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except DefenseContractError as exc:
        print(f"TEACHER_DEFENSE_CHECK_FAIL: {exc}", file=sys.stderr)
        raise SystemExit(1)
