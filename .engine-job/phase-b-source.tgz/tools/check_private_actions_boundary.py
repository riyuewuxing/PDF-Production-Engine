#!/usr/bin/env python3
"""Fail closed while private GitHub-hosted Actions are forbidden as a project dependency."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKFLOWS = ROOT / ".github" / "workflows"

def main() -> int:
    active = []
    if WORKFLOWS.exists():
        active = sorted([*WORKFLOWS.glob("*.yml"), *WORKFLOWS.glob("*.yaml")])
    if active:
        print("FAIL: private GitHub Actions workflow(s) present while hosted Actions are forbidden")
        for path in active:
            print("- " + path.relative_to(ROOT).as_posix())
        return 1
    print("PASS: no private GitHub-hosted Actions workflow dependency")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
