"""Generic contract checks for teacher structured-interview assets.

Validates prior-art, artifact-first contracts, schemas, profiles and synthetic regression
without knowing specific business question identities or assuming one exam's flow shape.
"""
from __future__ import annotations
from pathlib import Path
import re, sys, yaml

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'content/job-search/teacher/interview/structured'
CONTRACT=BASE/'contracts/structured-interview-v1.yaml'
MATERIAL_CONTRACT=BASE/'contracts/structured-material-pack-v1.yaml'
CASE_SCHEMA=BASE/'schemas/training-case-v1.yaml'
STATE_SCHEMA=BASE/'schemas/training-state-v1.yaml'
REFERENCE_SCHEMA=BASE/'schemas/reference-item-v1.yaml'
PRIOR_ART=BASE/'references/prior-art.md'
TAXONOMY=BASE/'question-taxonomy.md'
REGRESSION_DIR=BASE/'regression'
PROFILES=BASE/'profiles'

class StructuredContractError(ValueError): pass

def load_yaml(path):
    if not path.exists(): raise StructuredContractError(f'missing required file: {path.relative_to(ROOT)}')
    data=yaml.safe_load(path.read_text(encoding='utf-8'))
    if data is None: raise StructuredContractError(f'empty yaml: {path.relative_to(ROOT)}')
    return data

def taxonomy_ids():
    ids=set(re.findall(r'^###\s+(T\d+)\b',TAXONOMY.read_text(encoding='utf-8'),flags=re.MULTILINE))
    if len(ids)<5: raise StructuredContractError('question taxonomy unexpectedly small or unparsable')
    return ids

def validate_prior_art():
    if not PRIOR_ART.exists(): raise StructuredContractError('prior-art registry missing')
    text=PRIOR_ART.read_text(encoding='utf-8')
    repos=set(re.findall(r'Repo:\s*`([^`]+/[^`]+)`',text))
    if len(repos)<3: raise StructuredContractError('prior-art registry must compare at least three repositories')
    for token in ('License:','本项目决策'):
        if token not in text: raise StructuredContractError(f'prior-art metadata missing: {token}')
    return len(repos)

def validate_contract(c):
    if c.get('id')!='structured-interview-v1' or c.get('scope')!='content/job-search/teacher/interview/structured':
        raise StructuredContractError('structured contract identity/scope drift')
    if c.get('default_mode')!='material-production':
        raise StructuredContractError('structured default mode must remain material-production')
    if (c.get('product_contract') or {}).get('material_pack')!='structured-material-pack-v1.yaml':
        raise StructuredContractError('material-pack contract route missing')
    if (c.get('prior_art') or {}).get('registry')!='../references/prior-art.md':
        raise StructuredContractError('prior-art registry route missing')
    forbidden=set((c.get('source_policy') or {}).get('forbid_fabrication') or [])
    need={'official_duration','official_question_count','official_score_weight','user_personal_experience'}
    if need-forbidden: raise StructuredContractError(f'source anti-fabrication policy missing: {sorted(need-forbidden)}')
    profiles=c.get('profiles') or {}
    if profiles.get('default','MISSING') is not None or profiles.get('directory')!='../profiles':
        raise StructuredContractError('profile routing/default policy drift')
    interactive=c.get('interactive_training') or {}
    if interactive.get('default_enabled') is not False:
        raise StructuredContractError('interactive training must not be default-enabled')
    modes=set((interactive.get('modes') or {}).keys())
    if not {'mock','drill','review'}.issubset(modes):
        raise StructuredContractError('optional mock/drill/review modes required')
    if 'Never block material production' not in str(interactive.get('hard_rule') or ''):
        raise StructuredContractError('material production no-block rule missing')
    hints=(c.get('hint_ladder') or {}).get('levels') or {}
    if {0,1,2,3,4}!={int(k) for k in hints}: raise StructuredContractError('hint ladder must define 0-4')
    adaptive=c.get('adaptive_training') or {}
    if adaptive.get('state_schema')!='../schemas/training-state-v1.yaml' or adaptive.get('history_dedup') is not True:
        raise StructuredContractError('adaptive state/dedup contract missing')
    follow=c.get('followup_policy') or {}
    if follow.get('material_mode')!='prewritten_likely_variants' or follow.get('interactive_mode')!='answer_derived_first':
        raise StructuredContractError('material/interactive follow-up separation missing')
    if (c.get('scoring') or {}).get('default_weights','MISSING') is not None:
        raise StructuredContractError('default training weights must remain null')
    hard=set((c.get('qa') or {}).get('hard_fail') or [])
    for item in ('official_process_fact_without_profile','project_taxonomy_presented_as_official','new_major_capability_without_prior_art_review','material_generation_blocked_on_user_mock_answer'):
        if item not in hard: raise StructuredContractError(f'contract QA missing guard: {item}')
    if not (c.get('isolation') or {}).get('forbid_dependencies_on'): raise StructuredContractError('cross-module isolation missing')

def validate_material_contract(c):
    if c.get('id')!='structured-material-pack-v1' or c.get('scope')!='content/job-search/teacher/interview/structured':
        raise StructuredContractError('material-pack identity/scope drift')
    if c.get('default_mode')!='artifact-production':
        raise StructuredContractError('material-pack default mode must be artifact-production')
    pipeline=c.get('pipeline') or []
    for step in ('lock_official_profile_and_constraints','ingest_and_validate_reference_bank','build_question_cards','build_memory_version','publish_material_source'):
        if step not in pipeline: raise StructuredContractError(f'material pipeline missing: {step}')
    sections=set(c.get('required_sections') or [])
    need={'使用说明与官方范围','本场考试已知规则与未知项','T1-T9题型地图','分类题库与参考答案','速记版/背诵锚点','来源与身份说明'}
    if need-sections: raise StructuredContractError(f'material required sections missing: {sorted(need-sections)}')
    rules='\n'.join(c.get('artifact_rules') or [])
    for phrase in ('must not wait for user mock answers','personal-history questions','unknown official question count','must not be called official questions'):
        if phrase not in rules: raise StructuredContractError(f'material hard rule missing: {phrase}')
    inter=c.get('interactive_training') or {}
    if inter.get('status')!='optional': raise StructuredContractError('interactive training must be optional in material contract')
    if 'block material generation' not in '\n'.join(inter.get('must_not') or []):
        raise StructuredContractError('material contract must forbid interactive blocking')
    pub=c.get('publication') or {}
    if pub.get('canonical_source_format')!='markdown' or pub.get('target_user_artifact')!='pdf':
        raise StructuredContractError('material publication contract drift')

def validate_case_schema(s):
    if s.get('schema_id')!='structured-training-case-v1': raise StructuredContractError('unexpected training-case schema id')
    fields=set((s.get('fields') or {}).keys())
    need={'case_id','status','question','reference_id','profile_id','routing','constraints','cues','skeleton','reference_answer','followups','scoring','failure_modes','revision'}
    if need-fields: raise StructuredContractError(f'training schema missing fields: {sorted(need-fields)}')
    rules='\n'.join(s.get('hard_rules') or [])
    if 'sourced-training cases require a ready reference_id' not in rules:
        raise StructuredContractError('training schema missing reference-bank link rule')

def validate_reference_schema(s):
    if s.get('schema_id')!='structured-reference-item-v1': raise StructuredContractError('unexpected reference-item schema id')
    fields=set((s.get('fields') or {}).keys())
    need={'id','status','question','normalized_question','exact_key','source_id','source_usage','primary_type','risk_level'}
    if need-fields: raise StructuredContractError(f'reference schema missing fields: {sorted(need-fields)}')

def validate_state_schema(s):
    if s.get('schema_id')!='structured-training-state-v1': raise StructuredContractError('unexpected training-state schema id')
    fields=set((s.get('fields') or {}).keys())
    need={'state_id','updated_at','sessions','question_history','dimension_trends','type_coverage','failure_mode_counts','hint_dependency','next_drill'}
    if need-fields: raise StructuredContractError(f'training-state schema missing fields: {sorted(need-fields)}')

def _flatten_axes(raw):
    out=[]
    if isinstance(raw,list): out.extend(str(x) for x in raw if str(x).strip())
    elif isinstance(raw,dict):
        for values in raw.values():
            if isinstance(values,list): out.extend(str(x) for x in values if str(x).strip())
    return out

def validate_profile(path,p):
    pid=str(p.get('id') or '').strip()
    if not pid or path.stem!=pid or p.get('status')!='sourced-profile' or not p.get('last_verified'):
        raise StructuredContractError(f'{path.name}: invalid profile identity/status')
    sources=p.get('sources') or []
    if not sources: raise StructuredContractError(f'{pid}: no sources')
    seen=set()
    for src in sources:
        sid=str(src.get('id') or '')
        if not sid or sid in seen or not src.get('authority') or not str(src.get('url') or '').startswith('https://'):
            raise StructuredContractError(f'{pid}: invalid source registration')
        seen.add(sid)
    flow=p.get('interview_flow') or []
    if not isinstance(flow,list) or not flow or not all(isinstance(x,dict) and str(x.get('stage') or '').strip() for x in flow):
        raise StructuredContractError(f'{pid}: interview_flow missing/invalid')
    timed=0
    for stage in flow:
        for key in ('duration_minutes','duration_minutes_approx'):
            if key in stage:
                try: value=float(stage[key])
                except (TypeError,ValueError): raise StructuredContractError(f'{pid}: invalid {key}')
                if value<=0: raise StructuredContractError(f'{pid}: non-positive {key}')
                timed+=1
        if 'question_count' in stage and stage.get('question_count') is not None:
            try: count=int(stage['question_count'])
            except (TypeError,ValueError): raise StructuredContractError(f'{pid}: invalid question_count')
            if count<=0: raise StructuredContractError(f'{pid}: non-positive question_count')
    scope=p.get('structured_scope') or {}
    stage_name=str(scope.get('stage') or '').strip()
    if not stage_name: raise StructuredContractError(f'{pid}: structured_scope.stage missing')
    stages={str(x.get('stage')) for x in flow}
    if stage_name not in stages: raise StructuredContractError(f'{pid}: structured_scope stage not found in interview_flow')
    if timed<1: raise StructuredContractError(f'{pid}: profile must register at least one sourced timing fact')
    axes=_flatten_axes(p.get('official_competency_axes') or {})
    if len(set(axes))<2: raise StructuredContractError(f'{pid}: official competency axes unexpectedly incomplete')
    if (p.get('project_taxonomy') or {}).get('authority')!='project-training-only':
        raise StructuredContractError(f'{pid}: project taxonomy mislabeled')
    return pid

def validate_profiles():
    paths=sorted(PROFILES.glob('*.yaml')) if PROFILES.exists() else []
    if not paths: raise StructuredContractError('no sourced profile exists')
    ids=set()
    for path in paths:
        pid=validate_profile(path,load_yaml(path))
        if pid in ids: raise StructuredContractError(f'duplicate profile id: {pid}')
        ids.add(pid)
    return ids

def validate_fixture(case,types):
    cid=str(case.get('case_id') or '')
    if not cid or case.get('status')!='synthetic' or not str(case.get('question') or '').strip():
        raise StructuredContractError('invalid synthetic fixture')
    routing=case.get('routing') or {}; primary=routing.get('primary_type')
    if primary not in types: raise StructuredContractError(f'{cid}: unknown primary_type {primary!r}')
    if any(x not in types for x in routing.get('secondary_types') or []): raise StructuredContractError(f'{cid}: unknown secondary_type')
    if not routing.get('evaluation_target') or not case.get('expected_cues') or not case.get('anti_patterns'):
        raise StructuredContractError(f'{cid}: fixture metadata incomplete')

def validate_regression(types):
    paths=sorted(REGRESSION_DIR.glob('*.yaml')) if REGRESSION_DIR.exists() else []
    if not paths: raise StructuredContractError('no structured regression suites')
    total=0; seen_types=set()
    for path in paths:
        suite=load_yaml(path)
        if suite.get('status')!='non-formal': raise StructuredContractError(f'{path.name}: regression must remain non-formal')
        ids=set()
        for case in suite.get('cases') or []:
            validate_fixture(case,types)
            if case['case_id'] in ids: raise StructuredContractError(f'{path.name}: duplicate fixture id')
            ids.add(case['case_id']); seen_types.add(case['routing']['primary_type']); total+=1
    if len(seen_types)<3: raise StructuredContractError('regression not heterogeneous enough')
    return len(paths),total,seen_types

def selftest(types):
    bad={'case_id':'SELFTEST','status':'synthetic','question':'x','routing':{'primary_type':'TX','evaluation_target':'x'},'expected_cues':['x'],'anti_patterns':['x']}
    try: validate_fixture(bad,types)
    except StructuredContractError: pass
    else: raise AssertionError('selftest failed: invalid type accepted')

def main():
    types=taxonomy_ids(); prior=validate_prior_art(); validate_contract(load_yaml(CONTRACT)); validate_material_contract(load_yaml(MATERIAL_CONTRACT))
    validate_case_schema(load_yaml(CASE_SCHEMA)); validate_reference_schema(load_yaml(REFERENCE_SCHEMA)); validate_state_schema(load_yaml(STATE_SCHEMA))
    profiles=validate_profiles(); suites,fixtures,seen=validate_regression(types); selftest(types)
    print('structured-interview prior-art/artifact-contract/schema/profile/regression: PASS')
    print(f'prior_art_repos={prior} taxonomy_types={len(types)} profiles={len(profiles)} regression_suites={suites} fixtures={fixtures} primary_types={len(seen)}')
    return 0

if __name__=='__main__':
    try: raise SystemExit(main())
    except StructuredContractError as exc:
        print(f'STRUCTURED_CONTRACT_FAIL: {exc}',file=sys.stderr); raise SystemExit(1)
