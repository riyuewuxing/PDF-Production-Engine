"""Canonical formal Teaching Demo visual-QA renderer.

The complete formal current-run render capability lives in ``render_product``.
Import and CLI callers converge on that function.  Accepted-content prebuild
validation runs before any render-directory delete/create, PNG materialization or
render-manifest write.  Low-level one-PDF rasterization remains a primitive and does
not itself authorize a complete formal QA render.
"""
from __future__ import annotations

import argparse
import hashlib
from pathlib import Path
import shutil
import subprocess

import yaml

from check_teaching_demo_inputs import validate as validate_teaching_demo_inputs
import publisher_core as core
from pdf_text_occupancy import analyze_pdf, evaluate as evaluate_occupancy, selftest as occupancy_selftest

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_MANIFEST = "production/current-run.yaml"


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _safe_repo_path(raw: str | Path) -> Path:
    rel = Path(raw)
    if rel.is_absolute() or ".." in rel.parts:
        raise SystemExit(f"repository-relative manifest/output path required: {raw}")
    path = (ROOT / rel).resolve()
    path.relative_to(ROOT.resolve())
    return path


def load_cfg(manifest_raw: str | None = None) -> tuple[Path, dict, Path, Path]:
    raw = manifest_raw or DEFAULT_MANIFEST
    manifest = _safe_repo_path(raw)
    if not manifest.is_file():
        raise SystemExit(f"manifest missing: {raw}")
    cfg = yaml.safe_load(manifest.read_text(encoding="utf-8")) or {}
    if not isinstance(cfg, dict):
        raise SystemExit("manifest top level must be mapping")
    pdf_dir = _safe_repo_path(str(cfg.get("pdf_dir") or "outputs/current-run"))
    render_dir = _safe_repo_path(str(cfg.get("render_dir") or "qa/current-run-rendered"))
    return manifest, cfg, pdf_dir, render_dir


def declared_pdfs(cfg: dict, contract: dict, pdf_dir: Path) -> list[Path]:
    deliverables = cfg.get("deliverables") or {}
    expected_roles = [str(doc["deliverable_role"]) for doc in (contract.get("documents") or {}).values()]
    names: list[str] = []
    for role in expected_roles:
        if role not in deliverables:
            raise SystemExit(f"manifest deliverable role missing: {role}")
        names.append(str(deliverables[role]))
    extras = sorted(set(deliverables) - set(expected_roles))
    if extras:
        raise SystemExit("undeclared product deliverable role(s): " + ", ".join(extras))
    if len(names) != len(set(names)):
        raise SystemExit("manifest contains duplicate deliverable filenames")
    paths: list[Path] = []
    for name in names:
        candidate = (pdf_dir / name).resolve()
        candidate.relative_to(pdf_dir.resolve())
        paths.append(candidate)
    return paths


def render_pdf(pdf: Path, out: Path, dpi: int) -> list[Path]:
    """Rasterize one already-selected PDF; this is not the formal aggregate route."""
    out.mkdir(parents=True, exist_ok=True)
    prefix = out / "page"
    proc = subprocess.run(
        ["pdftoppm", "-png", "-r", str(dpi), str(pdf), str(prefix)],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )
    if proc.returncode:
        raise SystemExit(f"pdftoppm failed for {pdf.name}:\n{proc.stdout}")
    pages = sorted(out.glob("page-*.png"))
    if not pages:
        raise SystemExit(f"no rendered pages for {pdf.name}")
    return pages


def selftest() -> None:
    occupancy_selftest()
    contract = {
        "documents": {
            "x": {"deliverable_role": "alpha"},
            "y": {"deliverable_role": "beta"},
        },
        "render": {"dpi": 200},
    }
    cfg = {"deliverables": {"alpha": "a.pdf", "beta": "b.pdf"}}
    paths = declared_pdfs(cfg, contract, ROOT / "outputs/current-run")
    assert [p.name for p in paths] == ["a.pdf", "b.pdf"]
    try:
        declared_pdfs(
            {"deliverables": {"alpha": "a.pdf", "beta": "a.pdf"}},
            contract,
            ROOT / "outputs/current-run",
        )
    except SystemExit:
        pass
    else:
        raise AssertionError("duplicate deliverable names escaped")
    assert core.render_dpi(contract) == 200


def render_product(manifest_path: str | None = None) -> dict:
    """Render the complete formal QA package only after accepted-content prebuild PASS."""
    selftest()
    manifest, cfg, pdf_dir, render_dir = load_cfg(manifest_path)
    manifest_raw = manifest.relative_to(ROOT.resolve()).as_posix()

    # No formal render-output mutation may occur before this gate.  Font compilation
    # was already a build concern; render still rechecks case/content/publication
    # semantics and the independent accepted-content boundary.
    input_errors = validate_teaching_demo_inputs(
        manifest_raw,
        root=ROOT,
        run_font_probe=False,
    )
    if input_errors:
        raise SystemExit(
            "formal render input gate failed before QA render:\n" + "\n".join(input_errors)
        )

    contract = core.load_product_contract(cfg, ROOT)
    binding = core.validate_manifest_binding(cfg, contract)
    if binding:
        raise SystemExit("\n".join(binding))
    occupancy_policy = core.qa_policy(contract).get("visual_occupancy") or {}
    declared = declared_pdfs(cfg, contract, pdf_dir)
    actual = sorted(pdf_dir.glob("*.pdf")) if pdf_dir.exists() else []
    missing = [p.name for p in declared if not p.exists()]
    extras = sorted(p.name for p in actual if p not in declared)
    if missing:
        raise SystemExit("declared PDF(s) missing before visual render: " + ", ".join(missing))
    if extras:
        raise SystemExit("undeclared PDF(s) present before visual render: " + ", ".join(extras))

    dpi = core.render_dpi(contract)

    # First formal render-output mutation.  The accepted gate above is already PASS.
    if render_dir.exists():
        shutil.rmtree(render_dir)
    render_dir.mkdir(parents=True, exist_ok=True)

    total = 0
    evidence_manifest = {
        "version": 1,
        "manifest": manifest_raw,
        "render_dpi": dpi,
        "occupancy_policy": occupancy_policy,
        "documents": [],
        "warnings": [],
        "errors": [],
        "human_review_required": True,
    }
    for pdf in declared:
        pages = render_pdf(pdf, render_dir / pdf.stem, dpi)
        total += len(pages)
        metrics = analyze_pdf(pdf)
        warnings, errors = evaluate_occupancy(metrics, occupancy_policy)
        if len(metrics) != len(pages):
            errors.append(
                f"VISUAL_OCCUPANCY_PAGE_COUNT_DRIFT: bbox={len(metrics)} rendered={len(pages)}"
            )
        doc = {
            "pdf": pdf.relative_to(ROOT.resolve()).as_posix(),
            "sha256": _sha256(pdf),
            "rendered_pages": len(pages),
            "occupancy": metrics,
            "warnings": warnings,
            "errors": errors,
        }
        evidence_manifest["documents"].append(doc)
        evidence_manifest["warnings"].extend(f"{pdf.name}: {x}" for x in warnings)
        evidence_manifest["errors"].extend(f"{pdf.name}: {x}" for x in errors)
        print(f"{pdf.name}: {len(pages)} pages at {dpi}dpi")
        for warning in warnings:
            print("WARNING:", pdf.name, warning)

    evidence = render_dir / "render-manifest.yaml"
    evidence.write_text(
        yaml.safe_dump(evidence_manifest, allow_unicode=True, sort_keys=False),
        encoding="utf-8",
    )
    print(f"render evidence: {evidence.relative_to(ROOT.resolve())}")
    if evidence_manifest["errors"]:
        raise SystemExit(
            "visual occupancy machine gate failed:\n"
            + "\n".join(str(x) for x in evidence_manifest["errors"])
        )
    print(f"visual QA render ready: {total} pages at {dpi}dpi")
    print(
        "IMPORTANT: every rendered page must still be opened and inspected; "
        "render/occupancy success is not HUMAN visual acceptance."
    )
    return {
        "manifest": manifest_raw,
        "render_dir": render_dir.relative_to(ROOT.resolve()).as_posix(),
        "render_manifest": evidence.relative_to(ROOT.resolve()).as_posix(),
        "rendered_pages": total,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", default=None)
    parser.add_argument("--selftest", action="store_true")
    args = parser.parse_args()
    if args.selftest:
        selftest()
        print("PASS: formal Teaching Demo render selftest")
        return 0
    render_product(args.manifest)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
