"""Static checks for teacher self-introduction contracts, sources, templates and final closure.

This checker never invents candidate facts, calls an LLM, or assumes a Yunnan-wide interview format.
It checks repository declarations only. PDF visual QA remains a separate render-and-inspect gate.
"""
from __future__ import annotations

from pathlib import Path
import re
import sys
import yaml

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "content/job-search/teacher/self-introduction"
P = {
    "rules": BASE / "AGENTS.md",
    "readme": BASE / "README.md",
    "prior_art": BASE / "references/prior-art.md",
    "sources": BASE / "sources/source-registry.yaml",
    "scan": BASE / "sources/yunnan-self-introduction-scan-2026-08.md",
    "scope": BASE / "scopes/yunnan-teacher-self-introduction-v1.yaml",
    "contract": BASE / "contracts/teacher-self-introduction-material-pack-v1.yaml",
    "fact_schema": BASE / "schemas/fact-item-v1.yaml",
    "story_schema": BASE / "schemas/story-item-v1.yaml",
    "fact_template": BASE / "materials/yunnan/r1/templates/fact-bank-template.yaml",
    "story_template": BASE / "materials/yunnan/r1/templates/story-bank-template.yaml",
    "assembly_template": BASE / "materials/yunnan/r1/templates/assembly-template.yaml",
    "fill_registry": BASE / "materials/yunnan/r1/templates/fill-in-template-registry-v1.yaml",
    "r1_acceptance": BASE / "materials/yunnan/r1/ROUND1_ACCEPTANCE.md",
    "core_final": BASE / "materials/yunnan/r2/00_云南教师求职自我介绍核心资料.md",
    "fill_final": BASE / "materials/yunnan/r2/01_教师自我介绍填空模板册.md",
    "qa_final": BASE / "materials/yunnan/r2/02_claim_evidence_followup_QA.md",
    "manifest_final": BASE / "materials/yunnan/r2/final-manifest.yaml",
    "acceptance_final": BASE / "materials/yunnan/r2/FINAL_ACCEPTANCE.md",
    "publisher": ROOT / "tools/publish_yunnan_self_introduction.py",
}
SUPPORTED_SECONDS = [30, 60, 90, 120, 180]
BLOCKS = {f"B{i}" for i in range(1, 7)}
PROFILES = {
    "generic", "fresh-graduate", "experienced-teacher", "career-switch",
    "high-school-physics", "low-experience", "strong-evidence",
}


class CheckError(ValueError):
    pass


def yload(path: Path):
    if not path.exists():
        raise CheckError(f"missing: {path.relative_to(ROOT)}")
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    if data is None:
        raise CheckError(f"empty yaml: {path.relative_to(ROOT)}")
    return data


def require_text(path: Path, tokens: list[str]):
    text = path.read_text(encoding="utf-8")
    for token in tokens:
        if token not in text:
            raise CheckError(f"{path.name}: missing token {token!r}")
    return text


def check_prior_art() -> int:
    text = require_text(P["prior_art"], ["License:", "Reuse decision:", "Explicit rejection:", "Code/text copying:"])
    repos = set(re.findall(r"Repository:\s*`([^`]+/[^`]+)`", text))
    if len(repos) < 3:
        raise CheckError("prior-art must compare >=3 repositories")
    if "Brag-Bank" in text and "未声明OSS license" not in text:
        raise CheckError("unlicensed prior-art must remain reference-only")
    return len(repos)


def check_sources() -> int:
    data = yload(P["sources"])
    sources = data.get("sources") or {}
    if len(sources) < 8:
        raise CheckError("source registry too small for final closure")
    has_k12_yes = has_k12_no = has_anonymous = has_combined = False
    for sid, src in sources.items():
        if not str(src.get("url") or "").startswith("https://"):
            raise CheckError(f"{sid}: invalid url")
        kind = src.get("kind")
        intro = src.get("self_introduction") or {}
        if kind == "public-k12-employer-mirror" and intro.get("present") is True:
            has_k12_yes = True
        if kind == "official-k12-format-boundary" and intro.get("present") is False:
            has_k12_no = True
        if kind == "official-higher-ed-format" and intro.get("anonymous_rules"):
            has_anonymous = True
        if intro.get("combined_duration_minutes"):
            has_combined = True
    if not all([has_k12_yes, has_k12_no, has_anonymous, has_combined]):
        raise CheckError("source diversity missing K12 yes/no, anonymity, or combined-duration evidence")
    rules = "\n".join(data.get("rules") or [])
    for token in ("not a unified", "combined duration", "unknown", "user facts"):
        if token not in rules:
            raise CheckError(f"source guard missing {token!r}")
    return len(sources)


def check_scope_contract():
    scope = yload(P["scope"])
    if scope.get("region") != "云南省" or scope.get("unified_province_profile") is not False:
        raise CheckError("scope must remain Yunnan geographic, not unified exam profile")
    seconds = [int(v.get("seconds")) for v in scope.get("version_matrix") or []]
    if seconds != SUPPORTED_SECONDS:
        raise CheckError(f"duration matrix drift: {seconds}")
    if set(scope.get("content_blocks") or {}) != BLOCKS:
        raise CheckError("B1-B6 block drift")

    c = yload(P["contract"])
    if c.get("default_mode") != "material-production":
        raise CheckError("artifact-first default drift")
    if (c.get("scope") or {}).get("unified_exam_profile") is not False:
        raise CheckError("contract creates unified Yunnan profile")
    if (c.get("fact_policy") or {}).get("strong_claims_require_evidence") is not True:
        raise CheckError("strong claim evidence guard missing")
    if (c.get("fact_policy") or {}).get("metrics_require_source") is not True:
        raise CheckError("numeric evidence guard missing")
    if (c.get("publication") or {}).get("runtime_llm_api") is not False:
        raise CheckError("runtime LLM/API must remain disabled")


def check_schemas_templates():
    fact = yload(P["fact_schema"])
    story = yload(P["story_schema"])
    for field in ("id", "status", "category", "value", "source_type", "source_reference", "numeric_claim"):
        if field not in (fact.get("fields") or {}):
            raise CheckError(f"fact schema missing {field}")
    for field in ("id", "status", "fact_ids", "responsibility", "actions", "result", "likely_followups"):
        if field not in (story.get("fields") or {}):
            raise CheckError(f"story schema missing {field}")

    fb = yload(P["fact_template"])
    for item in fb.get("facts") or []:
        if item.get("status") != "placeholder" or item.get("source_type") != "placeholder":
            raise CheckError("fact template must remain placeholder-only")
        if item.get("numeric_claim") is not False:
            raise CheckError("placeholder cannot carry numeric claim")
    sb = yload(P["story_template"])
    for item in sb.get("stories") or []:
        if item.get("status") != "placeholder":
            raise CheckError("story template must remain placeholder-only")
    assembly = yload(P["assembly_template"])
    if int((assembly.get("format") or {}).get("target_seconds") or 0) not in SUPPORTED_SECONDS:
        raise CheckError("assembly duration unsupported")


def check_fill_templates() -> tuple[int, int]:
    reg = yload(P["fill_registry"])
    items = reg.get("templates") or []
    if len(items) != 18:
        raise CheckError(f"r1 fill registry count drift: {len(items)}")
    ids = [str(x.get("id")) for x in items]
    expected_ids = [f"SI-FILL-{i:03d}" for i in range(1, 19)]
    if ids != expected_ids:
        raise CheckError("fill registry IDs/order drift")
    if not PROFILES.issubset({str(x.get("candidate_profile")) for x in items}):
        raise CheckError("candidate profile coverage incomplete")

    text = P["fill_final"].read_text(encoding="utf-8")
    final_ids = sorted(set(re.findall(r"SI-FILL-\d{3}", text)))
    if final_ids != expected_ids:
        raise CheckError(f"final template book ids incomplete: {final_ids}")
    slot_count = len(re.findall(r"【填写：[^】]+】", text))
    if slot_count < 250:
        raise CheckError(f"final template book unexpectedly sparse: slots={slot_count}")
    if re.search(r"提高了\s*\d+%|提升了\s*\d+%", text):
        raise CheckError("hard-coded unsupported percentage found")
    return len(final_ids), slot_count


def check_final_closure(template_count: int, slot_count: int):
    manifest = yload(P["manifest_final"])
    if manifest.get("status") != "final-content-closed" or manifest.get("content_round") != 2:
        raise CheckError("final manifest closure drift")
    if (manifest.get("closure") or {}).get("content_complete") is not True:
        raise CheckError("content_complete must be true")
    if (manifest.get("closure") or {}).get("no_third_content_round") is not True:
        raise CheckError("third content round must remain closed")
    if (manifest.get("publication") or {}).get("publisher") != "tools/publish_yunnan_self_introduction.py":
        raise CheckError("publisher route drift")
    if (manifest.get("publication") or {}).get("runtime_llm_api") is not False:
        raise CheckError("final publisher cannot use runtime LLM/API")
    final = manifest.get("final_content") or {}
    if int(final.get("fill_in_template_count") or 0) != template_count:
        raise CheckError("final template count mismatch")
    if int((manifest.get("qa") or {}).get("visible_slot_count_final_source") or 0) != slot_count:
        raise CheckError("final slot count mismatch")

    require_text(P["core_final"], ["Fact Bank", "Story / Evidence Bank", "Claim -> Evidence -> Follow-up", "Personalized-ready"])
    require_text(P["qa_final"], ["18/18", "276", "R0", "R1", "R2", "R3"])
    acceptance = require_text(P["acceptance_final"], ["stable production", "200 DPI", "32/32页", "不写 machine PASS"])
    if "第二轮全部完成" not in acceptance:
        raise CheckError("final acceptance must close round 2")
    if not P["publisher"].exists():
        raise CheckError("publisher missing")
    pub_text = P["publisher"].read_text(encoding="utf-8")
    if "runtime LLM" not in pub_text or "reportlab" not in pub_text:
        raise CheckError("publisher declaration/import missing")


def main() -> int:
    for path in P.values():
        if not path.exists():
            raise CheckError(f"missing routed asset: {path.relative_to(ROOT)}")
    prior = check_prior_art()
    sources = check_sources()
    check_scope_contract()
    check_schemas_templates()
    template_count, slot_count = check_fill_templates()
    check_final_closure(template_count, slot_count)
    print("teacher-self-introduction static checks: PASS")
    print(f"prior_art={prior} sources={sources} templates={template_count} slots={slot_count}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except CheckError as exc:
        print(f"TEACHER_SELF_INTRO_CHECK_FAIL: {exc}", file=sys.stderr)
        raise SystemExit(1)
