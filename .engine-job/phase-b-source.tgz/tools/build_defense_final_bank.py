#!/usr/bin/env python3
"""Build the Product Round2 teacher-defense canonical bank deterministically.

Inputs are project-owned content. This script does not call an LLM/API and does not infer
Yunnan true-question identity or recruitment frequency. It enriches the 120 frozen Round1
seeds through explicit teaching policies and 48 reviewed physics answer authorities.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'content/job-search/teacher/interview/defense'
DEFAULT_SEEDS = BASE / 'materials/yunnan/final-quality-r1/question-seed-bank-v1.yaml'
DEFAULT_TEACHING = BASE / 'materials/yunnan/final-quality-r2/teaching-enrichment-policy-v1.yaml'
DEFAULT_PHYSICS = BASE / 'materials/yunnan/final-quality-r2/physics-answer-points-v1.yaml'
CANONICAL_PATH = 'content/job-search/teacher/interview/defense/materials/yunnan/final-quality-r2/canonical-bank-v2.yaml'


def load_yaml(path: Path) -> dict:
    data = yaml.safe_load(path.read_text(encoding='utf-8'))
    if not isinstance(data, dict):
        raise SystemExit(f'Invalid mapping: {path}')
    return data


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def git_blob_sha(path: Path) -> str:
    raw = path.read_bytes()
    h = hashlib.sha1()
    h.update(f'blob {len(raw)}\0'.encode())
    h.update(raw)
    return h.hexdigest()


def split_skeleton(raw: str) -> list[str]:
    parts = [x.strip() for x in re.split(r'\s*(?:->|→)\s*', raw) if x.strip()]
    if len(parts) < 3:
        parts = [x.strip() for x in re.split(r'[；;，,]', raw) if x.strip()]
    return parts[:5]


def teaching_point(dtype: str, token: str, index: int, total: int, prefix: str) -> str:
    t = token.strip()
    # High-value semantic transforms. The seed-specific token stays visible so the final checker
    # can prove that answer points are card-scoped rather than generic D-type boilerplate.
    rules = [
        (('证据', '诊断', '判据', '验证', '输出'), f'把“{t}”变成可观察证据：明确要看哪一个学生输出/教材事实，以及什么表现才支持你的判断。'),
        (('目标', '核心结果', '最低表现', '达标'), f'围绕“{t}”先给可执行的学习结果，并说明它怎样约束本课活动与评价，而不是只写抽象目标词。'),
        (('学情', '前置', '卡点', '误区', '分流'), f'对“{t}”说明具体认知起点或障碍，并给一个课堂内可快速确认的诊断动作；未知真实学情必须用条件表达。'),
        (('安全', '秩序', '风险'), f'处理“{t}”时先明确不可妥协的安全/课堂边界，再给现场动作和恢复学习的路径。'),
        (('替代', '方案', '调整', '修正', '重构', '补救'), f'针对“{t}”给出一个具体替代动作，并说明何时触发、它解决什么学习问题、怎样再验证。'),
        (('表征', '图像', '公式', '实验', '板书'), f'说明“{t}”承担的认知功能以及它和另一种表征之间怎样转换，避免把工具/形式本身当作教学目的。'),
        (('后续', '迁移', '连接'), f'把“{t}”落到一个后续学习任务，说明本课哪一结果会被再次调用，从而证明当前内容取舍有依据。'),
        (('边界', '条件', '取舍', '可后移', '舍弃'), f'对“{t}”明确适用边界或舍弃条件，说明什么可以后移、什么不能删，以及判断依据。'),
        (('学生', '参与', '主体', '行为'), f'围绕“{t}”说明学生实际承担的认知任务和产出，不用“参与积极/体现主体”替代学习证据。'),
        (('原因', '依据', '作用', '功能', '价值'), f'解释“{t}”时给出因果链：它解决什么学习问题、提供什么信息/支架、怎样影响下一步决策。'),
    ]
    sentence = None
    for keywords, candidate in rules:
        if any(k in t for k in keywords):
            sentence = candidate
            break
    if sentence is None:
        phase = ['先判断', '再落证据', '给课堂动作', '说明边界', '回到验证'][min(index, 4)]
        sentence = f'{phase}“{t}”：用当前课的具体内容/任务/学生输出说明，不把该词本身当成解释。'
    return f'{prefix}：{sentence}'


def build_teaching_followups(seed: dict, steps: list[str]) -> list[str]:
    """Create two natural, non-synonym, card-scoped oral drills.

    A asks for evidence in the language of the D-type. B changes a condition/failure state.
    Both bind to seed-specific skeleton nodes so they remain standalone-distinct without
    repeating the full primary question.
    """
    dtype = seed['defense_type']
    focus = steps[0] if steps else seed['knowledge_cluster']
    stress = steps[-1] if steps else focus
    stem = re.sub(r'[？?。！!]', '', str(seed['question']).strip())
    if len(stem) > 18:
        stem = stem[:18] + '…'

    evidence_templates = {
        'D1': f'就“{stem}”，只用当前课一个具体教材/任务证据证明你对“{focus}”的判断；这个证据怎样影响内容取舍？',
        'D2': f'就“{stem}”，给出一个学生可观察输出，说明你怎样判断“{focus}”已经落实，而不是只说目标名称。',
        'D3': f'就“{stem}”，指出当前课一个具体环节产出，证明“{focus}”确实服务学习，而不是形式安排。',
        'D4': f'就“{stem}”，给出一个你会观察到的学生表现，用它判断“{focus}”是否真的存在；看见后第一步做什么？',
        'D5': f'就“{stem}”，给出一个学生输出和判据，说明你怎样用证据判断“{focus}”，而不是凭感觉评价。',
        'D6': f'就“{stem}”，指出刚才试讲中一个具体片段或学习后果，说明你为什么把“{focus}”判定为需要反思的点。',
        'D8': f'就“{stem}”，只用当前课一个具体环节证明“{focus}”，并说清学生承担了什么认知任务。',
    }
    follow_a = evidence_templates[dtype]

    stress_templates = {
        'D1': f'在“{stem}”这个情境下，如果“{stress}”这一条件或后续需求与原先判断不同，你会怎样重新划定本课边界或调整顺序？',
        'D2': f'在“{stem}”这个情境下，如果围绕“{stress}”取得的证据不能支持目标达成，你会先改评价任务、教学活动还是目标表述？为什么？',
        'D3': f'在“{stem}”这个情境下，如果“{stress}”没有产生预期学习作用，你会保留、替换还是删除这个设计？请给替代动作和判断依据。',
        'D4': f'在“{stem}”这个情境下，如果处理到“{stress}”后学生仍然卡住或课堂状态没有改善，你怎样再次诊断，并换哪一种支架？',
        'D5': f'在“{stem}”这个情境下，如果从“{stress}”得到的证据与预期不一致，你会怎样调整后续教学，而不是只把结果记成对或错？',
        'D6': f'在“{stem}”这个情境下，如果按“{stress}”修正后学习结果仍无改善，你会继续局部修补，还是重构关键环节？依据是什么？',
        'D8': f'在“{stem}”这个情境下，如果“{stress}”与学生基础、课堂时间或安全边界发生冲突，你怎样取舍，同时保住核心学习目标？',
    }
    follow_b = stress_templates[dtype]
    return [follow_a, follow_b]


def build_teaching_card(seed: dict, profiles: dict) -> dict:
    dtype = seed['defense_type']
    profile = profiles[dtype]
    steps = split_skeleton(seed['compact_skeleton'])
    prefixes = list(profile.get('point_prefixes') or [])
    if not prefixes:
        prefixes = ['先判断', '再落证据', '给课堂动作', '说明边界', '回到验证']
    points = [
        teaching_point(dtype, token, i, len(steps), prefixes[min(i, len(prefixes) - 1)])
        for i, token in enumerate(steps)
    ]
    if len(points) < 3:
        points.append('回到验证：最后给出一个可观察的再次取证动作，确认你的教学判断真的改善了学生学习。')
    points = points[:5]
    card_focus = steps[0] if steps else seed['knowledge_cluster']
    return {
        'id': seed['id'],
        'status': 'mother-template',
        'source_identity': 'derived-defense-question',
        'source_basis': ['DEF-STD-MOE-001'],
        'defense_type': dtype,
        'topic_dependency': 'lesson-bound',
        'material_file': CANONICAL_PATH,
        'question': seed['question'],
        'examiner_intent': f"{profile['examiner_intent']} 本题特别检查“{card_focus}”是否真正落到当前课证据与教学决策。",
        'evidence_anchor': profile['evidence_anchor'],
        'current_lesson_reference': None,
        'subject_fact_source': None,
        'format_source_reference': None,
        'knowledge_cluster': seed['knowledge_cluster'],
        'training_tier': seed['training_tier'],
        'answer_time_seconds': seed['answer_time_seconds'],
        'compact_skeleton': seed['compact_skeleton'],
        'answer_points': points,
        'followups': build_teaching_followups(seed, steps),
        'red_flags': list(profile['red_flags'])[:4],
        'self_score_dimensions': list(profile['self_score_dimensions']),
        'volume': profile['volume'],
        'views': ['detail', 'practice', 'quick-reference'],
    }


def physics_volume(cluster: str) -> str:
    if cluster.startswith('mechanics-') or cluster.startswith('thermal-'):
        return 'physics-mechanics-thermal'
    return 'physics-em-optics-modern-experiment'


def build_physics_card(seed: dict, authority: dict, common: dict) -> dict:
    return {
        'id': seed['id'],
        'status': 'mother-template',
        'source_identity': 'derived-defense-question',
        'source_basis': ['DEF-SUBJ-HS-PHYS-STD-2020'],
        'defense_type': 'D7',
        'topic_dependency': 'topic-adaptable',
        'material_file': CANONICAL_PATH,
        'question': seed['question'],
        'examiner_intent': authority['examiner_intent'],
        'evidence_anchor': common['evidence_anchor'],
        'current_lesson_reference': None,
        'subject_fact_source': {
            'baseline': 'content/job-search/teacher/interview/defense/sources/physics-subject-basis-v1.yaml',
            'ids': ['DEF-SUBJ-HS-PHYS-STD-2020'],
            'topic_specific_cross_check_required': True,
        },
        'format_source_reference': None,
        'knowledge_cluster': seed['knowledge_cluster'],
        'training_tier': seed['training_tier'],
        'answer_time_seconds': seed['answer_time_seconds'],
        'compact_skeleton': seed['compact_skeleton'],
        'answer_points': list(authority['answer_points']),
        'followups': list(authority['followups'])[:2],
        'red_flags': list(authority['red_flags'])[:4],
        'self_score_dimensions': list(common['self_score_dimensions']),
        'volume': physics_volume(seed['knowledge_cluster']),
        'views': ['detail', 'practice', 'quick-reference'],
    }


def norm(text: str) -> str:
    return re.sub(r'[\W_]+', '', text, flags=re.UNICODE).lower()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--seeds', type=Path, default=DEFAULT_SEEDS)
    parser.add_argument('--teaching-policy', type=Path, default=DEFAULT_TEACHING)
    parser.add_argument('--physics-authority', type=Path, default=DEFAULT_PHYSICS)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--metrics', type=Path)
    args = parser.parse_args(argv)

    seeds = load_yaml(args.seeds)
    teaching_policy = load_yaml(args.teaching_policy)
    physics_policy = load_yaml(args.physics_authority)

    teaching = (seeds.get('teaching_variants') or {}).get('items') or []
    physics = (seeds.get('physics_variants') or {}).get('items') or []
    profiles = teaching_policy['profiles']
    physics_by_id = {x['id']: x for x in physics_policy['items']}

    if len(teaching) != 72 or len(physics) != 48:
        raise SystemExit(f'Round1 seed count drift: teaching={len(teaching)} physics={len(physics)}')
    missing = sorted(set(x['id'] for x in physics) - set(physics_by_id))
    extra = sorted(set(physics_by_id) - set(x['id'] for x in physics))
    if missing or extra:
        raise SystemExit(f'Physics authority mismatch missing={missing} extra={extra}')

    cards = [build_teaching_card(x, profiles) for x in teaching]
    cards += [build_physics_card(x, physics_by_id[x['id']], physics_policy['common']) for x in physics]

    volumes: dict[str, int] = {}
    for card in cards:
        volumes[card['volume']] = volumes.get(card['volume'], 0) + 1
    all_followups = [followup for card in cards for followup in card['followups']]
    unique_followups = len({norm(x) for x in all_followups})

    output = {
        'version': 2,
        'id': 'yunnan-teacher-defense-canonical-bank-v2',
        'status': 'PRODUCT_ROUND2_CANONICAL',
        'identity': 'project-authored-training-bank',
        'claim': '120 canonical training cards; not Yunnan true questions and not frequency claims.',
        'source_bindings': {
            'round1_seed': {
                'path': str(args.seeds.relative_to(ROOT)) if args.seeds.is_relative_to(ROOT) else str(args.seeds),
                'git_blob_sha': git_blob_sha(args.seeds),
                'sha256': sha256(args.seeds),
            },
            'teaching_policy': {
                'path': str(args.teaching_policy.relative_to(ROOT)) if args.teaching_policy.is_relative_to(ROOT) else str(args.teaching_policy),
                'git_blob_sha': git_blob_sha(args.teaching_policy),
                'sha256': sha256(args.teaching_policy),
            },
            'physics_authority': {
                'path': str(args.physics_authority.relative_to(ROOT)) if args.physics_authority.is_relative_to(ROOT) else str(args.physics_authority),
                'git_blob_sha': git_blob_sha(args.physics_authority),
                'sha256': sha256(args.physics_authority),
            },
        },
        'metrics': {
            'canonical_card_count': len(cards),
            'teaching_card_count': len(teaching),
            'physics_card_count': len(physics),
            'followups_per_card': 2,
            'followup_prompt_count': len(cards) * 2,
            'unique_followup_prompt_count': unique_followups,
            'effective_training_prompt_count': len(cards) * 3,
            'source_bound_special_card_count': 18,
            'effective_training_prompt_definition': 'primary canonical question + two card-scoped non-synonym followups',
        },
        'volume_counts': volumes,
        'cards': cards,
    }

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(yaml.safe_dump(output, allow_unicode=True, sort_keys=False, width=140), encoding='utf-8')
    metrics = {
        'status': 'MACHINE_PASS',
        'canonical_bank_sha256': sha256(args.output),
        'canonical_bank_git_blob_sha': git_blob_sha(args.output),
        **output['metrics'],
        'volume_counts': volumes,
    }
    if args.metrics:
        args.metrics.parent.mkdir(parents=True, exist_ok=True)
        args.metrics.write_text(json.dumps(metrics, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(metrics, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
