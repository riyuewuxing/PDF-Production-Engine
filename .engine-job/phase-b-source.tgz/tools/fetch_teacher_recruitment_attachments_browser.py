#!/usr/bin/env python3
"""Playwright request/click fallback for Phase9 official recruitment attachments."""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from dataclasses import asdict
from pathlib import Path
from urllib.parse import urljoin

import yaml
from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
from playwright.sync_api import sync_playwright

from fetch_teacher_recruitment_attachments import (
    AttachmentCandidate,
    DownloadRecord,
    USER_AGENT,
    classify_source,
    clean_filename,
    infer_extension,
    is_attachment_anchor,
    utc_now,
    validate_binary,
)


def load_existing(path: Path) -> dict:
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    return {"version": 1, "id": "phase9-attachment-live-regression-result", "records": [], "articles": []}


def best_records(records: list[dict]) -> list[dict]:
    best: dict[str, dict] = {}
    for rec in records:
        url = rec.get("attachment_url")
        if not url:
            continue
        old = best.get(url)
        if old is None or (not old.get("validation_ok") and rec.get("validation_ok")):
            best[url] = rec
    return list(best.values())


def validate_saved(candidate: AttachmentCandidate, path: Path, backend: str, final_url: str | None = None,
                   content_type: str | None = None) -> DownloadRecord:
    data = path.read_bytes()
    digest = hashlib.sha256(data).hexdigest() if data else None
    ok, kind = validate_binary(path, candidate.expected_extension, content_type)
    return DownloadRecord(
        **asdict(candidate), final_url=final_url or candidate.attachment_url, backend=backend,
        filename=path.name, content_type=content_type, size_bytes=len(data), sha256=digest,
        validation_ok=ok, validation_kind=kind,
        failure_class=None if ok else "binary-validation-failed",
        failure_detail=None if ok else kind, captured_at=utc_now(),
    )


def click_capture(page, anchor, candidate: AttachmentCandidate, files_dir: Path) -> DownloadRecord:
    try:
        with page.expect_download(timeout=20000) as info:
            anchor.click(timeout=15000)
        download = info.value
        name = clean_filename(download.suggested_filename or candidate.anchor_text or candidate.article_id)
        if candidate.expected_extension and not name.lower().endswith(candidate.expected_extension):
            name += candidate.expected_extension
        target = files_dir / name
        if target.exists():
            target = files_dir / f"{target.stem}-{hashlib.sha256(candidate.attachment_url.encode()).hexdigest()[:8]}{target.suffix}"
        download.save_as(str(target))
        failure = download.failure()
        if failure:
            target.unlink(missing_ok=True)
            raise RuntimeError(failure)
        return validate_saved(candidate, target, "playwright-download", final_url=download.url)
    except PlaywrightTimeoutError as exc:
        return DownloadRecord(
            **asdict(candidate), final_url=None, backend="playwright-download", filename=None,
            content_type=None, size_bytes=0, sha256=None, validation_ok=False, validation_kind=None,
            failure_class="download-event-timeout", failure_detail=str(exc), captured_at=utc_now(),
        )
    except Exception as exc:
        return DownloadRecord(
            **asdict(candidate), final_url=None, backend="playwright-download", filename=None,
            content_type=None, size_bytes=0, sha256=None, validation_ok=False, validation_kind=None,
            failure_class="download-event-failed", failure_detail=f"{type(exc).__name__}: {exc}", captured_at=utc_now(),
        )


def browser_request_capture(context, candidate: AttachmentCandidate, files_dir: Path) -> DownloadRecord:
    try:
        response = context.request.get(
            candidate.attachment_url,
            headers={"Referer": candidate.article_url, "Accept": "*/*", "User-Agent": USER_AGENT},
            timeout=30000,
        )
        if not response.ok:
            raise RuntimeError(f"HTTP {response.status}")
        body = response.body()
        name = clean_filename(candidate.anchor_text or candidate.article_id)
        if candidate.expected_extension and not name.lower().endswith(candidate.expected_extension):
            name += candidate.expected_extension
        target = files_dir / name
        if target.exists():
            target = files_dir / f"{target.stem}-{hashlib.sha256(candidate.attachment_url.encode()).hexdigest()[:8]}{target.suffix}"
        target.write_bytes(body)
        return validate_saved(candidate, target, "playwright-request", final_url=response.url,
                              content_type=response.headers.get("content-type"))
    except Exception as exc:
        return DownloadRecord(
            **asdict(candidate), final_url=None, backend="playwright-request", filename=None,
            content_type=None, size_bytes=0, sha256=None, validation_ok=False, validation_kind=None,
            failure_class="browser-request-failed", failure_detail=f"{type(exc).__name__}: {exc}", captured_at=utc_now(),
        )


def run(manifest_path: Path, out_dir: Path) -> int:
    cfg = yaml.safe_load(manifest_path.read_text(encoding="utf-8"))
    articles = cfg.get("articles") or []
    policy = cfg.get("policy") or {}
    out_dir.mkdir(parents=True, exist_ok=True)
    files_dir = out_dir / "files"
    files_dir.mkdir(exist_ok=True)
    result_path = out_dir / "attachment-capture-manifest.json"
    existing = load_existing(result_path)
    records: list[dict] = list(existing.get("records") or [])
    article_results = {a.get("article_id"): a for a in (existing.get("articles") or [])}
    already_valid = {r.get("attachment_url") for r in records if r.get("validation_ok")}
    discovered_urls = {r.get("attachment_url") for r in records if r.get("attachment_url")}

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        context = browser.new_context(user_agent=USER_AGENT, accept_downloads=True)
        for article in articles:
            page = context.new_page()
            browser_error = None
            browser_discovered = 0
            try:
                page.goto(article["article_url"], wait_until="domcontentloaded", timeout=45000)
                anchors = page.locator("a").all()
                for anchor in anchors:
                    try:
                        href = (anchor.get_attribute("href") or "").strip()
                        text = (anchor.inner_text(timeout=2000) or "").strip()
                    except Exception:
                        continue
                    if not is_attachment_anchor(href, text):
                        continue
                    absolute = urljoin(article["article_url"], href)
                    candidate = AttachmentCandidate(
                        article_id=article["article_id"], event_id=article["event_id"],
                        article_url=article["article_url"], attachment_url=absolute, anchor_text=text,
                        source_class=classify_source(absolute), expected_extension=infer_extension(absolute, text),
                    )
                    discovered_urls.add(absolute)
                    browser_discovered += 1
                    if absolute in already_valid:
                        continue

                    # First reuse the real browser context/cookies without navigating away from the article.
                    req = browser_request_capture(context, candidate, files_dir)
                    records.append(asdict(req))
                    if req.validation_ok:
                        already_valid.add(absolute)
                        continue

                    # Only if browser-context HTTP still fails, use the actual download event from the anchor.
                    rec = click_capture(page, anchor, candidate, files_dir)
                    records.append(asdict(rec))
                    if rec.validation_ok:
                        already_valid.add(absolute)
            except Exception as exc:
                browser_error = f"{type(exc).__name__}: {exc}"
            finally:
                article_results[article["article_id"]] = {
                    **article_results.get(article["article_id"], {}),
                    "article_id": article["article_id"], "event_id": article["event_id"],
                    "article_url": article["article_url"],
                    "expected_attachment_count": int(article.get("expected_attachment_count", 0)),
                    "browser_discovered": browser_discovered, "browser_page_error": browser_error,
                }
                page.close()
        context.close()
        browser.close()

    final_records = best_records(records)
    valid = [r for r in final_records if r.get("validation_ok")]
    failed = [r for r in final_records if not r.get("validation_ok")]
    expected_total = int(policy.get("expected_total_attachments", 0))
    required_classes = set(policy.get("source_class_coverage_required") or [])
    valid_classes = sorted({r.get("source_class") for r in valid if r.get("source_class")})
    summary = {
        "articles": len(articles),
        "expected_attachments": expected_total,
        "discovered_unique_attachments": len(discovered_urls),
        "binary_validated": len(valid),
        "binary_failed": len(failed),
        "source_classes_validated": valid_classes,
        "strong_pass_13_of_13": len(valid) == expected_total and len(discovered_urls) >= expected_total,
        "minimum_pass": bool(valid) and required_classes.issubset(set(valid_classes)),
    }
    merged = {
        "version": 1, "id": "phase9-attachment-live-regression-result",
        "executed_at": utc_now(), "manifest": str(manifest_path), "summary": summary,
        "articles": list(article_results.values()), "records": final_records,
    }
    result_path.write_text(json.dumps(merged, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0 if summary["minimum_pass"] else 2


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()
    return run(args.manifest, args.out)


if __name__ == "__main__":
    sys.exit(main())
