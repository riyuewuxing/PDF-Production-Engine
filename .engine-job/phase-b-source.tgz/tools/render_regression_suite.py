"""Render every built regression fixture PDF for visual QA.

Cases are discovered from manifests. Render DPI is shared product policy; a
fixture may not override it. Render success never certifies visual quality.
"""
from __future__ import annotations
from pathlib import Path
import shutil
import subprocess
import publisher_core as core
from regression_case import ROOT,discover_cases,load_case

OUT_ROOT=ROOT/'outputs/regression'
RENDER_ROOT=ROOT/'qa/regression-rendered'


def render_pdf(pdf:Path,out_dir:Path,dpi:int)->list[Path]:
    out_dir.mkdir(parents=True,exist_ok=True); prefix=out_dir/'page'
    proc=subprocess.run(['pdftoppm','-png','-r',str(dpi),str(pdf),str(prefix)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    if proc.returncode: raise SystemExit(f'pdftoppm failed for {pdf}:\n{proc.stdout}')
    pages=sorted(out_dir.glob('page-*.png'))
    if not pages: raise SystemExit(f'no rendered pages for {pdf}')
    return pages


def dpi_for_case(cfg:dict)->int:
    regression=cfg.get('regression_contract') or {}
    if 'visual_render_dpi' in regression:
        raise SystemExit('REGRESSION_SHARED_POLICY_LEAK: visual_render_dpi')
    contract=core.load_product_contract(cfg)
    return core.render_dpi(contract)


def selftest()->None:
    fake={'product_contract':'teacher-trial-two-pdf-v1','regression_contract':{}}
    assert dpi_for_case(fake)>=150
    leaked={'product_contract':'teacher-trial-two-pdf-v1','regression_contract':{'visual_render_dpi':240}}
    try: dpi_for_case(leaked)
    except SystemExit: pass
    else: raise AssertionError('fixture-local render DPI escaped shared-policy gate')


def main()->int:
    selftest(); cases=discover_cases()
    if not cases: raise SystemExit('no regression cases discovered')
    if RENDER_ROOT.exists(): shutil.rmtree(RENDER_ROOT)
    RENDER_ROOT.mkdir(parents=True,exist_ok=True)
    total_pdfs=0; total_pages=0
    for manifest in cases:
        cfg,case_dir,_=load_case(manifest); slug=case_dir.name; pdf_dir=OUT_ROOT/slug
        pdfs=sorted(pdf_dir.glob('*.pdf')) if pdf_dir.exists() else []
        if not pdfs: raise SystemExit(f'no built regression PDFs for fixture: {slug}')
        dpi=dpi_for_case(cfg)
        for pdf in pdfs:
            pages=render_pdf(pdf,RENDER_ROOT/slug/pdf.stem,dpi); total_pdfs+=1; total_pages+=len(pages)
            print(f'{slug}/{pdf.name}: {len(pages)} pages at {dpi}dpi')
    print(f'regression visual QA render ready: {total_pdfs} PDFs / {total_pages} pages')
    print('IMPORTANT: every rendered page must still be opened and inspected; this command does not certify visual quality.')
    return 0

if __name__=='__main__': raise SystemExit(main())
