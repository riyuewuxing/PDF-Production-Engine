#!/usr/bin/env python3
"""Machine regression for the structured-interview section pagination contract."""
from __future__ import annotations

import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PUBLISHER = ROOT / 'tools' / 'publish_yunnan_structured.py'


def main() -> int:
    source = PUBLISHER.read_text(encoding='utf-8')
    tree = ast.parse(source, filename=str(PUBLISHER))

    # Unconditional section PageBreak was the production failure class. The
    # scoped publisher must not regress to that primitive.
    imported = {
        alias.name
        for node in ast.walk(tree)
        if isinstance(node, ast.ImportFrom) and node.module == 'reportlab.platypus'
        for alias in node.names
    }
    if 'CondPageBreak' not in imported:
        raise SystemExit('structured pagination regression: CondPageBreak is not imported')
    if 'PageBreak' in imported:
        raise SystemExit('structured pagination regression: unconditional PageBreak reintroduced')

    calls = [
        node for node in ast.walk(tree)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == 'CondPageBreak'
    ]
    if len(calls) != 1 or len(calls[0].args) != 1:
        raise SystemExit('structured pagination regression: expected one declarative CondPageBreak budget')
    arg = calls[0].args[0]
    if not (
        isinstance(arg, ast.BinOp)
        and isinstance(arg.op, ast.Mult)
        and isinstance(arg.left, ast.Constant)
        and isinstance(arg.left.value, (int, float))
        and isinstance(arg.right, ast.Name)
        and arg.right.id == 'mm'
    ):
        raise SystemExit('structured pagination regression: section budget must be <number> * mm')
    budget_mm = float(arg.left.value)
    if not 50 <= budget_mm <= 80:
        raise SystemExit(f'structured pagination regression: unreasonable section budget {budget_mm} mm')

    # The conditional break is scoped to generic T1-T9 category boundaries;
    # never to a question id, fixed output page, or case-specific title.
    if "^T[1-9]" not in source:
        raise SystemExit('structured pagination regression: generic T1-T9 boundary matcher missing')
    forbidden = ('YN-REF-', 'YN-R2-', 'page-000', 'page_number ==', 'doc.page ==')
    leaks = [token for token in forbidden if token in source]
    if leaks:
        raise SystemExit(f'structured pagination regression: case/page special-casing found: {leaks}')

    print(f'structured pagination contract: PASS (conditional budget={budget_mm:g} mm)')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
