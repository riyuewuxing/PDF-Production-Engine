#!/usr/bin/env python3
"""Create one canonical Teaching Demo case scaffold.

The initializer creates structure only. It never writes finished teaching content.
Every new case is born on the single current content line defined by
production/contracts/teaching-demo-content.yaml and production/process/teaching-demo-content/PROCESS.md.
"""
from __future__ import annotations

import argparse
import hashlib
from pathlib import Path
import re
from typing import Any
import yaml

from artifact_foundation import ROOT, safe_repo_path

PRODUCT_CONTRACT_PATH = Path("production/contracts/teacher-trial-two-pdf-v1.yaml")
CONTENT_CONTRACT_PATH = Path("production/contracts/teaching-demo-content.yaml")
CASE_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*$")
HEX40_RE = re.compile(r"^[0-9a-f]{40}$")


def csv_ints(raw: str) -> list[int]:
    values = [x.strip() for x in raw.split(",") if x.strip()]
    out = [int(x) for x in values]
    if not out or any(x < 1 for x in out):
        raise ValueError("page list must contain positive integers")
    if len(set(out)) != len(out):
        raise ValueError("page list must not contain duplicates")
    return out


def _git_blob_sha(path: Path) -> str:
    raw = path.read_bytes()
    return hashlib.sha1(f"blob {len(raw)}\0".encode("ascii") + raw).hexdigest()


def load_contracts(root: Path = ROOT) -> tuple[dict[str, Any], dict[str, Any]]:
    product = yaml.safe_load((root / PRODUCT_CONTRACT_PATH).read_text(encoding="utf-8")) or {}
    content = yaml.safe_load((root / CONTENT_CONTRACT_PATH).read_text(encoding="utf-8")) or {}
    if product.get("id") != "teacher-trial-two-pdf-v1":
        raise ValueError("unexpected Teaching Demo product contract")
    case = product.get("case_manifest") or {}
    if case.get("schema_id") != "teacher-trial-case-v1" or case.get("schema_version") != 1:
        raise ValueError("Teaching Demo case schema authority missing")
    if content.get("id") != "teaching-demo-content" or content.get("status") != "ACTIVE_CANONICAL":
        raise ValueError("canonical Teaching Demo content contract missing")
    return product, content


def scaffold_paths(product: dict[str, Any]) -> dict[str, str]:
    raw = ((product.get("case_manifest") or {}).get("scaffold") or {}).get("source_files") or {}
    required = {"evidence", "board", "reference_plan", "exam_skeleton", "trial", "defense", "analysis"}
    if set(raw) != required or not all(isinstance(v, str) and v for v in raw.values()):
        raise ValueError("case scaffold source_files contract drift")
    return dict(raw)


def validate_args(args: argparse.Namespace) -> None:
    if not CASE_ID_RE.fullmatch(args.case_id):
        raise ValueError("case-id must match [A-Za-z0-9][A-Za-z0-9._-]*")
    if not args.title.strip() or not args.book.strip():
        raise ValueError("title/book must be non-empty")
    if args.book_id is not None and not str(args.book_id).strip():
        raise ValueError("book-id must be non-empty when provided")
    if not isinstance(args.source_repo, str) or "/" not in args.source_repo:
        raise ValueError("source-repo must be owner/repo")
    if not isinstance(args.source_path, str) or not args.source_path.strip():
        raise ValueError("source-path must be non-empty")
    if not HEX40_RE.fullmatch(args.source_ref):
        raise ValueError("source-ref must be a lowercase 40-char commit SHA")
    if not HEX40_RE.fullmatch(args.source_blob_sha):
        raise ValueError("source-blob-sha must be a lowercase 40-char git blob SHA")
    if args.source_size_bytes < 100_000:
        raise ValueError("source-size-bytes is suspiciously small")
    printed = csv_ints(args.printed_pages)
    physical = csv_ints(args.pdf_pages)
    if len(printed) != len(physical):
        raise ValueError("pdf-pages and printed-pages must have equal counts")
    if args.repository_source_file is not None and not str(args.repository_source_file).strip():
        raise ValueError("repository-source-file must be non-empty when provided")


def _source_pages(args: argparse.Namespace, *, root: Path) -> tuple[str, dict[str, Any]]:
    physical = csv_ints(args.pdf_pages)
    if args.repository_source_file:
        source_file = safe_repo_path(root, args.repository_source_file, must_exist=True)
        if not source_file.is_file():
            raise ValueError("repository-source-file must resolve to a file")
        if source_file.stat().st_size != args.source_size_bytes:
            raise ValueError("repository-source-file size does not match locked source-size-bytes")
        actual_blob = _git_blob_sha(source_file)
        if actual_blob != args.source_blob_sha:
            raise ValueError("repository-source-file Git blob does not match locked source-blob-sha")
        return "exact-page-repository", {
            "mode": "repository-pdf",
            "file": args.repository_source_file,
            "blob_sha": args.source_blob_sha,
            "size_bytes": args.source_size_bytes,
            "pages": physical,
            "audit_locator": {
                "repo": args.source_repo,
                "ref": args.source_ref,
                "path": args.source_path,
                "blob_sha": args.source_blob_sha,
            },
        }
    source_pages: dict[str, Any] = {
        "mode": "remote-pdf",
        "repo": args.source_repo,
        "ref": args.source_ref,
        "path": args.source_path,
        "blob_sha": args.source_blob_sha,
        "size_bytes": args.source_size_bytes,
        "pages": physical,
    }
    if args.source_url:
        source_pages["url"] = args.source_url
    return "exact-page-remote", source_pages


def build_manifest(args: argparse.Namespace, product: dict[str, Any], case_dir_rel: str, *, root: Path = ROOT) -> dict[str, Any]:
    scaffold = product["case_manifest"]["scaffold"]
    files = scaffold_paths(product)
    deliverable_templates = scaffold.get("deliverable_templates") or {}
    defaults = scaffold.get("default_constraints") or {}
    authority, source_pages = _source_pages(args, root=root)
    inp: dict[str, Any] = {
        "authority": authority,
        "book": args.book,
        "printed_pages": csv_ints(args.printed_pages),
        "source_pages": source_pages,
    }
    if args.book_id:
        inp["book_id"] = args.book_id
    return {
        "version": product["case_manifest"]["schema_version"],
        "schema_id": product["case_manifest"]["schema_id"],
        "instance_revision": 1,
        "mode": "single-run",
        "case_id": args.case_id,
        "title": args.title,
        "product_contract": product["id"],
        "content_contract": "teaching-demo-content",
        "workspace": case_dir_rel,
        "source": files,
        "deliverables": {role: str(template).format(title=args.title) for role, template in deliverable_templates.items()},
        "pdf_dir": f"outputs/teaching-demo/{args.case_id}",
        "tex_dir": f"outputs/teaching-demo/{args.case_id}-tex",
        "render_dir": f"qa/teaching-demo/{args.case_id}-rendered",
        "cache_dir": f"{case_dir_rel}/.source-cache",
        "constraints": {
            "board_sections_min": int(defaults.get("board_sections_min", 3)),
            "figure_count_min": args.figure_count_min,
        },
    }


def _dump(data: Any) -> str:
    return yaml.safe_dump(data, allow_unicode=True, sort_keys=False)


def scaffold_content(case_id: str, title: str, book: str, printed_pages: list[int], *, source_locator: dict[str, Any]) -> dict[str, str]:
    evidence = {
        "case_id": case_id,
        "title": title,
        "book": book,
        "printed_pages": printed_pages,
        "status": "scaffold",
        "scaffold_status": "INCOMPLETE",
        "source_locator": source_locator,
        "verification": {
            "exact_pages_verified": False,
            "page_text_verified": False,
            "canonical_pdf_pixels_inspected": False,
        },
        "evidence_units": [
            {"id": "E1", "kind": "TODO", "summary": "TODO: 实际查看题面/教材页后填写，不得凭记忆"}
        ],
    }
    science = {
        "case_id": case_id,
        "claims": [{
            "claim_id": "C1",
            "claim": "TODO",
            "evidence_refs": ["E1"],
            "direct_observation": "TODO",
            "inference": "TODO",
            "alternative_explanations": ["TODO"],
            "exclusion_or_limitation": "TODO",
            "max_justified_conclusion": "TODO",
            "boundary_not_claimed": "TODO",
            "misconception_risk": "TODO",
        }],
    }
    boundary = {"case_id": case_id, "must_teach": ["TODO"], "may_mention": [], "out_of_scope": ["TODO"]}
    points = {"case_id": case_id, "points": [{
        "point_id": "P1",
        "learning_gain": "TODO",
        "prerequisite_knowledge_ids": [],
        "evidence_or_resource_ids": ["E1"],
        "formation_cycle_id": "CY1",
        "next_need": "TODO",
        "out_of_scope_guard": "TODO",
    }]}
    students = {"case_id": case_id, "cycles": [{
        "cycle_id": "CY1",
        "point_id": "P1",
        "knows_before": ["TODO"],
        "visible_now": ["TODO"],
        "teacher_prompt": "TODO",
        "student_task": "observe",
        "plausible_short_response": "TODO",
        "likely_wrong_response": "TODO",
        "scaffold_1": "TODO",
        "scaffold_2": "TODO",
        "formed_knowledge_ids": ["K1"],
        "formation_evidence": "TODO",
    }]}
    resources = {"case_id": case_id, "resources": [{
        "resource_id": "R1",
        "asset_path_or_source_page": "TODO",
        "identity": "TODO",
        "reveal_before_cycle": "CY1",
        "teacher_action": "TODO",
        "student_observes": "TODO",
        "directly_observed": "TODO",
        "inferred_from_conditions": "TODO",
        "task": "TODO",
        "supports_claims": ["C1"],
    }]}
    board_plan = {"version": 3, "cases": [{
        "id": case_id,
        "layout": "formation-timeline",
        "fragments": {"B1": {"point_id": "P1", "label": "TODO", "text": "TODO"}},
    }]}
    board_timeline = {"case_id": case_id, "board_deltas": [{
        "delta_id": "B1",
        "trigger_cycle": "CY1",
        "prerequisite_knowledge_ids": ["K1"],
        "newly_formed_knowledge_ids": ["K1"],
        "add_only": ["TODO"],
        "forbidden_before_trigger": ["TODO: 尚未形成的答案/结论"],
    }]}
    enactment = {"case_id": case_id, "status": "ESTIMATE", "segments": [{
        "id": "T1",
        "spoken_equivalent": "TODO: 实际会说出的中文/公式口读",
        "speech_seconds_range": [0, 0],
        "board_seconds": 0,
        "resource_view_seconds": 0,
        "think_or_response_seconds": 0,
        "overlap": [],
    }]}
    preflight = {
        "case_id": case_id,
        "science_red_team": {"decision": "PENDING"},
        "student_state_simulation": {"decision": "PENDING"},
        "enactment_board_dry_run": {"decision": "PENDING"},
        "hard_fail_triggered": [],
    }
    trial = f"# {title}｜逐字稿\n\nTODO: 按 Student-State / Resource / Board Timeline 展开。\n\n[[BOARD:B1]]\n"
    return {
        "evidence.yaml": _dump(evidence),
        "SCIENCE_REASONING_AUDIT.yaml": _dump(science),
        "teaching-boundary.yaml": _dump(boundary),
        "point-chain.yaml": _dump(points),
        "STUDENT_STATE_LEDGER.yaml": _dump(students),
        "RESOURCE_ACTION_MAP.yaml": _dump(resources),
        "BOARD_PLAN.yaml": _dump(board_plan),
        "BOARD_TIMELINE.yaml": _dump(board_timeline),
        "ENACTMENT_TIMELINE.yaml": _dump(enactment),
        "semantic-preflight-review.yaml": _dump(preflight),
        "01_训练参考教案.md": f"# {title}｜训练参考教案\n\nTODO: 先完成 canonical semantic artifacts，再展开教案。\n",
        "02_考场骨架教案.md": f"# {title}｜考场骨架教案\n\nTODO: 压缩为真实可手写、可回忆的控制骨架。\n",
        "03_逐字稿.md": trial,
        "04_课题专属答辩.md": f"# {title}｜课题专属答辩\n\nTODO: 只写该课题特有的答辩问题与回答。\n",
        "05_教材到骨架提炼解析.md": f"# {title}｜教材到骨架提炼解析\n\nTODO: 解释 evidence → reasoning → boundary → point → classroom 的压缩过程。\n",
    }


def initialize(args: argparse.Namespace, *, root: Path = ROOT) -> tuple[Path, Path]:
    validate_args(args)
    product, _ = load_contracts(root)
    case_root = str(args.case_root).rstrip("/")
    case_dir_rel = f"{case_root}/{args.case_id}"
    case_dir = safe_repo_path(root, case_dir_rel)
    manifest = case_dir / "manifest.yaml"
    if case_dir.exists() and any(case_dir.iterdir()):
        raise ValueError(f"case directory already exists and is non-empty: {case_dir_rel}")
    case_dir.mkdir(parents=True, exist_ok=True)
    data = build_manifest(args, product, case_dir_rel, root=root)
    manifest.write_text(_dump(data), encoding="utf-8")
    locator = {
        "repo": args.source_repo,
        "ref": args.source_ref,
        "path": args.source_path,
        "blob_sha": args.source_blob_sha,
        "pdf_pages": csv_ints(args.pdf_pages),
    }
    content = scaffold_content(args.case_id, args.title, args.book, csv_ints(args.printed_pages), source_locator=locator)
    for filename, body in content.items():
        (case_dir / filename).write_text(body, encoding="utf-8")
    expected = scaffold_paths(product)
    missing = [filename for filename in expected.values() if filename not in content]
    if missing:
        raise ValueError(f"initializer missing product source scaffolds: {missing}")
    return manifest, case_dir


def selftest() -> None:
    assert csv_ints("1, 2, 3") == [1, 2, 3]
    try:
        csv_ints("1,1")
    except ValueError:
        pass
    else:
        raise AssertionError("duplicate page list should fail")
    assert CASE_ID_RE.fullmatch("demo-01") and not CASE_ID_RE.fullmatch("../escape")
    locator = {"repo": "o/r", "ref": "a" * 40, "path": "book.pdf", "blob_sha": "b" * 40, "pdf_pages": [4]}
    content = scaffold_content("SYNTH-1", "合成课题", "合成教材", [1], source_locator=locator)
    required = {
        "evidence.yaml", "SCIENCE_REASONING_AUDIT.yaml", "teaching-boundary.yaml", "point-chain.yaml",
        "STUDENT_STATE_LEDGER.yaml", "RESOURCE_ACTION_MAP.yaml", "BOARD_PLAN.yaml", "BOARD_TIMELINE.yaml",
        "ENACTMENT_TIMELINE.yaml", "semantic-preflight-review.yaml", "01_训练参考教案.md", "02_考场骨架教案.md",
        "03_逐字稿.md", "04_课题专属答辩.md", "05_教材到骨架提炼解析.md",
    }
    assert required <= set(content)
    board = yaml.safe_load(content["BOARD_PLAN.yaml"])
    assert "B1" in board["cases"][0]["fragments"]
    assert "[[BOARD:B1]]" in content["03_逐字稿.md"]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--selftest", action="store_true")
    parser.add_argument("--case-id")
    parser.add_argument("--title")
    parser.add_argument("--book")
    parser.add_argument("--book-id", default=None)
    parser.add_argument("--printed-pages")
    parser.add_argument("--source-repo")
    parser.add_argument("--source-ref")
    parser.add_argument("--source-path")
    parser.add_argument("--source-blob-sha")
    parser.add_argument("--source-size-bytes", type=int)
    parser.add_argument("--pdf-pages")
    parser.add_argument("--source-url", default=None)
    parser.add_argument("--repository-source-file", default=None)
    parser.add_argument("--figure-count-min", type=int, default=0)
    parser.add_argument("--case-root", default="production/teaching-demo-cases")
    args = parser.parse_args()
    selftest()
    if args.selftest:
        print("PASS: canonical Teaching Demo case initializer selftest")
        return 0
    required = ["case_id", "title", "book", "printed_pages", "source_repo", "source_ref", "source_path", "source_blob_sha", "source_size_bytes", "pdf_pages"]
    missing = [x for x in required if getattr(args, x) in (None, "")]
    if missing:
        parser.error("missing required arguments: " + ", ".join("--" + x.replace("_", "-") for x in missing))
    manifest, case_dir = initialize(args)
    print(f"Teaching Demo canonical case scaffold created: {case_dir.relative_to(ROOT)}")
    print(f"manifest: {manifest.relative_to(ROOT)}")
    print("IMPORTANT: verify actual source pages and complete the canonical semantic artifacts; preflight remains closed until all gates pass.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
