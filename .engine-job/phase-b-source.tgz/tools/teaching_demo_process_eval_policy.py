from __future__ import annotations

import json
from pathlib import Path

from teaching_demo_process_eval_common import (
    CURRENT_REL, LEDGER_CONTRACT_REL, POOL_REL, RULES_REL, SLOTS_REL,
    GateError, git_is_ancestor, git_show_bytes, load_yaml, require_canonical_ledger,
    safe_rel_path, selection_digest, sha256_bytes,
)
from teaching_demo_process_eval_execution import validate_fresh_slot_execution

def validate(repo: Path, *, verify_git_history: bool = True) -> dict:
    require_canonical_ledger()
    rules_path = repo / RULES_REL
    pool_path = repo / POOL_REL
    current_path = repo / CURRENT_REL
    ledger_contract_path = repo / LEDGER_CONTRACT_REL
    if not all(p.is_file() for p in (rules_path, pool_path, current_path, ledger_contract_path)):
        raise GateError("PROCESS_EVALUATION_CONTROL_FILE_MISSING")

    rules = load_yaml(rules_path)
    pool = load_yaml(pool_path)
    try:
        current = json.loads(current_path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise GateError(f"CURRENT_TEXTBOOK_MAP_INVALID: {exc}") from exc
    ledger_contract = load_yaml(ledger_contract_path)
    if not all(isinstance(x, dict) for x in (rules, pool, ledger_contract)):
        raise GateError("PROCESS_EVALUATION_CONTROL_MAPPING_INVALID")

    if rules.get("process_product", {}).get("primary_product") != "reusable_agent_operable_process":
        raise GateError("PROCESS_PRODUCT_IDENTITY_INVALID")
    budget_rule = rules.get("global_experiment_budget", {})
    if budget_rule.get("max_process_evaluation_slots") != 3 or budget_rule.get("fourth_slot") != "forbidden":
        raise GateError("GLOBAL_SLOT_BUDGET_INVALID")
    if rules.get("topic_rotation", {}).get("slots_2_and_3", {}).get("random_selection_required") is not True:
        raise GateError("RANDOM_TOPIC_ROTATION_NOT_REQUIRED")
    if rules.get("random_selection", {}).get("algorithm_id") != "sha256-beacon-commit-modulo-v1":
        raise GateError("RANDOM_SELECTION_ALGORITHM_INVALID")

    topics = pool.get("topics") or []
    if len(topics) < 12:
        raise GateError(f"TOPIC_POOL_TOO_SMALL: {len(topics)}")
    ids = [t.get("case_id") for t in topics if isinstance(t, dict)]
    if len(ids) != len(topics) or any(not x for x in ids) or len(ids) != len(set(ids)):
        raise GateError("TOPIC_POOL_CASE_ID_INVALID_OR_DUPLICATE")
    current_ids = set((current.get("ids") or {}).keys())
    bad_books = sorted({t.get("textbook_id") for t in topics if t.get("textbook_id") not in current_ids})
    if bad_books:
        raise GateError(f"TOPIC_POOL_UNKNOWN_TEXTBOOK_IDS: {bad_books}")
    excluded = {x.get("case_id") for x in pool.get("excluded_prior_or_historical_topics", []) if isinstance(x, dict)}
    if "transformer-principle-v1" not in excluded:
        raise GateError("TRANSFORMER_NOT_EXCLUDED_FROM_FRESH_RANDOM_POOL")

    pool_sha = sha256_bytes(pool_path.read_bytes())
    ordered = sorted(topics, key=lambda item: item["case_id"])
    slot_files = sorted((repo / SLOTS_REL).glob("slot-*.yaml"))
    if not slot_files:
        raise GateError("PROCESS_EVALUATION_SLOT_LEDGER_EMPTY")
    if len(slot_files) > 3:
        raise GateError(f"PROCESS_EVALUATION_SLOT_RECORD_LIMIT_EXCEEDED: {len(slot_files)}")

    seen: set[str] = set()
    consumed_slots = 0
    slots = []
    for expected_slot, path in enumerate(slot_files, start=1):
        record = load_yaml(path)
        if not isinstance(record, dict):
            raise GateError(f"PROCESS_EVALUATION_SLOT_NOT_MAPPING: {path.name}")
        slot = record.get("slot_number")
        if slot != expected_slot:
            raise GateError(f"PROCESS_EVALUATION_SLOT_SEQUENCE_INVALID: expected={expected_slot} actual={slot}")
        selection = record.get("selection") or {}
        if not isinstance(selection, dict):
            raise GateError(f"SLOT{slot}_SELECTION_NOT_MAPPING")
        case_id = selection.get("case_id")
        if not case_id or case_id in seen:
            raise GateError(f"PROCESS_EVALUATION_CASE_REUSE: {case_id}")
        seen.add(case_id)
        budget = record.get("budget") or {}
        if not isinstance(budget, dict):
            raise GateError(f"SLOT{slot}_BUDGET_NOT_MAPPING")
        consumed = budget.get("consumes_global_slot")
        if not isinstance(consumed, bool):
            raise GateError(f"SLOT{slot}_CONSUMPTION_FLAG_INVALID")
        if consumed:
            consumed_slots += 1

        if slot == 1:
            if case_id != "transformer-principle-v1":
                raise GateError("SLOT1_BASELINE_CASE_INVALID")
            if not consumed:
                raise GateError("SLOT1_MUST_CONSUME_GLOBAL_SLOT")
            legacy = record.get("artifact_execution") or {}
            if not isinstance(legacy, dict) or not legacy.get("job_id") or not legacy.get("attempt_id"):
                raise GateError("SLOT1_LEGACY_EXECUTION_IDENTITY_MISSING")
            evidence_rel = safe_rel_path(legacy.get("phase_d_evidence"), label="SLOT1_LEGACY_EVIDENCE")
            if not (repo / evidence_rel).is_file():
                raise GateError(f"SLOT1_LEGACY_EVIDENCE_MISSING: {evidence_rel.as_posix()}")
            execution_summary = {"mode": "legacy_explicit_evidence", "job_id": legacy.get("job_id"), "attempt_id": legacy.get("attempt_id")}
        else:
            if selection.get("method") != "sha256-beacon-commit-modulo-v1":
                raise GateError(f"SLOT{slot}_RANDOM_METHOD_INVALID")
            pool_lock = selection.get("pool_lock") or {}
            if not isinstance(pool_lock, dict) or pool_lock.get("path") != POOL_REL.as_posix():
                raise GateError(f"SLOT{slot}_POOL_PATH_INVALID")
            if pool_lock.get("sha256") != pool_sha:
                raise GateError(f"SLOT{slot}_POOL_SHA_MISMATCH")
            lock_commit = pool_lock.get("commit")
            beacon = selection.get("beacon") or {}
            entropy_commit = selection.get("entropy_commit")
            if not lock_commit:
                raise GateError(f"SLOT{slot}_POOL_LOCK_COMMIT_MISSING")
            if not isinstance(beacon, dict) or not beacon.get("output_value") or not beacon.get("source_url") or not beacon.get("pulse_id"):
                raise GateError(f"SLOT{slot}_BEACON_EVIDENCE_MISSING")
            if not entropy_commit or entropy_commit == lock_commit:
                raise GateError(f"SLOT{slot}_ENTROPY_COMMIT_INVALID")
            digest = selection_digest(beacon["output_value"], pool_sha, entropy_commit, slot)
            index = int(digest, 16) % len(ordered)
            selected = ordered[index]
            if selection.get("digest_sha256") != digest:
                raise GateError(f"SLOT{slot}_SELECTION_DIGEST_MISMATCH")
            if selection.get("selected_index") != index:
                raise GateError(f"SLOT{slot}_SELECTION_INDEX_MISMATCH")
            if case_id != selected["case_id"]:
                raise GateError(f"SLOT{slot}_SELECTED_CASE_MISMATCH: expected={selected['case_id']} actual={case_id}")
            if selection.get("title") != selected.get("title") or selection.get("textbook_id") != selected.get("textbook_id"):
                raise GateError(f"SLOT{slot}_SELECTED_TOPIC_METADATA_MISMATCH")
            if verify_git_history:
                if sha256_bytes(git_show_bytes(repo, lock_commit, POOL_REL)) != pool_sha:
                    raise GateError(f"SLOT{slot}_POOL_LOCK_COMMIT_BYTES_MISMATCH")
                if not git_is_ancestor(repo, lock_commit, entropy_commit):
                    raise GateError(f"SLOT{slot}_ENTROPY_COMMIT_NOT_AFTER_POOL_LOCK")
            execution_summary = validate_fresh_slot_execution(repo, slot, record, str(case_id), ledger_contract, verify_git_history=verify_git_history)

        slots.append({"slot_number": slot, "case_id": case_id, "status": record.get("status"), "consumed": consumed, "execution": execution_summary})

    if consumed_slots > 3:
        raise GateError(f"PROCESS_EVALUATION_CONSUMED_SLOT_LIMIT_EXCEEDED: {consumed_slots}")
    return {
        "result": "PASS",
        "gate_scope": "control_and_execution_consistency",
        "process_maturity_claim": "NOT_ASSERTED_BY_THIS_GATE",
        "pool_topics": len(topics),
        "pool_sha256": pool_sha,
        "slot_records": len(slots),
        "consumed_slots": consumed_slots,
        "remaining_slots": 3 - consumed_slots,
        "slots": slots,
    }


