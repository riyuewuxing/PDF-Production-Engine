#!/usr/bin/env python3
"""Deterministic publisher for Yunnan teacher self-introduction final materials.

Reads only repository Markdown sources. No runtime LLM/API. Every deliverable PDF must still be
rendered and visually inspected under the repository-wide AGENTS.md PDF rule.
"""
from __future__ import annotations

import argparse
import re
from html import escape
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    BaseDocTemplate,
    Frame,
    ListFlowable,
    ListItem,
    PageBreak,
    PageTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
)

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "content/job-search/teacher/self-introduction/materials/yunnan/r2"

ACCENT = colors.HexColor("#244A63")
ACCENT_2 = colors.HexColor("#3C6E71")
TEXT = colors.HexColor("#20262B")
MUTED = colors.HexColor("#5C6770")
RULE = colors.HexColor("#C9D5DC")


def register_fonts() -> tuple[str, str]:
    regular_candidates = [
        Path("/usr/share/fonts/truetype/arphic-gbsn00lp/gbsn00lp.ttf"),
        Path("/usr/share/fonts/truetype/arphic/uming.ttc"),
    ]
    bold_candidates = [
        Path("/usr/share/fonts/truetype/arphic-gkai00mp/gkai00mp.ttf"),
    ]
    regular = next((p for p in regular_candidates if p.exists()), None)
    bold = next((p for p in bold_candidates if p.exists()), None)
    if regular:
        pdfmetrics.registerFont(TTFont("SelfIntroCN-Regular", str(regular)))
        if bold:
            pdfmetrics.registerFont(TTFont("SelfIntroCN-Bold", str(bold)))
        else:
            pdfmetrics.registerFont(TTFont("SelfIntroCN-Bold", str(regular)))
        pdfmetrics.registerFontFamily(
            "SelfIntroCN",
            normal="SelfIntroCN-Regular",
            bold="SelfIntroCN-Bold",
            italic="SelfIntroCN-Regular",
            boldItalic="SelfIntroCN-Bold",
        )
        return "SelfIntroCN-Regular", "SelfIntroCN-Bold"
    pdfmetrics.registerFont(UnicodeCIDFont("STSong-Light"))
    return "STSong-Light", "STSong-Light"


REGULAR_FONT, BOLD_FONT = register_fonts()
STYLES = getSampleStyleSheet()
BODY = ParagraphStyle(
    "BodyCN", parent=STYLES["BodyText"], fontName=REGULAR_FONT, fontSize=10.3,
    leading=16, textColor=TEXT, spaceAfter=5.5, wordWrap="CJK",
)
H1 = ParagraphStyle(
    "H1CN", parent=STYLES["Heading1"], fontName=BOLD_FONT, fontSize=20,
    leading=26, textColor=ACCENT, spaceBefore=8, spaceAfter=10, wordWrap="CJK",
)
H2 = ParagraphStyle(
    "H2CN", parent=STYLES["Heading2"], fontName=BOLD_FONT, fontSize=14.3,
    leading=20, textColor=ACCENT, spaceBefore=11, spaceAfter=6, wordWrap="CJK",
)
H3 = ParagraphStyle(
    "H3CN", parent=STYLES["Heading3"], fontName=BOLD_FONT, fontSize=11.5,
    leading=16, textColor=ACCENT_2, spaceBefore=8, spaceAfter=4, wordWrap="CJK",
)
SMALL = ParagraphStyle("SmallCN", parent=BODY, fontSize=8.6, leading=13, textColor=MUTED)
COVER_TITLE = ParagraphStyle(
    "CoverTitle", parent=H1, alignment=TA_CENTER, fontSize=26, leading=34,
    textColor=ACCENT, spaceAfter=10,
)
COVER_SUB = ParagraphStyle(
    "CoverSub", parent=BODY, alignment=TA_CENTER, fontSize=11.5, leading=18, textColor=MUTED,
)
TOC_ITEM = ParagraphStyle("TOCItem", parent=BODY, fontSize=10, leading=15, leftIndent=4 * mm, spaceAfter=3)
CALLOUT = ParagraphStyle(
    "Callout", parent=BODY, fontSize=9.1, leading=14, textColor=colors.HexColor("#365B70"),
    backColor=colors.HexColor("#F2F7F9"), borderPadding=(5, 6, 5, 6),
    borderColor=RULE, borderWidth=0.4,
)


class Doc(BaseDocTemplate):
    def __init__(self, filename: Path, title: str):
        super().__init__(
            str(filename), pagesize=A4, leftMargin=19 * mm, rightMargin=19 * mm,
            topMargin=20 * mm, bottomMargin=18 * mm, title=title,
            author="qiuzhidaren / ChatGPT Sol",
        )
        self.doc_title = title
        frame = Frame(self.leftMargin, self.bottomMargin, self.width, self.height, id="normal")
        self.addPageTemplates(PageTemplate(id="main", frames=[frame], onPage=self._page))

    def _page(self, canvas, doc):
        canvas.saveState()
        if doc.page > 1:
            canvas.setStrokeColor(RULE)
            canvas.setLineWidth(0.5)
            canvas.line(self.leftMargin, A4[1] - 13 * mm, A4[0] - self.rightMargin, A4[1] - 13 * mm)
            canvas.setFont(REGULAR_FONT, 8)
            canvas.setFillColor(MUTED)
            canvas.drawString(self.leftMargin, A4[1] - 10.3 * mm, self.doc_title)
            canvas.drawRightString(A4[0] - self.rightMargin, 9 * mm, str(doc.page))
        canvas.restoreState()


def inline_markup(text: str) -> str:
    value = escape(text, quote=False)
    value = re.sub(r"`([^`]+)`", r'<font color="#435A68">\1</font>', value)
    value = re.sub(r"(【填写：.*?】)", r'<font color="#1F5F7A"><b>\1</b></font>', value)
    value = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", value)
    return value


def paragraph(text: str, style=BODY) -> Paragraph:
    return Paragraph(inline_markup(text), style)


def headings(text: str) -> list[str]:
    return [line[3:].strip() for line in text.splitlines() if line.startswith("## ")]


def cover(title: str, subtitle: str):
    return [
        Spacer(1, 45 * mm),
        Paragraph(escape(title), COVER_TITLE),
        Paragraph(escape(subtitle), COVER_SUB),
        Spacer(1, 8 * mm),
        Paragraph("范围：云南省内教师求职（K12优先）", COVER_SUB),
        Paragraph("版本：第二轮最终版", COVER_SUB),
        Spacer(1, 20 * mm),
        Paragraph("证据优先 · Source-aware · No fabrication · 可填空 · 可追问", COVER_SUB),
        PageBreak(),
    ]


def toc(items: list[str]):
    data = [[Paragraph(str(i), TOC_ITEM), Paragraph(escape(item), TOC_ITEM)] for i, item in enumerate(items, 1)]
    table = Table(data, colWidths=[10 * mm, 150 * mm], hAlign="LEFT")
    table.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LINEBELOW", (0, 0), (-1, -1), 0.25, colors.HexColor("#E6ECEF")),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    return [Paragraph("目录", H1), paragraph("具体招聘格式仍以当前 source 为准。", SMALL), Spacer(1, 4 * mm), table, PageBreak()]


def markdown_flowables(text: str, template_mode: bool):
    story = []
    pending: list[str] = []
    bullets: list[str] = []

    def flush_paragraph():
        nonlocal pending
        if pending:
            joined = " ".join(x.strip() for x in pending if x.strip())
            if joined:
                story.append(paragraph(joined))
            pending = []

    def flush_bullets():
        nonlocal bullets
        if bullets:
            story.append(ListFlowable(
                [ListItem(paragraph(item), leftIndent=4 * mm) for item in bullets],
                bulletType="bullet", leftIndent=7 * mm,
                bulletFontName=REGULAR_FONT, bulletFontSize=7, spaceAfter=5,
            ))
            bullets = []

    for raw in text.splitlines():
        s = raw.strip()
        if not s:
            flush_paragraph(); flush_bullets(); continue
        if s == "---":
            flush_paragraph(); flush_bullets(); story.append(Spacer(1, 2 * mm)); continue
        if s.startswith("# "):
            flush_paragraph(); flush_bullets(); continue
        if s.startswith("## "):
            flush_paragraph(); flush_bullets()
            title = s[3:].strip()
            is_template = template_mode and bool(re.match(r"T\d+\s*\|", title))
            if is_template:
                story.append(PageBreak())
            story.append(Paragraph(inline_markup(title), H1 if is_template else H2))
            continue
        if s.startswith("### "):
            flush_paragraph(); flush_bullets(); story.append(Paragraph(inline_markup(s[4:].strip()), H3)); continue
        m = re.match(r"[-*]\s+(.+)", s)
        if m:
            flush_paragraph(); bullets.append(m.group(1)); continue
        m = re.match(r"\d+[\.、]\s*(.+)", s)
        if m:
            flush_paragraph(); bullets.append(m.group(1)); continue
        if "->" in s and len(s) < 140:
            flush_paragraph(); flush_bullets(); story.append(Paragraph(inline_markup(s), CALLOUT)); continue
        pending.append(s)

    flush_paragraph(); flush_bullets()
    return story


def build(source: Path, output: Path, title: str, subtitle: str, template_mode: bool):
    text = source.read_text(encoding="utf-8")
    doc = Doc(output, title)
    story = cover(title, subtitle) + toc(headings(text)) + markdown_flowables(text, template_mode)
    doc.build(story)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out-dir", type=Path, default=ROOT / "outputs/self-introduction/yunnan")
    args = parser.parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)

    build(
        BASE / "00_云南教师求职自我介绍核心资料.md",
        args.out_dir / "云南教师求职自我介绍核心资料.pdf",
        "云南教师求职自我介绍核心资料",
        "Fact Bank / Story Bank / Source-aware / Claim-Evidence-Follow-up",
        False,
    )
    build(
        BASE / "01_教师自我介绍填空模板册.md",
        args.out_dir / "教师自我介绍填空模板册.pdf",
        "教师自我介绍填空模板册",
        "18种模板 + M1-M10可插拔模块 + 匿名安全模式",
        True,
    )
    print(args.out_dir / "云南教师求职自我介绍核心资料.pdf")
    print(args.out_dir / "教师自我介绍填空模板册.pdf")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
