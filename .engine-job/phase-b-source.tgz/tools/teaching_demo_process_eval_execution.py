from __future__ import annotations

from pathlib import Path
from typing import Any

from teaching_demo_process_eval_common import (
    ARTIFACT_JOBS_REL,
    LEDGER_CONTRACT_REL,
    WARM_ACCEPT_SCHEMA,
    WARM_DIFF_SCHEMA,
    GateError,
    binding_set,
    git_diff_names,
    git_is_ancestor,
    is_git_sha1,
    job_matches_case,
    ledger_derive,
    ledger_project_lifecycle,
    ledger_validate,
    load_bound_yaml_evidence,
    load_yaml,
    normalize_scope_paths,
    parse_iso8601,
    require_canonical_ledger,
    safe_rel_path,
    sha256_file,
)


def _materialized_binding_set(repo: Path, items: Any, *, label: str) -> set[tuple[str, str, str]]:
    result = binding_set(items, label=label, require_nonempty=True)
    for rel, digest, _kind in result:
        path = repo / Path(rel)
        if not path.is_file():
            raise GateError(f"{label}_BOUND_FILE_MISSING: {rel}")
        actual = sha256_file(path)
        if actual != digest:
            raise GateError(f"{label}_BOUND_FILE_HASH_MISMATCH: {rel}: declared={digest} actual={actual}")
    return result


def warm_claims_pass(record: dict) -> bool:
    if record.get("warm_path_success") is True:
        return True
    warm = record.get("warm_path")
    if isinstance(warm, dict):
        value = warm.get("status") or warm.get("result") or warm.get("decision")
        if isinstance(value, str) and value.upper() in {"PASS", "SUCCESS", "WARM_PATH_PASS"}:
            return True
    for key in ("status", "result"):
        value = record.get(key)
        if isinstance(value, str) and "WARM" in value.upper() and (
            "PASS" in value.upper() or "SUCCESS" in value.upper()
        ):
            return True
    return False


def validate_warm_claim(
    repo: Path,
    slot: int,
    record: dict,
    execution: dict | None,
    attempt_id: str | None,
    *,
    verify_git_history: bool,
) -> None:
    if not warm_claims_pass(record):
        return
    if execution is None or not attempt_id:
        raise GateError(f"SLOT{slot}_WARM_SUCCESS_WITHOUT_BOUND_EXECUTION")
    if not verify_git_history:
        raise GateError(f"SLOT{slot}_WARM_SUCCESS_REQUIRES_GIT_HISTORY")

    types = [str(e.get("type")) for e in execution["events"] if e.get("attempt_id") == attempt_id]
    required = {
        "BUILD_STARTED",
        "BUILD_COMPLETED",
        "MACHINE_VERIFICATION_PASSED",
        "FINAL_RENDER_COMPLETED",
        "HUMAN_REVIEW_ACCEPTED",
    }
    missing = sorted(required - set(types))
    if missing:
        raise GateError(f"SLOT{slot}_WARM_SUCCESS_LEDGER_EVIDENCE_MISSING: {missing}")

    job = execution["job"]
    if job.get("state") not in {"HUMAN_ACCEPTED", "PUBLISHED"}:
        raise GateError(f"SLOT{slot}_WARM_SUCCESS_JOB_NOT_HUMAN_ACCEPTED")
    outputs = _materialized_binding_set(repo, job.get("outputs"), label=f"SLOT{slot}_JOB_OUTPUTS")
    human = job.get("human_acceptance")
    if not isinstance(human, dict) or human.get("state") != "REVIEW_PASS":
        raise GateError(f"SLOT{slot}_WARM_SUCCESS_HUMAN_ACCEPTANCE_STATE_INVALID")
    accepted_outputs = binding_set(
        human.get("accepted_outputs"), label=f"SLOT{slot}_JOB_ACCEPTED_OUTPUTS", require_nonempty=True
    )
    if accepted_outputs != outputs:
        raise GateError(f"SLOT{slot}_WARM_SUCCESS_ACCEPTED_OUTPUTS_MISMATCH")

    warm = record.get("warm_path")
    if not isinstance(warm, dict):
        raise GateError(f"SLOT{slot}_WARM_SUCCESS_DETAIL_REQUIRED")

    diff_receipt = load_bound_yaml_evidence(
        repo, warm.get("implementation_diff_evidence"), label=f"SLOT{slot}_WARM_DIFF_EVIDENCE"
    )
    if diff_receipt.get("schema_id") != WARM_DIFF_SCHEMA:
        raise GateError(f"SLOT{slot}_WARM_DIFF_SCHEMA_INVALID")
    if diff_receipt.get("decision") != "NO_GENERIC_IMPLEMENTATION_CHANGE":
        raise GateError(f"SLOT{slot}_WARM_DIFF_DECISION_INVALID")
    baseline = diff_receipt.get("baseline_commit")
    head = diff_receipt.get("head_commit")
    if not is_git_sha1(baseline) or not is_git_sha1(head) or baseline == head:
        raise GateError(f"SLOT{slot}_WARM_DIFF_COMMIT_IDENTITY_INVALID")
    scope_paths = normalize_scope_paths(diff_receipt.get("scope_paths"))
    declared_changed = diff_receipt.get("changed_files")
    if not isinstance(declared_changed, list) or not all(isinstance(x, str) and x for x in declared_changed):
        raise GateError(f"SLOT{slot}_WARM_DIFF_CHANGED_FILES_INVALID")
    if len(declared_changed) != len(set(declared_changed)):
        raise GateError(f"SLOT{slot}_WARM_DIFF_CHANGED_FILES_DUPLICATE")
    declared_changed = sorted(declared_changed)
    if not git_is_ancestor(repo, baseline, head):
        raise GateError(f"SLOT{slot}_WARM_DIFF_BASELINE_NOT_ANCESTOR")
    actual_changed = git_diff_names(repo, baseline, head, scope_paths)
    if actual_changed != declared_changed:
        raise GateError(
            f"SLOT{slot}_WARM_DIFF_RECEIPT_CONTRADICTS_GIT: "
            f"declared={declared_changed} actual={actual_changed}"
        )
    if actual_changed:
        raise GateError(f"SLOT{slot}_WARM_GENERIC_IMPLEMENTATION_CHANGED: {actual_changed}")

    acceptance = load_bound_yaml_evidence(
        repo,
        warm.get("independent_acceptance_evidence"),
        label=f"SLOT{slot}_WARM_INDEPENDENT_ACCEPTANCE",
    )
    if acceptance.get("schema_id") != WARM_ACCEPT_SCHEMA:
        raise GateError(f"SLOT{slot}_WARM_ACCEPTANCE_SCHEMA_INVALID")
    if acceptance.get("decision") != "ACCEPT":
        raise GateError(f"SLOT{slot}_WARM_ACCEPTANCE_DECISION_INVALID")
    if acceptance.get("case_id") != record.get("selection", {}).get("case_id"):
        raise GateError(f"SLOT{slot}_WARM_ACCEPTANCE_CASE_MISMATCH")
    if acceptance.get("job_id") != execution["job_id"]:
        raise GateError(f"SLOT{slot}_WARM_ACCEPTANCE_JOB_MISMATCH")
    if acceptance.get("attempt_id") != attempt_id:
        raise GateError(f"SLOT{slot}_WARM_ACCEPTANCE_ATTEMPT_MISMATCH")
    if acceptance.get("implementation_head_commit") != head:
        raise GateError(f"SLOT{slot}_WARM_ACCEPTANCE_IMPLEMENTATION_HEAD_MISMATCH")
    if acceptance.get("reviewer_role") not in {"INDEPENDENT_HUMAN", "INDEPENDENT_PLANNER"}:
        raise GateError(f"SLOT{slot}_WARM_ACCEPTANCE_REVIEWER_ROLE_INVALID")
    if not parse_iso8601(acceptance.get("reviewed_at")):
        raise GateError(f"SLOT{slot}_WARM_ACCEPTANCE_TIMESTAMP_INVALID")
    receipt_outputs = binding_set(
        acceptance.get("accepted_outputs"),
        label=f"SLOT{slot}_WARM_ACCEPTANCE_OUTPUTS",
        require_nonempty=True,
    )
    if receipt_outputs != accepted_outputs:
        raise GateError(f"SLOT{slot}_WARM_ACCEPTANCE_OUTPUT_BINDINGS_MISMATCH")


def discover_case_executions(repo: Path, case_id: str, contract: dict) -> list[dict[str, Any]]:
    require_canonical_ledger()
    root = repo / ARTIFACT_JOBS_REL
    if not root.is_dir():
        return []
    executions: list[dict[str, Any]] = []
    candidates = sorted(
        path
        for path in root.rglob("*")
        if path.is_file() and path.suffix.lower() in {".yaml", ".yml"}
    )
    for job_path in candidates:
        job_rel = job_path.relative_to(repo).as_posix()
        job = load_yaml(job_path)
        if not isinstance(job, dict):
            raise GateError(f"CASE_JOB_YAML_NOT_MAPPING: {job_rel}")
        if not job_matches_case(job, case_id):
            continue
        if job.get("module_id") != "teacher_teaching_demo":
            raise GateError(f"CASE_JOB_MODULE_MISMATCH: {job_rel}")
        if not isinstance(job.get("job_id"), str) or not job.get("job_id"):
            raise GateError(f"CASE_JOB_ID_MISSING: {job_rel}")
        ledger_rel = safe_rel_path(job.get("execution_ledger"), label="CASE_JOB_LEDGER")
        ledger_path = repo / ledger_rel
        if not ledger_path.is_file():
            raise GateError(f"CASE_JOB_LEDGER_MISSING: {ledger_rel.as_posix()}")
        ledger = load_yaml(ledger_path)
        if not isinstance(ledger, dict):
            raise GateError(f"CASE_JOB_LEDGER_NOT_MAPPING: {ledger_rel.as_posix()}")
        if ledger.get("job_id") != job.get("job_id"):
            raise GateError(f"CASE_JOB_LEDGER_JOB_ID_MISMATCH: {ledger_rel.as_posix()}")

        errors = list(ledger_validate(ledger, repo, contract_path=repo / LEDGER_CONTRACT_REL))
        if errors:
            raise GateError(
                f"CASE_JOB_LEDGER_INVALID: {ledger_rel.as_posix()}: " + " | ".join(errors)
            )
        events = ledger.get("events")
        if not isinstance(events, list) or not all(isinstance(x, dict) for x in events):
            raise GateError(f"CASE_JOB_LEDGER_NORMALIZATION_UNSAFE: {ledger_rel.as_posix()}")
        lifecycle_state, lifecycle_errors = ledger_project_lifecycle(events, contract)
        if lifecycle_errors:
            raise GateError(
                f"CASE_JOB_LEDGER_LIFECYCLE_INVALID: {ledger_rel.as_posix()}: "
                + " | ".join(lifecycle_errors)
            )
        if job.get("state") != lifecycle_state:
            raise GateError(
                f"CASE_JOB_STATE_LEDGER_MISMATCH: {job_rel}: "
                f"job={job.get('state')} ledger={lifecycle_state}"
            )
        executions.append(
            {
                "job_rel": job_rel,
                "job_id": job.get("job_id"),
                "job": job,
                "ledger_rel": ledger_rel.as_posix(),
                "ledger": ledger,
                "events": events,
                "starts": [e for e in events if e.get("type") == "BUILD_STARTED"],
                "metrics": ledger_derive(events),
                "artifact_state": lifecycle_state,
            }
        )
    return executions


def validate_fresh_slot_execution(
    repo: Path,
    slot: int,
    record: dict,
    case_id: str,
    contract: dict,
    *,
    verify_git_history: bool,
) -> dict[str, Any]:
    executions = discover_case_executions(repo, case_id, contract)
    starts = [(ex, event) for ex in executions for event in ex["starts"]]
    budget = record.get("budget") or {}
    if not isinstance(budget, dict):
        raise GateError(f"SLOT{slot}_BUDGET_NOT_MAPPING")
    consumed = budget.get("consumes_global_slot")
    if consumed is True and not starts:
        raise GateError(f"SLOT{slot}_CONSUMED_WITHOUT_BUILD_STARTED")
    if consumed is False and starts:
        raise GateError(f"SLOT{slot}_BUILD_STARTED_BUT_CONSUMPTION_FALSE")
    if len(starts) > 1:
        identities = [f"{ex['job_id']}:{ev.get('attempt_id')}" for ex, ev in starts]
        raise GateError(f"SLOT{slot}_SAME_CASE_MULTIPLE_PRODUCT_COMPOSITIONS: {identities}")
    product_started = budget.get("product_pdf_composition_started")
    if product_started is not None and product_started is not bool(starts):
        raise GateError(f"SLOT{slot}_PRODUCT_COMPOSITION_FLAG_LEDGER_MISMATCH")
    consumed_at = budget.get("consumed_at_build_started")
    if consumed and not parse_iso8601(consumed_at):
        raise GateError(f"SLOT{slot}_BUILD_STARTED_TIMESTAMP_INVALID")

    if not executions:
        if consumed:
            raise GateError(f"SLOT{slot}_NO_CASE_JOB_FOR_CONSUMED_SLOT")
        validate_warm_claim(repo, slot, record, None, None, verify_git_history=verify_git_history)
        return {"job_count": 0, "build_starts": 0, "attempt_id": None}

    binding = record.get("execution_binding")
    if not isinstance(binding, dict):
        raise GateError(f"SLOT{slot}_EXECUTION_BINDING_REQUIRED")
    if binding.get("protocol") != "artifact-ledger-v1":
        raise GateError(f"SLOT{slot}_EXECUTION_BINDING_PROTOCOL_INVALID")
    if binding.get("case_id") != case_id:
        raise GateError(f"SLOT{slot}_EXECUTION_BINDING_CASE_MISMATCH")
    bound_job = safe_rel_path(binding.get("job"), label=f"SLOT{slot}_BOUND_JOB").as_posix()
    bound_ledger = safe_rel_path(binding.get("ledger"), label=f"SLOT{slot}_BOUND_LEDGER").as_posix()
    bound_attempt = binding.get("attempt_id")
    target = next(
        (ex for ex in executions if ex["job_rel"] == bound_job and ex["ledger_rel"] == bound_ledger),
        None,
    )
    if target is None:
        raise GateError(f"SLOT{slot}_EXECUTION_BINDING_NOT_IN_CASE_SCOPE")

    if starts:
        execution, event = starts[0]
        attempt_id = event.get("attempt_id")
        if execution is not target:
            raise GateError(f"SLOT{slot}_BUILD_STARTED_ON_UNBOUND_JOB")
        if not isinstance(bound_attempt, str) or bound_attempt != attempt_id:
            raise GateError(f"SLOT{slot}_EXECUTION_BINDING_ATTEMPT_MISMATCH")
        if budget.get("attempt_id") not in (None, attempt_id):
            raise GateError(f"SLOT{slot}_BUDGET_ATTEMPT_ID_MISMATCH")
        if consumed_at != event.get("occurred_at"):
            raise GateError(f"SLOT{slot}_BUILD_STARTED_TIMESTAMP_MISMATCH")
        validate_warm_claim(
            repo, slot, record, execution, str(attempt_id), verify_git_history=verify_git_history
        )
        return {
            "job_count": len(executions),
            "build_starts": 1,
            "attempt_id": attempt_id,
            "job": execution["job_rel"],
            "ledger": execution["ledger_rel"],
            "artifact_state": execution["artifact_state"],
        }

    if bound_attempt not in (None, ""):
        raise GateError(f"SLOT{slot}_BOUND_ATTEMPT_WITHOUT_BUILD_STARTED")
    validate_warm_claim(repo, slot, record, target, None, verify_git_history=verify_git_history)
    return {
        "job_count": len(executions),
        "build_starts": 0,
        "attempt_id": None,
        "job": target["job_rel"],
        "ledger": target["ledger_rel"],
        "artifact_state": target["artifact_state"],
    }
