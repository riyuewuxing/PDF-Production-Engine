#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import math
import re
from collections import Counter, defaultdict
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
ATLAS = ROOT / "production/process-development/teaching-demo-quality-v2/textbook-topic-atlas"
GEN = ATLAS / "generated"
PUNCT_RE = re.compile(r"[\s\u3000，。！？；：、,.!?;:（）()【】\[\]《》<>“”‘’\-—_]+")
CHAPTER_RE = re.compile(r"第[一二三四五六七八九十百0-9]+章")
SECTION_RE = re.compile(r"第[一二三四五六七八九十百0-9]+节")


def read_jsonl(path: Path):
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                yield json.loads(line)


def write_jsonl(path: Path, rows):
    with path.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")


def norm(text: str) -> str:
    return PUNCT_RE.sub("", (text or "").lower())


def grams(text: str) -> list[str]:
    s = norm(text)
    out = []
    for n in (2, 3):
        if len(s) >= n:
            out.extend(s[i:i+n] for i in range(len(s)-n+1))
    out.extend(re.findall(r"[a-z0-9]+", s))
    return out or ([s] if s else [])


def classify_non_content_pages(atoms):
    by_page = defaultdict(list)
    for a in atoms:
        by_page[(a["book_id"], int(a["physical_page"]))].append(a)
    excluded = {}
    for key, rows in by_page.items():
        book_id, p = key
        if p > 10:
            continue
        text = "\n".join(r.get("text", "") for r in rows)
        compact = norm(text)
        chapter_count = len(CHAPTER_RE.findall(text))
        section_count = len(SECTION_RE.findall(text))
        heading_count = sum(1 for r in rows if r.get("heading_level") is not None)
        numeric_tail_count = sum(1 for r in rows if re.search(r"\D\d{1,3}$", norm(r.get("text", ""))))
        reasons = []
        if "目录" in text:
            reasons.append("contains_目录")
        if chapter_count >= 2:
            reasons.append("multiple_chapter_entries")
        if section_count >= 5 and heading_count >= 5:
            reasons.append("many_section_entries")
        if p <= 6 and heading_count >= 8 and numeric_tail_count >= 5:
            reasons.append("dense_heading_page_number_entries")
        if p <= 4 and ("普通高中教科书" in text or "人民教育出版社" in text) and len(compact) < 180:
            reasons.append("cover_or_title_matter")
        if reasons:
            excluded[key] = reasons
    return excluded


def query_scores(query: str, ttus: list[dict], alias_map: dict[str, list[str]]):
    qn = norm(query)
    alias_targets = list(alias_map.get(query, []))
    expanded = [query] + alias_targets
    expanded_norm = [norm(x) for x in expanded if norm(x)]
    docs_tokens = [grams(t["canonical_title"] + " " + " ".join(t.get("aliases", [])) + " " + t.get("search_excerpt", "")) for t in ttus]
    N = len(docs_tokens)
    df = Counter()
    for toks in docs_tokens:
        for tok in set(toks):
            df[tok] += 1
    avgdl = sum(len(x) for x in docs_tokens) / max(1, N)
    qtokens = grams(" ".join(expanded))
    out = []
    for i, t in enumerate(ttus):
        title_n = norm(t["canonical_title"])
        alias_n = [norm(a) for a in t.get("aliases", [])]
        text_n = norm(t.get("search_excerpt", ""))
        score = 0.0
        if qn and (qn == title_n or qn in title_n):
            score += 35.0
        if any(x and (x in title_n or x in alias_n) for x in expanded_norm):
            score += 20.0
        if any(x and x in text_n for x in expanded_norm):
            score += 10.0
        # Ordered alias targets represent exam-sized intent candidates. Earlier entries
        # outrank mechanism/context terms, without hard-coding textbook pages.
        for rank, target in enumerate(alias_targets):
            tn = norm(target)
            if tn and (tn in title_n or title_n in tn):
                score += max(8.0, 32.0 - 4.0 * rank)
        toks = docs_tokens[i]
        tf = Counter(toks)
        dl = max(1, len(toks))
        bm = 0.0
        for qt in qtokens:
            if tf[qt] == 0:
                continue
            idf = math.log(1 + (N - df[qt] + 0.5) / (df[qt] + 0.5))
            bm += idf * (tf[qt] * 2.2) / (tf[qt] + 1.2 * (1 - 0.75 + 0.75 * dl / max(1, avgdl)))
        score += bm * 1.8
        qg = set(grams(" ".join(expanded)))
        dg = set(grams(t["canonical_title"] + " " + " ".join(t.get("aliases", []))))
        if qg and dg:
            score += 8.0 * len(qg & dg) / len(qg | dg)
        score += float(t["exam_fit"]["teacher_recruitment_fragment_10m"]) * 2.0
        out.append((score, t))
    return sorted(out, key=lambda x: (-x[0], x[1]["topic_id"]))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fail-on-benchmark", action="store_true")
    args = ap.parse_args()
    atoms = list(read_jsonl(GEN / "atoms.jsonl"))
    raw_ttus = list(read_jsonl(GEN / "ttus.jsonl"))
    aliases = yaml.safe_load((ATLAS / "ALIASES.yaml").read_text(encoding="utf-8"))["aliases"]
    bench = yaml.safe_load((ATLAS / "QUERY_BENCHMARK.yaml").read_text(encoding="utf-8"))

    excluded = classify_non_content_pages(atoms)
    curated = []
    removed = []
    for t in raw_ttus:
        core_pages = {(t["book_id"], int(x["physical_page"])) for x in t.get("core_span", [])}
        if core_pages and all(p in excluded for p in core_pages):
            removed.append({"topic_id": t["topic_id"], "title": t["canonical_title"], "book_id": t["book_id"], "pages": sorted(p[1] for p in core_pages)})
        else:
            curated.append(t)
    write_jsonl(GEN / "retrieval-ttus.jsonl", curated)

    rows = []
    pass_count = 0
    slot2_ok = False
    for item in bench["queries"]:
        ranked = query_scores(item["q"], curated, aliases)[:5]
        top3 = [t for _, t in ranked[:3]]
        expected = item.get("expected_any", [])
        ok = any(any(norm(e) in norm(t["canonical_title"] + t.get("search_excerpt", "")) for e in expected) for t in top3)
        if item.get("kind") == "broad_cluster":
            ok = ok and len({t["topic_id"] for t in top3 if float(t["equivalent_page_coverage"]) <= 2.0}) >= 2
        if item["q"] == "分子动理论的基本内容":
            slot2_ok = ok and all((t["book_id"], int(t["core_span"][0]["physical_page"])) not in excluded for t in top3)
            ok = ok and slot2_ok
        pass_count += int(ok)
        rows.append({
            "query": item["q"], "kind": item["kind"], "pass": ok,
            "top3": [{
                "topic_id": t["topic_id"], "title": t["canonical_title"], "book_id": t["book_id"],
                "coverage": t["equivalent_page_coverage"], "score": round(score, 3),
                "first_physical_page": t["core_span"][0]["physical_page"],
            } for score, t in ranked[:3]],
        })
    rate = pass_count / max(1, len(bench["queries"]))
    max_cov = max((float(t["equivalent_page_coverage"]) for t in curated), default=0.0)
    overall = rate >= float(bench["acceptance"]["top_3_pass_rate_min"]) and slot2_ok and max_cov <= 2.0

    report = {
        "pass": overall,
        "pass_count": pass_count,
        "query_count": len(bench["queries"]),
        "pass_rate": round(rate, 4),
        "slot_2_exact_top3_pass": slot2_ok,
        "raw_ttu_count": len(raw_ttus),
        "retrieval_ttu_count": len(curated),
        "frontmatter_ttu_removed": len(removed),
        "excluded_page_count": len(excluded),
        "max_equivalent_page_coverage": max_cov,
        "rows": rows,
    }
    (GEN / "retrieval-benchmark-report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    (GEN / "frontmatter-filter-report.json").write_text(json.dumps({
        "excluded_pages": [{"book_id": k[0], "physical_page": k[1], "reasons": v} for k, v in sorted(excluded.items())],
        "removed_ttu_count": len(removed),
        "removed_examples": removed[:100],
        "policy": "raw atoms/TTUs retained; only formal retrieval index excludes machine-detected front matter",
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({k: report[k] for k in report if k != "rows"}, ensure_ascii=False))
    if args.fail_on_benchmark and not overall:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
