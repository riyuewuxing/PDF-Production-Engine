"""Static checks for the teacher written-exam source/profile/material contracts.

This checker is deterministic and offline. It validates source identity, profile isolation,
current D-class outline routing, source-observed schema extensions and first-stage materials.
It does not call an LLM/API and does not claim any question is official merely from a format
announcement or candidate-recall page.
"""
from __future__ import annotations

import json
from pathlib import Path
import sys
import yaml

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "content/job-search/teacher/written-exam"
PATHS = {
    "rules": BASE / "AGENTS.md",
    "readme": BASE / "README.md",
    "prior_art": BASE / "references/prior-art.md",
    "sources": BASE / "sources/source-registry.yaml",
    "scan": BASE / "sources/yunnan-written-exam-scan-2026-08.md",
    "scope": BASE / "scopes/yunnan-teacher-written-exam-v1.yaml",
    "contract": BASE / "contracts/teacher-written-exam-material-pack-v1.yaml",
    "schema": BASE / "schemas/reference-item-v1.yaml",
    "bank_readme": BASE / "reference-bank/README.md",
    "raw_seed": BASE / "reference-bank/raw/dclass-2026-recalled-seed-v1.md",
    "normalized_seed": BASE / "reference-bank/normalized/dclass-2026-recalled-seed-v1.jsonl",
    "normalized_supplement": BASE / "reference-bank/normalized/dclass-2026-recalled-primary-supplement-v1.jsonl",
    "map": BASE / "materials/yunnan/r1/00_云南教师笔试考情地图.md",
    "dclass": BASE / "materials/yunnan/r1/01_D类2026大纲拆解.md",
    "physics": BASE / "materials/yunnan/r1/02_高中物理跨考试Family路由.md",
    "subjective": BASE / "materials/yunnan/r1/03_综应D三类主观题得分方法.md",
    "strategy": BASE / "materials/yunnan/r1/04_职测D策略选择方法.md",
    "special_physics": BASE / "materials/yunnan/r1/05_特岗初中物理知识与实验地图.md",
    "calibration": BASE / "materials/yunnan/r1/06_D类2026回忆题源校准.md",
}
FAMILIES = {"YN-WE-F1", "YN-WE-F2", "YN-WE-F3"}
DCLASS_MODULES = {"常识判断", "言语理解与表达", "数量分析", "判断推理", "策略选择"}
DCLASS_COMPETENCIES = {"师德践行能力", "教育教学核心能力", "教师自主发展能力"}
DCLASS_MAJOR_TYPES = {"辨析题", "案例分析题", "教育方案设计题"}


class WrittenExamCheckError(ValueError):
    pass


def yload(path: Path):
    if not path.exists():
        raise WrittenExamCheckError(f"missing: {path.relative_to(ROOT)}")
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    if data is None:
        raise WrittenExamCheckError(f"empty yaml: {path.relative_to(ROOT)}")
    return data


def read_jsonl(path: Path) -> list[dict]:
    rows = []
    for line_no, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        value = json.loads(line)
        if not isinstance(value, dict):
            raise WrittenExamCheckError(f"{path.name}:{line_no}: row must be object")
        rows.append(value)
    return rows


def check_prior_art() -> int:
    text = PATHS["prior_art"].read_text(encoding="utf-8")
    repos = [line for line in text.splitlines() if line.startswith("- Repository:")]
    if len(repos) < 3:
        raise WrittenExamCheckError("Prior-Art First requires at least 3 inspected repositories")
    for token in ("License:", "Reuse decision:", "Explicit rejection:", "Code/text copying:"):
        if token not in text:
            raise WrittenExamCheckError(f"prior-art field missing: {token}")
    if "AGPL-3.0" not in text or "reference-only" not in text:
        raise WrittenExamCheckError("license/reuse boundary not visible")
    return len(repos)


def check_sources() -> int:
    data = yload(PATHS["sources"])
    sources = data.get("sources") or {}
    if len(sources) < 10:
        raise WrittenExamCheckError("written-exam source registry unexpectedly small")
    families = set()
    has_current_outline = has_dclass = has_special = has_high_school = has_mixed = False
    recalled_stages = set()
    for sid, src in sources.items():
        url = str(src.get("url") or "")
        if not url.startswith("https://"):
            raise WrittenExamCheckError(f"{sid}: invalid source url")
        family = src.get("profile_family")
        if family:
            if family not in FAMILIES:
                raise WrittenExamCheckError(f"{sid}: unknown profile_family={family}")
            families.add(family)
        if sid == "WE-OUTLINE-2026" and src.get("kind") == "official-outline-mirror":
            has_current_outline = True
        if family == "YN-WE-F1" and src.get("kind") == "official-format":
            has_dclass = True
        if family == "YN-WE-F2" and src.get("kind") == "official-format":
            has_special = True
        if family == "YN-WE-F3":
            content = str((src.get("format") or {}).get("content") or "")
            if "高中" in str(src.get("scope") or "") or "高中" in content:
                has_high_school = True
            if "教育理论" in content:
                has_mixed = True
        if src.get("kind") == "public-recalled-question-source":
            scope_text = str(src.get("scope") or "")
            if "小学" in scope_text:
                recalled_stages.add("小学D类")
            if "中学" in scope_text:
                recalled_stages.add("中学D类")
            if "网络" not in str(src.get("recall_identity") or "") and "考生" not in str(src.get("recall_identity") or ""):
                raise WrittenExamCheckError(f"{sid}: recalled source identity not explicit")
    if families != FAMILIES:
        raise WrittenExamCheckError(f"family coverage drift: {families}")
    if not all((has_current_outline, has_dclass, has_special, has_high_school, has_mixed)):
        raise WrittenExamCheckError("source diversity incomplete")
    if recalled_stages != {"小学D类", "中学D类"}:
        raise WrittenExamCheckError(f"2026 D recalled source stage coverage incomplete: {recalled_stages}")
    rules = "\n".join(data.get("rules") or [])
    for token in ("not a unified", "unknown stays null", "cross-year", "derived-practice", "recalled"):
        if token not in rules:
            raise WrittenExamCheckError(f"source guard missing: {token}")
    return len(sources)


def check_scope() -> None:
    scope = yload(PATHS["scope"])
    if scope.get("id") != "yunnan-teacher-written-exam-v1":
        raise WrittenExamCheckError("scope id drift")
    if scope.get("region") != "云南省" or scope.get("unified_province_profile") is not False:
        raise WrittenExamCheckError("scope must remain Yunnan geographic, non-unified")
    families = set((scope.get("profile_families") or {}).keys())
    if families != FAMILIES:
        raise WrittenExamCheckError(f"scope family drift: {families}")
    domains = scope.get("question_domains") or {}
    if set(domains["DCLASS_VOCATIONAL_APTITUDE"]["modules"]) != DCLASS_MODULES:
        raise WrittenExamCheckError("D-class vocational aptitude module drift")
    if set(domains["DCLASS_COMPREHENSIVE"]["competency_domains"]) != DCLASS_COMPETENCIES:
        raise WrittenExamCheckError("D-class comprehensive competency drift")
    if set(domains["DCLASS_COMPREHENSIVE"]["major_question_types"]) != DCLASS_MAJOR_TYPES:
        raise WrittenExamCheckError("D-class official major question-type drift")


def check_contract() -> None:
    c = yload(PATHS["contract"])
    if c.get("id") != "teacher-written-exam-material-pack-v1" or c.get("default_mode") != "material-production":
        raise WrittenExamCheckError("contract identity/default mode drift")
    if (c.get("scope") or {}).get("unified_exam_profile") is not False:
        raise WrittenExamCheckError("contract creates unified Yunnan profile")
    pp = c.get("profile_policy") or {}
    if pp.get("route_before_content") is not True or set(pp.get("allowed_families") or []) != FAMILIES:
        raise WrittenExamCheckError("profile routing contract drift")
    rp = c.get("reference_policy") or {}
    for key in ("derived_practice_must_be_labeled", "answer_required_for_ready_item", "analysis_required_for_ready_item", "objective_answer_unique", "subjective_requires_answer_points_or_rubric"):
        if rp.get(key) is not True:
            raise WrittenExamCheckError(f"reference QA missing: {key}")
    publication = c.get("publication") or {}
    if publication.get("runtime_llm_api") is not False:
        raise WrittenExamCheckError("runtime LLM/API must remain disabled")
    if publication.get("every_deliverable_pdf_requires_same_round_render_and_visual_inspection") is not True:
        raise WrittenExamCheckError("PDF real-render rule missing")


def check_schema() -> None:
    s = yload(PATHS["schema"])
    if int(s.get("version") or 0) < 2:
        raise WrittenExamCheckError("reference schema must include source-observed application-writing extension")
    if s.get("schema_id") != "teacher-written-exam-reference-item-v1":
        raise WrittenExamCheckError("reference schema id drift")
    fields = s.get("fields") or {}
    required = {
        "id", "status", "profile_family", "profile_id", "stage", "subject", "module",
        "question_type", "stem", "normalized_stem", "exact_key", "answer", "answer_points",
        "rubric", "analysis", "knowledge_tags", "source_id", "source_usage", "risk"
    }
    missing = required - set(fields)
    if missing:
        raise WrittenExamCheckError(f"reference schema missing fields: {sorted(missing)}")
    usages = set(fields["source_usage"].get("values") or [])
    for usage in ("official-question", "public-recalled-question", "public-training", "derived-practice", "user-provided"):
        if usage not in usages:
            raise WrittenExamCheckError(f"source_usage missing: {usage}")
    types = set(fields["question_type"].get("values") or [])
    if "application-writing" not in types:
        raise WrittenExamCheckError("source-observed application-writing type missing")


def check_recalled_seed() -> int:
    rows = read_jsonl(PATHS["normalized_seed"]) + read_jsonl(PATHS["normalized_supplement"])
    ids = {str(r.get("id")) for r in rows}
    if len(rows) != 8 or len(ids) != 8:
        raise WrittenExamCheckError(f"2026 D recalled ready seed drift: rows={len(rows)} ids={len(ids)}")
    stages = {str(r.get("stage")) for r in rows}
    if stages != {"小学D类", "中学D类"}:
        raise WrittenExamCheckError(f"recalled seed stage coverage drift: {stages}")
    if not any(r.get("question_type") == "application-writing" for r in rows):
        raise WrittenExamCheckError("recalled seed must preserve source-observed application writing")
    for row in rows:
        if row.get("status") != "ready" or row.get("source_usage") != "public-recalled-question":
            raise WrittenExamCheckError(f"{row.get('id')}: recalled seed identity/status drift")
        if not row.get("answer") or not row.get("analysis") or not row.get("answer_points"):
            raise WrittenExamCheckError(f"{row.get('id')}: ready recalled item lacks project answer closure")
        notes = str(row.get("notes") or "")
        if "官方答案" in notes and "不是官方答案" not in notes:
            raise WrittenExamCheckError(f"{row.get('id')}: recalled item may not claim official answer")
    return len(rows)


def check_materials() -> None:
    exam_map = PATHS["map"].read_text(encoding="utf-8")
    dclass = PATHS["dclass"].read_text(encoding="utf-8")
    physics = PATHS["physics"].read_text(encoding="utf-8")
    subjective = PATHS["subjective"].read_text(encoding="utf-8")
    strategy = PATHS["strategy"].read_text(encoding="utf-8")
    special = PATHS["special_physics"].read_text(encoding="utf-8")
    calibration = PATHS["calibration"].read_text(encoding="utf-8")
    for family in sorted(FAMILIES):
        if family not in exam_map:
            raise WrittenExamCheckError(f"exam map missing {family}")
    for token in DCLASS_MODULES | DCLASS_COMPETENCIES | DCLASS_MAJOR_TYPES:
        if token not in dclass:
            raise WrittenExamCheckError(f"D-class material missing {token}")
    for token in ("路线A", "路线B", "路线C", "初中物理", "高中物理", "source-bound"):
        if token not in physics:
            raise WrittenExamCheckError(f"physics routing material missing {token}")
    for token in ("辨析题", "案例分析题", "教育方案设计题", "评分点"):
        if token not in subjective:
            raise WrittenExamCheckError(f"subjective method material missing {token}")
    for token in ("安全", "角色", "信息不足", "时序", "选项"):
        if token not in strategy:
            raise WrittenExamCheckError(f"strategy-selection material missing {token}")
    for token in ("初中物理", "实验", "义务教育", "电学"):
        if token not in special:
            raise WrittenExamCheckError(f"special-post physics material missing {token}")
    for token in ("application-writing", "小学4", "中学4", "8项", "不是官方"):
        if token not in calibration:
            raise WrittenExamCheckError(f"D-class recall calibration missing {token}")


def main() -> int:
    for path in PATHS.values():
        if not path.exists():
            raise WrittenExamCheckError(f"missing routed asset: {path.relative_to(ROOT)}")
    prior_count = check_prior_art()
    source_count = check_sources()
    check_scope()
    check_contract()
    check_schema()
    recalled_count = check_recalled_seed()
    check_materials()
    print("teacher written-exam source/profile/material checks: PASS")
    print(f"prior_art={prior_count} sources={source_count} families={len(FAMILIES)} recalled_ready={recalled_count}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (WrittenExamCheckError, json.JSONDecodeError) as exc:
        print(f"TEACHER_WRITTEN_EXAM_CHECK_FAIL: {exc}", file=sys.stderr)
        raise SystemExit(1)
