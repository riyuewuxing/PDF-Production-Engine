"""Generic manifest-driven regression contract for teaching-demo fixtures.

Topic names, case ids, source-role names, required tokens and figure markers live
in case.yaml plus the selected shared product contract. Shared publication policy
must never be copied into fixture regression_contract mappings.
"""
from __future__ import annotations
from pathlib import Path
import re
import tempfile
import yaml
import publisher_core as product
from physics_notation import lint_text,selftest as notation_selftest

ROOT=Path(__file__).resolve().parents[1]
FORBIDDEN_SHARED_REGRESSION_KEYS={'visual_render_dpi','publisher','global_typography','symbol_notation_policy'}


def manifest_path(case_arg:str|Path)->Path:
    p=Path(case_arg)
    if not p.is_absolute(): p=ROOT/p
    if p.is_dir(): p=p/'case.yaml'
    return p.resolve()


def load_case(case_arg:str|Path):
    path=manifest_path(case_arg)
    if not path.exists(): raise FileNotFoundError(path)
    cfg=yaml.safe_load(path.read_text(encoding='utf-8')) or {}
    return cfg,path.parent,path


def discover_cases(root:Path=ROOT)->list[Path]:
    base=root/'production/regression'
    if not base.exists(): return []
    return sorted(p for p in base.glob('*/case.yaml') if p.is_file())


def _shared_product_roles(cfg:dict,errors:list[str],contract_root:Path=ROOT)->tuple[dict,set[str]]:
    contract_id=cfg.get('product_contract')
    if not contract_id:
        errors.append('PRODUCT_CONTRACT_MISSING'); return {},set()
    try: contract=product.load_product_contract(cfg,root=contract_root)
    except Exception as exc:
        errors.append('PRODUCT_CONTRACT_INVALID: '+repr(exc)); return {},set()
    roles:set[str]=set()
    for doc in (contract.get('documents') or {}).values():
        if doc.get('source_role'): roles.add(str(doc['source_role']))
        for section in doc.get('sections') or []:
            if section.get('source_role'): roles.add(str(section['source_role']))
    return contract,roles


def _regression_assertion_roles(contract:dict)->set[str]:
    roles:set[str]=set(); evidence_role=contract.get('evidence_source_role')
    if evidence_role: roles.add(str(evidence_role))
    roles.update(str(x) for x in (contract.get('notation_roles') or []) if x)
    roles.update(str(x) for x in (contract.get('required_markers') or {}).keys() if x)
    for key in ('required_tokens','forbidden_tokens'):
        for rule in contract.get(key) or []: roles.update(str(x) for x in (rule.get('roles') or []) if x)
    roles.update(str(x) for x in (contract.get('max_nonspace_chars') or {}).keys() if x)
    board=contract.get('board') or {}; defense=contract.get('defense') or {}
    if board.get('source_role'): roles.add(str(board['source_role']))
    if defense.get('source_role'): roles.add(str(defense['source_role']))
    return roles


def _read_sources(cfg:dict,case_dir:Path,roles:set[str],errors:list[str])->dict[str,str]:
    src=cfg.get('source') or {}; out={}
    for role in sorted(roles):
        rel=src.get(role)
        if not rel:
            errors.append(f'SOURCE_ROLE_MISSING: {role}'); out[role]=''; continue
        p=case_dir/str(rel)
        if not p.exists():
            errors.append(f'SOURCE_FILE_MISSING: {role}: {rel}'); out[role]=''; continue
        out[role]=p.read_text(encoding='utf-8')
    return out


def _dotted(data:dict,path:str):
    cur=data
    for part in path.split('.'):
        if not isinstance(cur,dict) or part not in cur: return None
        cur=cur[part]
    return cur


def _board_case(cfg:dict,texts:dict[str,str],board_expect:dict,errors:list[str]):
    role=str(board_expect.get('source_role') or '')
    if not role:
        errors.append('BOARD_SOURCE_ROLE_MISSING'); return None
    try: data=yaml.safe_load(texts.get(role,'')) or {}
    except Exception as exc:
        errors.append(f'BOARD_YAML_INVALID: {exc}'); return None
    case_id=cfg.get('case_id'); cases=[x for x in (data.get('cases') or []) if x.get('id')==case_id]
    if len(cases)!=1:
        errors.append(f'BOARD_CASE_COUNT: expected 1 for {case_id}, got {len(cases)}'); return None
    return cases[0]


def validate_case(case_arg:str|Path,*,contract_root:Path=ROOT)->list[str]:
    cfg,case_dir,_=load_case(case_arg); errors=[]; regression=cfg.get('regression_contract') or {}
    if not regression: return ['REGRESSION_CONTRACT_MISSING']
    for key in sorted(FORBIDDEN_SHARED_REGRESSION_KEYS & set(regression)):
        errors.append(f'REGRESSION_SHARED_POLICY_LEAK: {key}')
    _,product_roles=_shared_product_roles(cfg,errors,contract_root)
    referenced_roles=product_roles|_regression_assertion_roles(regression); texts=_read_sources(cfg,case_dir,referenced_roles,errors)
    if regression.get('require_not_formal_delivery') and not cfg.get('not_formal_delivery'): errors.append('REGRESSION_MUST_BE_NONFORMAL')
    expected_status=regression.get('expected_status')
    if expected_status is not None and cfg.get('status')!=expected_status: errors.append(f'REGRESSION_STATUS_DRIFT: expected {expected_status}, got {cfg.get("status")}')
    lock_cfg=regression.get('source_lock') or {}
    if lock_cfg:
        lock=_dotted(cfg,lock_cfg.get('path','input.canonical_pdf'))
        if not isinstance(lock,dict): errors.append('SOURCE_LOCK_OBJECT_MISSING'); lock={}
        for key in lock_cfg.get('required_fields') or []:
            if not lock.get(key): errors.append(f'SOURCE_LOCK_FIELD_MISSING: {key}')
        for key in lock_cfg.get('null_until_human_verified') or []:
            if lock.get(key) is not None: errors.append(f'SOURCE_LOCK_FIELD_MUST_REMAIN_NULL: {key}')
    evidence_role=regression.get('evidence_source_role')
    if regression.get('evidence_false_flags') and not evidence_role: errors.append('EVIDENCE_SOURCE_ROLE_MISSING')
    if evidence_role:
        try: evidence=yaml.safe_load(texts.get(str(evidence_role),'')) or {}
        except Exception as exc: errors.append(f'EVIDENCE_YAML_INVALID: {exc}'); evidence={}
        source_status=evidence.get('source_status') or {}
        for flag in regression.get('evidence_false_flags') or []:
            if source_status.get(flag): errors.append(f'FALSE_SOURCE_PROMOTION: {flag}')
    notation_selftest()
    for role in regression.get('notation_roles') or []:
        for issue in lint_text(texts.get(str(role),'')): errors.append(f'{issue.code}: {role}: ${issue.fragment}$')
    for role,tokens in (regression.get('required_markers') or {}).items():
        text=texts.get(str(role),'')
        for token in tokens or []:
            if token not in text: errors.append(f'REQUIRED_MARKER_MISSING: {role}: {token}')
    for rule in regression.get('required_tokens') or []:
        combined='\n'.join(texts.get(str(role),'') for role in rule.get('roles') or [])
        for token in rule.get('tokens') or []:
            if token not in combined: errors.append(f'REQUIRED_TOKEN_MISSING: {token}')
    for rule in regression.get('forbidden_tokens') or []:
        combined='\n'.join(texts.get(str(role),'') for role in rule.get('roles') or [])
        for token in rule.get('tokens') or []:
            if token in combined: errors.append(f'FORBIDDEN_TOKEN_PRESENT: {token}')
    for role,limit in (regression.get('max_nonspace_chars') or {}).items():
        count=len(re.sub(r'\s+','',texts.get(str(role),'')))
        if count>int(limit): errors.append(f'MAX_NONSPACE_EXCEEDED: {role}: {count}>{limit}')
    board_expect=regression.get('board') or {}
    if board_expect:
        board=_board_case(cfg,texts,board_expect,errors)
        if board:
            if board_expect.get('layout') and board.get('layout')!=board_expect['layout']: errors.append(f'BOARD_LAYOUT_DRIFT: {board.get("layout")}')
            expected_numbers=board_expect.get('section_numbers')
            if expected_numbers is not None:
                actual=[x.get('number') for x in (board.get('sections') or [])]
                if actual!=expected_numbers: errors.append(f'BOARD_SECTION_NUMBERING_DRIFT: {actual}')
            expected_ids=board_expect.get('increment_ids')
            if expected_ids is not None:
                actual=list((board.get('increments') or {}).keys())
                if actual!=expected_ids: errors.append(f'BOARD_INCREMENT_CHAIN_DRIFT: {actual}')
    defense_cfg=regression.get('defense') or {}
    if defense_cfg:
        role=defense_cfg.get('source_role')
        if not role: errors.append('DEFENSE_SOURCE_ROLE_MISSING')
        else:
            pattern=defense_cfg.get('heading_regex',r'^##\s+\d+\.'); count=len(re.findall(pattern,texts.get(str(role),''),flags=re.M)); lo,hi=int(defense_cfg.get('min',0)),int(defense_cfg.get('max',10**9))
            if not lo<=count<=hi: errors.append(f'DEFENSE_COUNT_INVALID: {count} not in [{lo},{hi}]')
    return errors


def selftest()->None:
    notation_selftest()
    with tempfile.TemporaryDirectory(prefix='qz-regression-contract-') as tmp:
        d=Path(tmp); contract_dir=d/'production/contracts'; contract_dir.mkdir(parents=True)
        contract={
            'version':1,'id':'synthetic-regression-v1',
            'documents':{
                'primary':{'deliverable_role':'alpha','tex_filename':'a.tex','header_kind':'A','title_suffix':'A','subtitle':'A','sections':[
                    {'role':'source','heading':'一','renderer':'source_pages'}, {'role':'reference','heading':'二','renderer':'markdown','source_role':'ref_role'}, {'role':'skeleton','heading':'三','renderer':'markdown','source_role':'skel_role'}, {'role':'spoken','heading':'四','renderer':'markdown','source_role':'talk_role'}, {'role':'questions','heading':'五','renderer':'markdown','source_role':'qa_role'}]},
                'secondary':{'deliverable_role':'beta','tex_filename':'b.tex','header_kind':'B','title_suffix':'B','subtitle':'B','renderer':'markdown','source_role':'analysis_role'}},
            'render':{'dpi':200},
            'publication':{'publisher':'XeLaTeX','require_global_typography':True,'require_symbol_notation_lint':True,'forbid_case_id_leak':True,'forbidden_engineering_regexes':[r'\bP\d+\b']},
            'source_policy':{'require_source_pages':True,'require_locked_identity':True,'require_resilient_transport':True},
            'manifest_constraints':{'allowed':[],'required':[]},
            'qa':{'training_deliverable_role':'alpha','extraction_deliverable_role':'beta','skeleton_section_role':'skeleton','trial_section_role':'spoken','defense_section_role':'questions','homework_solution_section_role':'reference','exam_skeleton_section_pages_max':1,'skeleton_density':{'max_nonspace_chars':800,'min_content_lines':7,'max_content_lines':28,'max_avg_visible_chars_per_line':46,'max_single_line_visible_chars':96,'max_full_sentence_ratio':.3,'min_cue_line_ratio':.6,'max_long_prose_lines':2},'defense_questions':{'heading_regex':r'^##\s+\d+\.','min':1,'max':2},'homework_solution':{'required':False,'token':'解析'},'required_training_section_roles':['source','questions'],'required_extraction_sections':['证据']}}
        (contract_dir/'synthetic-regression-v1.yaml').write_text(yaml.safe_dump(contract,allow_unicode=True,sort_keys=False),encoding='utf-8')
        files={'evidence.yaml':'source_status:\n  pixel_ok: false\n','BOARD_PLAN.yaml':'cases:\n- id: SYNTH-A\n  layout: linear\n  sections: []\n  increments:\n    P0: x\n','reference.md':'# synthetic\nREQUIRED\n','skeleton.md':'# synthetic\nshort\n','trial.md':'# synthetic\nREQUIRED\n','defense.md':'## 1. Q\nA\n','analysis.md':'# synthetic\n'}
        for name,text in files.items(): (d/name).write_text(text,encoding='utf-8')
        cfg={'case_id':'SYNTH-A','title':'synthetic unrelated fixture','product_contract':'synthetic-regression-v1','status':'blocked','not_formal_delivery':True,'input':{'canonical_pdf':{'repo':'r','ref':'f','path':'p.pdf','blob_sha':'b','size_bytes':1,'physical_pages':None}},'source':{'evidence_role':'evidence.yaml','board_role':'BOARD_PLAN.yaml','ref_role':'reference.md','skel_role':'skeleton.md','talk_role':'trial.md','qa_role':'defense.md','analysis_role':'analysis.md'},'regression_contract':{'expected_status':'blocked','require_not_formal_delivery':True,'source_lock':{'path':'input.canonical_pdf','required_fields':['repo','ref','path','blob_sha','size_bytes'],'null_until_human_verified':['physical_pages']},'evidence_source_role':'evidence_role','evidence_false_flags':['pixel_ok'],'notation_roles':['ref_role','skel_role','talk_role','qa_role','analysis_role','board_role'],'required_tokens':[{'roles':['ref_role','talk_role'],'tokens':['REQUIRED']}],'forbidden_tokens':[{'roles':['skel_role'],'tokens':['FORBIDDEN']}],'max_nonspace_chars':{'skel_role':200},'board':{'source_role':'board_role','layout':'linear','section_numbers':[],'increment_ids':['P0']},'defense':{'source_role':'qa_role','heading_regex':r'^##\s+\d+\.','min':1,'max':2}}}
        (d/'case.yaml').write_text(yaml.safe_dump(cfg,allow_unicode=True,sort_keys=False),encoding='utf-8')
        found=validate_case(d/'case.yaml',contract_root=d)
        if found: raise AssertionError('generic regression selftest pass fixture rejected: '+repr(found))
        bad=yaml.safe_load((d/'case.yaml').read_text(encoding='utf-8')); bad['regression_contract']['visual_render_dpi']=240; (d/'case.yaml').write_text(yaml.safe_dump(bad,allow_unicode=True,sort_keys=False),encoding='utf-8')
        found=validate_case(d/'case.yaml',contract_root=d)
        if not any(x.startswith('REGRESSION_SHARED_POLICY_LEAK') for x in found): raise AssertionError('fixture-local shared render policy escaped')
        bad['regression_contract'].pop('visual_render_dpi'); (d/'case.yaml').write_text(yaml.safe_dump(bad,allow_unicode=True,sort_keys=False),encoding='utf-8')
        (d/'skeleton.md').write_text('# synthetic\nFORBIDDEN\n',encoding='utf-8'); found=validate_case(d/'case.yaml',contract_root=d)
        if not any(x.startswith('FORBIDDEN_TOKEN_PRESENT') for x in found): raise AssertionError('generic regression selftest failed to reject forbidden token')

if __name__=='__main__': selftest(); print('generic regression contract selftest: PASS')
