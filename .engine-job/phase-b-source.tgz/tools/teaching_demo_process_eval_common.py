from __future__ import annotations

import hashlib
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Any

import yaml

try:
    from check_execution_ledger import derive as ledger_derive
    from check_execution_ledger import project_lifecycle as ledger_project_lifecycle
    from check_execution_ledger import validate as ledger_validate
    CANONICAL_IMPORT_ERROR: str | None = None
except Exception as exc:
    ledger_derive = ledger_project_lifecycle = ledger_validate = None
    CANONICAL_IMPORT_ERROR = f"{type(exc).__name__}: {exc}"

RULES_REL = Path("production/process-development/teaching-demo-quality-v2/PROCESS_EVALUATION_RULES.yaml")
POOL_REL = Path("production/process-development/teaching-demo-quality-v2/TOPIC_POOL.yaml")
SLOTS_REL = Path("production/process-development/teaching-demo-quality-v2/process-evaluation/slots")
CURRENT_REL = Path("assets/textbooks/physics/pep/CURRENT.json")
LEDGER_CONTRACT_REL = Path("production/contracts/execution-ledger-v1.yaml")
ARTIFACT_JOBS_REL = Path("production/artifact-jobs/teacher_teaching_demo")
CASE_ROOT_REL = Path("production/teaching-demo-cases")
WARM_DIFF_SCHEMA = "teaching-demo-warm-implementation-diff-v1"
WARM_ACCEPT_SCHEMA = "teaching-demo-warm-independent-acceptance-v1"
WARM_REQUIRED_SCOPE_PATHS = {
    "tools",
    "production/contracts",
    "production/templates/teacher_teaching_demo",
}
HEX = set("0123456789abcdef")


class GateError(RuntimeError):
    pass


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def is_sha256(value: Any) -> bool:
    return isinstance(value, str) and len(value) == 64 and set(value) <= HEX


def is_git_sha1(value: Any) -> bool:
    return isinstance(value, str) and len(value) == 40 and set(value.lower()) <= HEX


def parse_iso8601(value: Any) -> bool:
    if not isinstance(value, str) or not value:
        return False
    try:
        datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return False
    return True


def load_yaml(path: Path):
    try:
        return yaml.safe_load(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise GateError(f"YAML_LOAD_FAILED: {path}: {exc}") from exc


def safe_rel_path(value: Any, *, label: str) -> Path:
    if not isinstance(value, str) or not value.strip():
        raise GateError(f"{label}_MISSING")
    rel = Path(value)
    if rel.is_absolute() or ".." in rel.parts:
        raise GateError(f"{label}_PATH_INVALID: {value}")
    return rel


def require_canonical_ledger() -> None:
    if CANONICAL_IMPORT_ERROR is not None or not all(
        callable(x) for x in (ledger_validate, ledger_project_lifecycle, ledger_derive)
    ):
        suffix = f": {CANONICAL_IMPORT_ERROR}" if CANONICAL_IMPORT_ERROR else ""
        raise GateError("CANONICAL_LEDGER_VALIDATOR_UNAVAILABLE" + suffix)


def selection_digest(beacon_output: str, pool_sha256: str, entropy_commit: str, slot: int) -> str:
    payload = f"{beacon_output}\n{pool_sha256}\n{entropy_commit}\n{slot}".encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def git_show_bytes(repo: Path, commit: str, rel: Path) -> bytes:
    try:
        return subprocess.check_output(
            ["git", "-C", str(repo), "show", f"{commit}:{rel.as_posix()}"],
            stderr=subprocess.STDOUT,
        )
    except (subprocess.CalledProcessError, OSError) as exc:
        raise GateError(f"POOL_LOCK_COMMIT_CANNOT_RESOLVE: {commit}:{rel}") from exc


def git_is_ancestor(repo: Path, ancestor: str, descendant: str) -> bool:
    try:
        result = subprocess.run(
            ["git", "-C", str(repo), "merge-base", "--is-ancestor", ancestor, descendant],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except OSError as exc:
        raise GateError(f"GIT_ANCESTRY_CHECK_FAILED: {ancestor} -> {descendant}") from exc
    if result.returncode not in (0, 1):
        raise GateError(f"GIT_ANCESTRY_CHECK_FAILED: {ancestor} -> {descendant}")
    return result.returncode == 0


def git_diff_names(repo: Path, baseline: str, head: str, scope_paths: list[str]) -> list[str]:
    try:
        raw = subprocess.check_output(
            ["git", "-C", str(repo), "diff", "--name-only", baseline, head, "--", *scope_paths],
            stderr=subprocess.STDOUT,
            text=True,
        )
    except (subprocess.CalledProcessError, OSError) as exc:
        raise GateError(f"WARM_IMPLEMENTATION_DIFF_CANNOT_RECOMPUTE: {baseline}..{head}") from exc
    return sorted({line.strip() for line in raw.splitlines() if line.strip()})


def case_manifest_path(case_id: str) -> str:
    return (CASE_ROOT_REL / case_id / "manifest.yaml").as_posix()


def job_matches_case(job: dict, case_id: str) -> bool:
    target = case_manifest_path(case_id)
    return any(
        isinstance(binding, dict)
        and binding.get("path") == target
        and binding.get("kind") == "case_manifest"
        for binding in (job.get("input_bindings") or [])
    )


def binding_key(binding: Any, *, label: str) -> tuple[str, str, str]:
    if not isinstance(binding, dict):
        raise GateError(f"{label}_BINDING_NOT_MAPPING")
    path = safe_rel_path(binding.get("path"), label=f"{label}_PATH").as_posix()
    digest = binding.get("sha256")
    kind = binding.get("kind")
    if not is_sha256(digest):
        raise GateError(f"{label}_SHA256_INVALID")
    if not isinstance(kind, str) or not kind:
        raise GateError(f"{label}_KIND_INVALID")
    return path, digest, kind


def binding_set(items: Any, *, label: str, require_nonempty: bool = False) -> set[tuple[str, str, str]]:
    if not isinstance(items, list):
        raise GateError(f"{label}_MUST_BE_LIST")
    if require_nonempty and not items:
        raise GateError(f"{label}_EMPTY")
    result = {binding_key(item, label=f"{label}[{idx}]") for idx, item in enumerate(items)}
    if len(result) != len(items):
        raise GateError(f"{label}_DUPLICATE_BINDING")
    return result


def load_bound_yaml_evidence(repo: Path, ref: Any, *, label: str) -> dict:
    if not isinstance(ref, dict):
        raise GateError(f"{label}_REFERENCE_MUST_BE_MAPPING")
    rel = safe_rel_path(ref.get("path"), label=f"{label}_PATH")
    digest = ref.get("sha256")
    if not is_sha256(digest):
        raise GateError(f"{label}_REFERENCE_SHA256_INVALID")
    path = repo / rel
    if not path.is_file():
        raise GateError(f"{label}_FILE_MISSING: {rel.as_posix()}")
    actual = sha256_file(path)
    if actual != digest:
        raise GateError(f"{label}_HASH_MISMATCH: declared={digest} actual={actual}")
    data = load_yaml(path)
    if not isinstance(data, dict):
        raise GateError(f"{label}_EVIDENCE_NOT_MAPPING")
    return data


def normalize_scope_paths(value: Any) -> list[str]:
    if not isinstance(value, list) or not value:
        raise GateError("WARM_DIFF_SCOPE_PATHS_INVALID")
    out: list[str] = []
    for idx, raw in enumerate(value):
        rel = safe_rel_path(raw, label=f"WARM_DIFF_SCOPE_PATHS[{idx}]").as_posix().rstrip("/")
        if not rel:
            raise GateError("WARM_DIFF_SCOPE_PATH_EMPTY")
        out.append(rel)
    if len(out) != len(set(out)):
        raise GateError("WARM_DIFF_SCOPE_PATH_DUPLICATE")
    if not WARM_REQUIRED_SCOPE_PATHS <= set(out):
        raise GateError(f"WARM_DIFF_SCOPE_INCOMPLETE: {sorted(WARM_REQUIRED_SCOPE_PATHS - set(out))}")
    return sorted(out)
