"""Validate normalized structured-interview reference-bank JSONL files.

Includes deterministic exact duplicate detection and a conservative character n-gram
near-duplicate heuristic. It never claims semantic equivalence or official provenance.
"""
from __future__ import annotations
import argparse,hashlib,json,re,sys,unicodedata
from pathlib import Path
import yaml

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'content/job-search/teacher/interview/structured'
REGISTRY=BASE/'reference-bank/source-registry.yaml'
DEFAULT_DIR=BASE/'reference-bank/normalized'
TYPES={f'T{i}' for i in range(1,10)}
STATUSES={'ready','needs-review','rejected'}
USAGE={'verbatim','paraphrased','summary','derived-scenario','synthetic','user-provided'}
RISKS={'normal','conflict','safety','ethics-compliance','unknown'}
NEAR_DUP_THRESHOLD=0.88

def args():
    p=argparse.ArgumentParser(description='Validate normalized structured-interview reference bank.')
    p.add_argument('input',nargs='*',help='JSONL file(s); defaults to reference-bank/normalized/*.jsonl')
    return p.parse_args()

def clean(v): return re.sub(r'\s+',' ',str(v or '').replace('\ufeff',' ')).strip()

def canonical(q):
    text=unicodedata.normalize('NFKC',clean(q)).lower()
    return ''.join(ch for ch in text if ch.isalnum())

def exact_key(q): return hashlib.sha256(canonical(q).encode('utf-8')).hexdigest()[:16]

def grams(text,n=2):
    text=canonical(text)
    if len(text)<n: return {text} if text else set()
    return {text[i:i+n] for i in range(len(text)-n+1)}

def similarity(a,b):
    ga,gb=grams(a),grams(b)
    if not ga or not gb: return 0.0
    return len(ga&gb)/len(ga|gb)

def load_registry():
    data=yaml.safe_load(REGISTRY.read_text(encoding='utf-8')) or {}
    sources=data.get('sources') or {}
    if not isinstance(sources,dict) or not sources: raise ValueError('source registry empty/invalid')
    for sid,src in sources.items():
        if not isinstance(src,dict) or not src.get('authority') or not str(src.get('url') or '').startswith('https://'):
            raise ValueError(f'invalid source registry entry: {sid}')
        allowed=src.get('allowed_usage') or []
        if not isinstance(allowed,list) or not allowed: raise ValueError(f'{sid}: allowed_usage missing')
        unknown=set(str(x) for x in allowed)-USAGE
        if unknown: raise ValueError(f'{sid}: unsupported allowed_usage: {sorted(unknown)}')
    return sources

def discover(raw):
    if raw: paths=[Path(x) for x in raw]
    else: paths=sorted(DEFAULT_DIR.glob('*.jsonl')) if DEFAULT_DIR.exists() else []
    if not paths: raise FileNotFoundError('no normalized reference-bank JSONL files found')
    return paths

def load_jsonl(path):
    out=[]
    with path.open('r',encoding='utf-8-sig') as f:
        for n,line in enumerate(f,1):
            if not line.strip(): continue
            obj=json.loads(line)
            if not isinstance(obj,dict): raise ValueError(f'{path}:{n}: record must be object')
            obj['_path']=str(path); obj['_line']=n; out.append(obj)
    return out

def validate_record(r,sources,seen_ids,seen_exact):
    errs=[]; rid=clean(r.get('id')); status=clean(r.get('status'))
    if not rid: errs.append('missing id')
    elif rid in seen_ids: errs.append(f'duplicate id: {rid}')
    else: seen_ids.add(rid)
    if status not in STATUSES: errs.append(f'invalid status: {status}')
    q=clean(r.get('question')); norm=clean(r.get('normalized_question')); ex=clean(r.get('exact_key'))
    if not q: errs.append('missing question')
    if norm!=canonical(q): errs.append('normalized_question mismatch')
    if ex!=exact_key(q): errs.append('exact_key mismatch')
    sid=clean(r.get('source_id')); usage=clean(r.get('source_usage'))
    if sid not in sources: errs.append(f'unregistered source_id: {sid}')
    if usage not in USAGE: errs.append(f'invalid source_usage: {usage}')
    elif sid in sources and usage not in set(sources[sid].get('allowed_usage') or []): errs.append(f'source_usage not allowed by source registry: {usage}')
    primary=clean(r.get('primary_type'))
    secondary=r.get('secondary_types') or []
    if not isinstance(secondary,list) or any(clean(x) not in TYPES for x in secondary): errs.append('invalid secondary_types')
    if clean(r.get('risk_level')) not in RISKS: errs.append('invalid risk_level')
    if usage=='derived-scenario':
        notes=clean(r.get('notes'))
        if not notes: errs.append('derived-scenario requires notes explaining derivation/non-official status')
    if status=='ready':
        if primary not in TYPES: errs.append('ready record requires valid primary_type')
        if ex in seen_exact: errs.append(f'exact duplicate of {seen_exact[ex]}')
        else: seen_exact[ex]=rid
    elif primary and primary not in TYPES: errs.append('invalid primary_type')
    if not isinstance(r.get('tags') or [],list): errs.append('tags must be list')
    return errs

def near_duplicate_errors(records):
    ready=[r for r in records if clean(r.get('status'))=='ready']
    errors=[]
    for i,a in enumerate(ready):
        for b in ready[i+1:]:
            if a.get('exact_key')==b.get('exact_key'): continue
            score=similarity(a.get('question'),b.get('question'))
            if score<NEAR_DUP_THRESHOLD: continue
            if a.get('dedup_exception') or b.get('dedup_exception'): continue
            errors.append(f"near-duplicate {a.get('id')} ~ {b.get('id')} similarity={score:.2f}; add dedup_exception only when training value is explicit")
    return errors

def main():
    try:
        sources=load_registry(); records=[]
        for path in discover(args().input): records.extend(load_jsonl(path))
        seen_ids=set(); seen_exact={}; errors=[]
        for r in records:
            for err in validate_record(r,sources,seen_ids,seen_exact): errors.append(f"{r['_path']}:{r['_line']}: {err}")
        errors.extend(near_duplicate_errors(records))
    except Exception as exc:
        print(f'STRUCTURED_REFERENCE_BANK_FAIL: {exc}',file=sys.stderr); return 1
    if errors:
        print('\n'.join(errors),file=sys.stderr); print(f'STRUCTURED_REFERENCE_BANK_FAIL invalid={len(errors)} records={len(records)}',file=sys.stderr); return 1
    print(f'structured reference bank: PASS records={len(records)} sources={len(sources)} near_dup_threshold={NEAR_DUP_THRESHOLD}')
    return 0

if __name__=='__main__': raise SystemExit(main())
