"""Canonical machine acceptance runner for teacher structured-interview assets.

Runs repository-wide route/generalization gates before structured-specific checks. It
never knows a specific question, case id, training suite or exam profile identity.
"""
from __future__ import annotations
from pathlib import Path
import subprocess,sys

ROOT=Path(__file__).resolve().parents[1]
GLOBAL_GATES=['check_tooling_routes.py','check_generalization_architecture.py']
STRUCTURED_GATES=[
    'validate_structured_reference_bank.py',
    'check_structured_interview.py',
    'check_structured_training_cases.py',
    'check_structured_training_state.py',
    'check_structured_pagination.py',
]
STAGES=GLOBAL_GATES+STRUCTURED_GATES

def selftest():
    if len(STAGES)!=len(set(STAGES)): raise AssertionError('duplicate structured acceptance stage')
    for stage in STAGES:
        if not (ROOT/'tools'/stage).exists(): raise AssertionError(f'missing structured acceptance tool: {stage}')
    product_tools={'run_acceptance.py','publisher_core.py','build_current_run.py','check_current_run.py','render_current_run.py'}
    if product_tools & set(STAGES): raise AssertionError('teaching-demo product execution leaked into structured acceptance')

def run(stage):
    cmd=[sys.executable,str(ROOT/'tools'/stage)]
    print('>>>',' '.join(cmd),flush=True)
    proc=subprocess.run(cmd,cwd=ROOT)
    if proc.returncode: raise SystemExit(f'structured acceptance failed: {stage}: exit={proc.returncode}')

def main():
    selftest()
    for stage in STAGES: run(stage)
    print('structured-interview phase-3 machine acceptance: PASS')
    return 0

if __name__=='__main__': raise SystemExit(main())
