"""Locate candidate PDF physical pages for any locked textbook printed pages.

This tool fixes a recurring failure mode: guessing that printed page N maps to a
particular PDF physical page. It never promotes a mapping automatically.

Workflow:
  locked source identity -> obtain/validate binary -> text-rank candidate page
  sequences -> render top candidates at 200 dpi -> human visual confirmation.

All topic-specific anchors live in the supplied manifest. The locator itself has
no default topic, title or case id.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import re
import shutil
import subprocess
import sys

import yaml
from pypdf import PdfReader

import build_current_run as publisher

ROOT = Path(__file__).resolve().parents[1]


def load_case(path: Path) -> dict:
    data = yaml.safe_load(path.read_text(encoding='utf-8')) or {}
    if not data:
        raise SystemExit(f'empty manifest: {path}')
    return data


def source_and_locator(cfg: dict) -> tuple[dict, dict, list[int]]:
    inp = cfg.get('input') or {}
    source = inp.get('canonical_pdf') or inp.get('source_pages') or {}
    locator = inp.get('page_locator') or {}
    printed = [int(x) for x in (inp.get('printed_pages') or [])]
    if not printed:
        raise SystemExit('manifest must define input.printed_pages')
    for key in ('repo', 'ref', 'path', 'blob_sha', 'size_bytes'):
        if not source.get(key):
            raise SystemExit(f'locked source missing {key}')
    if not locator.get('anchors'):
        raise SystemExit('manifest must define input.page_locator.anchors')
    return source, locator, printed


def extract_page_text(pdf: Path, page: int) -> str:
    proc = subprocess.run(
        ['pdftotext', '-f', str(page), '-l', str(page), '-layout', str(pdf), '-'],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )
    if proc.returncode:
        return ''
    return proc.stdout


def normalize(text: str) -> str:
    return re.sub(r'\s+', '', text)


def page_score(text: str, anchors: list[str], context: list[str], printed_page: int | None) -> tuple[int, list[str]]:
    compact = normalize(text)
    score = 0
    hits: list[str] = []
    for anchor in anchors:
        key = normalize(str(anchor))
        if key and key in compact:
            score += 5
            hits.append('anchor:' + str(anchor))
    for marker in context:
        key = normalize(str(marker))
        if key and key in compact:
            score += 2
            hits.append('context:' + str(marker))
    if printed_page is not None and re.search(rf'(?<!\d){printed_page}(?!\d)', text):
        score += 8
        hits.append('printed-number:' + str(printed_page))
    return score, hits


def rank_sequences(page_text: list[str], printed: list[int], locator: dict) -> list[dict]:
    anchors = [str(x) for x in (locator.get('anchors') or [])]
    context = [str(x) for x in (locator.get('printed_page_context') or [])]
    count = int(locator.get('expected_count') or len(printed))
    if count != len(printed):
        raise SystemExit('page_locator.expected_count must equal len(input.printed_pages)')
    ranked = []
    for start in range(1, len(page_text) - count + 2):
        total = 0
        details = []
        for offset in range(count):
            physical = start + offset
            score, hits = page_score(page_text[physical - 1], anchors, context, printed[offset])
            total += score
            details.append({'physical_page': physical, 'printed_page': printed[offset], 'score': score, 'hits': hits})
        if locator.get('require_consecutive', True):
            total += 4
        ranked.append({'start_physical_page': start, 'physical_pages': list(range(start, start + count)), 'score': total, 'details': details})
    ranked.sort(key=lambda x: (-x['score'], x['start_physical_page']))
    return ranked


def render_pages(pdf: Path, pages: list[int], out_dir: Path, dpi: int = 200) -> list[str]:
    out_dir.mkdir(parents=True, exist_ok=True)
    outputs = []
    for page in pages:
        prefix = out_dir / f'physical-{page:04d}'
        png = Path(str(prefix) + '.png')
        proc = subprocess.run(
            ['pdftoppm', '-f', str(page), '-l', str(page), '-singlefile', '-png', '-r', str(dpi), str(pdf), str(prefix)],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
        )
        if proc.returncode or not png.exists():
            raise SystemExit(f'pdftoppm failed for physical page {page}:\n{proc.stdout[-3000:]}')
        outputs.append(str(png))
    return outputs


def make_contact_sheet(paths: list[str], output: Path):
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        return
    cards = []
    for path in paths:
        p = Path(path)
        im = Image.open(p).convert('RGB')
        width = 520
        height = round(im.height * width / im.width)
        im = im.resize((width, height))
        card = Image.new('RGB', (width + 24, height + 54), 'white')
        card.paste(im, (12, 34))
        ImageDraw.Draw(card).text((12, 10), p.stem, fill='black')
        cards.append(card)
    if not cards:
        return
    sheet = Image.new('RGB', (sum(x.width for x in cards), max(x.height for x in cards)), (235, 235, 235))
    x = 0
    for card in cards:
        sheet.paste(card, (x, 0)); x += card.width
    sheet.save(output, quality=90)


def selftest():
    # Deliberately synthetic and unrelated to any real regression fixture.
    synthetic = [
        '目录',
        '单元甲 18 其他内容',
        '单元甲 19 其他内容',
        '单元甲 20 合成目标 核心词甲 核心词乙',
        '单元甲 21 核心词丙 核心词丁 合成目标',
        '单元甲 22 后续内容',
    ]
    locator = {
        'anchors': ['合成目标', '核心词甲', '核心词乙', '核心词丙', '核心词丁'],
        'printed_page_context': ['单元甲'],
        'expected_count': 2,
        'require_consecutive': True,
    }
    ranked = rank_sequences(synthetic, [20, 21], locator)
    assert ranked[0]['physical_pages'] == [4, 5], ranked[:3]
    print('locked textbook page locator selftest: PASS')


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('--manifest', type=Path, help='case/current-run manifest containing source identity + page_locator')
    parser.add_argument('--pdf', type=Path, help='optional local locked PDF; still validated against manifest identity')
    parser.add_argument('--out-dir', type=Path, default=ROOT/'qa/source-page-locator')
    parser.add_argument('--top', type=int, default=4)
    parser.add_argument('--selftest', action='store_true')
    args = parser.parse_args(argv)
    if args.selftest:
        selftest()
        if not args.manifest:
            return 0
    if not args.manifest:
        parser.error('--manifest is required unless --selftest is used alone')

    cfg = load_case(args.manifest)
    source, locator, printed = source_and_locator(cfg)
    case_id = cfg.get('case_id') or args.manifest.stem
    out = args.out_dir / str(case_id)
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True, exist_ok=True)

    if args.pdf:
        pdf = args.pdf.resolve()
        publisher._validate_locked_pdf(pdf, source)
        acquisition = {'transport': 'local-validated-argument', 'cache_hit': False}
    else:
        pdf, acquisition = publisher._download_locked_pdf(source)

    total_pages = len(PdfReader(str(pdf)).pages)
    texts = [extract_page_text(pdf, page) for page in range(1, total_pages + 1)]
    ranked = rank_sequences(texts, printed, locator)
    top = ranked[:max(1, args.top)]
    unique_pages = []
    for candidate in top:
        for page in candidate['physical_pages']:
            if page not in unique_pages:
                unique_pages.append(page)

    render_dir = out / 'candidate-pages-200dpi'
    rendered = render_pages(pdf, unique_pages, render_dir, 200)
    make_contact_sheet(rendered, out / 'candidate-contact-sheet.jpg')

    report = {
        'case_id': case_id,
        'printed_pages': printed,
        'locked_source': {k: source.get(k) for k in ('repo','ref','path','blob_sha','size_bytes')},
        'acquisition': acquisition,
        'pdf_total_physical_pages': total_pages,
        'top_candidate_sequences': top,
        'rendered_candidate_pages': rendered,
        'status': 'HUMAN_PIXEL_CONFIRMATION_REQUIRED',
        'promotion_rule': 'Do not write physical_pages or page_pixels_verified=true until rendered candidates are actually opened and confirmed.',
    }
    (out / 'locator-report.yaml').write_text(yaml.safe_dump(report, allow_unicode=True, sort_keys=False), encoding='utf-8')
    print(yaml.safe_dump(report, allow_unicode=True, sort_keys=False))
    return 0


if __name__ == '__main__':
    sys.exit(main())
