#!/usr/bin/env python3
from __future__ import annotations

from collections import Counter
from pathlib import Path
import re
import sys
import yaml

ROOT = Path(__file__).resolve().parents[1]
BANK = ROOT / 'content/job-search/teacher/interview/defense/materials/yunnan/final-quality-r1/question-seed-bank-v1.yaml'


def fail(message: str) -> None:
    raise SystemExit(f'DEFENSE_FINALIZATION_SEED_FAIL: {message}')


def main() -> int:
    data = yaml.safe_load(BANK.read_text(encoding='utf-8'))
    if not isinstance(data, dict):
        fail('bank is not a mapping')
    teaching = (data.get('teaching_variants') or {}).get('items') or []
    physics = (data.get('physics_variants') or {}).get('items') or []
    items = teaching + physics
    if len(teaching) != 72:
        fail(f'teaching count expected 72, got {len(teaching)}')
    if len(physics) != 48:
        fail(f'physics count expected 48, got {len(physics)}')
    if len(items) != int(data.get('count') or 0) or len(items) != 120:
        fail(f'total count mismatch: declared={data.get("count")} actual={len(items)}')

    ids = [item.get('id') for item in items]
    if any(not isinstance(x, str) or not re.fullmatch(r'DEF-R1-[A-Z0-9-]+', x) for x in ids):
        fail('invalid id pattern')
    dup = [k for k, n in Counter(ids).items() if n > 1]
    if dup:
        fail(f'duplicate ids: {dup}')

    required = {'defense_type', 'knowledge_cluster', 'training_tier', 'answer_time_seconds', 'question', 'compact_skeleton'}
    for item in items:
        missing = sorted(k for k in required if not item.get(k))
        if missing:
            fail(f'{item.get("id")}: missing {missing}')
        if item['training_tier'] not in {'core', 'frequent', 'stretch'}:
            fail(f'{item["id"]}: invalid training_tier')
        if item['answer_time_seconds'] not in {30, 60, 90}:
            fail(f'{item["id"]}: invalid answer_time_seconds')
        if len(item['question']) < 8:
            fail(f'{item["id"]}: question too short')
        if len(item['compact_skeleton']) < 5:
            fail(f'{item["id"]}: skeleton too short')

    t_counts = Counter(item['defense_type'] for item in teaching)
    expected = {'D1': 10, 'D2': 10, 'D3': 12, 'D4': 12, 'D5': 10, 'D6': 10, 'D8': 8}
    if dict(t_counts) != expected:
        fail(f'teaching taxonomy drift: {dict(t_counts)} != {expected}')
    if any(item['defense_type'] != 'D7' for item in physics):
        fail('all physics seeds must be D7')

    corpus = '\n'.join(item['question'] for item in items)
    forbidden_claims = ['云南真题', '历年真题', '必考', '每年都考', '高频真题']
    hit = [term for term in forbidden_claims if term in corpus]
    if hit:
        fail(f'forbidden provenance/frequency claim: {hit}')

    normalized = Counter(re.sub(r'[，。？！；：“”\s]', '', item['question']) for item in items)
    duplicate_questions = [q for q, n in normalized.items() if n > 1]
    if duplicate_questions:
        fail(f'exact normalized duplicate questions: {duplicate_questions[:5]}')

    print('DEFENSE_FINALIZATION_SEED_PASS total=120 teaching=72 physics=48')
    print(f'teaching_taxonomy={dict(t_counts)}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
