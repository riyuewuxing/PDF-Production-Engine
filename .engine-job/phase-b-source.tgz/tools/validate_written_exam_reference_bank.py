"""Validate normalized teacher written-exam JSONL reference banks.

Hard failures include missing profile/source identity, ready items without answer/analysis,
subject-bound items without stage/subject, invalid question/source usages and exact duplicates.
"""
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path
import sys

FAMILIES = {"YN-WE-F1", "YN-WE-F2", "YN-WE-F3"}
QUESTION_TYPES = {
    "single-choice", "multiple-choice", "true-false", "fill-blank", "short-answer",
    "discrimination", "case-analysis", "education-design", "application-writing",
    "calculation", "proof", "experiment", "other-subjective",
}
SUBJECTIVE_TYPES = {
    "fill-blank", "short-answer", "discrimination", "case-analysis", "education-design",
    "application-writing", "calculation", "proof", "experiment", "other-subjective",
}
SOURCE_USAGES = {
    "official-question", "public-recalled-question", "public-training", "derived-practice", "user-provided"
}
RISKS = {"low", "medium", "high"}


class BankValidationError(ValueError):
    pass


def load_rows(path: Path) -> list[dict]:
    rows = []
    for line_no, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            value = json.loads(line)
        except json.JSONDecodeError as exc:
            raise BankValidationError(f"line {line_no}: invalid JSON: {exc}") from exc
        if not isinstance(value, dict):
            raise BankValidationError(f"line {line_no}: row must be object")
        value["_line"] = line_no
        rows.append(value)
    return rows


def nonempty(value) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        return bool(value.strip())
    if isinstance(value, (list, dict)):
        return bool(value)
    return True


def validate_row(row: dict) -> None:
    line = row["_line"]
    rid = str(row.get("id") or "")
    if not rid.startswith("WE-"):
        raise BankValidationError(f"line {line}: invalid id={rid!r}")
    status = row.get("status")
    if status not in {"ready", "partial", "placeholder", "retired"}:
        raise BankValidationError(f"{rid}: invalid status={status!r}")
    family = row.get("profile_family")
    if family not in FAMILIES:
        raise BankValidationError(f"{rid}: invalid profile_family={family!r}")
    qtype = row.get("question_type")
    if qtype not in QUESTION_TYPES:
        raise BankValidationError(f"{rid}: invalid question_type={qtype!r}")
    usage = row.get("source_usage")
    if usage not in SOURCE_USAGES:
        raise BankValidationError(f"{rid}: invalid source_usage={usage!r}")
    if row.get("risk") not in RISKS:
        raise BankValidationError(f"{rid}: invalid risk={row.get('risk')!r}")
    for field in ("stem", "normalized_stem", "exact_key", "module"):
        if not nonempty(row.get(field)):
            raise BankValidationError(f"{rid}: missing {field}")

    if family in {"YN-WE-F2", "YN-WE-F3"}:
        if not nonempty(row.get("stage")) or not nonempty(row.get("subject")):
            raise BankValidationError(f"{rid}: subject-bound family requires stage and subject")

    if usage != "user-provided" and not nonempty(row.get("source_id")):
        raise BankValidationError(f"{rid}: non-user source_usage requires source_id")

    if status != "ready":
        return
    if not nonempty(row.get("answer")):
        raise BankValidationError(f"{rid}: ready item missing answer")
    if not nonempty(row.get("analysis")):
        raise BankValidationError(f"{rid}: ready item missing analysis")

    if qtype == "single-choice":
        options = row.get("options")
        if not isinstance(options, dict) or len(options) < 2:
            raise BankValidationError(f"{rid}: single-choice requires option map")
        answer = row.get("answer")
        if isinstance(answer, list) or str(answer) not in options:
            raise BankValidationError(f"{rid}: single-choice answer must be exactly one option key")

    if qtype in SUBJECTIVE_TYPES and not (nonempty(row.get("answer_points")) or nonempty(row.get("rubric"))):
        raise BankValidationError(f"{rid}: subjective ready item needs answer_points or rubric")

    if usage == "derived-practice":
        notes = str(row.get("notes") or "")
        if "真题" in notes or "官方原题" in notes:
            raise BankValidationError(f"{rid}: derived-practice notes may not claim true/official question status")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    args = parser.parse_args()

    rows = load_rows(args.input)
    for row in rows:
        validate_row(row)

    ready_keys = [str(r.get("exact_key")) for r in rows if r.get("status") == "ready"]
    duplicates = [key for key, count in Counter(ready_keys).items() if count > 1]
    if duplicates:
        raise BankValidationError(f"exact duplicate ready items: {duplicates[:10]}")

    by_family = Counter(str(r.get("profile_family")) for r in rows)
    by_usage = Counter(str(r.get("source_usage")) for r in rows)
    print(f"written-exam reference bank: PASS rows={len(rows)} ready={sum(r.get('status') == 'ready' for r in rows)}")
    print("families=" + json.dumps(by_family, ensure_ascii=False, sort_keys=True))
    print("source_usage=" + json.dumps(by_usage, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except BankValidationError as exc:
        print(f"WRITTEN_EXAM_BANK_FAIL: {exc}", file=sys.stderr)
        raise SystemExit(1)
