#!/usr/bin/env python3
"""Deterministic maintenance gate for Phase9 recruitment attachment capture."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
import yaml

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "content/job-search/teacher/position-research"
FIXTURE = BASE / "fixtures/attachment-live-regression-v1.yaml"
PRIMARY = ROOT / "tools/fetch_teacher_recruitment_attachments.py"
BROWSER = ROOT / "tools/fetch_teacher_recruitment_attachments_browser.py"
SANITIZER = ROOT / "tools/sanitize_teacher_recruitment_attachment_artifacts.py"
ORCHESTRATOR = ROOT / "tools/run_teacher_recruitment_attachment_capture.py"
CORRECTION = BASE / "materials/yunnan/maintenance/attachment-source-corrections-v1.yaml"
LIVE = BASE / "materials/yunnan/maintenance/attachment-live-result.json"


def require(ok: bool, msg: str, errors: list[str]) -> None:
    if not ok:
        errors.append(msg)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--require-live", action="store_true")
    args = ap.parse_args()
    errors: list[str] = []

    cfg = yaml.safe_load(FIXTURE.read_text(encoding="utf-8"))
    articles = cfg.get("articles") or []
    policy = cfg.get("policy") or {}
    require(len(articles) == 6, "live regression must keep six official article fixtures", errors)
    require(policy.get("expected_total_attachments") == 13, "expected attachment total must be 13", errors)
    require(set(policy.get("source_class_coverage_required") or []) == {"static-file", "virtual-vsb"},
            "both static-file and virtual-vsb must be required", errors)
    require(sum(int(a.get("expected_attachment_count", 0)) for a in articles) == 13,
            "per-article expected attachment counts must sum to 13", errors)
    require(all(a.get("authority_level") in {"A0", "A1"} for a in articles),
            "all live fixtures must be official A0/A1", errors)

    primary = PRIMARY.read_text(encoding="utf-8")
    for token in [
        "httpx.Client", "follow_redirects=True", '"Referer"', "iter_bytes", "hashlib.sha256",
        "%PDF-", "D0CF11E0A1B11AE1", "[Content_Types].xml", "html-error-page",
    ]:
        require(token in primary, f"primary downloader missing required implementation marker: {token}", errors)

    browser = BROWSER.read_text(encoding="utf-8")
    for token in ["sync_playwright", "page.expect_download", "download.save_as", "browser_request_capture"]:
        require(token in browser, f"browser fallback missing required marker: {token}", errors)

    sanitizer = SANITIZER.read_text(encoding="utf-8")
    for token in ["sha256_file", "validate_binary", "removed_unvalidated_files", "integrity_errors"]:
        require(token in sanitizer, f"artifact sanitizer missing required marker: {token}", errors)

    orchestrator = ORCHESTRATOR.read_text(encoding="utf-8")
    require("--no-browser-fallback" in orchestrator,
            "canonical orchestrator must keep primary downloader static/session-only", errors)
    require("fetch_teacher_recruitment_attachments_browser.py" in orchestrator,
            "canonical orchestrator must route browser fallback through dedicated script", errors)
    require("sanitize_teacher_recruitment_attachment_artifacts.py" in orchestrator,
            "canonical orchestrator must sanitize artifacts before acceptance", errors)

    correction = yaml.safe_load(CORRECTION.read_text(encoding="utf-8"))
    require(bool(correction.get("corrections")), "attachment source correction record missing", errors)
    require("20260514_240839.html" in CORRECTION.read_text(encoding="utf-8"),
            "Diqing 2026-05-14 attachment-source correction missing", errors)

    if errors:
        print("FAIL: Phase9 attachment maintenance deterministic gate")
        for error in errors:
            print(f"- {error}")
        return 1

    print("PASS_IMPLEMENTATION: Phase9 attachment downloader/fixture/validation contract")
    print("articles=6 expected_attachments=13 source_classes=static-file,virtual-vsb")
    print("canonical_route=http-session -> dedicated-playwright -> artifact-integrity")

    if not LIVE.exists():
        print("LIVE_BINARY_VERIFIED=NO (live runner result manifest absent)")
        return 2 if args.require_live else 0

    live = json.loads(LIVE.read_text(encoding="utf-8"))
    summary = live.get("summary") or {}
    integrity = live.get("artifact_integrity") or {}
    validated = int(summary.get("binary_validated") or 0)
    expected = int(summary.get("expected_attachments") or 0)
    classes = set(summary.get("source_classes_validated") or [])
    require(expected == 13, "live result expected total drifted from 13", errors)
    require(validated > 0, "live result contains no validated binary", errors)
    require({"static-file", "virtual-vsb"}.issubset(classes), "live result did not validate both source classes", errors)
    require(integrity.get("sanitized") is True, "live artifact was not sanitized", errors)
    require(not (integrity.get("integrity_errors") or []), "live artifact integrity errors are present", errors)
    for record in live.get("records") or []:
        if record.get("validation_ok"):
            require(bool(record.get("sha256")), "validated live binary missing sha256", errors)
            require(int(record.get("size_bytes") or 0) > 0, "validated live binary has zero bytes", errors)
            require(bool(record.get("validation_kind")), "validated live binary missing validation_kind", errors)

    if errors:
        print("FAIL_LIVE: Phase9 live binary attachment gate")
        for error in errors:
            print(f"- {error}")
        return 2

    if validated == 13 and summary.get("strong_pass_13_of_13") is True:
        print("LIVE_BINARY_VERIFIED=STRONG_PASS 13/13")
    else:
        print(f"LIVE_BINARY_VERIFIED=PARTIAL_PASS {validated}/13")
    return 0


if __name__ == "__main__":
    sys.exit(main())
