#!/usr/bin/env python3
"""Deterministic publisher for teacher resume-materials Phase8.

Reads only repository YAML/Markdown assets. No LLM/API calls. Public outputs stay in
placeholder/fillable mode unless verified candidate data is supplied by a future scoped flow.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import yaml

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle, KeepTogether, Flowable

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "content/job-search/teacher/resume-materials"
CONTRACT = BASE / "contracts/phase8-first-wave-publication-v1.yaml"
FONT = "/usr/share/fonts/truetype/arphic-gbsn00lp/gbsn00lp.ttf"
pdfmetrics.registerFont(TTFont("RM-CN", FONT))
W, H = A4
LM = RM = 16 * mm
TM = 18 * mm
BM = 16 * mm
INK = colors.HexColor("#1F2937")
SUB = colors.HexColor("#5B6472")
LINE = colors.HexColor("#CBD5E1")
PANEL = colors.HexColor("#F5F7FA")
WARN = colors.HexColor("#FFF4CC")
ACCENT = colors.HexColor("#E7EEF8")
DANGER = colors.HexColor("#FCE7E7")

base = getSampleStyleSheet()
ST = {
    "body": ParagraphStyle("body", fontName="RM-CN", fontSize=9.4, leading=14.2, textColor=INK, wordWrap="CJK", spaceAfter=4),
    "small": ParagraphStyle("small", fontName="RM-CN", fontSize=8.0, leading=11.5, textColor=SUB, wordWrap="CJK"),
    "h1": ParagraphStyle("h1", fontName="RM-CN", fontSize=20, leading=26, textColor=INK, wordWrap="CJK", spaceAfter=8),
    "h2": ParagraphStyle("h2", fontName="RM-CN", fontSize=13.5, leading=19, textColor=INK, wordWrap="CJK", spaceBefore=7, spaceAfter=5),
    "h3": ParagraphStyle("h3", fontName="RM-CN", fontSize=10.8, leading=15.5, textColor=INK, wordWrap="CJK", spaceBefore=4, spaceAfter=3),
    "title": ParagraphStyle("title", fontName="RM-CN", fontSize=23, leading=30, alignment=1, textColor=INK, wordWrap="CJK", spaceAfter=10),
    "subtitle": ParagraphStyle("subtitle", fontName="RM-CN", fontSize=10.5, leading=16, alignment=1, textColor=SUB, wordWrap="CJK"),
}


def esc(s):
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def P(s, style="body"):
    return Paragraph(esc(s), ST[style])


def load_yaml(path):
    return yaml.safe_load(Path(path).read_text(encoding="utf-8"))


class BlankBox(Flowable):
    def __init__(self, height=14 * mm, label="填写"):
        super().__init__()
        self.width = W - LM - RM
        self.height = height
        self.label = label

    def draw(self):
        c = self.canv
        c.saveState()
        c.setStrokeColor(LINE)
        c.roundRect(0, 0, self.width, self.height, 2.5 * mm, stroke=1, fill=0)
        c.setFont("RM-CN", 7.5)
        c.setFillColor(SUB)
        c.drawString(3 * mm, self.height - 5 * mm, self.label)
        c.restoreState()


def card(title, body, fill=PANEL):
    t = Table([[P(title, "h3")], [body if isinstance(body, Flowable) else P(body)]], colWidths=[W - LM - RM])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), fill), ("BOX", (0, 0), (-1, -1), 0.6, LINE),
        ("LEFTPADDING", (0, 0), (-1, -1), 7), ("RIGHTPADDING", (0, 0), (-1, -1), 7),
        ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    return t


def tbl(rows, widths):
    data = [[P(x, "small" if r else "body") for x in row] for r, row in enumerate(rows)]
    t = Table(data, colWidths=widths, repeatRows=1)
    t.setStyle(TableStyle([
        ("GRID", (0, 0), (-1, -1), 0.45, LINE), ("BACKGROUND", (0, 0), (-1, 0), ACCENT),
        ("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 4),
        ("RIGHTPADDING", (0, 0), (-1, -1), 4), ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    return t


def header_footer(canvas, doc, title):
    canvas.saveState(); canvas.setFont("RM-CN", 7.3); canvas.setFillColor(SUB)
    canvas.drawString(LM, H - 9 * mm, title); canvas.drawRightString(W - RM, 8 * mm, f"第 {doc.page} 页")
    canvas.setStrokeColor(LINE); canvas.line(LM, H - 11 * mm, W - RM, H - 11 * mm); canvas.restoreState()


def cover(title, note):
    return [Spacer(1, 22 * mm), P(title, "title"), P("Phase8 · placeholder/fillable edition", "subtitle"),
            Spacer(1, 9 * mm), card("使用边界", note, WARN), Spacer(1, 7 * mm),
            card("本册原则", "只记录真实事实、真实证据与 specific 招聘要求；unknown / pending / missing 不自动补全。", ACCENT),
            PageBreak()]


def build_master():
    profile = load_yaml(BASE / "materials/yunnan/r1/templates/candidate-master-profile-v1.yaml")
    evidence = load_yaml(BASE / "materials/yunnan/r1/templates/evidence-bank-template-v1.yaml")
    story = cover("教师求职事实与证据主档填写册", "本册是私人事实/证据整理工具，不是已经完成的个人简历；空白框均为填写位。")
    story += [P("1. Candidate Fact 与 Evidence Asset 分离", "h1"),
              card("Candidate Fact", "同一事实只维护一次；简历只能选择、排序、压缩，不能制造新事实。"), Spacer(1, 4 * mm),
              card("Evidence Asset", "证明材料独立维护 verified / pending / missing / expired 等状态。"), PageBreak(),
              P("2. 事实主档", "h1")]
    for fact in profile.get("facts", []):
        label = fact.get("label", fact.get("candidate_fact_id"))
        hint = fact.get("value", "<填写真实值>")
        story += [P(label, "h3"), P(hint, "small"), BlankBox(14 * mm, "填写真实值 / 未知则留空"), Spacer(1, 2 * mm)]
    story += [PageBreak(), P("3. 证据资产清单", "h1")]
    rows = [["证据", "ID", "状态", "隐私"]]
    for a in evidence.get("assets", []):
        rows.append([a.get("title", ""), a.get("evidence_asset_id", ""), a.get("status", "pending"), a.get("redaction_policy", "")])
    story += [tbl(rows, [48 * mm, 40 * mm, 34 * mm, 57 * mm]), PageBreak(), P("4. 证据状态盘点", "h1")]
    for a in evidence.get("assets", []):
        block = [P(f"{a.get('title','')}  {a.get('evidence_asset_id','')}", "h3"),
                 tbl([["状态", "文件位置/版本", "下一步"], ["□ verified  □ pending  □ missing  □ expired", "", ""]], [58 * mm, 62 * mm, 59 * mm]),
                 Spacer(1, 3 * mm)]
        story.append(KeepTogether(block))
    story += [PageBreak(), P("5. 私人目录与隐私", "h1"), card("敏感信息", "完整身份证号、家庭住址、证书编号和原始扫描件默认不进入公开仓库。", DANGER),
              Spacer(1, 6 * mm), BlankBox(65 * mm, "私人目录 / 备份位置 / 更新日期"), PageBreak(), P("6. 完成度检查", "h1")]
    for x in ["□ 没有用常见经验补全事实", "□ 高风险资格字段有证据或明确 pending", "□ 数字/奖项/角色没有被强化", "□ 敏感证件未进入公开版", "□ missing / expired 已转为行动项"]:
        story += [P(x), Spacer(1, 2 * mm)]
    return story


def fixture_rows(path):
    data = load_yaml(path)
    rows = [["材料", "requiredness", "阶段", "形态/条件"]]
    for r in data.get("requirements", []):
        rows.append([r.get("label", r.get("requirement_type", "")), r.get("requiredness", ""), r.get("stage", ""), r.get("submission_format", r.get("condition", "")) or ""])
    return data, rows


def build_packet():
    fixtures = [
        BASE / "materials/yunnan/r1/source-fixtures/bs1-2026-campus-requirements-v1.yaml",
        BASE / "materials/yunnan/r1/source-fixtures/bs1-2026-public-selection-requirements-v1.yaml",
        BASE / "materials/yunnan/r1/source-fixtures/baoshan-2026-public-institution-qualification-review-v1.yaml",
    ]
    story = cover("云南教师报名材料路由与缺口检查手册", "3个 fixture 只说明各自招聘，不构成云南统一报名清单；换公告必须重新读取 current source。")
    story += [P("1. 五阶段路由", "h1"), tbl([["阶段", "核心"], ["Initial Application", "deadline/channel/命名/格式/签章"], ["Qualification Review", "原件/复印件/岗位资格"], ["Interview Entry", "按通知准备"], ["Signing", "specific 通知"], ["Onboarding", "不能提前写成首次报名义务"]], [50 * mm, 129 * mm]), PageBreak()]
    for i, path in enumerate(fixtures, start=2):
        data, rows = fixture_rows(path)
        story += [P(f"{i}. {data.get('id')}", "h1"), P(f"source_id={data.get('source_id')} · mode={data.get('recruitment_mode')}", "small"), tbl(rows, [55 * mm, 31 * mm, 42 * mm, 51 * mm]), PageBreak()]
    story += [P("5. 三类招聘横向对照", "h1"), card("阶段隔离", "校园招聘、在编选调、事业单位资格复审的材料结构不可静默继承。", WARN), PageBreak(),
              P("6. Specific Recruitment Gap 表", "h1"), tbl([["requirement", "stage", "requiredness", "evidence", "status", "action"]] + [["", "", "", "", "□ ready □ missing □ expired □ unknown", ""] for _ in range(5)], [34 * mm, 28 * mm, 28 * mm, 31 * mm, 34 * mm, 24 * mm]),
              Spacer(1, 7 * mm), P("7. 提交前装配记录", "h1"), tbl([["字段", "填写"], ["Recruitment / Position", ""], ["Source / 公告标题", ""], ["Deadline", ""], ["Channel", ""], ["文件命名", ""], ["合并顺序/大小/格式", ""], ["签字/盖章", ""], ["资格复审地点/时间", ""]], [54 * mm, 125 * mm])]
    return story


def build_resume():
    variants = load_yaml(BASE / "materials/yunnan/r1/templates/resume-variant-template-v1.yaml")
    story = cover("教师简历证据化写作与四类变体模板", "本册只提供结构骨架；正式 bullet 必须能回链 candidate_fact_id，数字与动词强度不得超过事实/证据。")
    story += [P("1. 正确写作流水线", "h1"), card("正确", "原始事实 → 证据强度 → 岗位相关性 → 选择细节 → 压缩成 bullet", ACCENT), Spacer(1, 5 * mm), card("错误", "岗位想要什么 → 猜形容词 → 反向编经历", DANGER),
              PageBreak(), P("2. Bullet 工作页", "h1")]
    for x in ["Candidate Fact ID", "Context", "Role", "Action", "Object", "Evidence / Result", "Relevance", "压缩后的正式 Bullet"]:
        story += [P(x, "h3"), BlankBox(13 * mm if x != "压缩后的正式 Bullet" else 24 * mm, "填写真实内容"), Spacer(1, 2 * mm)]
    for no, v in enumerate(variants.get("variants", []), start=3):
        story += [PageBreak(), P(f"{no}. {v.get('target_mode')} 变体", "h1"), P(f"Variant ID={v.get('resume_variant_id')} · page_target={v.get('page_target')}", "small"),
                  P("建议 section order：" + " → ".join(v.get("section_order", []))), BlankBox(16 * mm, "页首 Headline"), Spacer(1, 4 * mm), BlankBox(30 * mm, "Section 1"), Spacer(1, 4 * mm), BlankBox(30 * mm, "Section 2"), Spacer(1, 4 * mm), BlankBox(30 * mm, "Section 3"), Spacer(1, 5 * mm),
                  P("□ 每个 bullet 都能回链 candidate_fact_id"), P("□ 所有数字有真实口径与证据"), P("□ 没有把团队成果写成个人独立成果"), P("□ 没有生成 source 未要求的资格结论")]
    story += [PageBreak(), P("7. 最终 Bullet QA", "h1")]
    for x in ["这条来自哪个 candidate_fact_id？", "数字证据和口径在哪里？", "动词是否比真实角色更强？", "是否把团队成果写成个人成果？", "是否使用了 source 未支持的资格判断？"]:
        story += [P("□ " + x), Spacer(1, 2 * mm)]
    story += [Spacer(1, 7 * mm), card("发布门槛", "第一问答不出来，这条不能进入正式简历。", WARN)]
    return story


def build_pdf(path, title, story):
    doc = SimpleDocTemplate(str(path), pagesize=A4, leftMargin=LM, rightMargin=RM, topMargin=TM, bottomMargin=BM, title=title, author="qiuzhidaren")
    doc.build(story, onFirstPage=lambda c, d: header_footer(c, d, title), onLaterPages=lambda c, d: header_footer(c, d, title))


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--out-dir", default=str(BASE / "materials/yunnan/r2/final")); args = ap.parse_args()
    out = Path(args.out_dir); out.mkdir(parents=True, exist_ok=True)
    products = [
        ("01_教师求职事实与证据主档填写册.pdf", "教师求职事实与证据主档填写册", build_master()),
        ("02_云南教师报名材料路由与缺口检查手册.pdf", "云南教师报名材料路由与缺口检查手册", build_packet()),
        ("03_教师简历证据化写作与四类变体模板.pdf", "教师简历证据化写作与四类变体模板", build_resume()),
    ]
    result = []
    for fn, title, story in products:
        path = out / fn; build_pdf(path, title, story); b = path.read_bytes(); result.append({"file": str(path), "bytes": len(b), "sha256": hashlib.sha256(b).hexdigest()})
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
