"""Validate complete teacher structured-interview training case suites.

The validator is data-driven: it knows schema fields, taxonomy/profile/reference
registries and source rules, never individual question text or case ids.
"""
from __future__ import annotations

import json
from pathlib import Path
import re
import sys

import yaml

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "content/job-search/teacher/interview/structured"
TAXONOMY = BASE / "question-taxonomy.md"
PROFILES = BASE / "profiles"
CASES = BASE / "training/cases"
REFERENCE_DIR = BASE / "reference-bank/normalized"
SOURCE_REGISTRY = BASE / "reference-bank/source-registry.yaml"


class TrainingCaseError(ValueError):
    pass


def load_yaml(path: Path):
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    if data is None:
        raise TrainingCaseError(f"empty yaml: {path.relative_to(ROOT)}")
    return data


def taxonomy_ids() -> set[str]:
    text = TAXONOMY.read_text(encoding="utf-8")
    ids = set(re.findall(r"^###\s+(T\d+)\b", text, flags=re.MULTILINE))
    if not ids:
        raise TrainingCaseError("taxonomy ids not found")
    return ids


def load_profiles() -> dict[str, dict]:
    out: dict[str, dict] = {}
    for path in sorted(PROFILES.glob("*.yaml")):
        profile = load_yaml(path)
        pid = str(profile.get("id") or "").strip()
        if not pid:
            raise TrainingCaseError(f"profile id missing: {path.name}")
        if pid in out:
            raise TrainingCaseError(f"duplicate profile id: {pid}")
        out[pid] = profile
    if not out:
        raise TrainingCaseError("no profiles available")
    return out


def load_source_registry() -> dict[str, dict]:
    data = load_yaml(SOURCE_REGISTRY)
    sources = data.get("sources") or {}
    if not isinstance(sources, dict) or not sources:
        raise TrainingCaseError("reference source registry missing/empty")
    return sources


def load_reference_bank() -> dict[str, dict]:
    paths = sorted(REFERENCE_DIR.glob("*.jsonl")) if REFERENCE_DIR.exists() else []
    if not paths:
        raise TrainingCaseError("normalized reference bank missing")
    out: dict[str, dict] = {}
    for path in paths:
        with path.open("r", encoding="utf-8-sig") as handle:
            for line_no, line in enumerate(handle, start=1):
                if not line.strip():
                    continue
                item = json.loads(line)
                if not isinstance(item, dict):
                    raise TrainingCaseError(f"{path.name}:{line_no}: reference record must be object")
                rid = str(item.get("id") or "").strip()
                if not rid:
                    raise TrainingCaseError(f"{path.name}:{line_no}: reference id missing")
                if rid in out:
                    raise TrainingCaseError(f"duplicate reference id: {rid}")
                out[rid] = item
    return out


def official_axes(profile: dict) -> set[str]:
    axes = profile.get("official_competency_axes") or {}
    out: set[str] = set()
    if isinstance(axes, dict):
        for values in axes.values():
            if isinstance(values, list):
                out |= {str(value) for value in values if str(value).strip()}
    elif isinstance(axes, list):
        out |= {str(value) for value in axes if str(value).strip()}
    return out


def require_nonempty_list(case: dict, field: str, cid: str) -> list:
    value = case.get(field)
    if not isinstance(value, list) or not value:
        raise TrainingCaseError(f"{cid}: {field} must be a non-empty list")
    return value


def validate_reference_link(case: dict, cid: str, references: dict[str, dict], source_registry: dict[str, dict]) -> None:
    rid = str(case.get("reference_id") or "").strip()
    if not rid:
        raise TrainingCaseError(f"{cid}: sourced-training case requires reference_id")
    if rid not in references:
        raise TrainingCaseError(f"{cid}: unknown reference_id {rid!r}")
    ref = references[rid]
    if ref.get("status") != "ready":
        raise TrainingCaseError(f"{cid}: reference_id {rid!r} is not ready")
    source_id = str(ref.get("source_id") or "").strip()
    if source_id not in source_registry:
        raise TrainingCaseError(f"{cid}: reference source_id is not registered: {source_id!r}")
    if str(case.get("question") or "").strip() != str(ref.get("question") or "").strip():
        raise TrainingCaseError(f"{cid}: question drift from reference_id {rid!r}")
    if str((case.get("routing") or {}).get("primary_type") or "").strip() != str(ref.get("primary_type") or "").strip():
        raise TrainingCaseError(f"{cid}: primary_type drift from reference_id {rid!r}")
    ref_profile = str(ref.get("profile_id") or "").strip()
    case_profile = str(case.get("profile_id") or "").strip()
    if ref_profile and case_profile != ref_profile:
        raise TrainingCaseError(f"{cid}: profile_id drift from reference_id {rid!r}")
    ref_risk = str(ref.get("risk_level") or "").strip()
    case_risk = str((case.get("routing") or {}).get("risk_level") or "").strip()
    if ref_risk and ref_risk != "unknown" and case_risk != ref_risk:
        raise TrainingCaseError(f"{cid}: risk_level drift from reference_id {rid!r}")


def validate_case(case: dict, types: set[str], profiles: dict[str, dict], references: dict[str, dict], source_registry: dict[str, dict]) -> None:
    cid = str(case.get("case_id") or "").strip()
    if not cid:
        raise TrainingCaseError("case_id missing")
    status = case.get("status")
    if status not in {"synthetic", "sourced-training", "formal"}:
        raise TrainingCaseError(f"{cid}: invalid status {status!r}")
    if not str(case.get("question") or "").strip():
        raise TrainingCaseError(f"{cid}: question missing")

    if status == "sourced-training":
        validate_reference_link(case, cid, references, source_registry)
    elif status == "formal":
        source = case.get("source") or {}
        if not str(source.get("authority") or "").strip():
            raise TrainingCaseError(f"{cid}: formal case missing source authority")

    pid = str(case.get("profile_id") or "").strip()
    profile = None
    if pid:
        if pid not in profiles:
            raise TrainingCaseError(f"{cid}: unknown profile_id {pid!r}")
        profile = profiles[pid]

    routing = case.get("routing") or {}
    primary = routing.get("primary_type")
    if primary not in types:
        raise TrainingCaseError(f"{cid}: unknown primary_type {primary!r}")
    for secondary in routing.get("secondary_types") or []:
        if secondary not in types:
            raise TrainingCaseError(f"{cid}: unknown secondary_type {secondary!r}")
    if not str(routing.get("evaluation_target") or "").strip():
        raise TrainingCaseError(f"{cid}: evaluation_target missing")

    mapped_axes = set(routing.get("official_competency_axes") or [])
    if mapped_axes:
        if profile is None:
            raise TrainingCaseError(f"{cid}: official competency mapping requires a sourced profile")
        unknown = mapped_axes - official_axes(profile)
        if unknown:
            raise TrainingCaseError(f"{cid}: competency axes not defined by profile: {sorted(unknown)}")

    if routing.get("risk_level") in {"safety", "ethics-compliance"}:
        cue_text = " ".join(str(x) for x in case.get("cues") or [])
        if not any(token in cue_text for token in ("安全", "权益", "上报", "边界", "风险", "保护", "廉洁", "合规")):
            raise TrainingCaseError(f"{cid}: high-risk case lacks explicit risk-handling cue")

    require_nonempty_list(case, "cues", cid)
    require_nonempty_list(case, "skeleton", cid)
    require_nonempty_list(case, "followups", cid)
    require_nonempty_list(case, "failure_modes", cid)
    require_nonempty_list(case, "revision", cid)
    if not str(case.get("reference_answer") or "").strip():
        raise TrainingCaseError(f"{cid}: reference_answer missing")

    scoring = case.get("scoring") or {}
    mode = scoring.get("rubric_mode")
    if mode not in {"training", "official"}:
        raise TrainingCaseError(f"{cid}: invalid rubric_mode {mode!r}")
    require_nonempty_list(scoring, "project_dimensions", cid)
    if mode == "official" and not str(scoring.get("official_source") or "").strip():
        raise TrainingCaseError(f"{cid}: official rubric mode requires official_source")
    scoring_axes = set(scoring.get("official_competency_axes") or [])
    if scoring_axes:
        if profile is None:
            raise TrainingCaseError(f"{cid}: scoring official axes require profile")
        unknown = scoring_axes - official_axes(profile)
        if unknown:
            raise TrainingCaseError(f"{cid}: scoring axes not defined by profile: {sorted(unknown)}")

    constraints = case.get("constraints") or {}
    if "answer_time_seconds_target" in constraints:
        if not pid and not str(constraints.get("answer_time_source") or "").strip():
            raise TrainingCaseError(f"{cid}: timing target requires profile or explicit source")


def validate_suite(path: Path, types: set[str], profiles: dict[str, dict], references: dict[str, dict], source_registry: dict[str, dict]) -> tuple[int, set[str]]:
    suite = load_yaml(path)
    if suite.get("status") != "non-formal":
        raise TrainingCaseError(f"{path.name}: current training suite must remain non-formal")
    cases = suite.get("cases") or []
    if not cases:
        raise TrainingCaseError(f"{path.name}: no cases")
    ids: set[str] = set()
    types_seen: set[str] = set()
    for case in cases:
        validate_case(case, types, profiles, references, source_registry)
        cid = case["case_id"]
        if cid in ids:
            raise TrainingCaseError(f"{path.name}: duplicate case_id {cid}")
        ids.add(cid)
        types_seen.add(case["routing"]["primary_type"])
    return len(cases), types_seen


def selftest(types: set[str], profiles: dict[str, dict], references: dict[str, dict], source_registry: dict[str, dict]) -> None:
    pid = next(iter(profiles))
    bad = {
        "case_id": "SELFTEST",
        "status": "synthetic",
        "question": "x",
        "profile_id": pid,
        "routing": {"primary_type": "TX", "evaluation_target": "x"},
        "cues": ["x"], "skeleton": ["x"], "reference_answer": "x", "followups": ["x"],
        "scoring": {"rubric_mode": "training", "project_dimensions": ["x"]},
        "failure_modes": ["x"], "revision": ["x"],
    }
    try:
        validate_case(bad, types, profiles, references, source_registry)
    except TrainingCaseError:
        pass
    else:
        raise AssertionError("selftest failed: invalid taxonomy id accepted")

    missing_reference = dict(bad)
    missing_reference["case_id"] = "SELFTEST-SOURCED"
    missing_reference["status"] = "sourced-training"
    missing_reference["routing"] = {"primary_type": sorted(types)[0], "evaluation_target": "x", "risk_level": "normal"}
    try:
        validate_case(missing_reference, types, profiles, references, source_registry)
    except TrainingCaseError:
        pass
    else:
        raise AssertionError("selftest failed: sourced case without reference_id accepted")


def main() -> int:
    types = taxonomy_ids()
    profiles = load_profiles()
    references = load_reference_bank()
    source_registry = load_source_registry()
    paths = sorted(CASES.glob("*.yaml"))
    if not paths:
        raise TrainingCaseError("no structured training case suites found")
    total = 0
    seen: set[str] = set()
    for path in paths:
        count, types_seen = validate_suite(path, types, profiles, references, source_registry)
        total += count
        seen |= types_seen
    selftest(types, profiles, references, source_registry)
    print("structured-interview training cases: PASS")
    print(f"suites={len(paths)} cases={total} primary_types={len(seen)} profiles={len(profiles)} references={len(references)}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except TrainingCaseError as exc:
        print(f"STRUCTURED_TRAINING_CASE_FAIL: {exc}", file=sys.stderr)
        raise SystemExit(1)
