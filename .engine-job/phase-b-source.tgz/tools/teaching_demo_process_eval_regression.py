from __future__ import annotations

import json
import subprocess
import tempfile
from pathlib import Path
from typing import Any

import yaml

import teaching_demo_process_eval_common as common
from teaching_demo_process_eval_common import (
    ARTIFACT_JOBS_REL, CURRENT_REL, LEDGER_CONTRACT_REL, POOL_REL, RULES_REL, SLOTS_REL,
    WARM_ACCEPT_SCHEMA, WARM_DIFF_SCHEMA, WARM_REQUIRED_SCOPE_PATHS, GateError,
    case_manifest_path, load_yaml, require_canonical_ledger, selection_digest, sha256_bytes, sha256_file,
)
from teaching_demo_process_eval_execution import validate_warm_claim
from teaching_demo_process_eval_policy import validate

def _write_yaml(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(data, allow_unicode=True, sort_keys=False), encoding="utf-8")


def _fixture(root: Path) -> tuple[Path, str]:
    _write_yaml(root / RULES_REL, {
        "process_product": {"primary_product": "reusable_agent_operable_process"},
        "global_experiment_budget": {"max_process_evaluation_slots": 3, "fourth_slot": "forbidden"},
        "topic_rotation": {"slots_2_and_3": {"random_selection_required": True}},
        "random_selection": {"algorithm_id": "sha256-beacon-commit-modulo-v1"},
    })
    topics = [{"case_id": f"case-{i:02d}", "title": f"Topic {i:02d}", "textbook_id": "book-1"} for i in range(12)]
    _write_yaml(root / POOL_REL, {"excluded_prior_or_historical_topics": [{"case_id": "transformer-principle-v1"}], "topics": topics})
    (root / CURRENT_REL).parent.mkdir(parents=True)
    (root / CURRENT_REL).write_text(json.dumps({"ids": {"book-1": "book.pdf"}}), encoding="utf-8")
    _write_yaml(root / LEDGER_CONTRACT_REL, {
        "lifecycle_transition_types": ["JOB_CREATED", "INPUTS_LOCKED", "BLOCKS_ACCEPTED", "BUILT", "MACHINE_VERIFIED", "HUMAN_ACCEPTED", "PUBLISHED"],
        "event_types": ["JOB_CREATED", "INPUTS_LOCKED", "BLOCKS_ACCEPTED", "BUILT", "MACHINE_VERIFIED", "HUMAN_ACCEPTED", "PUBLISHED", "BUILD_STARTED", "BUILD_COMPLETED", "BUILD_FAILED", "MACHINE_VERIFICATION_PASSED", "MACHINE_VERIFICATION_FAILED", "FINAL_RENDER_COMPLETED", "HUMAN_REVIEW_ACCEPTED", "HUMAN_REVIEW_REJECTED"],
        "attempt_event_types": ["BUILD_STARTED", "BUILD_COMPLETED", "BUILD_FAILED", "MACHINE_VERIFICATION_PASSED", "MACHINE_VERIFICATION_FAILED", "FINAL_RENDER_COMPLETED", "HUMAN_REVIEW_ACCEPTED", "HUMAN_REVIEW_REJECTED"],
        "attempt_protocol": {"once_any_final_render_observed_all_reviewed_attempts_require_own_final_render": True},
    })
    legacy_evidence = Path("qa/machine-evidence/slot1.yaml")
    _write_yaml(root / legacy_evidence, {"result": "historical"})
    _write_yaml(root / SLOTS_REL / "slot-01.yaml", {"slot_number": 1, "status": "CONSUMED_PROCESS_DEFECT_DISCOVERED", "selection": {"case_id": "transformer-principle-v1"}, "budget": {"consumes_global_slot": True}, "artifact_execution": {"job_id": "legacy-r9", "attempt_id": "a1", "phase_d_evidence": legacy_evidence.as_posix()}})
    pool_sha = sha256_bytes((root / POOL_REL).read_bytes())
    beacon, entropy = "abc", "1" * 40
    digest = selection_digest(beacon, pool_sha, entropy, 2)
    ordered = sorted(topics, key=lambda item: item["case_id"])
    index = int(digest, 16) % len(ordered)
    selected, case_id = ordered[index], ordered[index]["case_id"]
    _write_yaml(root / case_manifest_path(case_id), {"case_id": case_id})
    job_rel = ARTIFACT_JOBS_REL / f"{case_id}-r1.yaml"
    ledger_rel = Path("production/execution-ledgers/teacher_teaching_demo") / f"{case_id}-r1.yaml"
    job_id = f"teaching-demo-{case_id}-r1"
    _write_yaml(root / job_rel, {"job_id": job_id, "module_id": "teacher_teaching_demo", "state": "JOB_CREATED", "execution_ledger": ledger_rel.as_posix(), "input_bindings": [{"path": case_manifest_path(case_id), "kind": "case_manifest", "sha256": "0" * 64}], "outputs": [], "human_acceptance": {"state": "PENDING", "reviewed_at": None, "accepted_outputs": []}})
    _write_yaml(root / ledger_rel, {"contract": LEDGER_CONTRACT_REL.as_posix(), "job_id": job_id, "events": [{"seq": 1, "event_id": "e1", "occurred_at": "2026-01-01T00:00:00Z", "type": "JOB_CREATED", "actor": "ChatGPT"}, {"seq": 2, "event_id": "e2", "occurred_at": "2026-01-01T00:00:01Z", "type": "BUILD_STARTED", "actor": "Engine", "attempt_id": "slot2-a1"}]})
    slot2 = {"slot_number": 2, "status": "ROUND4_COMPOSITION_STARTED", "selection": {"method": "sha256-beacon-commit-modulo-v1", "pool_lock": {"path": POOL_REL.as_posix(), "commit": "0" * 40, "sha256": pool_sha}, "beacon": {"output_value": beacon, "source_url": "https://example.invalid/beacon", "pulse_id": "pulse-1"}, "entropy_commit": entropy, "digest_sha256": digest, "selected_index": index, "case_id": case_id, "title": selected["title"], "textbook_id": selected["textbook_id"]}, "budget": {"consumes_global_slot": True, "product_pdf_composition_started": True, "consumed_at_build_started": "2026-01-01T00:00:01Z", "attempt_id": "slot2-a1"}, "execution_binding": {"protocol": "artifact-ledger-v1", "case_id": case_id, "job": job_rel.as_posix(), "ledger": ledger_rel.as_posix(), "attempt_id": "slot2-a1"}}
    _write_yaml(root / SLOTS_REL / "slot-02.yaml", slot2)
    return root / SLOTS_REL / "slot-02.yaml", case_id

def _expect_error(root: Path, code: str) -> None:
    try:
        validate(root, verify_git_history=False)
    except GateError as exc:
        if code not in str(exc):
            raise AssertionError(f"expected {code}, got {exc}") from exc
        return
    raise AssertionError(f"expected failure containing {code}")


def _selftest_warm_positive() -> None:
    with tempfile.TemporaryDirectory(prefix="qz-warm-positive-") as tmp:
        repo = Path(tmp)
        subprocess.run(["git", "init"], cwd=repo, check=True, stdout=subprocess.DEVNULL)
        subprocess.run(["git", "config", "user.email", "selftest@example.invalid"], cwd=repo, check=True)
        subprocess.run(["git", "config", "user.name", "selftest"], cwd=repo, check=True)
        for rel in sorted(WARM_REQUIRED_SCOPE_PATHS):
            p = repo / rel / ".keep"
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text("stable\n", encoding="utf-8")
        subprocess.run(["git", "add", "."], cwd=repo, check=True)
        subprocess.run(["git", "commit", "-m", "baseline"], cwd=repo, check=True, stdout=subprocess.DEVNULL)
        baseline = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip()
        (repo / "qa").mkdir()
        (repo / "qa/non-generic.txt").write_text("case-only\n", encoding="utf-8")
        subprocess.run(["git", "add", "."], cwd=repo, check=True)
        subprocess.run(["git", "commit", "-m", "case-only"], cwd=repo, check=True, stdout=subprocess.DEVNULL)
        head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip()
        output_path = repo / "outputs/result.pdf"
        output_path.parent.mkdir()
        output_path.write_bytes(b"%PDF-1.4\nselftest\n")
        output_binding = {"path": "outputs/result.pdf", "sha256": sha256_file(output_path), "kind": "pdf"}
        diff_path = repo / "qa/warm-diff.yaml"
        diff_receipt = {"schema_id": WARM_DIFF_SCHEMA, "decision": "NO_GENERIC_IMPLEMENTATION_CHANGE", "baseline_commit": baseline, "head_commit": head, "scope_paths": sorted(WARM_REQUIRED_SCOPE_PATHS), "changed_files": []}
        _write_yaml(diff_path, diff_receipt)
        accept_path = repo / "qa/warm-accept.yaml"
        accept_receipt = {"schema_id": WARM_ACCEPT_SCHEMA, "decision": "ACCEPT", "case_id": "case-warm", "job_id": "job-warm", "attempt_id": "a1", "implementation_head_commit": head, "reviewer_role": "INDEPENDENT_PLANNER", "reviewed_at": "2026-01-01T00:00:10Z", "accepted_outputs": [output_binding]}
        _write_yaml(accept_path, accept_receipt)
        record = {"selection": {"case_id": "case-warm"}, "warm_path": {"status": "PASS", "implementation_diff_evidence": {"path": "qa/warm-diff.yaml", "sha256": sha256_file(diff_path)}, "independent_acceptance_evidence": {"path": "qa/warm-accept.yaml", "sha256": sha256_file(accept_path)}}}
        execution = {"job_id": "job-warm", "job": {"state": "HUMAN_ACCEPTED", "outputs": [output_binding], "human_acceptance": {"state": "REVIEW_PASS", "accepted_outputs": [output_binding]}}, "events": [{"type": "BUILD_STARTED", "attempt_id": "a1"}, {"type": "BUILD_COMPLETED", "attempt_id": "a1"}, {"type": "MACHINE_VERIFICATION_PASSED", "attempt_id": "a1"}, {"type": "FINAL_RENDER_COMPLETED", "attempt_id": "a1"}, {"type": "HUMAN_REVIEW_ACCEPTED", "attempt_id": "a1"}]}
        validate_warm_claim(repo, 2, record, execution, "a1", verify_git_history=True)
        bad = yaml.safe_load(yaml.safe_dump(record))
        bad["warm_path"]["independent_acceptance_evidence"]["sha256"] = "0" * 64
        try:
            validate_warm_claim(repo, 2, bad, execution, "a1", verify_git_history=True)
        except GateError as exc:
            assert "HASH_MISMATCH" in str(exc)
        else:
            raise AssertionError("stale warm acceptance hash escaped")

        rejected = yaml.safe_load(yaml.safe_dump(accept_receipt)); rejected["decision"] = "REJECT"
        _write_yaml(accept_path, rejected)
        rejected_record = yaml.safe_load(yaml.safe_dump(record)); rejected_record["warm_path"]["independent_acceptance_evidence"]["sha256"] = sha256_file(accept_path)
        try:
            validate_warm_claim(repo, 2, rejected_record, execution, "a1", verify_git_history=True)
        except GateError as exc:
            assert "ACCEPTANCE_DECISION_INVALID" in str(exc)
        else:
            raise AssertionError("rejected warm acceptance escaped")

        wrong_attempt = yaml.safe_load(yaml.safe_dump(accept_receipt)); wrong_attempt["attempt_id"] = "wrong"
        _write_yaml(accept_path, wrong_attempt)
        wrong_record = yaml.safe_load(yaml.safe_dump(record)); wrong_record["warm_path"]["independent_acceptance_evidence"]["sha256"] = sha256_file(accept_path)
        try:
            validate_warm_claim(repo, 2, wrong_record, execution, "a1", verify_git_history=True)
        except GateError as exc:
            assert "ACCEPTANCE_ATTEMPT_MISMATCH" in str(exc)
        else:
            raise AssertionError("wrong warm attempt escaped")

        missing_case = yaml.safe_load(yaml.safe_dump(accept_receipt)); missing_case.pop("case_id")
        _write_yaml(accept_path, missing_case)
        missing_record = yaml.safe_load(yaml.safe_dump(record)); missing_record["warm_path"]["independent_acceptance_evidence"]["sha256"] = sha256_file(accept_path)
        try:
            validate_warm_claim(repo, 2, missing_record, execution, "a1", verify_git_history=True)
        except GateError as exc:
            assert "ACCEPTANCE_CASE_MISMATCH" in str(exc)
        else:
            raise AssertionError("missing warm identity escaped")

        _write_yaml(accept_path, accept_receipt)
        contradictory = yaml.safe_load(yaml.safe_dump(diff_receipt)); contradictory["changed_files"] = ["tools/fake.py"]
        _write_yaml(diff_path, contradictory)
        contradiction_record = yaml.safe_load(yaml.safe_dump(record)); contradiction_record["warm_path"]["implementation_diff_evidence"]["sha256"] = sha256_file(diff_path)
        try:
            validate_warm_claim(repo, 2, contradiction_record, execution, "a1", verify_git_history=True)
        except GateError as exc:
            assert "DIFF_RECEIPT_CONTRADICTS_GIT" in str(exc)
        else:
            raise AssertionError("contradictory warm diff escaped")


def selftest() -> None:
    with tempfile.TemporaryDirectory(prefix="qz-process-eval-") as tmp:
        root = Path(tmp)
        slot2_path, _ = _fixture(root)
        good = validate(root, verify_git_history=False)
        assert good["consumed_slots"] == 2 and good["process_maturity_claim"] == "NOT_ASSERTED_BY_THIS_GATE"
        original = load_yaml(slot2_path)

        bad = yaml.safe_load(yaml.safe_dump(original)); bad["budget"]["consumes_global_slot"] = False
        _write_yaml(slot2_path, bad); _expect_error(root, "BUILD_STARTED_BUT_CONSUMPTION_FALSE")
        bad = yaml.safe_load(yaml.safe_dump(original)); bad["execution_binding"]["case_id"] = "wrong-case"
        _write_yaml(slot2_path, bad); _expect_error(root, "EXECUTION_BINDING_CASE_MISMATCH")
        bad = yaml.safe_load(yaml.safe_dump(original)); bad.pop("execution_binding")
        _write_yaml(slot2_path, bad); _expect_error(root, "EXECUTION_BINDING_REQUIRED")
        _write_yaml(slot2_path, original)

        job_path = root / original["execution_binding"]["job"]
        original_job = load_yaml(job_path)
        bad_job = yaml.safe_load(yaml.safe_dump(original_job)); bad_job["state"] = "PUBLISHED"
        _write_yaml(job_path, bad_job); _expect_error(root, "CASE_JOB_STATE_LEDGER_MISMATCH")
        _write_yaml(job_path, original_job)

        ledger_path = root / original["execution_binding"]["ledger"]
        original_ledger = load_yaml(ledger_path)
        bad_ledger = yaml.safe_load(yaml.safe_dump(original_ledger))
        bad_ledger["events"][-1]["seq"] = 999
        bad_ledger["events"][-1]["event_id"] = bad_ledger["events"][0]["event_id"]
        bad_ledger["events"][-1]["occurred_at"] = "not-a-timestamp"
        bad_ledger["events"][-1].pop("actor")
        _write_yaml(ledger_path, bad_ledger); _expect_error(root, "CASE_JOB_LEDGER_INVALID")
        _write_yaml(ledger_path, original_ledger)

        duplicate_job = yaml.safe_load(yaml.safe_dump(original_job))
        duplicate_ledger = yaml.safe_load(yaml.safe_dump(original_ledger))
        duplicate_job["job_id"] = original_job["job_id"] + "-duplicate"
        nested_ledger_rel = Path("production/execution-ledgers/teacher_teaching_demo/probe-duplicate.yaml")
        duplicate_job["execution_ledger"] = nested_ledger_rel.as_posix()
        duplicate_ledger["job_id"] = duplicate_job["job_id"]
        _write_yaml(root / nested_ledger_rel, duplicate_ledger)
        nested_job_path = ARTIFACT_JOBS_REL / "renamed-path" / "probe-duplicate.yaml"
        _write_yaml(root / nested_job_path, duplicate_job)
        _expect_error(root, "SAME_CASE_MULTIPLE_PRODUCT_COMPOSITIONS")
        (root / nested_job_path).unlink(); (root / nested_ledger_rel).unlink()

        fake_warm = yaml.safe_load(yaml.safe_dump(original))
        fake_warm["warm_path"] = {"status": "PASS", "implementation_diff_evidence": {"path": "probe-diff.txt", "sha256": "0" * 64}, "independent_acceptance_evidence": {"path": "probe-review.txt", "sha256": "0" * 64}}
        (root / "probe-diff.txt").write_text("REJECT\n", encoding="utf-8")
        (root / "probe-review.txt").write_text("REJECT\n", encoding="utf-8")
        _write_yaml(slot2_path, fake_warm); _expect_error(root, "WARM_SUCCESS_REQUIRES_GIT_HISTORY")
        _write_yaml(slot2_path, original)

        for number, cid in ((3, "case-99"), (4, "case-98")):
            extra = yaml.safe_load(yaml.safe_dump(original)); extra["slot_number"] = number; extra["selection"]["case_id"] = cid
            _write_yaml(root / SLOTS_REL / f"slot-{number:02d}.yaml", extra)
        _expect_error(root, "SLOT_RECORD_LIMIT_EXCEEDED")
        (root / SLOTS_REL / "slot-03.yaml").unlink(); (root / SLOTS_REL / "slot-04.yaml").unlink()
        assert validate(root, verify_git_history=False)["result"] == "PASS"

    _selftest_warm_positive()
    saved_error, saved_validate = common.CANONICAL_IMPORT_ERROR, common.ledger_validate
    try:
        common.CANONICAL_IMPORT_ERROR = "synthetic missing dependency"; common.ledger_validate = None
        try:
            require_canonical_ledger()
        except GateError as exc:
            assert "CANONICAL_LEDGER_VALIDATOR_UNAVAILABLE" in str(exc)
        else:
            raise AssertionError("canonical dependency failure silently downgraded")
    finally:
        common.CANONICAL_IMPORT_ERROR, common.ledger_validate = saved_error, saved_validate

    print("PROCESS_EVALUATION_SELFTEST_PASS cases=current-positive,state-drift,full-ledger-structure,nested-duplicate,warm-fail-closed,warm-positive,stale-warm-hash,fourth-slot,canonical-dependency")


