#!/usr/bin/env python3
"""Deterministically publish the Yunnan teacher structured-interview material pack.

This is a scoped publisher for the Yunnan material pack. It does not reuse the
teaching-demo Page-to-Plan product contract and it never hard-codes question IDs.
"""
from __future__ import annotations

import argparse
import html
import re
import subprocess
from pathlib import Path

try:
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.platypus import CondPageBreak, HRFlowable, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
except ImportError as exc:
    raise SystemExit('ReportLab is required: pip install reportlab') from exc

FOOTER_TITLE = '云南省教师招聘结构化面试资料'


def _font_match(pattern: str) -> Path | None:
    try:
        out = subprocess.check_output(['fc-match', '-f', '%{file}', pattern], text=True).strip()
    except Exception:
        return None
    path = Path(out) if out else None
    return path if path and path.exists() else None


def _first_existing(candidates: list[Path | None]) -> Path | None:
    return next((path for path in candidates if path and path.exists()), None)


def register_cjk_fonts() -> None:
    # Prefer embeddable TrueType CJK fonts. Never copy/commit/share the font files.
    body = _first_existing([
        _font_match('AR PL SungtiL GB'),
        Path('/usr/share/fonts/truetype/arphic-gbsn00lp/gbsn00lp.ttf'),
        Path('/usr/share/fonts/truetype/wqy/wqy-zenhei.ttf'),
    ])
    head = _first_existing([
        _font_match('AR PL KaitiM GB'),
        Path('/usr/share/fonts/truetype/arphic-gkai00mp/gkai00mp.ttf'),
        body,
    ])
    if not body:
        raise SystemExit(
            'No embeddable CJK TrueType font found. Install an AR PL/WenQuanYi CJK '
            'font package; font files are runtime dependencies and are not stored in this repo.'
        )
    pdfmetrics.registerFont(TTFont('CJK', str(body)))
    pdfmetrics.registerFont(TTFont('CJKHead', str(head or body)))


def inline_md(text: str) -> str:
    value = html.escape(text.strip())
    value = re.sub(r'`([^`]+)`', r'<font name="CJK">\1</font>', value)
    value = re.sub(r'\*\*([^*]+)\*\*', r'<font name="CJKHead">\1</font>', value)
    return value


def make_styles() -> dict[str, ParagraphStyle]:
    base = getSampleStyleSheet()
    return {
        'title': ParagraphStyle(
            'title', parent=base['Title'], fontName='CJKHead', fontSize=20,
            leading=26, alignment=TA_CENTER, spaceAfter=8 * mm,
            textColor=colors.HexColor('#1f2937'), wordWrap='CJK'
        ),
        'h1': ParagraphStyle(
            'h1', parent=base['Heading1'], fontName='CJKHead', fontSize=15.5,
            leading=21, spaceBefore=6 * mm, spaceAfter=3 * mm,
            textColor=colors.HexColor('#111827'), wordWrap='CJK'
        ),
        'h2': ParagraphStyle(
            'h2', parent=base['Heading2'], fontName='CJKHead', fontSize=11.4,
            leading=16.5, spaceBefore=4.5 * mm, spaceAfter=2.2 * mm,
            textColor=colors.HexColor('#1f2937'), wordWrap='CJK'
        ),
        'h3': ParagraphStyle(
            'h3', parent=base['Heading3'], fontName='CJKHead', fontSize=10,
            leading=14.5, spaceBefore=3 * mm, spaceAfter=1.2 * mm,
            textColor=colors.HexColor('#374151'), wordWrap='CJK'
        ),
        'body': ParagraphStyle(
            'body', parent=base['BodyText'], fontName='CJK', fontSize=8.7,
            leading=13.6, spaceAfter=2.2 * mm, wordWrap='CJK',
            textColor=colors.HexColor('#30343b')
        ),
        'bullet': ParagraphStyle(
            'bullet', parent=base['BodyText'], fontName='CJK', fontSize=8.6,
            leading=13.2, leftIndent=5 * mm, firstLineIndent=-2.6 * mm,
            spaceAfter=1.2 * mm, wordWrap='CJK'
        ),
        'quote': ParagraphStyle(
            'quote', parent=base['BodyText'], fontName='CJK', fontSize=8.3,
            leading=12.8, leftIndent=4 * mm, rightIndent=4 * mm,
            borderPadding=(2 * mm, 3 * mm, 2 * mm, 3 * mm),
            backColor=colors.HexColor('#f4f5f7'), borderColor=colors.HexColor('#e5e7eb'),
            borderWidth=0.5, borderRadius=2, spaceAfter=2.5 * mm, wordWrap='CJK'
        ),
        'small': ParagraphStyle(
            'small', parent=base['BodyText'], fontName='CJK', fontSize=7.8,
            leading=11.5, textColor=colors.HexColor('#6b7280'), wordWrap='CJK'
        ),
    }


def table_from_markdown(lines: list[str], styles: dict[str, ParagraphStyle]) -> Table:
    rows: list[list[str]] = []
    for line in lines:
        cells = [cell.strip() for cell in line.strip().strip('|').split('|')]
        if cells and all(re.fullmatch(r':?-{3,}:?', cell or '') for cell in cells):
            continue
        rows.append(cells)
    columns = max(len(row) for row in rows)
    data = []
    for row_index, row in enumerate(rows):
        rendered = []
        for column_index in range(columns):
            cell = row[column_index] if column_index < len(row) else ''
            style = ParagraphStyle(
                f'tcell-{row_index}-{column_index}', parent=styles['small'],
                fontName='CJKHead' if row_index == 0 else 'CJK',
                fontSize=8.4 if row_index == 0 else 8.2, leading=12
            )
            rendered.append(Paragraph(inline_md(cell), style))
        data.append(rendered)
    width = 174 * mm
    widths = [50 * mm, 124 * mm] if columns == 2 else [width / columns] * columns
    table = Table(data, colWidths=widths, repeatRows=1, hAlign='LEFT')
    table.setStyle(TableStyle([
        ('GRID', (0, 0), (-1, -1), 0.4, colors.HexColor('#d1d5db')),
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#f3f4f6')),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('LEFTPADDING', (0, 0), (-1, -1), 4),
        ('RIGHTPADDING', (0, 0), (-1, -1), 4),
        ('TOPPADDING', (0, 0), (-1, -1), 4),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
    ]))
    return table


def markdown_flowables(text: str, document_title: str):
    styles = make_styles()
    story = [Paragraph(inline_md(document_title), styles['title'])]
    lines = text.splitlines()
    index = 0
    paragraph: list[str] = []

    def flush() -> None:
        nonlocal paragraph
        if paragraph:
            joined = ' '.join(part.strip() for part in paragraph if part.strip())
            if joined:
                story.append(Paragraph(inline_md(joined), styles['body']))
            paragraph = []

    while index < len(lines):
        raw = lines[index].rstrip()
        stripped = raw.strip()
        if stripped.startswith('|'):
            flush()
            block = []
            while index < len(lines) and lines[index].strip().startswith('|'):
                block.append(lines[index])
                index += 1
            story.append(table_from_markdown(block, styles))
            story.append(Spacer(1, 3 * mm))
            continue
        if not stripped:
            flush()
            index += 1
            continue
        if stripped == '---':
            flush()
            story.append(Spacer(1, 1 * mm))
            story.append(HRFlowable(width='100%', thickness=0.45, color=colors.HexColor('#e5e7eb')))
            story.append(Spacer(1, 1 * mm))
            index += 1
            continue
        heading = re.match(r'^(#{1,3})\s+(.*)$', stripped)
        if heading:
            flush()
            level = len(heading.group(1))
            title = heading.group(2)
            # Keep T1-T9 category headings with useful following content without
            # wasting the remainder of the previous page. CondPageBreak only breaks
            # when less than the declared vertical budget remains.
            if level == 1 and story and re.match(r'^T[1-9](?:[｜| ]|$)', title):
                story.append(CondPageBreak(62 * mm))
            story.append(Paragraph(inline_md(title), styles[f'h{level}']))
            index += 1
            continue
        if stripped.startswith('>'):
            flush()
            story.append(Paragraph(inline_md(stripped.lstrip('>').strip()), styles['quote']))
            index += 1
            continue
        if re.match(r'^[-*]\s+', stripped):
            flush()
            item = re.sub(r'^[-*]\s+', '', stripped)
            story.append(Paragraph('• ' + inline_md(item), styles['bullet']))
            index += 1
            continue
        if re.match(r'^\d+\.\s+', stripped):
            flush()
            story.append(Paragraph(inline_md(stripped), styles['body']))
            index += 1
            continue
        paragraph.append(stripped)
        index += 1
    flush()
    return story


def footer(canvas, doc) -> None:
    canvas.saveState()
    canvas.setFont('CJK', 7.5)
    canvas.setFillColor(colors.HexColor('#7b8190'))
    canvas.drawString(doc.leftMargin, 9 * mm, FOOTER_TITLE)
    canvas.drawRightString(A4[0] - doc.rightMargin, 9 * mm, str(doc.page))
    canvas.restoreState()


def build_pdf(markdown: str, output: Path, title: str) -> None:
    first_heading = f'# {title}'
    stripped = markdown.lstrip()
    if stripped.startswith(first_heading):
        markdown = stripped[len(first_heading):].lstrip('\n')
    document = SimpleDocTemplate(
        str(output), pagesize=A4, leftMargin=18 * mm, rightMargin=18 * mm,
        topMargin=17 * mm, bottomMargin=16 * mm, title=title, author='qiuzhidaren'
    )
    document.build(markdown_flowables(markdown, title), onFirstPage=footer, onLaterPages=footer)


def compose_core(source_root: Path) -> str:
    cards = source_root / 'cards'
    pieces: list[str] = []
    intro = cards / '00_intro.md'
    if intro.exists():
        pieces.append(intro.read_text(encoding='utf-8'))
    card_paths = sorted(cards.glob('T*.md'))
    if not card_paths:
        raise SystemExit(f'No T*.md cards found under {cards}')
    pieces.extend(path.read_text(encoding='utf-8') for path in card_paths)
    return '\n\n'.join(pieces)


def main() -> int:
    parser = argparse.ArgumentParser(description='Publish the Yunnan structured-interview material pack.')
    parser.add_argument('--source-root', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()

    register_cjk_fonts()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    quick = args.source_root / '云南省教师招聘结构化面试速记框架.md'
    if not quick.exists():
        raise SystemExit(f'Missing quick framework: {quick}')

    build_pdf(
        compose_core(args.source_root),
        args.output_dir / '云南省教师招聘结构化面试核心题库.pdf',
        '云南省教师招聘结构化面试核心题库',
    )
    build_pdf(
        quick.read_text(encoding='utf-8'),
        args.output_dir / '云南省教师招聘结构化面试速记框架.pdf',
        '云南省教师招聘结构化面试速记框架',
    )
    print(f'published to {args.output_dir}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
