#!/usr/bin/env python3
"""Deterministic teacher recruitment acquisition queue, production planner, and synthetic E2E gate."""
from __future__ import annotations

from collections import defaultdict
from pathlib import Path
import argparse
import json
import sys
import yaml

ROOT = Path(__file__).resolve().parents[1]
POSITION_ROOT = ROOT / "content/job-search/teacher/position-research"
REGISTRY = POSITION_ROOT / "sources/yunnan-source-registry.yaml"
R2 = POSITION_ROOT / "materials/yunnan/r2"
DEFAULT_EVENTS = R2 / "canonical-current-recruitment-events.yaml"
DEFAULT_ROUTES = R2 / "downstream-routing-sample.yaml"
SYNTHETIC_FIXTURE = POSITION_ROOT / "fixtures/synthetic-campus-recruitment-round1-v1.yaml"

AUTH_RANK = {"A0": 0, "A1": 1, "B": 2, "C": 3, "D": 4}
OFFICIAL_ASSERTION_LEVELS = {"A0", "A1"}
CORRECTION_ROLES = {"correction", "supplement"}
RECRUITMENT_SURFACE_ROLES = {"issuer-primary", "official-repost", "recruitment-system"}
DISCOVERY_SURFACE_ROLES = {"campus-discovery", "discovery"}


def load_yaml(path: Path) -> dict:
    return yaml.safe_load(path.read_text(encoding="utf-8")) or {}


def print_acquisition_queue(priorities: set[str]) -> int:
    data = load_yaml(REGISTRY)
    sources = data.get("sources") or {}
    gaps = data.get("discovery_gaps") or []

    queue = []
    for sid, src in sources.items():
        if src.get("priority") not in priorities:
            continue
        queue.append(
            (
                src.get("priority"),
                src.get("geography"),
                sid,
                src.get("acquisition_strategy"),
                src.get("entry_url"),
                src.get("verification_status"),
            )
        )
    queue.sort(key=lambda x: (x[0], x[1], x[2]))

    print("# REGISTERED ACQUISITION QUEUE")
    for priority, geo, sid, strategy, url, status in queue:
        print(f"{priority}\t{geo}\t{sid}\t{strategy}\t{status}\t{url}")

    print("\n# EXPLICIT DISCOVERY GAPS")
    for gap in sorted(gaps, key=lambda g: (g.get("priority", "P9"), g.get("geography", ""), g.get("target", ""))):
        if gap.get("priority") not in priorities:
            continue
        print(f"{gap.get('priority')}\t{gap.get('geography')}\t{gap.get('target')}")

    print("\n# COUNTS")
    print(f"registered={len(queue)} gaps={sum(1 for g in gaps if g.get('priority') in priorities)}")
    print("planner_only=true network_calls=false")
    return 0


def subject_matches(event: dict, subject: str | None) -> bool:
    if not subject:
        return True
    needle = subject.casefold()
    text = " ".join(
        str(event.get(key) or "")
        for key in ("title", "positions_summary", "focus_subject_hit", "geography", "recruitment_mode")
    ).casefold()
    aliases = {
        "physics": ("physics", "物理"),
        "物理": ("physics", "物理"),
    }
    terms = aliases.get(needle, (needle,))
    return any(term.casefold() in text for term in terms)


def build_pipeline(events_doc: dict, routes_doc: dict, *, include_closed: bool, subject: str | None) -> dict:
    routes = {item.get("event_id"): item for item in (routes_doc.get("samples") or []) if item.get("event_id")}
    selected = []
    excluded_closed = 0
    unresolved_attachments = 0

    for event in events_doc.get("events") or []:
        event_id = event.get("event_id")
        opening = event.get("current_opening")
        if not isinstance(opening, bool):
            raise ValueError(f"{event_id}: current_opening must be explicit bool")
        if not include_closed and not opening:
            excluded_closed += 1
            continue
        if not subject_matches(event, subject):
            continue

        attachment = event.get("attachments") or {}
        known = int(attachment.get("known_official_links") or 0)
        captured = int(attachment.get("binary_captured") or 0)
        if known > captured:
            unresolved_attachments += 1

        route = routes.get(event_id) or {}
        eligibility_status = route.get("eligibility_status") or "CANDIDATE_DATA_REQUIRED"
        if eligibility_status != "CANDIDATE_DATA_REQUIRED":
            raise ValueError(f"{event_id}: candidate-neutral planner cannot emit eligibility verdict")

        next_actions = []
        if not opening:
            next_actions.append("DO_NOT_RECOMMEND_AS_CURRENT_OPPORTUNITY")
        if known > captured:
            next_actions.append("ACQUIRE_AND_VALIDATE_OFFICIAL_ATTACHMENTS")
        next_actions.append("LOAD_CANDIDATE_FACT_EVIDENCE_BEFORE_ELIGIBILITY")
        if not route:
            next_actions.append("DERIVE_SOURCE_BOUND_MODULE_ROUTE")

        selected.append(
            {
                "event_id": event_id,
                "title": event.get("title"),
                "geography": event.get("geography"),
                "recruitment_mode": event.get("recruitment_mode"),
                "current_status": event.get("current_status"),
                "current_opening": opening,
                "authority_level": event.get("authority_level"),
                "source_url": event.get("source_url"),
                "source_locator": event.get("source_locator"),
                "positions_summary": event.get("positions_summary"),
                "focus_subject_hit": event.get("focus_subject_hit"),
                "attachment_gate": {
                    "known_official_links": known,
                    "binary_captured": captured,
                    "unresolved": known > captured,
                },
                "eligibility_status": eligibility_status,
                "required_candidate_facts": route.get("required_candidate_facts") or [],
                "resume_materials_route": route.get("resume_materials_route"),
                "selection_routes": route.get("selection_routes") or [],
                "inactive_routes": route.get("inactive_routes") or [],
                "next_actions": next_actions,
            }
        )

    return {
        "version": 1,
        "planner": "teacher-job-production-plan",
        "source_as_of": events_doc.get("as_of"),
        "policy": {
            "closed_jobs_excluded_by_default": True,
            "eligibility_requires_candidate_facts": True,
            "unknown_attachment_fields_remain_unknown": True,
            "module_routing_is_source_bound": True,
        },
        "query": {"include_closed": include_closed, "subject": subject},
        "summary": {
            "source_events": len(events_doc.get("events") or []),
            "selected_events": len(selected),
            "closed_events_excluded": excluded_closed,
            "selected_with_unresolved_attachments": unresolved_attachments,
        },
        "events": selected,
    }


def _pick_current_official_document(documents: list[dict]) -> dict:
    official = [d for d in documents if d.get("authority_level") in OFFICIAL_ASSERTION_LEVELS]
    if not official:
        raise ValueError("cannot pick current official document from discovery-only records")

    corrections = [d for d in official if d.get("document_role") in CORRECTION_ROLES]
    if corrections:
        return max(corrections, key=lambda d: str(d.get("published_at") or ""))

    best_rank = min(AUTH_RANK.get(str(d.get("authority_level")), 99) for d in official)
    strongest = [d for d in official if AUTH_RANK.get(str(d.get("authority_level")), 99) == best_rank]
    return max(strongest, key=lambda d: str(d.get("published_at") or ""))


def evaluate_synthetic_recruitment(data: dict, *, subject: str | None) -> dict:
    """Evaluate synthetic source graph without treating synthetic data as real recruitment information."""
    if data.get("synthetic") is not True:
        raise ValueError("synthetic E2E fixture must carry synthetic=true")

    schools = {item.get("school_id"): item for item in (data.get("schools") or []) if item.get("school_id")}
    surfaces = {item.get("surface_id"): item for item in (data.get("surfaces") or []) if item.get("surface_id")}
    if not schools or not surfaces:
        raise ValueError("synthetic fixture requires school universe and source surfaces")

    groups: dict[str, list[dict]] = defaultdict(list)
    for document in data.get("documents") or []:
        doc_id = document.get("document_id")
        canonical_key = document.get("canonical_key")
        surface_id = document.get("surface_id")
        if not doc_id or not canonical_key:
            raise ValueError("synthetic document missing document_id/canonical_key")
        if surface_id not in surfaces:
            raise ValueError(f"{doc_id}: unresolved surface_id {surface_id}")
        if document.get("authority_level") != surfaces[surface_id].get("authority_level"):
            raise ValueError(f"{doc_id}: document/surface authority mismatch")
        groups[canonical_key].append(document)

    official_events: list[dict] = []
    discovery_pending: list[dict] = []

    for canonical_key, documents in sorted(groups.items()):
        official = [d for d in documents if d.get("authority_level") in OFFICIAL_ASSERTION_LEVELS]
        if not official:
            best = min(
                documents,
                key=lambda d: (
                    AUTH_RANK.get(str(d.get("authority_level")), 99),
                    str(d.get("published_at") or ""),
                ),
            )
            discovery_pending.append(
                {
                    "canonical_key": canonical_key,
                    "school_ids": best.get("school_ids") or [],
                    "title": best.get("title"),
                    "recruitment_mode": best.get("recruitment_mode"),
                    "best_discovery_document_id": best.get("document_id"),
                    "best_discovery_authority_level": best.get("authority_level"),
                    "status": "DISCOVERY_PENDING_OFFICIAL_CLOSURE",
                    "next_actions": ["FIND_A0_A1_EMPLOYER_OR_GOVERNING_AUTHORITY_SOURCE"],
                }
            )
            continue

        current = _pick_current_official_document(documents)
        opening = current.get("current_opening")
        if not isinstance(opening, bool):
            raise ValueError(f"{current.get('document_id')}: current_opening must be explicit bool")

        dependency = current.get("attachment_dependency") or {}
        known = int(dependency.get("known_official_links") or 0)
        captured = int(dependency.get("binary_captured") or 0)
        attachment_blocked = known > captured
        subjects = [] if attachment_blocked else list(current.get("subjects") or [])

        aliases = {"physics": {"physics", "物理"}, "物理": {"physics", "物理"}}
        terms = aliases.get((subject or "").casefold(), {(subject or "").casefold()}) if subject else set()
        subject_match = True if not subject else any(str(s).casefold() in terms for s in subjects)

        status = "CURRENT_OFFICIAL" if opening else "CLOSED_OFFICIAL"
        if opening and attachment_blocked:
            status = "CURRENT_ATTACHMENT_BLOCKED"

        next_actions: list[str] = []
        if not opening:
            next_actions.append("DO_NOT_RECOMMEND_AS_CURRENT_OPPORTUNITY")
        if attachment_blocked:
            next_actions.append("ACQUIRE_AND_VALIDATE_OFFICIAL_ATTACHMENTS")
        if opening:
            next_actions.append("LOAD_CANDIDATE_FACT_EVIDENCE_BEFORE_ELIGIBILITY")

        official_events.append(
            {
                "canonical_key": canonical_key,
                "school_ids": current.get("school_ids") or [],
                "title": current.get("title"),
                "current_document_id": current.get("document_id"),
                "authority_level": current.get("authority_level"),
                "recruitment_mode": current.get("recruitment_mode"),
                "current_opening": opening,
                "application_deadline": current.get("application_deadline"),
                "source_url": current.get("source_url"),
                "subject_status": "UNKNOWN_ATTACHMENT_REQUIRED" if attachment_blocked else "RESOLVED",
                "subjects": subjects,
                "subject_query_match": subject_match,
                "positions": current.get("positions") or [],
                "requirements": current.get("requirements") or [],
                "eligibility_status": "CANDIDATE_DATA_REQUIRED",
                "resume_materials_route": current.get("resume_materials_route"),
                "selection_routes": current.get("selection_routes") or [],
                "status": status,
                "source_chain": [
                    d.get("document_id")
                    for d in sorted(documents, key=lambda item: str(item.get("published_at") or ""))
                ],
                "next_actions": next_actions,
            }
        )

    school_coverage: list[dict] = []
    for school_id, school in sorted(schools.items()):
        linked = [s for s in surfaces.values() if school_id in (s.get("school_ids") or [])]
        roster = [
            s
            for s in linked
            if s.get("surface_role") == "school-roster" and s.get("authority_level") in OFFICIAL_ASSERTION_LEVELS
        ]
        official_recruitment = [
            s
            for s in linked
            if s.get("surface_role") in RECRUITMENT_SURFACE_ROLES
            and s.get("authority_level") in OFFICIAL_ASSERTION_LEVELS
        ]
        discovery = [s for s in linked if s.get("surface_role") in DISCOVERY_SURFACE_ROLES]

        if official_recruitment:
            coverage_status = "VERIFIED_RECRUITMENT_SURFACE"
        elif discovery:
            coverage_status = "DISCOVERY_ONLY_RECRUITMENT_SURFACE"
        else:
            coverage_status = "NO_RECRUITMENT_SURFACE"

        school_coverage.append(
            {
                "school_id": school_id,
                "school_name": school.get("name"),
                "rostered": bool(roster),
                "coverage_status": coverage_status,
                "official_recruitment_surfaces": [s.get("surface_id") for s in official_recruitment],
                "discovery_surfaces": [s.get("surface_id") for s in discovery],
            }
        )

    current_official = [e for e in official_events if e.get("current_opening") is True]
    attachment_blocked_current = [e for e in current_official if e.get("subject_status") == "UNKNOWN_ATTACHMENT_REQUIRED"]
    actionable_current = [
        e
        for e in current_official
        if e.get("subject_status") == "RESOLVED" and (not subject or e.get("subject_query_match") is True)
    ]
    closed_archive = [e for e in official_events if e.get("current_opening") is False]
    campus_candidate_keys = {
        key
        for key, docs in groups.items()
        if any(d.get("recruitment_mode") == "campus-recruitment" for d in docs)
    }
    campus_official = [e for e in official_events if e.get("recruitment_mode") == "campus-recruitment"]

    summary = {
        "candidate_event_groups": len(groups),
        "official_canonical_events": len(official_events),
        "current_official_events": len(current_official),
        "current_physics_actionable": len(actionable_current) if (subject or "").casefold() in {"物理", "physics"} else None,
        "attachment_blocked_current": len(attachment_blocked_current),
        "discovery_pending_official_closure": len(discovery_pending),
        "closed_official_events": len(closed_archive),
        "campus_candidate_events": len(campus_candidate_keys),
        "campus_officially_closed_events": len(campus_official),
        "rostered_schools": sum(1 for item in school_coverage if item.get("rostered")),
        "schools_with_verified_recruitment_surface": sum(
            1 for item in school_coverage if item.get("coverage_status") == "VERIFIED_RECRUITMENT_SURFACE"
        ),
        "schools_with_discovery_only_recruitment_surface": sum(
            1 for item in school_coverage if item.get("coverage_status") == "DISCOVERY_ONLY_RECRUITMENT_SURFACE"
        ),
    }

    return {
        "version": 1,
        "planner": "teacher-recruitment-synthetic-e2e",
        "synthetic": True,
        "as_of": data.get("as_of"),
        "query": {"subject": subject},
        "policy": {
            "school_roster_is_coverage_denominator": True,
            "B_C_D_are_discovery_only_for_job_assertions": True,
            "correction_overrides_prior_announcement": True,
            "attachment_unknowns_do_not_become_subject_facts": True,
            "closed_jobs_never_actionable": True,
            "eligibility_requires_candidate_facts": True,
        },
        "summary": summary,
        "actionable_current": actionable_current,
        "attachment_blocked_current": attachment_blocked_current,
        "discovery_pending_official_closure": discovery_pending,
        "closed_archive": closed_archive,
        "school_coverage": school_coverage,
    }


def validate_synthetic_expected(result: dict, expected: dict) -> None:
    summary = result.get("summary") or {}
    errors = []
    for key, expected_value in expected.items():
        if summary.get(key) != expected_value:
            errors.append(f"{key}: expected={expected_value!r} actual={summary.get(key)!r}")

    if any(item.get("authority_level") not in OFFICIAL_ASSERTION_LEVELS for item in result.get("actionable_current") or []):
        errors.append("discovery-only source leaked into actionable current opportunities")
    if any(item.get("current_opening") is not True for item in result.get("actionable_current") or []):
        errors.append("closed event leaked into actionable current opportunities")
    if any(item.get("eligibility_status") != "CANDIDATE_DATA_REQUIRED" for item in result.get("actionable_current") or []):
        errors.append("synthetic planner inferred candidate eligibility")
    if any(
        item.get("subject_status") != "UNKNOWN_ATTACHMENT_REQUIRED"
        for item in result.get("attachment_blocked_current") or []
    ):
        errors.append("attachment-blocked event lost unknown-field gate")

    corrected = [
        item
        for item in result.get("actionable_current") or []
        if item.get("canonical_key") == "SYN-EVENT-D-DIRECT"
    ]
    if not corrected or corrected[0].get("current_document_id") != "DOC-D-CORRECTION":
        errors.append("correction document did not supersede earlier announcement")

    if errors:
        raise AssertionError("; ".join(errors))


def self_test() -> int:
    events = load_yaml(DEFAULT_EVENTS)
    routes = load_yaml(DEFAULT_ROUTES)

    current = build_pipeline(events, routes, include_closed=False, subject=None)
    if any(not item["current_opening"] for item in current["events"]):
        raise AssertionError("closed event leaked into default current-opportunity plan")

    physics_history = build_pipeline(events, routes, include_closed=True, subject="物理")
    if not physics_history["events"]:
        raise AssertionError("physics filter returned no source-bound historical sample")
    closed_physics = [item for item in physics_history["events"] if not item["current_opening"]]
    if closed_physics and not all(
        "DO_NOT_RECOMMEND_AS_CURRENT_OPPORTUNITY" in item["next_actions"] for item in closed_physics
    ):
        raise AssertionError("closed-event safety action missing")

    if any(item["eligibility_status"] != "CANDIDATE_DATA_REQUIRED" for item in physics_history["events"]):
        raise AssertionError("planner inferred candidate eligibility")

    synthetic = load_yaml(SYNTHETIC_FIXTURE)
    synthetic_result = evaluate_synthetic_recruitment(
        synthetic,
        subject=(synthetic.get("policy") or {}).get("subject_query") or "物理",
    )
    validate_synthetic_expected(synthetic_result, synthetic.get("expected") or {})

    print("PASS: teacher position acquisition/pipeline planner self-test")
    print(
        f"default_current={current['summary']['selected_events']} "
        f"physics_with_history={physics_history['summary']['selected_events']} "
        f"synthetic_actionable={synthetic_result['summary']['current_physics_actionable']} "
        f"synthetic_discovery_pending={synthetic_result['summary']['discovery_pending_official_closure']}"
    )
    return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--priority", action="append", choices=["P0", "P1", "P2", "P3"])
    ap.add_argument("--pipeline", action="store_true", help="Build downstream production plan from canonical events.")
    ap.add_argument("--events", type=Path, default=DEFAULT_EVENTS)
    ap.add_argument("--routes", type=Path, default=DEFAULT_ROUTES)
    ap.add_argument("--include-closed", action="store_true", help="Include closed/historical events in pipeline output.")
    ap.add_argument("--subject", help="Optional subject filter, e.g. 物理 or physics.")
    ap.add_argument("--synthetic-e2e", action="store_true", help="Run synthetic campus/school recruitment E2E fixture.")
    ap.add_argument("--synthetic-fixture", type=Path, default=SYNTHETIC_FIXTURE)
    ap.add_argument("--format", choices=["yaml", "json"], default="yaml")
    ap.add_argument("--self-test", action="store_true")
    args = ap.parse_args()

    if args.self_test:
        return self_test()

    if args.synthetic_e2e:
        try:
            fixture = load_yaml(args.synthetic_fixture)
            plan = evaluate_synthetic_recruitment(
                fixture,
                subject=args.subject or (fixture.get("policy") or {}).get("subject_query"),
            )
            validate_synthetic_expected(plan, fixture.get("expected") or {})
        except (OSError, ValueError, AssertionError, yaml.YAMLError) as exc:
            print(f"FAIL: {exc}", file=sys.stderr)
            return 2
        if args.format == "json":
            print(json.dumps(plan, ensure_ascii=False, indent=2))
        else:
            print(yaml.safe_dump(plan, allow_unicode=True, sort_keys=False).rstrip())
        return 0

    if not args.pipeline:
        priorities = set(args.priority or ["P0", "P1"])
        return print_acquisition_queue(priorities)

    try:
        plan = build_pipeline(
            load_yaml(args.events),
            load_yaml(args.routes),
            include_closed=args.include_closed,
            subject=args.subject,
        )
    except (OSError, ValueError, yaml.YAMLError) as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        return 2

    if args.format == "json":
        print(json.dumps(plan, ensure_ascii=False, indent=2))
    else:
        print(yaml.safe_dump(plan, allow_unicode=True, sort_keys=False).rstrip())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
