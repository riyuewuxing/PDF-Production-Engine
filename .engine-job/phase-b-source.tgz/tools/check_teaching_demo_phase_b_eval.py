#!/usr/bin/env python3
"""Teaching Demo Phase-B eval harness.

This executable is evaluation-only. It does not create Gate-B activation, does
not open accepted mode, and does not sign production controller receipts. The
synthetic HMAC key below exists only inside selftest fixtures and has no runtime
authority.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
import hashlib
import hmac
import json
import os
from pathlib import Path
import tempfile

import yaml

import check_teaching_demo_content as content_gate
import teaching_demo_content_enforcement as enforcement
import verify_teaching_demo_semantic_provenance as provenance

ROOT = Path(__file__).resolve().parents[1]
CORPUS_PATH = ROOT / "production/process/teaching-demo-content/validation/phase-b/GOLD_CORPUS.yaml"
SEMANTIC_CALIBRATION_PACKET_PATH = ROOT / "production/process/teaching-demo-content/validation/phase-b/SEMANTIC_CALIBRATION_CASES.yaml"
POSITIVE_SEMANTIC_GOLD_CANDIDATE_PATH = ROOT / "production/process/teaching-demo-content/validation/phase-b/POSITIVE_SEMANTIC_GOLD_CANDIDATE.yaml"
POSITIVE_HUMAN_REVIEW_PACKET_PATH = ROOT / "production/process/teaching-demo-content/validation/phase-b/POSITIVE_SEMANTIC_GOLD_HUMAN_REVIEW_INPUT.yaml"
POSITIVE_HUMAN_REVIEW_RESULT_PATH = ROOT / "production/process/teaching-demo-content/validation/phase-b/POSITIVE_SEMANTIC_GOLD_HUMAN_REVIEW_RESULT.yaml"
TRUSTED_SEMANTIC_EXECUTION_INPUT_PATH = ROOT / "production/process/teaching-demo-content/validation/phase-b/TRUSTED_SEMANTIC_EXECUTION_INPUT.yaml"
TRUSTED_SEMANTIC_EXECUTION_RESULT_PATH = ROOT / "production/process/teaching-demo-content/validation/phase-b/TRUSTED_SEMANTIC_EXECUTION_RESULT.yaml"
TRUSTED_CONTEXT_ENV = "TEACHING_DEMO_TRUSTED_SEMANTIC_CONTEXT_JSON"
TRUSTED_MAC_KEY_ENV = "TEACHING_DEMO_TRUSTED_SEMANTIC_MAC_KEY_HEX"
TRUSTED_CONTEXT_SCHEMA_ID = "teaching-demo-phase-b-trusted-semantic-context-v1"
LIVE_RESULT_SCHEMA_ID = "teaching-demo-phase-b-trusted-semantic-execution-result-v1"
LIVE_JUDGE_OUTPUT_SCHEMA_ID = "teaching-demo-phase-b-semantic-judge-output-v1"
CONTRACT_PATH = ROOT / "production/contracts/teaching-demo-content.yaml"
TEST_KEY = b"phase-b-eval-only-key-not-production-authority"
KEY_ID = "phase-b-eval-test-key"
RUN_ID = "run-gold-001"
NONCE = "nonce-gold-001"
CASE_ID = "phase-b-gold"
INPUT_DIGEST = hashlib.sha256(b"phase-b-gold-semantic-input-set").hexdigest()
CONTROLLER_ID = "trusted-semantic-controller-v1"
CONTROLLER_SOURCE = hashlib.sha256(b"trusted-semantic-controller-source-v1").hexdigest()
RUNTIME = {"name": "controller-runtime", "version": "1.0"}
RUNNERS = {
    provenance.SCIENCE_JUDGE_ID: "science-evidence-judge-v1",
    provenance.ENACTMENT_JUDGE_ID: "enactment-student-judge-v1",
}
OUTPUTS = {
    provenance.SCIENCE_JUDGE_ID: {
        "path": "semantic/SCIENCE_EVIDENCE_JUDGE.yaml",
        "sha256": hashlib.sha256(b"science-output").hexdigest(),
    },
    provenance.ENACTMENT_JUDGE_ID: {
        "path": "semantic/ENACTMENT_STUDENT_JUDGE.yaml",
        "sha256": hashlib.sha256(b"enactment-output").hexdigest(),
    },
}
TRUSTED_NOW = "2026-09-10T12:00:00Z"
PERMANENT_MUTANT_IDS = {
    "P0-RRA4-A",
    "P0-RRA4-B",
    "P0-RRA4-D",
    "P1-RRA4-E",
    "P0-H",
    "P1-PROV",
    "P1-PROV-REPLAY-RUN",
    "P1-PROV-REPLAY-NONCE",
}
SEMANTIC_CORPUS_IDS = {*(f"M{i:02d}" for i in range(1, 16)), "M20", "M21"}
LIVE_SEMANTIC_MUTANT_IDS = {"M01", "M02", "M03", "M04"}
MACHINE_MUTANT_IDS = {*(f"M{i:02d}" for i in range(5, 16))}
SEMANTIC_MUTANT_FIXTURES = {
    "M01": {
        "judge": "Science/Evidence Judge",
        "requirement_id": "REQ-SCI-001",
        "semantic_input": {
            "visible_evidence": "学生只观察到两组数值，没有形成比例关系。",
            "author_sidecar_claim": "两个量成正比。",
            "target_claim": "两个量成正比。",
        },
    },
    "M02": {
        "judge": "Enactment/Student Judge",
        "requirement_id": "REQ-STU-002",
        "semantic_input": {
            "instruction_mode": "independent_transfer",
            "teacher_before_response": "先把关键消元步骤 q 约掉写出来，再请学生独立完成。",
            "student_response": "按教师刚刚给出的步骤复述。",
        },
    },
    "M03": {
        "judge": "Science/Evidence Judge",
        "requirement_id": "REQ-STU-001",
        "semantic_input": {
            "visible_before_task": "只有现象，没有后续定量关系。",
            "student_response": "直接使用尚未形成的后续定量关系回答。",
        },
    },
    "M04": {
        "judge": "Science/Evidence Judge",
        "requirement_id": "REQ-SCI-001",
        "semantic_input": {
            "visible_evidence": "单一条件下的一次观察。",
            "target_claim": "对所有条件都成立的普遍结论。",
        },
    },
}

SEMANTIC_CALIBRATION_CASE_IDS = {*LIVE_SEMANTIC_MUTANT_IDS, "M21"}
M21_SEMANTIC_CALIBRATION_FIXTURE = {
    "judge": "Science/Evidence Judge",
    "requirement_id": "REQ-REL-001",
    "semantic_input": {
        "event_type": "PARAPHRASE",
        "event_text": "所以这个量可能有某种规律。",
        "visible_span": "这个量可能有某种规律",
        "target_knowledge_id": "K1",
        "formation_claim": "该 visible span 已经充分建立 K1。",
    },
}


def _canonical_semantic_input_digest(value: object) -> str:
    raw = json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    ).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _git_blob_sha1(path: Path) -> str:
    data = path.read_bytes()
    return hashlib.sha1(f"blob {len(data)}\0".encode("ascii") + data).hexdigest()


def _repo_path(raw: object) -> Path:
    if not isinstance(raw, str) or not raw:
        raise AssertionError(f"Phase-B corpus path invalid: {raw!r}")
    rel = Path(raw)
    if rel.is_absolute() or ".." in rel.parts:
        raise AssertionError(f"Phase-B corpus path escapes repository: {raw!r}")
    path = (ROOT / rel).resolve()
    path.relative_to(ROOT.resolve())
    if not path.is_file():
        raise AssertionError(f"Phase-B corpus bound file missing: {raw}")
    return path


def _load_corpus() -> dict:
    data = yaml.safe_load(CORPUS_PATH.read_text(encoding="utf-8")) or {}
    if not isinstance(data, dict):
        raise AssertionError("Phase-B GOLD_CORPUS must be a mapping")
    return data


def _corpus_selftest() -> None:
    """Bind the eval harness to immutable human failures and declared mutant set."""
    data = _load_corpus()
    if data.get("id") != "teaching-demo-phase-b-gold-corpus-v1":
        raise AssertionError("Phase-B GOLD_CORPUS identity drift")
    if data.get("authority") != "EVAL_ONLY_NOT_GATE_B_ACTIVATION":
        raise AssertionError("Phase-B corpus authority drift")
    if data.get("gate_b_activation") is not False or data.get("accepted_mode_unlock") is not False:
        raise AssertionError("Phase-B corpus attempted to acquire Gate-B/accepted authority")
    if data.get("process_calibration_claimed") is not False:
        raise AssertionError("Phase-B corpus attempted to claim CALIBRATED")

    history = data.get("historical_failure_bindings")
    if not isinstance(history, list) or len(history) < 4:
        raise AssertionError("Phase-B corpus historical failure bindings incomplete")
    seen_history: set[str] = set()
    for item in history:
        if not isinstance(item, dict):
            raise AssertionError("Phase-B historical binding must be a mapping")
        binding_id = item.get("id")
        if not isinstance(binding_id, str) or not binding_id or binding_id in seen_history:
            raise AssertionError(f"Phase-B historical binding id invalid/duplicate: {binding_id!r}")
        seen_history.add(binding_id)
        if item.get("immutable_decision") != "REJECT":
            raise AssertionError(f"historical failure rewritten as non-REJECT: {binding_id}")
        path = _repo_path(item.get("path"))
        declared = item.get("git_blob_sha1")
        actual = _git_blob_sha1(path)
        if declared != actual:
            raise AssertionError(
                f"Phase-B historical corpus binding drift: {binding_id}: declared={declared} actual={actual}"
            )

    semantic = data.get("semantic_mutants")
    if not isinstance(semantic, list):
        raise AssertionError("Phase-B semantic mutant catalog missing")
    semantic_ids = [x.get("id") for x in semantic if isinstance(x, dict)]
    if len(semantic_ids) != len(set(semantic_ids)):
        raise AssertionError("Phase-B semantic mutant ids duplicate")
    missing_semantic = sorted(SEMANTIC_CORPUS_IDS - set(semantic_ids))
    if missing_semantic:
        raise AssertionError(f"Phase-B semantic corpus lost required mutants: {missing_semantic}")
    catalog_by_id = {str(x.get("id")): x for x in semantic if isinstance(x, dict) and x.get("id")}
    for mutant_id in MACHINE_MUTANT_IDS:
        if (catalog_by_id.get(mutant_id) or {}).get("enforcement_class") != "MACHINE_DETERMINISTIC":
            raise AssertionError(f"Phase-B machine mutant classification drift: {mutant_id}")
    for mutant_id in LIVE_SEMANTIC_MUTANT_IDS:
        if (catalog_by_id.get(mutant_id) or {}).get("enforcement_class") != "SEMANTIC_JUDGE":
            raise AssertionError(f"Phase-B semantic mutant classification drift: {mutant_id}")

    permanent = data.get("permanent_architecture_and_provenance_mutants")
    if not isinstance(permanent, list):
        raise AssertionError("Phase-B permanent mutant catalog missing")
    permanent_ids = [x.get("id") for x in permanent if isinstance(x, dict)]
    if len(permanent_ids) != len(set(permanent_ids)):
        raise AssertionError("Phase-B permanent mutant ids duplicate")
    if set(permanent_ids) != PERMANENT_MUTANT_IDS:
        raise AssertionError(
            "Phase-B permanent mutant set drift: "
            f"expected={sorted(PERMANENT_MUTANT_IDS)} actual={sorted(set(permanent_ids))}"
        )
    for group in (semantic, permanent):
        for item in group:
            if not isinstance(item, dict) or item.get("expected") != "REJECT":
                raise AssertionError(f"Phase-B negative mutant must remain REJECT: {item!r}")

    positive = data.get("positive_gold") or {}
    controller_gold = positive.get("controller_provenance_synthetic") if isinstance(positive, dict) else None
    if not isinstance(controller_gold, dict) or controller_gold.get("production_authority") is not False:
        raise AssertionError("test-only controller Gold must never become production authority")
    semantic_gold = positive.get("semantic_content_human_reviewed") if isinstance(positive, dict) else None
    if not isinstance(semantic_gold, dict):
        raise AssertionError("semantic HUMAN Gold state missing from Phase-B corpus")
    if semantic_gold.get("status") != "HUMAN_REVIEWED_PASS":
        raise AssertionError("Phase-B semantic HUMAN Gold must reflect the external PASS result")
    if semantic_gold.get("gate_b_effect") != "HUMAN_LANE_SATISFIED_GATE_B_STILL_BLOCKED":
        raise AssertionError("HUMAN Gold PASS must not self-authorize Gate B")
    if semantic_gold.get("human_review_decision") != "PASS":
        raise AssertionError("Phase-B semantic HUMAN Gold decision drift")
    if semantic_gold.get("trusted_semantic_pass_on_same_digest") != "REQUIRED_NOT_YET_EXECUTED":
        raise AssertionError("HUMAN Gold must still require trusted semantic PASS")

    gold_candidate_path = _repo_path(semantic_gold.get("candidate_path"))
    actual_candidate_blob = _git_blob_sha1(gold_candidate_path)
    if semantic_gold.get("candidate_git_blob_sha1") != actual_candidate_blob:
        raise AssertionError("Phase-B HUMAN Gold candidate blob binding drift")
    gold_candidate = yaml.safe_load(gold_candidate_path.read_text(encoding="utf-8")) or {}
    gold_case = gold_candidate.get("candidate_case") if isinstance(gold_candidate, dict) else None
    if not isinstance(gold_case, dict):
        raise AssertionError("Phase-B HUMAN Gold candidate invalid")
    actual_semantic_digest = _canonical_semantic_input_digest(gold_case.get("semantic_input"))
    if (
        semantic_gold.get("semantic_input_digest") != actual_semantic_digest
        or gold_case.get("semantic_input_digest") != actual_semantic_digest
    ):
        raise AssertionError("Phase-B HUMAN Gold semantic digest binding drift")

    review_result_path = _repo_path(semantic_gold.get("human_review_result_path"))
    actual_review_blob = _git_blob_sha1(review_result_path)
    if semantic_gold.get("human_review_result_git_blob_sha1") != actual_review_blob:
        raise AssertionError("Phase-B external HUMAN result blob binding drift")
    review_result = yaml.safe_load(review_result_path.read_text(encoding="utf-8")) or {}
    if (
        not isinstance(review_result, dict)
        or review_result.get("decision") != "PASS"
        or review_result.get("candidate_git_blob_sha1") != actual_candidate_blob
        or review_result.get("semantic_input_digest") != actual_semantic_digest
        or (review_result.get("external_evidence") or {}).get("sha256") != semantic_gold.get("external_review_source_sha256")
    ):
        raise AssertionError("Phase-B external HUMAN result/corpus binding drift")

    evidence = data.get("phase_b_evidence_state") or {}
    if not isinstance(evidence, dict):
        raise AssertionError("Phase-B evidence state missing")
    if evidence.get("gate_b_state") != "BLOCKED" or evidence.get("accepted_mode") != "FAIL_CLOSED":
        raise AssertionError("Phase-B source corpus must not self-authorize Gate B/accepted mode")
    if evidence.get("trusted_semantic_execution_input") != "SOURCE_BOUND_READY_FOR_EXTERNAL_RUNTIME":
        raise AssertionError("Phase-B trusted semantic execution input state drift")
    execution_input_path = _repo_path(evidence.get("trusted_semantic_execution_input_path"))
    if _git_blob_sha1(execution_input_path) != evidence.get("trusted_semantic_execution_input_git_blob_sha1"):
        raise AssertionError("Phase-B trusted semantic execution input corpus binding drift")


def _semantic_mutant_materialization_selftest() -> None:
    """Materialize M01-M04 without fabricating semantic-judge kill evidence."""
    data = _load_corpus()
    catalog = {
        str(item.get("id")): item
        for item in data.get("semantic_mutants") or []
        if isinstance(item, dict) and item.get("id")
    }
    contract = yaml.safe_load(CONTRACT_PATH.read_text(encoding="utf-8")) or {}
    registry = {
        str(item.get("requirement_id")): item
        for item in contract.get("requirement_registry") or []
        if isinstance(item, dict) and item.get("requirement_id")
    }
    if set(SEMANTIC_MUTANT_FIXTURES) != LIVE_SEMANTIC_MUTANT_IDS:
        raise AssertionError("Phase-B live semantic fixture set drift")
    for mutant_id, fixture in SEMANTIC_MUTANT_FIXTURES.items():
        row = catalog.get(mutant_id)
        if not isinstance(row, dict) or row.get("enforcement_class") != "SEMANTIC_JUDGE" or row.get("expected") != "REJECT":
            raise AssertionError(f"Phase-B semantic mutant catalog row invalid: {mutant_id}")
        requirement = registry.get(str(fixture.get("requirement_id")))
        if not isinstance(requirement, dict) or requirement.get("enforcement_class") != "SEMANTIC_JUDGE":
            raise AssertionError(f"Phase-B semantic mutant requirement invalid: {mutant_id}")
        if requirement.get("enforcer") != fixture.get("judge"):
            raise AssertionError(f"Phase-B semantic mutant judge drift: {mutant_id}")
        semantic_input = fixture.get("semantic_input")
        if not isinstance(semantic_input, dict) or not semantic_input:
            raise AssertionError(f"Phase-B semantic mutant input missing: {mutant_id}")
        digest = hashlib.sha256(
            yaml.safe_dump(semantic_input, allow_unicode=True, sort_keys=True).encode("utf-8")
        ).hexdigest()
        if len(digest) != 64:
            raise AssertionError(f"Phase-B semantic mutant digest invalid: {mutant_id}")
    # Intentionally no PASS verdict is synthesized here. A real kill for M01-M04
    # requires a trusted semantic-controller/judge invocation bound by provenance.


def _semantic_calibration_packet_selftest() -> None:
    """Bind external calibration work to exact mutant inputs without authoring verdicts."""
    packet = yaml.safe_load(SEMANTIC_CALIBRATION_PACKET_PATH.read_text(encoding="utf-8")) or {}
    if not isinstance(packet, dict):
        raise AssertionError("Phase-B semantic calibration packet must be a mapping")
    if packet.get("schema_id") != "teaching-demo-phase-b-semantic-calibration-cases-v1":
        raise AssertionError("Phase-B semantic calibration packet schema drift")
    if packet.get("authority") != "EVAL_ONLY_NOT_GATE_B_ACTIVATION":
        raise AssertionError("Phase-B semantic calibration packet authority drift")
    if packet.get("gate_b_activation") is not False or packet.get("accepted_mode_unlock") is not False:
        raise AssertionError("Phase-B semantic calibration packet attempted to unlock Gate B/accepted mode")
    if packet.get("process_calibration_claimed") is not False:
        raise AssertionError("Phase-B semantic calibration packet attempted to claim CALIBRATED")

    forbidden = set(packet.get("result_fields_forbidden_in_this_file") or [])
    required_forbidden = {
        "verdict", "decision", "judge_output", "controller_receipt",
        "authenticator", "production_mac_key",
    }
    if forbidden != required_forbidden:
        raise AssertionError(
            f"Phase-B semantic calibration forbidden-result field set drift: "
            f"expected={sorted(required_forbidden)} actual={sorted(forbidden)}"
        )

    def walk(value: object, path: str = "packet") -> None:
        if isinstance(value, dict):
            for key, child in value.items():
                if key in forbidden and key != "result_fields_forbidden_in_this_file":
                    raise AssertionError(
                        f"Phase-B semantic calibration packet contains authored result field: {path}.{key}"
                    )
                walk(child, f"{path}.{key}")
        elif isinstance(value, list):
            for index, child in enumerate(value):
                walk(child, f"{path}[{index}]")

    walk(packet)

    digest_contract = packet.get("canonical_digest") or {}
    if digest_contract.get("algorithm") != "SHA-256" or digest_contract.get("encoding") != "canonical-json-sort-keys-utf8-v1":
        raise AssertionError("Phase-B semantic calibration digest contract drift")

    trusted = packet.get("trusted_invocation_requirements") or {}
    required_true = {
        "fresh_run_id_required",
        "fresh_nonce_required",
        "expected_values_must_come_from_trusted_invocation_not_receipt",
        "controller_id_and_source_sha256_required",
        "runtime_name_and_version_required",
        "both_judge_runner_identities_required",
        "producer_and_session_identity_required_for_each_judge",
        "both_judge_outputs_exact_path_sha256_bound",
        "controller_receipt_authenticator_required",
        "production_mac_key_must_remain_external_to_repository",
        "one_semantic_input_digest_shared_by_both_judge_runs",
    }
    missing_true = sorted(key for key in required_true if trusted.get(key) is not True)
    if missing_true:
        raise AssertionError(f"Phase-B semantic calibration trusted-invocation contract drift: {missing_true}")

    rows = packet.get("cases")
    if not isinstance(rows, list):
        raise AssertionError("Phase-B semantic calibration cases missing")
    by_id = {
        str(row.get("case_id")): row
        for row in rows
        if isinstance(row, dict) and row.get("case_id")
    }
    if len(by_id) != len(rows) or set(by_id) != SEMANTIC_CALIBRATION_CASE_IDS:
        raise AssertionError(
            "Phase-B semantic calibration case set drift: "
            f"expected={sorted(SEMANTIC_CALIBRATION_CASE_IDS)} actual={sorted(by_id)}"
        )

    contract = yaml.safe_load(CONTRACT_PATH.read_text(encoding="utf-8")) or {}
    registry = {
        str(item.get("requirement_id")): item
        for item in contract.get("requirement_registry") or []
        if isinstance(item, dict) and item.get("requirement_id")
    }
    fixtures = dict(SEMANTIC_MUTANT_FIXTURES)
    fixtures["M21"] = M21_SEMANTIC_CALIBRATION_FIXTURE

    for case_id in sorted(SEMANTIC_CALIBRATION_CASE_IDS):
        row = by_id[case_id]
        fixture = fixtures[case_id]
        if row.get("mutant_id") != case_id or row.get("expected_outcome") != "REJECT":
            raise AssertionError(f"Phase-B semantic calibration mutant expectation drift: {case_id}")
        if row.get("target_judge") != fixture["judge"]:
            raise AssertionError(f"Phase-B semantic calibration judge drift: {case_id}")
        if row.get("target_requirement_id") != fixture["requirement_id"]:
            raise AssertionError(f"Phase-B semantic calibration requirement drift: {case_id}")
        requirement = registry.get(str(row.get("target_requirement_id")))
        if not isinstance(requirement, dict) or requirement.get("enforcement_class") != "SEMANTIC_JUDGE":
            raise AssertionError(f"Phase-B semantic calibration target is not a semantic requirement: {case_id}")
        if requirement.get("enforcer") != row.get("target_judge"):
            raise AssertionError(f"Phase-B semantic calibration enforcer mismatch: {case_id}")
        if row.get("semantic_input") != fixture["semantic_input"]:
            raise AssertionError(f"Phase-B semantic calibration input drift: {case_id}")
        actual_digest = _canonical_semantic_input_digest(row.get("semantic_input"))
        if row.get("semantic_input_digest") != actual_digest:
            raise AssertionError(
                f"Phase-B semantic calibration digest drift: {case_id}: "
                f"declared={row.get('semantic_input_digest')} actual={actual_digest}"
            )

    positive = packet.get("positive_semantic_gold") or {}
    if (
        positive.get("status") != "REQUIRED_NOT_YET_CURATED"
        or positive.get("authority_required") != "HUMAN_REVIEWED"
        or positive.get("author_self_attestation_forbidden") is not True
        or positive.get("gate_b_effect") != "BLOCKING"
    ):
        raise AssertionError("Phase-B semantic calibration positive-Gold blocker drift")


def _positive_semantic_gold_candidate_selftest() -> None:
    """Keep the prepared positive case non-authoritative and prove its legal-path shape."""
    candidate = yaml.safe_load(POSITIVE_SEMANTIC_GOLD_CANDIDATE_PATH.read_text(encoding="utf-8")) or {}
    if not isinstance(candidate, dict):
        raise AssertionError("Phase-B positive semantic Gold candidate must be a mapping")
    if candidate.get("schema_id") != "teaching-demo-phase-b-positive-semantic-gold-candidate-v1":
        raise AssertionError("Phase-B positive semantic Gold candidate schema drift")
    if candidate.get("authority") != "CANDIDATE_ONLY_NOT_HUMAN_GOLD":
        raise AssertionError("Phase-B positive semantic Gold candidate authority drift")
    if candidate.get("accepted_mode_unlock") is not False or candidate.get("gate_b_activation") is not False:
        raise AssertionError("Phase-B positive semantic Gold candidate attempted to unlock accepted mode/Gate B")
    if candidate.get("process_calibration_claimed") is not False:
        raise AssertionError("Phase-B positive semantic Gold candidate attempted to claim CALIBRATED")
    if candidate.get("human_review_status") != "REQUIRED_NOT_YET_PERFORMED" or candidate.get("gate_b_effect") != "BLOCKING":
        raise AssertionError("Phase-B positive semantic Gold candidate human-review blocker drift")

    forbidden = set(candidate.get("result_fields_forbidden_in_candidate") or [])
    expected_forbidden = {
        "human_decision", "judge_verdicts", "judge_outputs",
        "controller_receipt", "authenticator", "production_mac_key",
    }
    if forbidden != expected_forbidden:
        raise AssertionError(
            f"Phase-B positive semantic Gold candidate forbidden-result set drift: "
            f"expected={sorted(expected_forbidden)} actual={sorted(forbidden)}"
        )

    def walk(value: object, path: str = "candidate") -> None:
        if isinstance(value, dict):
            for key, child in value.items():
                if key in forbidden:
                    raise AssertionError(
                        f"Phase-B positive semantic Gold candidate contains authored result field: {path}.{key}"
                    )
                walk(child, f"{path}.{key}")
        elif isinstance(value, list):
            for index, child in enumerate(value):
                walk(child, f"{path}[{index}]")

    scrubbed = dict(candidate)
    scrubbed.pop("result_fields_forbidden_in_candidate", None)
    walk(scrubbed)

    case = candidate.get("candidate_case") or {}
    if case.get("case_id") != "POS-GOLD-01":
        raise AssertionError("Phase-B positive semantic Gold candidate case id drift")
    if case.get("candidate_expected_semantic_outcome") != "PASS_IF_HUMAN_APPROVED_AND_LIVE_TRUSTED_JUDGE_PASS":
        raise AssertionError("Phase-B positive semantic Gold candidate expectation drift")
    required_ids = {
        "REQ-SCI-001", "REQ-SCI-002", "REQ-SCI-003", "REQ-REL-001",
        "REQ-STU-001", "REQ-STU-002", "REQ-STU-003", "REQ-INT-002",
        "REQ-RES-003", "REQ-TIM-005",
    }
    if set(case.get("target_requirements") or []) != required_ids:
        raise AssertionError("Phase-B positive semantic Gold candidate requirement set drift")
    semantic_input = case.get("semantic_input")
    if not isinstance(semantic_input, dict) or not semantic_input:
        raise AssertionError("Phase-B positive semantic Gold candidate input missing")
    actual_digest = _canonical_semantic_input_digest(semantic_input)
    if case.get("semantic_input_digest") != actual_digest:
        raise AssertionError(
            f"Phase-B positive semantic Gold candidate digest drift: "
            f"declared={case.get('semantic_input_digest')} actual={actual_digest}"
        )

    contract = yaml.safe_load(CONTRACT_PATH.read_text(encoding="utf-8")) or {}
    registry = {
        str(item.get("requirement_id")): item
        for item in contract.get("requirement_registry") or []
        if isinstance(item, dict) and item.get("requirement_id")
    }
    expected_enforcers = {
        "REQ-SCI-001": "Science/Evidence Judge",
        "REQ-SCI-002": "Science/Evidence Judge",
        "REQ-SCI-003": "Science/Evidence Judge",
        "REQ-REL-001": "Science/Evidence Judge",
        "REQ-STU-001": "Science/Evidence Judge",
        "REQ-STU-002": "Enactment/Student Judge",
        "REQ-STU-003": "Enactment/Student Judge",
        "REQ-INT-002": "Enactment/Student Judge",
        "REQ-RES-003": "Science/Evidence Judge",
        "REQ-TIM-005": "Enactment/Student Judge",
    }
    for requirement_id in sorted(required_ids):
        requirement = registry.get(requirement_id)
        if not isinstance(requirement, dict) or requirement.get("enforcement_class") != "SEMANTIC_JUDGE":
            raise AssertionError(
                f"Phase-B positive semantic Gold candidate target is not SEMANTIC_JUDGE: {requirement_id}"
            )
        if requirement.get("enforcer") != expected_enforcers[requirement_id]:
            raise AssertionError(
                f"Phase-B positive semantic Gold candidate enforcer drift: "
                f"{requirement_id}:{requirement.get('enforcer')}"
            )

    # Prevent the positive fixture from repeating the Round-2/M01 sidecar-only defect.
    teacher_before = semantic_input.get("teacher_before_response")
    student_response = semantic_input.get("student_response")
    formation_span = semantic_input.get("formation_span")
    if not all(isinstance(x, str) and x.strip() for x in (teacher_before, student_response, formation_span)):
        raise AssertionError("Phase-B positive candidate formation text missing")
    if "成正比" in teacher_before or "2 N/C" in teacher_before:
        raise AssertionError("Phase-B positive candidate teacher leaks target relation/answer before response")
    if formation_span not in student_response:
        raise AssertionError("Phase-B positive candidate formation is sidecar-only, not inside student response")
    modes = semantic_input.get("instruction_modes") or {}
    formation_cycle_id = modes.get("formation_cycle_id")
    practice_cycle_id = modes.get("practice_cycle_id")
    formation_mode = modes.get("formation_cycle")
    practice_mode = modes.get("practice_cycle")
    if formation_cycle_id != "C-FORM" or practice_cycle_id != "C-PRACTICE":
        raise AssertionError("Phase-B positive candidate cycle identity drift")
    if formation_mode not in content_gate.core.INSTRUCTION_MODES or practice_mode not in content_gate.core.INSTRUCTION_MODES:
        raise AssertionError("Phase-B positive candidate uses a non-canonical instruction mode")
    if formation_mode != "scaffolded_formation" or practice_mode != "independent_transfer":
        raise AssertionError("Phase-B positive candidate formation/transfer mode split drift")
    if formation_mode not in content_gate.core.INTERACTIVE_MODES or practice_mode not in content_gate.core.INTERACTIVE_MODES:
        raise AssertionError("Phase-B positive candidate interactive-mode binding drift")
    practice_teacher = semantic_input.get("practice_teacher_before_response")
    if not isinstance(practice_teacher, str) or not practice_teacher.strip():
        raise AssertionError("Phase-B positive candidate transfer prompt missing")
    if "8 μN" in practice_teacher or "答案是" in practice_teacher:
        raise AssertionError("Phase-B positive candidate transfer prompt leaks the target answer")

    # Visible numeric evidence must itself support the bounded relation.
    rows = semantic_input.get("visible_evidence")
    if not isinstance(rows, list) or len(rows) < 3:
        raise AssertionError("Phase-B positive candidate visible evidence incomplete")
    ratios: list[float] = []
    for row in rows:
        if not isinstance(row, dict):
            raise AssertionError("Phase-B positive candidate evidence row invalid")
        q = row.get("q_uC")
        force = row.get("F_uN")
        declared_ratio = row.get("F_over_q_N_per_C")
        if not all(isinstance(x, (int, float)) and not isinstance(x, bool) for x in (q, force, declared_ratio)):
            raise AssertionError("Phase-B positive candidate evidence row nonnumeric")
        if float(q) <= 0:
            raise AssertionError("Phase-B positive candidate q must be positive")
        actual_ratio = float(force) / float(q)
        if abs(actual_ratio - float(declared_ratio)) > 1e-9:
            raise AssertionError("Phase-B positive candidate F/q evidence arithmetic drift")
        ratios.append(actual_ratio)
    if max(ratios) - min(ratios) > 1e-9:
        raise AssertionError("Phase-B positive candidate visible F/q ratios are not constant")

    # Bind resource -> response -> formation -> reveal -> oralize -> board -> practice,
    # and make the timing path actually recomputable rather than a prose-only claim.
    events = semantic_input.get("typed_events")
    if not isinstance(events, list):
        raise AssertionError("Phase-B positive candidate typed event sequence missing")
    expected_ids = [f"POS-E{i:02d}" for i in range(1, 15)]
    actual_ids = [event.get("event_id") for event in events if isinstance(event, dict)]
    if actual_ids != expected_ids or len(events) != len(expected_ids):
        raise AssertionError(
            f"Phase-B positive candidate event order drift: expected={expected_ids} actual={actual_ids}"
        )
    structure_errors = content_gate.arch.validate_event_stream(events)
    if structure_errors:
        raise AssertionError(f"Phase-B positive candidate event stream is not canonical: {structure_errors}")
    by_id = {event["event_id"]: event for event in events}
    for event_id in expected_ids:
        expected_cycle = formation_cycle_id if int(event_id[-2:]) <= 10 else practice_cycle_id
        if by_id[event_id].get("cycle_id") != expected_cycle:
            raise AssertionError(
                f"Phase-B positive candidate event cycle drift: {event_id}:{by_id[event_id].get('cycle_id')}"
            )
    release_claims = by_id["POS-E05"].get("release_claims")
    expected_release_claims = [{"knowledge_id": "K-FQ-PROP", "visible_span": formation_span}]
    if release_claims != expected_release_claims:
        raise AssertionError("Phase-B positive candidate release claim is not embedded on the formation event")
    release_errors = enforcement._validate_release_claims(events, ["K-FQ-PROP"])
    if release_errors:
        raise AssertionError(f"Phase-B positive candidate release-claim structure invalid: {release_errors}")
    expected_types = {
        "POS-E01": "RESOURCE_SHOW", "POS-E02": "ASK", "POS-E03": "INVITE",
        "POS-E04": "WAIT", "POS-E05": "STUDENT_RESPONSE", "POS-E06": "PARAPHRASE",
        "POS-E07": "FEEDBACK", "POS-E08": "RESOURCE_REVEAL",
        "POS-E09": "FORMULA_ORALIZE", "POS-E10": "BOARD_ADD",
        "POS-E11": "PRACTICE", "POS-E12": "WAIT",
        "POS-E13": "STUDENT_RESPONSE", "POS-E14": "FEEDBACK",
    }
    for event_id, event_type in expected_types.items():
        if by_id[event_id].get("type") != event_type:
            raise AssertionError(f"Phase-B positive candidate event type drift: {event_id}")
    if by_id["POS-E02"].get("text") != teacher_before or by_id["POS-E05"].get("text") != student_response:
        raise AssertionError("Phase-B positive candidate teacher/student text is not event-bound")
    if by_id["POS-E11"].get("text") != practice_teacher:
        raise AssertionError("Phase-B positive candidate transfer prompt is not event-bound")
    if by_id["POS-E01"].get("answer_bearing_conclusion_visible") is not False:
        raise AssertionError("Phase-B positive candidate answer-bearing resource is visible before response")
    if semantic_input.get("resource_reveal_after_formation_event") != "POS-E08":
        raise AssertionError("Phase-B positive candidate resource reveal binding drift")
    if semantic_input.get("formula_oralization_after_formation_event") != "POS-E09":
        raise AssertionError("Phase-B positive candidate formula oralization binding drift")
    if semantic_input.get("board_add_after_formation_event") != "POS-E10":
        raise AssertionError("Phase-B positive candidate board binding drift")
    if semantic_input.get("practice_after_formation_event") != "POS-E11":
        raise AssertionError("Phase-B positive candidate practice binding drift")

    elapsed = 0.0
    for event in events:
        timing = event.get("timing")
        if not isinstance(timing, dict) or not timing:
            raise AssertionError(f"Phase-B positive candidate timing missing: {event.get('event_id')}")
        numeric = [
            float(value)
            for value in timing.values()
            if isinstance(value, (int, float)) and not isinstance(value, bool)
        ]
        if len(numeric) != len(timing) or any(value <= 0 for value in numeric):
            raise AssertionError(f"Phase-B positive candidate timing invalid: {event.get('event_id')}")
        elapsed += sum(numeric)
    declared_total = semantic_input.get("typed_event_total_seconds")
    if not isinstance(declared_total, (int, float)) or isinstance(declared_total, bool):
        raise AssertionError("Phase-B positive candidate declared timing total invalid")
    if abs(float(declared_total) - elapsed) > 1e-9:
        raise AssertionError(
            f"Phase-B positive candidate timing total drift: declared={declared_total} actual={elapsed}"
        )

    claims = candidate.get("candidate_design_claims")
    if not isinstance(claims, list) or len(claims) < 7 or not all(isinstance(x, str) and x.strip() for x in claims):
        raise AssertionError("Phase-B positive semantic Gold candidate design claims incomplete")

    # Independent HUMAN review must be allowed to reject the candidate. Requiring
    # PASS as the only representable review outcome would destroy reviewer independence.
    human = candidate.get("independent_human_review_required") or {}
    if (
        human.get("reviewer_role") != "INDEPENDENT_HUMAN"
        or human.get("implementation_and_review_separate") is not True
        or human.get("exact_candidate_byte_binding_required") is not True
        or human.get("decision_required") != "PASS_OR_REJECT"
        or human.get("pass_required_for_gold_promotion") is not True
        or human.get("reject_keeps_gate_b_blocked") is not True
        or human.get("review_notes_required") is not True
        or human.get("author_self_attestation_forbidden") is not True
    ):
        raise AssertionError("Phase-B positive semantic Gold candidate HUMAN review contract drift")

    trusted = candidate.get("trusted_semantic_execution_required_after_human_review") or {}
    required_true = {
        "both_judges_required",
        "fresh_run_id_and_nonce_required",
        "exact_semantic_input_digest_required",
        "exact_judge_output_bindings_required",
        "controller_provenance_receipt_required",
        "production_mac_key_external_to_repository",
    }
    missing = sorted(key for key in required_true if trusted.get(key) is not True)
    if missing:
        raise AssertionError(f"Phase-B positive semantic Gold candidate trusted-runtime contract drift: {missing}")



def _positive_human_review_packet_selftest() -> None:
    """Freeze exact candidate bytes for an external HUMAN review without authoring its result."""
    packet = yaml.safe_load(POSITIVE_HUMAN_REVIEW_PACKET_PATH.read_text(encoding="utf-8")) or {}
    if not isinstance(packet, dict):
        raise AssertionError("Phase-B positive HUMAN review packet must be a mapping")
    if packet.get("schema_id") != "teaching-demo-phase-b-positive-human-review-input-v1":
        raise AssertionError("Phase-B positive HUMAN review packet schema drift")
    if packet.get("authority") != "REVIEW_INPUT_ONLY_NO_DECISION":
        raise AssertionError("Phase-B positive HUMAN review packet authority drift")
    for key in ("gate_b_activation", "accepted_mode_unlock", "process_calibration_claimed", "human_gold_claimed"):
        if packet.get(key) is not False:
            raise AssertionError(f"Phase-B positive HUMAN review packet attempted authority escalation: {key}")

    if packet.get("repository_authored_review_result_forbidden") is not True:
        raise AssertionError("Phase-B positive HUMAN review input must forbid repository-authored review results")

    binding = packet.get("candidate_binding") or {}
    expected_candidate_rel = POSITIVE_SEMANTIC_GOLD_CANDIDATE_PATH.relative_to(ROOT).as_posix()
    if binding.get("path") != expected_candidate_rel:
        raise AssertionError("Phase-B positive HUMAN review packet candidate path drift")
    candidate_path = _repo_path(binding.get("path"))
    actual_blob = _git_blob_sha1(candidate_path)
    if binding.get("git_blob_sha1") != actual_blob:
        raise AssertionError(
            f"Phase-B positive HUMAN review packet candidate blob drift: "
            f"declared={binding.get('git_blob_sha1')} actual={actual_blob}"
        )

    candidate = yaml.safe_load(candidate_path.read_text(encoding="utf-8")) or {}
    if not isinstance(candidate, dict):
        raise AssertionError("Phase-B positive HUMAN review packet bound candidate invalid")
    if binding.get("candidate_authority_expected") != "CANDIDATE_ONLY_NOT_HUMAN_GOLD":
        raise AssertionError("Phase-B positive HUMAN review packet candidate-authority expectation drift")
    if candidate.get("authority") != binding.get("candidate_authority_expected"):
        raise AssertionError("Phase-B positive HUMAN review packet candidate authority mismatch")
    case = candidate.get("candidate_case") or {}
    if binding.get("case_id") != "POS-GOLD-01" or case.get("case_id") != binding.get("case_id"):
        raise AssertionError("Phase-B positive HUMAN review packet case binding drift")
    semantic_input = case.get("semantic_input")
    actual_digest = _canonical_semantic_input_digest(semantic_input)
    if (
        binding.get("semantic_input_digest") != actual_digest
        or case.get("semantic_input_digest") != actual_digest
    ):
        raise AssertionError(
            "Phase-B positive HUMAN review packet semantic digest drift: "
            f"packet={binding.get('semantic_input_digest')} "
            f"candidate={case.get('semantic_input_digest')} actual={actual_digest}"
        )

    review_scope = packet.get("review_scope") or {}
    if (
        review_scope.get("reviewer_role_required") != "INDEPENDENT_HUMAN"
        or review_scope.get("implementation_and_review_separate") is not True
        or review_scope.get("exact_candidate_byte_binding_required") is not True
        or set(review_scope.get("decision_domain") or []) != {"PASS", "REJECT"}
        or review_scope.get("author_self_attestation_forbidden") is not True
    ):
        raise AssertionError("Phase-B positive HUMAN review scope drift")

    checks = packet.get("required_checks")
    expected_check_ids = {f"HR-POS-{i:02d}" for i in range(1, 11)}
    if not isinstance(checks, list):
        raise AssertionError("Phase-B positive HUMAN review checks missing")
    check_ids = [item.get("id") for item in checks if isinstance(item, dict)]
    if len(check_ids) != len(checks) or set(check_ids) != expected_check_ids or len(check_ids) != len(set(check_ids)):
        raise AssertionError(
            f"Phase-B positive HUMAN review check set drift: expected={sorted(expected_check_ids)} actual={sorted(check_ids)}"
        )
    if not all(isinstance(item.get("check"), str) and item.get("check").strip() for item in checks):
        raise AssertionError("Phase-B positive HUMAN review check text missing")

    output = packet.get("external_review_output_contract") or {}
    expected_output_fields = {
        "schema_id", "candidate_path", "candidate_git_blob_sha1", "semantic_input_digest",
        "reviewer_reference", "reviewer_role", "independence_attestation",
        "implementation_and_review_separate", "reviewed_at", "decision",
        "per_check_findings", "review_notes",
    }
    if set(output.get("required_fields") or []) != expected_output_fields:
        raise AssertionError("Phase-B positive HUMAN review output contract field drift")
    if (
        output.get("schema_id_expected") != "teaching-demo-phase-b-positive-human-review-result-v1"
        or output.get("candidate_path_must_equal_bound_path") is not True
        or output.get("candidate_git_blob_sha1_must_equal_bound_blob") is not True
        or output.get("semantic_input_digest_must_equal_bound_digest") is not True
        or output.get("reviewer_reference_required") is not True
        or output.get("reviewer_role_expected") != "INDEPENDENT_HUMAN"
        or output.get("independence_attestation_required") is not True
        or output.get("implementation_and_review_separate_must_be") is not True
        or set(output.get("decision_allowed") or []) != {"PASS", "REJECT"}
        or output.get("every_required_check_must_have_finding") is not True
        or output.get("pass_requires_all_required_checks_pass") is not True
        or output.get("reject_keeps_gate_b_blocked") is not True
    ):
        raise AssertionError("Phase-B positive HUMAN review output contract drift")

    promotion = packet.get("promotion_rule") or {}
    required_true = {
        "human_pass_alone_is_not_gate_b",
        "human_pass_alone_is_not_calibrated",
        "human_pass_alone_does_not_unlock_accepted_mode",
        "exact_candidate_bytes_required_for_gold_promotion",
        "trusted_semantic_controller_pass_on_same_digest_still_required_for_false_positive_evidence",
    }
    missing = sorted(key for key in required_true if promotion.get(key) is not True)
    if missing:
        raise AssertionError(f"Phase-B positive HUMAN review promotion rule drift: {missing}")


def _positive_human_review_result_selftest() -> None:
    """Consume an external HUMAN result without converting repository authorship into review authority."""
    review_input = yaml.safe_load(POSITIVE_HUMAN_REVIEW_PACKET_PATH.read_text(encoding="utf-8")) or {}
    result = yaml.safe_load(POSITIVE_HUMAN_REVIEW_RESULT_PATH.read_text(encoding="utf-8")) or {}
    if not isinstance(review_input, dict) or not isinstance(result, dict):
        raise AssertionError("Phase-B positive HUMAN review input/result must be mappings")

    output_contract = review_input.get("external_review_output_contract") or {}
    required_fields = set(output_contract.get("required_fields") or [])
    missing_fields = sorted(field for field in required_fields if field not in result)
    if missing_fields:
        raise AssertionError(f"Phase-B positive HUMAN review result missing required fields: {missing_fields}")

    if result.get("schema_id") != output_contract.get("schema_id_expected"):
        raise AssertionError("Phase-B positive HUMAN review result schema drift")
    if result.get("authority") != "EXTERNAL_HUMAN_REVIEW_RESULT":
        raise AssertionError("Phase-B positive HUMAN review result authority drift")
    for key in ("gate_b_activation", "accepted_mode_unlock", "process_calibration_claimed"):
        if result.get(key) is not False:
            raise AssertionError(f"Phase-B positive HUMAN review result attempted authority escalation: {key}")

    binding = review_input.get("candidate_binding") or {}
    if (
        result.get("candidate_path") != binding.get("path")
        or result.get("candidate_git_blob_sha1") != binding.get("git_blob_sha1")
        or result.get("semantic_input_digest") != binding.get("semantic_input_digest")
    ):
        raise AssertionError("Phase-B positive HUMAN review result candidate binding mismatch")

    candidate_path = _repo_path(result.get("candidate_path"))
    actual_blob = _git_blob_sha1(candidate_path)
    candidate = yaml.safe_load(candidate_path.read_text(encoding="utf-8")) or {}
    case = candidate.get("candidate_case") if isinstance(candidate, dict) else None
    if not isinstance(case, dict):
        raise AssertionError("Phase-B positive HUMAN review result bound candidate invalid")
    actual_digest = _canonical_semantic_input_digest(case.get("semantic_input"))
    if (
        result.get("candidate_git_blob_sha1") != actual_blob
        or result.get("semantic_input_digest") != actual_digest
        or case.get("semantic_input_digest") != actual_digest
    ):
        raise AssertionError("Phase-B positive HUMAN review result stale against current candidate")

    if not isinstance(result.get("reviewer_reference"), str) or not result.get("reviewer_reference").strip():
        raise AssertionError("Phase-B positive HUMAN review result reviewer reference missing")
    if result.get("reviewer_role") != "INDEPENDENT_HUMAN":
        raise AssertionError("Phase-B positive HUMAN review result reviewer role drift")
    if not isinstance(result.get("independence_attestation"), str) or not result.get("independence_attestation").strip():
        raise AssertionError("Phase-B positive HUMAN review result independence attestation missing")
    if result.get("implementation_and_review_separate") is not True:
        raise AssertionError("Phase-B positive HUMAN review result separation assertion missing")
    if not isinstance(result.get("reviewed_at"), str) or not result.get("reviewed_at").strip():
        raise AssertionError("Phase-B positive HUMAN review result reviewed_at missing")

    allowed = set(output_contract.get("decision_allowed") or [])
    decision = result.get("decision")
    if decision not in allowed:
        raise AssertionError(f"Phase-B positive HUMAN review result decision invalid: {decision!r}")

    required_checks = review_input.get("required_checks") or []
    expected_ids = {item.get("id") for item in required_checks if isinstance(item, dict)}
    findings = result.get("per_check_findings")
    if not isinstance(findings, list):
        raise AssertionError("Phase-B positive HUMAN review result findings missing")
    finding_ids = [item.get("id") for item in findings if isinstance(item, dict)]
    if len(finding_ids) != len(findings) or set(finding_ids) != expected_ids or len(finding_ids) != len(set(finding_ids)):
        raise AssertionError(
            f"Phase-B positive HUMAN review result finding set drift: expected={sorted(expected_ids)} actual={sorted(finding_ids)}"
        )
    for item in findings:
        if item.get("decision") not in {"PASS", "REJECT"}:
            raise AssertionError(f"Phase-B positive HUMAN review finding decision invalid: {item!r}")
        if not isinstance(item.get("finding"), str) or not item.get("finding").strip():
            raise AssertionError(f"Phase-B positive HUMAN review finding text missing: {item!r}")
    if decision == "PASS" and any(item.get("decision") != "PASS" for item in findings):
        raise AssertionError("Phase-B positive HUMAN PASS requires every required check PASS")
    if decision == "REJECT" and not any(item.get("decision") == "REJECT" for item in findings):
        raise AssertionError("Phase-B positive HUMAN REJECT requires at least one rejected check")
    if not isinstance(result.get("review_notes"), str) or not result.get("review_notes").strip():
        raise AssertionError("Phase-B positive HUMAN review notes missing")

    evidence = result.get("external_evidence") or {}
    evidence_sha = evidence.get("sha256")
    if (
        evidence.get("type") != "user_supplied_review_screenshot"
        or not isinstance(evidence_sha, str)
        or len(evidence_sha) != 64
        or any(ch not in "0123456789abcdef" for ch in evidence_sha)
        or evidence.get("materialization_role") != "PHASE_B_IMPLEMENTER_TRANSCRIPTION_ONLY"
        or evidence.get("decision_origin") != "EXTERNAL_INDEPENDENT_HUMAN"
    ):
        raise AssertionError("Phase-B positive HUMAN review external evidence provenance invalid")

    promotion = result.get("promotion_constraints") or {}
    required_true = {
        "candidate_bytes_must_remain_unchanged",
        "human_pass_promotes_only_to_human_reviewed_positive_gold",
        "trusted_semantic_controller_pass_on_same_digest_still_required",
        "exact_checkout_runtime_evidence_still_required",
        "independent_gate_b_still_required",
    }
    missing = sorted(key for key in required_true if promotion.get(key) is not True)
    if missing:
        raise AssertionError(f"Phase-B positive HUMAN review result promotion constraints drift: {missing}")



def _trusted_semantic_execution_input_selftest() -> None:
    """Bind the external trusted-runtime handoff without placing runtime authority in the repository."""
    request = yaml.safe_load(TRUSTED_SEMANTIC_EXECUTION_INPUT_PATH.read_text(encoding="utf-8")) or {}
    if not isinstance(request, dict):
        raise AssertionError("Phase-B trusted semantic execution input must be a mapping")
    if request.get("schema_id") != "teaching-demo-phase-b-trusted-semantic-execution-input-v1":
        raise AssertionError("Phase-B trusted semantic execution input schema drift")
    if request.get("authority") != "INPUT_ONLY_NO_CONTROLLER_AUTHORITY":
        raise AssertionError("Phase-B trusted semantic execution input authority drift")
    for key in ("gate_b_activation", "accepted_mode_unlock", "process_calibration_claimed", "runtime_execution_claimed"):
        if request.get(key) is not False:
            raise AssertionError(f"Phase-B trusted semantic execution input attempted authority escalation: {key}")

    forbidden = set(request.get("result_fields_forbidden_in_this_input") or [])
    expected_forbidden = {
        "judge_verdicts", "judge_outputs", "controller_execution_receipt",
        "integrity_authenticator", "trusted_signing_secret", "gate_b_decision",
    }
    if forbidden != expected_forbidden:
        raise AssertionError(
            "Phase-B trusted semantic execution input forbidden-result set drift: "
            f"expected={sorted(expected_forbidden)} actual={sorted(forbidden)}"
        )

    forbidden_identity_keys = {
        "controller_id", "controller_source_sha256", "runtime",
        "runner_id", "expected_controller_id", "expected_runtime",
        "expected_judge_runners",
    }

    def walk(value: object, path: str = "trusted_execution_input") -> None:
        if isinstance(value, dict):
            for key, child in value.items():
                if key in forbidden:
                    raise AssertionError(
                        f"Phase-B trusted semantic execution input contains authored result field: {path}.{key}"
                    )
                if key in forbidden_identity_keys:
                    raise AssertionError(
                        f"Phase-B trusted semantic execution input defines trusted runtime identity: {path}.{key}"
                    )
                walk(child, f"{path}.{key}")
        elif isinstance(value, list):
            for index, child in enumerate(value):
                walk(child, f"{path}[{index}]")

    scrubbed = dict(request)
    scrubbed.pop("result_fields_forbidden_in_this_input", None)
    walk(scrubbed)

    verifier_bindings = request.get("repository_verifier_bindings") or {}
    expected_verifier_paths = {
        "semantic_provenance_verifier": "tools/verify_teaching_demo_semantic_provenance.py",
        "phase_b_eval_verifier": "tools/check_teaching_demo_phase_b_eval.py",
        "acceptance_router": "tools/run_acceptance.py",
    }
    if not isinstance(verifier_bindings, dict) or set(verifier_bindings) != set(expected_verifier_paths):
        raise AssertionError("Phase-B trusted semantic repository verifier binding set drift")
    for binding_id, expected_path in expected_verifier_paths.items():
        binding = verifier_bindings.get(binding_id)
        path = _repo_path(expected_path)
        if (
            not isinstance(binding, dict)
            or binding.get("path") != expected_path
            or binding.get("git_blob_sha1") != _git_blob_sha1(path)
        ):
            raise AssertionError(
                f"Phase-B trusted semantic repository verifier binding drift: {binding_id}"
            )

    negative = request.get("negative_calibration") or {}
    packet_path = _repo_path(negative.get("packet_path"))
    if _git_blob_sha1(packet_path) != negative.get("packet_git_blob_sha1"):
        raise AssertionError("Phase-B trusted semantic execution input negative packet blob drift")
    packet = yaml.safe_load(packet_path.read_text(encoding="utf-8")) or {}
    packet_rows = {
        str(row.get("case_id")): row
        for row in packet.get("cases") or []
        if isinstance(row, dict) and row.get("case_id")
    }
    request_rows = {
        str(row.get("case_id")): row
        for row in negative.get("cases") or []
        if isinstance(row, dict) and row.get("case_id")
    }
    if set(request_rows) != SEMANTIC_CALIBRATION_CASE_IDS or len(request_rows) != len(negative.get("cases") or []):
        raise AssertionError("Phase-B trusted semantic execution negative case set drift")
    for case_id in sorted(SEMANTIC_CALIBRATION_CASE_IDS):
        packet_row = packet_rows.get(case_id) or {}
        request_row = request_rows[case_id]
        if (
            request_row.get("semantic_input_digest") != packet_row.get("semantic_input_digest")
            or request_row.get("expected_outcome") != "REJECT"
            or packet_row.get("expected_outcome") != "REJECT"
        ):
            raise AssertionError(f"Phase-B trusted semantic execution negative case binding drift: {case_id}")

    positive = request.get("positive_gold") or {}
    if positive.get("case_id") != "POS-GOLD-01" or positive.get("expected_outcome") != "PASS":
        raise AssertionError("Phase-B trusted semantic execution positive case expectation drift")
    candidate_path = _repo_path(positive.get("candidate_path"))
    actual_candidate_blob = _git_blob_sha1(candidate_path)
    candidate = yaml.safe_load(candidate_path.read_text(encoding="utf-8")) or {}
    candidate_case = candidate.get("candidate_case") if isinstance(candidate, dict) else None
    if not isinstance(candidate_case, dict):
        raise AssertionError("Phase-B trusted semantic execution positive candidate invalid")
    actual_digest = _canonical_semantic_input_digest(candidate_case.get("semantic_input"))
    if (
        positive.get("candidate_git_blob_sha1") != actual_candidate_blob
        or positive.get("semantic_input_digest") != actual_digest
        or candidate_case.get("semantic_input_digest") != actual_digest
    ):
        raise AssertionError("Phase-B trusted semantic execution positive candidate binding drift")

    result_path = _repo_path(positive.get("human_review_result_path"))
    actual_result_blob = _git_blob_sha1(result_path)
    review_result = yaml.safe_load(result_path.read_text(encoding="utf-8")) or {}
    if (
        positive.get("human_review_result_git_blob_sha1") != actual_result_blob
        or not isinstance(review_result, dict)
        or review_result.get("decision") != "PASS"
        or review_result.get("candidate_git_blob_sha1") != actual_candidate_blob
        or review_result.get("semantic_input_digest") != actual_digest
        or positive.get("external_review_source_sha256") != (review_result.get("external_evidence") or {}).get("sha256")
        or positive.get("human_lane_state") != "SATISFIED_EXTERNAL_10_OF_10_PASS"
    ):
        raise AssertionError("Phase-B trusted semantic execution HUMAN Gold binding drift")

    trusted = request.get("trusted_invocation_contract") or {}
    required_true = {
        "each_case_requires_fresh_run_id",
        "each_case_requires_fresh_nonce",
        "expected_controller_identity_must_come_from_trusted_runtime",
        "expected_controller_source_identity_must_come_from_trusted_runtime",
        "expected_runtime_name_and_version_must_come_from_trusted_runtime",
        "both_judge_runner_identities_must_come_from_trusted_runtime",
        "producer_and_session_identity_required_for_each_judge",
        "both_judges_required_for_each_case",
        "both_judges_must_use_same_case_semantic_input_digest",
        "exact_judge_output_path_and_sha256_bindings_required",
        "controller_execution_receipt_required",
        "external_integrity_authenticator_required",
        "trusted_signing_secret_must_remain_external_to_repository",
        "repository_input_must_not_define_trusted_runtime_identity",
    }
    missing = sorted(key for key in required_true if trusted.get(key) is not True)
    if missing:
        raise AssertionError(f"Phase-B trusted semantic execution contract drift: {missing}")

    execution = request.get("required_execution_set") or {}
    if (
        set(execution.get("case_ids") or []) != {*SEMANTIC_CALIBRATION_CASE_IDS, "POS-GOLD-01"}
        or execution.get("negative_expected_count") != 5
        or execution.get("positive_expected_count") != 1
        or execution.get("positive_pass_required_to_reject_always_fail_grader") is not True
        or execution.get("all_negative_rejects_required_for_semantic_mutant_kill_evidence") is not True
    ):
        raise AssertionError("Phase-B trusted semantic execution set drift")

    post = request.get("post_execution_requirements") or {}
    post_required = {
        "verify_each_receipt_with_trusted_invocation_expected_values",
        "bind_each_judge_output_to_exact_case_digest",
        "produce_semantic_calibration_report_from_actual_outputs_only",
        "produce_false_positive_legal_pass_evidence_from_positive_gold_only",
        "keep_gate_b_blocked_until_independent_review",
    }
    missing_post = sorted(key for key in post_required if post.get(key) is not True)
    if missing_post:
        raise AssertionError(f"Phase-B trusted semantic execution post-run contract drift: {missing_post}")

    result_contract = request.get("external_result_contract") or {}
    expected_result_contract = {
        "schema_id": LIVE_RESULT_SCHEMA_ID,
        "canonical_result_path": TRUSTED_SEMANTIC_EXECUTION_RESULT_PATH.relative_to(ROOT).as_posix(),
        "judge_output_schema_id": LIVE_JUDGE_OUTPUT_SCHEMA_ID,
        "judge_output_path_template": "production/process/teaching-demo-content/validation/phase-b/runtime-semantic/{case_id}/{judge_id}.yaml",
        "trusted_context_env": TRUSTED_CONTEXT_ENV,
        "trusted_mac_key_env": TRUSTED_MAC_KEY_ENV,
        "trusted_context_schema_id": TRUSTED_CONTEXT_SCHEMA_ID,
        "result_must_bind_execution_input_blob": True,
        "result_case_set_must_equal_required_execution_set": True,
        "target_negative_judge_must_return_FAIL": True,
        "positive_target_requirements_must_all_PASS": True,
        "every_case_controller_receipt_required": True,
        "every_receipt_must_verify_against_external_expected_values": True,
        "trusted_context_each_case_binds_semantic_input_digest": True,
        "trusted_context_each_case_binds_expected_outputs": True,
        "trusted_context_must_be_copied_without_secret_into_result": True,
        "trusted_context_must_bind_execution_input_blob": True,
        "trusted_context_must_bind_verification_time": True,
        "result_required_fields": [
            "schema_id", "authority", "gate_b_activation", "accepted_mode_unlock",
            "process_calibration_claimed", "execution_input_binding",
            "trusted_context", "trusted_context_sha256", "cases",
        ],
        "case_required_fields": [
            "case_id", "semantic_input_digest", "expected_outcome",
            "actual_outcome", "judge_outputs", "controller_execution_receipt",
        ],
        "judge_output_required_fields": [
            "schema_id", "case_id", "judge_id", "semantic_input_digest",
            "producer_id", "session_id", "decision", "reason", "confidence",
            "evidence_refs", "requirement_results",
        ],
        "requirement_result_required_fields": [
            "requirement_id", "verdict", "reason", "confidence", "evidence_refs",
        ],
        "controller_receipt_schema_id": provenance.SCHEMA_ID,
        "execution_input_binding_required_fields": ["path", "git_blob_sha1"],
        "output_binding_required_fields": ["path", "sha256"],
        "trusted_context_required_fields": [
            "schema_id", "key_id", "controller_id", "controller_source_sha256",
            "runtime", "judge_runners", "cases", "execution_input_git_blob_sha1",
            "trusted_now",
        ],
        "trusted_context_runtime_required_fields": ["name", "version"],
        "trusted_context_case_required_fields": [
            "run_id", "nonce", "semantic_input_digest", "expected_outputs",
        ],
        "required_judge_ids": list(provenance.REQUIRED_JUDGE_IDS),
        "gate_b_or_calibrated_claim_in_result_forbidden": True,
    }
    if result_contract != expected_result_contract:
        raise AssertionError("Phase-B trusted semantic external-result contract drift")


def _sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _trusted_runtime_context_from_env() -> dict:
    raw = os.environ.get(TRUSTED_CONTEXT_ENV)
    if not raw:
        raise AssertionError(f"Phase-B live semantic trusted context missing: env={TRUSTED_CONTEXT_ENV}")
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise AssertionError("Phase-B live semantic trusted context is not valid JSON") from exc
    if not isinstance(data, dict) or data.get("schema_id") != TRUSTED_CONTEXT_SCHEMA_ID:
        raise AssertionError("Phase-B live semantic trusted context schema invalid")
    expected_top_keys = {
        "schema_id", "key_id", "controller_id", "controller_source_sha256",
        "runtime", "judge_runners", "cases", "execution_input_git_blob_sha1",
        "trusted_now",
    }
    if set(data) != expected_top_keys:
        raise AssertionError(
            "Phase-B live semantic trusted context field set invalid: "
            f"expected={sorted(expected_top_keys)} actual={sorted(data)}"
        )
    required_scalars = ("key_id", "controller_id", "controller_source_sha256", "trusted_now")
    execution_input_blob = data.get("execution_input_git_blob_sha1")
    if (
        not isinstance(execution_input_blob, str)
        or len(execution_input_blob) != 40
        or any(ch not in "0123456789abcdef" for ch in execution_input_blob)
        or execution_input_blob != _git_blob_sha1(TRUSTED_SEMANTIC_EXECUTION_INPUT_PATH)
    ):
        raise AssertionError("Phase-B live semantic trusted context execution input blob drift")
    if not all(isinstance(data.get(k), str) and data.get(k) for k in required_scalars):
        raise AssertionError("Phase-B live semantic trusted context identity missing")
    if not provenance.HEX64.fullmatch(str(data.get("controller_source_sha256"))):
        raise AssertionError("Phase-B live semantic trusted controller source hash invalid")
    runtime = data.get("runtime")
    runners = data.get("judge_runners")
    if (
        not isinstance(runtime, dict)
        or set(runtime) != {"name", "version"}
        or not all(isinstance(runtime.get(k), str) and runtime.get(k) for k in ("name", "version"))
    ):
        raise AssertionError("Phase-B live semantic trusted runtime invalid")
    if not isinstance(runners, dict) or set(runners) != set(provenance.REQUIRED_JUDGE_IDS):
        raise AssertionError("Phase-B live semantic trusted runner set invalid")
    if not all(isinstance(runners.get(k), str) and runners.get(k) for k in provenance.REQUIRED_JUDGE_IDS):
        raise AssertionError("Phase-B live semantic trusted runner identity missing")
    cases = data.get("cases")
    expected_ids = {*SEMANTIC_CALIBRATION_CASE_IDS, "POS-GOLD-01"}
    if not isinstance(cases, dict) or set(cases) != expected_ids:
        raise AssertionError("Phase-B live semantic trusted context case set invalid")
    for case_id in sorted(expected_ids):
        item = cases.get(case_id)
        expected_case_keys = {"run_id", "nonce", "semantic_input_digest", "expected_outputs"}
        if not isinstance(item, dict) or set(item) != expected_case_keys or not all(
            isinstance(item.get(k), str) and item.get(k)
            for k in ("run_id", "nonce", "semantic_input_digest")
        ):
            raise AssertionError(f"Phase-B live semantic trusted challenge missing/invalid: {case_id}")
        if not provenance.HEX64.fullmatch(str(item.get("semantic_input_digest"))):
            raise AssertionError(f"Phase-B live semantic trusted input digest invalid: {case_id}")
        expected_outputs = item.get("expected_outputs")
        if not isinstance(expected_outputs, dict) or set(expected_outputs) != set(provenance.REQUIRED_JUDGE_IDS):
            raise AssertionError(f"Phase-B live semantic trusted expected output set invalid: {case_id}")
        for judge_id in provenance.REQUIRED_JUDGE_IDS:
            binding = expected_outputs.get(judge_id)
            expected_path = _live_output_relative_path(case_id, judge_id)
            if (
                not isinstance(binding, dict)
                or set(binding) != {"path", "sha256"}
                or binding.get("path") != expected_path
                or not provenance.HEX64.fullmatch(str(binding.get("sha256") or ""))
            ):
                raise AssertionError(f"Phase-B live semantic trusted expected output binding invalid: {case_id}:{judge_id}")
    return data


def _trusted_mac_key_from_env() -> bytes:
    raw = os.environ.get(TRUSTED_MAC_KEY_ENV)
    if not isinstance(raw, str) or len(raw) < 64 or len(raw) % 2 or any(ch not in "0123456789abcdefABCDEF" for ch in raw):
        raise AssertionError(f"Phase-B live semantic MAC key missing/invalid: env={TRUSTED_MAC_KEY_ENV}")
    key = bytes.fromhex(raw)
    if len(key) < 32:
        raise AssertionError("Phase-B live semantic MAC key must be at least 32 bytes")
    return key


def _live_output_relative_path(case_id: str, judge_id: str) -> str:
    return (
        "production/process/teaching-demo-content/validation/phase-b/"
        f"runtime-semantic/{case_id}/{judge_id}.yaml"
    )


def _require_nonempty_text(value: object, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise AssertionError(f"Phase-B live semantic {label} missing")
    return value


def _validate_live_judge_output(
    doc: object,
    *,
    case_id: str,
    judge_id: str,
    semantic_input_digest: str,
    expected_requirement_ids: set[str],
    negative_target_requirement: str | None,
) -> tuple[str, str]:
    if not isinstance(doc, dict):
        raise AssertionError(f"Phase-B live semantic judge output must be mapping: {case_id}:{judge_id}")
    expected_output_fields = {
        "schema_id", "case_id", "judge_id", "semantic_input_digest",
        "producer_id", "session_id", "decision", "reason", "confidence",
        "evidence_refs", "requirement_results",
    }
    if set(doc) != expected_output_fields:
        raise AssertionError(f"Phase-B live semantic judge output field set invalid: {case_id}:{judge_id}")
    if doc.get("schema_id") != LIVE_JUDGE_OUTPUT_SCHEMA_ID:
        raise AssertionError(f"Phase-B live semantic judge output schema drift: {case_id}:{judge_id}")
    if doc.get("case_id") != case_id or doc.get("judge_id") != judge_id:
        raise AssertionError(f"Phase-B live semantic judge identity drift: {case_id}:{judge_id}")
    if doc.get("semantic_input_digest") != semantic_input_digest:
        raise AssertionError(f"Phase-B live semantic judge input digest drift: {case_id}:{judge_id}")
    producer_id = _require_nonempty_text(doc.get("producer_id"), f"producer_id:{case_id}:{judge_id}")
    session_id = _require_nonempty_text(doc.get("session_id"), f"session_id:{case_id}:{judge_id}")
    decision = doc.get("decision")
    if decision not in {"PASS", "REJECT"}:
        raise AssertionError(f"Phase-B live semantic judge decision invalid: {case_id}:{judge_id}:{decision!r}")
    _require_nonempty_text(doc.get("reason"), f"reason:{case_id}:{judge_id}")
    confidence = doc.get("confidence")
    if not isinstance(confidence, (int, float)) or isinstance(confidence, bool) or not (0 <= float(confidence) <= 1):
        raise AssertionError(f"Phase-B live semantic judge confidence invalid: {case_id}:{judge_id}")
    evidence_refs = doc.get("evidence_refs")
    if not isinstance(evidence_refs, list) or not evidence_refs or not all(isinstance(x, str) and x for x in evidence_refs):
        raise AssertionError(f"Phase-B live semantic judge evidence refs invalid: {case_id}:{judge_id}")
    rows = doc.get("requirement_results")
    if not isinstance(rows, list):
        raise AssertionError(f"Phase-B live semantic requirement results invalid: {case_id}:{judge_id}")
    by_id: dict[str, dict] = {}
    for row in rows:
        if not isinstance(row, dict):
            raise AssertionError(f"Phase-B live semantic requirement result must be mapping: {case_id}:{judge_id}")
        expected_requirement_fields = {"requirement_id", "verdict", "reason", "confidence", "evidence_refs"}
        if set(row) != expected_requirement_fields:
            raise AssertionError(
                f"Phase-B live semantic requirement result field set invalid: {case_id}:{judge_id}"
            )
        rid = row.get("requirement_id")
        if not isinstance(rid, str) or not rid or rid in by_id:
            raise AssertionError(f"Phase-B live semantic requirement id invalid/duplicate: {case_id}:{judge_id}:{rid!r}")
        if row.get("verdict") not in {"PASS", "FAIL", "UNKNOWN"}:
            raise AssertionError(f"Phase-B live semantic verdict invalid: {case_id}:{judge_id}:{rid}")
        _require_nonempty_text(row.get("reason"), f"requirement reason:{case_id}:{judge_id}:{rid}")
        rc = row.get("confidence")
        if not isinstance(rc, (int, float)) or isinstance(rc, bool) or not (0 <= float(rc) <= 1):
            raise AssertionError(f"Phase-B live semantic requirement confidence invalid: {case_id}:{judge_id}:{rid}")
        refs = row.get("evidence_refs")
        if not isinstance(refs, list) or not refs or not all(isinstance(x, str) and x for x in refs):
            raise AssertionError(f"Phase-B live semantic requirement evidence refs invalid: {case_id}:{judge_id}:{rid}")
        by_id[rid] = row

    if negative_target_requirement is not None:
        target = by_id.get(negative_target_requirement)
        if not isinstance(target, dict) or target.get("verdict") != "FAIL" or decision != "REJECT":
            raise AssertionError(
                f"Phase-B live semantic target mutant not killed: {case_id}:{judge_id}:{negative_target_requirement}"
            )
    elif expected_requirement_ids:
        if set(by_id) != expected_requirement_ids:
            raise AssertionError(
                f"Phase-B live positive requirement coverage drift: {case_id}:{judge_id}:"
                f"expected={sorted(expected_requirement_ids)} actual={sorted(by_id)}"
            )
        if decision != "PASS" or any(row.get("verdict") != "PASS" for row in by_id.values()):
            raise AssertionError(f"Phase-B live positive Gold false reject: {case_id}:{judge_id}")
    return producer_id, session_id


def verify_live_semantic_execution_result(
    result_path: Path = TRUSTED_SEMANTIC_EXECUTION_RESULT_PATH,
    *,
    trusted_context: dict | None = None,
    mac_key: bytes | None = None,
) -> None:
    """Verify materialized external semantic outputs without importing trusted identity from repository data."""
    _corpus_selftest()
    _semantic_calibration_packet_selftest()
    _positive_semantic_gold_candidate_selftest()
    _positive_human_review_result_selftest()
    _trusted_semantic_execution_input_selftest()
    request = yaml.safe_load(TRUSTED_SEMANTIC_EXECUTION_INPUT_PATH.read_text(encoding="utf-8")) or {}
    context = trusted_context or _trusted_runtime_context_from_env()
    key = mac_key or _trusted_mac_key_from_env()
    if result_path.resolve() != TRUSTED_SEMANTIC_EXECUTION_RESULT_PATH.resolve():
        raise AssertionError("Phase-B live semantic result must use canonical result path")
    if not result_path.is_file():
        raise AssertionError("Phase-B live semantic canonical result missing")
    result = yaml.safe_load(result_path.read_text(encoding="utf-8")) or {}
    if not isinstance(result, dict) or result.get("schema_id") != LIVE_RESULT_SCHEMA_ID:
        raise AssertionError("Phase-B live semantic result schema invalid")
    expected_result_fields = {
        "schema_id", "authority", "gate_b_activation", "accepted_mode_unlock",
        "process_calibration_claimed", "execution_input_binding",
        "trusted_context", "trusted_context_sha256", "cases",
    }
    if set(result) != expected_result_fields:
        raise AssertionError(
            "Phase-B live semantic result field set invalid: "
            f"expected={sorted(expected_result_fields)} actual={sorted(result)}"
        )
    if result.get("authority") != "EXTERNAL_TRUSTED_SEMANTIC_EXECUTION_RESULT":
        raise AssertionError("Phase-B live semantic result authority invalid")
    if result.get("trusted_context") != context:
        raise AssertionError("Phase-B live semantic result trusted context differs from external invocation")
    if result.get("trusted_context_sha256") != _canonical_semantic_input_digest(context):
        raise AssertionError("Phase-B live semantic trusted context digest drift")
    for key_name in ("gate_b_activation", "accepted_mode_unlock", "process_calibration_claimed"):
        if result.get(key_name) is not False:
            raise AssertionError(f"Phase-B live semantic result attempted authority escalation: {key_name}")

    input_binding = result.get("execution_input_binding") or {}
    input_rel = TRUSTED_SEMANTIC_EXECUTION_INPUT_PATH.relative_to(ROOT).as_posix()
    if (
        not isinstance(input_binding, dict)
        or set(input_binding) != {"path", "git_blob_sha1"}
        or input_binding.get("path") != input_rel
        or input_binding.get("git_blob_sha1") != _git_blob_sha1(TRUSTED_SEMANTIC_EXECUTION_INPUT_PATH)
    ):
        raise AssertionError("Phase-B live semantic result execution-input binding drift")

    negative_rows = {
        str(x.get("case_id")): x
        for x in (request.get("negative_calibration") or {}).get("cases") or []
        if isinstance(x, dict) and x.get("case_id")
    }
    positive = request.get("positive_gold") or {}
    expected_case_ids = {*negative_rows, "POS-GOLD-01"}
    rows = result.get("cases")
    if not isinstance(rows, list):
        raise AssertionError("Phase-B live semantic result cases missing")
    by_case = {
        str(x.get("case_id")): x
        for x in rows
        if isinstance(x, dict) and x.get("case_id")
    }
    if len(by_case) != len(rows) or set(by_case) != expected_case_ids:
        raise AssertionError(
            "Phase-B live semantic result case set drift: "
            f"expected={sorted(expected_case_ids)} actual={sorted(by_case)}"
        )

    contract = yaml.safe_load(CONTRACT_PATH.read_text(encoding="utf-8")) or {}
    registry = {
        str(item.get("requirement_id")): item
        for item in contract.get("requirement_registry") or []
        if isinstance(item, dict) and item.get("requirement_id")
    }
    judge_enforcer = {
        provenance.SCIENCE_JUDGE_ID: "Science/Evidence Judge",
        provenance.ENACTMENT_JUDGE_ID: "Enactment/Student Judge",
    }
    candidate = yaml.safe_load(POSITIVE_SEMANTIC_GOLD_CANDIDATE_PATH.read_text(encoding="utf-8")) or {}
    candidate_case = candidate.get("candidate_case") or {}
    positive_requirements = set(str(x) for x in candidate_case.get("target_requirements") or [])
    positive_by_judge = {
        judge_id: {
            rid for rid in positive_requirements
            if isinstance(registry.get(rid), dict) and registry[rid].get("enforcer") == enforcer
        }
        for judge_id, enforcer in judge_enforcer.items()
    }

    owned_positive_requirements = set().union(*positive_by_judge.values())
    if owned_positive_requirements != positive_requirements or any(not ids for ids in positive_by_judge.values()):
        raise AssertionError(
            "Phase-B live semantic positive requirement ownership drift: "
            f"expected={sorted(positive_requirements)} owned={sorted(owned_positive_requirements)}"
        )

    expected_case_fields = {
        "case_id", "semantic_input_digest", "expected_outcome",
        "actual_outcome", "judge_outputs", "controller_execution_receipt",
    }
    for case_id in sorted(expected_case_ids):
        row = by_case[case_id]
        if set(row) != expected_case_fields:
            raise AssertionError(f"Phase-B live semantic case field set invalid: {case_id}")
        if case_id == "POS-GOLD-01":
            semantic_digest = str(positive.get("semantic_input_digest"))
            expected_outcome = "PASS"
            target_judge_id = None
            target_requirement = None
        else:
            source = negative_rows[case_id]
            semantic_digest = str(source.get("semantic_input_digest"))
            expected_outcome = "REJECT"
            packet = yaml.safe_load(SEMANTIC_CALIBRATION_PACKET_PATH.read_text(encoding="utf-8")) or {}
            packet_row = next(
                (x for x in packet.get("cases") or [] if isinstance(x, dict) and x.get("case_id") == case_id),
                None,
            )
            if not isinstance(packet_row, dict):
                raise AssertionError(f"Phase-B live semantic calibration case missing: {case_id}")
            target_requirement = str(packet_row.get("target_requirement_id"))
            target_enforcer = str(packet_row.get("target_judge"))
            target_judge_id = next(
                (jid for jid, enforcer in judge_enforcer.items() if enforcer == target_enforcer),
                None,
            )
            if target_judge_id is None:
                raise AssertionError(f"Phase-B live semantic target judge unresolved: {case_id}")

        if row.get("semantic_input_digest") != semantic_digest or row.get("expected_outcome") != expected_outcome:
            raise AssertionError(f"Phase-B live semantic case binding drift: {case_id}")
        if row.get("actual_outcome") != expected_outcome:
            raise AssertionError(f"Phase-B live semantic expected outcome not achieved: {case_id}")

        challenge = (context.get("cases") or {}).get(case_id) or {}
        if challenge.get("semantic_input_digest") != semantic_digest:
            raise AssertionError(f"Phase-B live semantic trusted input differs from repository handoff: {case_id}")
        trusted_outputs = challenge.get("expected_outputs")
        if not isinstance(trusted_outputs, dict) or set(trusted_outputs) != set(provenance.REQUIRED_JUDGE_IDS):
            raise AssertionError(f"Phase-B live semantic trusted expected output set missing: {case_id}")

        output_bindings = row.get("judge_outputs")
        if not isinstance(output_bindings, dict) or set(output_bindings) != set(provenance.REQUIRED_JUDGE_IDS):
            raise AssertionError(f"Phase-B live semantic judge output set invalid: {case_id}")
        expected_outputs: dict[str, dict[str, str]] = {}
        output_identity: dict[str, tuple[str, str]] = {}
        for judge_id in provenance.REQUIRED_JUDGE_IDS:
            binding = output_bindings.get(judge_id)
            trusted_binding = trusted_outputs.get(judge_id)
            expected_rel = _live_output_relative_path(case_id, judge_id)
            if (
                not isinstance(trusted_binding, dict)
                or set(trusted_binding) != {"path", "sha256"}
                or trusted_binding.get("path") != expected_rel
                or not provenance.HEX64.fullmatch(str(trusted_binding.get("sha256") or ""))
            ):
                raise AssertionError(f"Phase-B live semantic trusted expected output binding invalid: {case_id}:{judge_id}")
            if binding != trusted_binding:
                raise AssertionError(f"Phase-B live semantic result output differs from trusted invocation: {case_id}:{judge_id}")
            output_path = _repo_path(expected_rel)
            actual_sha = _sha256_file(output_path)
            if trusted_binding.get("sha256") != actual_sha:
                raise AssertionError(f"Phase-B live semantic judge output hash drift: {case_id}:{judge_id}")
            output_doc = yaml.safe_load(output_path.read_text(encoding="utf-8")) or {}
            expected_req_ids = positive_by_judge[judge_id] if case_id == "POS-GOLD-01" else set()
            negative_target = target_requirement if judge_id == target_judge_id else None
            output_identity[judge_id] = _validate_live_judge_output(
                output_doc,
                case_id=case_id,
                judge_id=judge_id,
                semantic_input_digest=semantic_digest,
                expected_requirement_ids=expected_req_ids,
                negative_target_requirement=negative_target,
            )
            expected_outputs[judge_id] = dict(trusted_binding)

        receipt = row.get("controller_execution_receipt")
        if not isinstance(receipt, dict):
            raise AssertionError(f"Phase-B live semantic controller receipt missing: {case_id}")
        errors = provenance.verify_controller_receipt(
            receipt,
            mac_key=key,
            expected_key_id=str(context.get("key_id")),
            expected_run_id=str(challenge.get("run_id")),
            expected_nonce=str(challenge.get("nonce")),
            expected_case_id=case_id,
            expected_semantic_input_digest=str(challenge.get("semantic_input_digest")),
            expected_controller_id=str(context.get("controller_id")),
            expected_controller_source_sha256=str(context.get("controller_source_sha256")),
            expected_runtime=dict(context.get("runtime") or {}),
            expected_judge_runners=dict(context.get("judge_runners") or {}),
            expected_outputs=expected_outputs,
            now=str(context.get("trusted_now")),
        )
        if errors:
            raise AssertionError(f"Phase-B live semantic provenance verification failed: {case_id}:{errors}")

        receipt_runs = {
            str(x.get("judge_id")): x
            for x in receipt.get("judge_runs") or []
            if isinstance(x, dict) and x.get("judge_id")
        }
        for judge_id, (producer_id, session_id) in output_identity.items():
            run = receipt_runs.get(judge_id) or {}
            if run.get("producer_id") != producer_id or run.get("session_id") != session_id:
                raise AssertionError(f"Phase-B live semantic producer/session binding drift: {case_id}:{judge_id}")


def _yaml_write(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(value, allow_unicode=True, sort_keys=False), encoding="utf-8")


def _core_mutant_errors(
    *,
    events: list[dict],
    trial_text: str,
    resource_ids: set[str] | None = None,
    resource_by_id: dict[str, dict] | None = None,
    expected_board_events: list[tuple[str, str, set[str]]] | None = None,
    board_plan: dict | None = None,
    practice_ids: set[str] | None = None,
) -> list[str]:
    """Run selected mutants through the real deterministic architecture-case primitive."""
    with tempfile.TemporaryDirectory(prefix="qz-phase-b-core-mutant-") as tmp:
        workspace = Path(tmp)
        role_texts = {role: "" for role in content_gate.core.USER_ROLES}
        role_texts["trial"] = trial_text
        sources: dict[str, str] = {}
        for role, text in role_texts.items():
            filename = f"{role}.md"
            (workspace / filename).write_text(text, encoding="utf-8")
            sources[role] = filename
        source_fixture = CONTRACT_PATH
        source_rel = source_fixture.relative_to(ROOT).as_posix()
        source_blob = _git_blob_sha1(source_fixture)
        manifest = {
            "case_id": "phase-b-machine-fixture",
            "source": sources,
            "input": {
                "printed_pages": [1],
                "source_pages": {
                    "mode": "repository-pdf",
                    "pages": [1],
                    "file": source_rel,
                    "blob_sha": source_blob,
                    "size_bytes": source_fixture.stat().st_size,
                    "sha256": _sha256_file(source_fixture),
                    "audit_locator": {
                        "repo": "phase-b-selftest",
                        "ref": "selftest-source-lock",
                        "path": source_rel,
                        "blob_sha": source_blob,
                    },
                },
            },
        }
        manifest_path = workspace / "manifest.yaml"
        _yaml_write(manifest_path, manifest)

        for filename in content_gate.core.LEGACY_SEMANTIC_FILES.values():
            _yaml_write(workspace / filename, {})
        board_plan_doc = board_plan or {"final_board": []}
        _yaml_write(workspace / content_gate.core.BOARD_PLAN, board_plan_doc)

        events_doc = {"schema_id": "teaching-demo-script-event-stream-v1", "events": events}
        facts = content_gate.arch.derive_script_facts(events)
        arch_docs = {
            "lesson_evidence_ir": {
                "schema_id": "teaching-demo-lesson-evidence-ir-v1",
                "knowledge_units": [],
                "required_formula_ids": [],
            },
            "script_events": events_doc,
            "script_facts": facts,
            "work_packet": {},
            "machine_gate": {},
            "science_evidence_judge": {},
            "enactment_student_judge": {},
            "source_review": {},
        }
        for key, filename in content_gate.core.ARCH_FILES.items():
            _yaml_write(workspace / filename, arch_docs[key])

        contract = yaml.safe_load(CONTRACT_PATH.read_text(encoding="utf-8")) or {}
        legacy = {"student_state": {"cycles": []}}
        legacy_context = {
            "evidence_ids": set(),
            "resource_ids": resource_ids or set(),
            "resource_by_id": resource_by_id or {},
            "expected_board_events": expected_board_events or [],
            "practice_ids": practice_ids or set(),
        }
        return content_gate.core.validate_architecture_case(
            ROOT,
            contract,
            manifest_path,
            manifest,
            workspace,
            legacy,
            arch_docs,
            board_plan_doc,
            role_texts,
            legacy_context,
        )


def _machine_mutants() -> None:
    """Execute M05-M15 through current deterministic production primitives."""
    # M05: declared classroom resource never appears in the actual event stream.
    m05 = _core_mutant_errors(
        events=[{"event_id": "M05-E1", "type": "SPEAK", "cycle_id": "C1", "text": "先观察。", "releases": [], "timing": {"speech_seconds": 1}}],
        trial_text="先观察。",
        resource_ids={"R1"},
    )
    m05_repaired = _core_mutant_errors(
        events=[
            {"event_id": "M05-E1", "type": "SPEAK", "cycle_id": "C1", "text": "先观察。", "releases": [], "timing": {"speech_seconds": 1}},
            {"event_id": "M05-SHOW", "type": "RESOURCE_SHOW", "cycle_id": "C1", "resource_id": "R1", "releases": [], "timing": {"action_seconds": 1}},
        ],
        trial_text="先观察。",
        resource_ids={"R1"},
    )
    _assert_differential_kill(
        "M05",
        m05,
        m05_repaired,
        "CONTENT_ACTUAL_RESOURCE_NOT_SHOWN",
    )

    # M06: answer-bearing resource is fully visible before the student's response.
    with tempfile.TemporaryDirectory(prefix="qz-phase-b-m06-") as tmp:
        workspace = Path(tmp)
        events = [
            {"event_id": "M06-SHOW", "type": "RESOURCE_SHOW", "cycle_id": "C1", "resource_id": "R1", "visibility": "FULL", "releases": [], "timing": {"action_seconds": 1}},
            {"event_id": "M06-R", "type": "STUDENT_RESPONSE", "cycle_id": "C1", "text": "我来回答。", "releases": [], "timing": {"speech_seconds": 1}},
            {"event_id": "M06-V", "type": "RESOURCE_REVEAL", "cycle_id": "C1", "resource_id": "R1", "releases": [], "timing": {"action_seconds": 1}},
        ]
        _yaml_write(workspace / "SCRIPT_EVENTS.yaml", {"events": events})
        _yaml_write(workspace / "SCRIPT_FACTS.yaml", content_gate.arch.derive_script_facts(events))
        _yaml_write(workspace / "RESOURCE_ACTION_MAP.yaml", {"resources": [{
            "resource_id": "R1", "use_mode": "discovery", "answer_bearing_information_ids": ["K1"], "reveal_before_cycle": "C1",
        }]})
        _yaml_write(workspace / "STUDENT_STATE_LEDGER.yaml", {"cycles": [{"cycle_id": "C1", "resource_ids": ["R1"]}]})
        m06 = enforcement.validate_resource_visibility(workspace)
        _assert_killed("M06", m06, "FULL_RESOURCE_SHOW_FORBIDDEN")

    # M07: board plan/delta exists but no BOARD_ADD reaches the actual stream.
    m07 = _core_mutant_errors(
        events=[{"event_id": "M07-E1", "type": "SPEAK", "cycle_id": "C1", "text": "形成结论。", "releases": [], "timing": {"speech_seconds": 1}}],
        trial_text="形成结论。",
        expected_board_events=[("B1", "K1 板书", set())],
        board_plan={"final_board": ["K1 板书"]},
    )
    m07_repaired = _core_mutant_errors(
        events=[
            {"event_id": "M07-E1", "type": "SPEAK", "cycle_id": "C1", "text": "形成结论。", "releases": [], "timing": {"speech_seconds": 1}},
            {"event_id": "M07-B1", "type": "BOARD_ADD", "cycle_id": "C1", "board_delta_id": "B1", "text": "K1 板书", "releases": [], "timing": {"action_seconds": 1}},
        ],
        trial_text="形成结论。",
        expected_board_events=[("B1", "K1 板书", set())],
        board_plan={"final_board": ["K1 板书"]},
    )
    _assert_differential_kill(
        "M07",
        m07,
        m07_repaired,
        "CONTENT_ACTUAL_FINAL_BOARD_NOT_EVENT_ACCUMULATION",
    )

    # M08: a short event summary is substituted for the full final spoken product.
    m08 = _core_mutant_errors(
        events=[{"event_id": "M08-E1", "type": "SPEAK", "cycle_id": "C1", "text": "这里只保留摘要。", "releases": [], "timing": {"speech_seconds": 1}}],
        trial_text="这是完整逐字稿第一句。\n这是完整逐字稿第二句。",
    )
    m08_repaired = _core_mutant_errors(
        events=[{"event_id": "M08-E1", "type": "SPEAK", "cycle_id": "C1", "text": "这是完整逐字稿第一句。\n这是完整逐字稿第二句。", "releases": [], "timing": {"speech_seconds": 1}}],
        trial_text="这是完整逐字稿第一句。\n这是完整逐字稿第二句。",
    )
    _assert_differential_kill(
        "M08",
        m08,
        m08_repaired,
        "CONTENT_ACTUAL_SPOKEN_COVERAGE_NOT_COMPLETE",
    )

    # M09: actual event timing cannot be recomputed because the spoken event has no duration.
    m09 = _core_mutant_errors(
        events=[{"event_id": "M09-E1", "type": "SPEAK", "cycle_id": "C1", "text": "没有口说时长。", "releases": []}],
        trial_text="没有口说时长。",
    )
    m09_repaired = _core_mutant_errors(
        events=[{"event_id": "M09-E1", "type": "SPEAK", "cycle_id": "C1", "text": "没有口说时长。", "releases": [], "timing": {"speech_seconds": 1}}],
        trial_text="没有口说时长。",
    )
    _assert_differential_kill(
        "M09",
        m09,
        m09_repaired,
        "CONTENT_ACTUAL_EVENT_TIMING_MISSING",
    )

    # M10: formula-like final text is not typed as FORMULA_ORALIZE.
    with tempfile.TemporaryDirectory(prefix="qz-phase-b-m10-") as tmp:
        workspace = Path(tmp)
        events = [{"event_id": "M10-E1", "type": "SPEAK", "cycle_id": "C1", "text": "所以 p=mv。", "releases": [], "timing": {"speech_seconds": 1}}]
        _yaml_write(workspace / "SCRIPT_EVENTS.yaml", {"events": events})
        _yaml_write(workspace / "SCRIPT_FACTS.yaml", content_gate.arch.derive_script_facts(events))
        m10 = enforcement.validate_formula_typing(workspace)
        _assert_killed("M10", m10, "CONTENT_ACTUAL_FORMULA_ORALIZATION_MISSING")

    # M11: final trial contains a PRACTICE event that the declared inventory omits.
    with tempfile.TemporaryDirectory(prefix="qz-phase-b-m11-") as tmp:
        workspace = Path(tmp)
        events = [{"event_id": "M11-P1", "type": "PRACTICE", "cycle_id": "C1", "practice_id": "P1", "text": "完成练习一。", "releases": [], "timing": {"speech_seconds": 1}}]
        _yaml_write(workspace / "SCRIPT_EVENTS.yaml", {"events": events})
        _yaml_write(workspace / "SCRIPT_FACTS.yaml", content_gate.arch.derive_script_facts(events))
        _yaml_write(workspace / "semantic-preflight-review.yaml", {"practice_inventory": []})
        m11 = enforcement.validate_practice_occurrences(workspace)
        _assert_killed("M11", m11, "CONTENT_ACTUAL_PRACTICE_INVENTORY_DRIFT")

    # M12: inventory claims completion but a second hidden practice is appended afterwards.
    with tempfile.TemporaryDirectory(prefix="qz-phase-b-m12-") as tmp:
        workspace = Path(tmp)
        events = [
            {"event_id": "M12-P1", "type": "PRACTICE", "cycle_id": "C1", "practice_id": "P1", "text": "练习一：完成。", "releases": [], "timing": {"speech_seconds": 1}},
            {"event_id": "M12-P2", "type": "PRACTICE", "cycle_id": "C1", "practice_id": "P2", "text": "隐藏练习二。", "releases": [], "timing": {"speech_seconds": 1}},
        ]
        _yaml_write(workspace / "SCRIPT_EVENTS.yaml", {"events": events})
        _yaml_write(workspace / "SCRIPT_FACTS.yaml", content_gate.arch.derive_script_facts(events))
        _yaml_write(workspace / "semantic-preflight-review.yaml", {"practice_inventory": [{
            "item_id": "P1", "execution_scope": "trial_event", "prompt_role": "trial", "prompt_anchor": "练习一",
        }]})
        m12 = enforcement.validate_practice_occurrences(workspace)
        _assert_killed("M12", m12, "CONTENT_ACTUAL_PRACTICE_INVENTORY_DRIFT")

    # M13: blocking semantic UNKNOWN is a machine-controlled fail-closed state.
    m13 = content_gate.arch.validate_judge_verdict({
        "requirement_id": "REQ-SCI-001",
        "verdict": "UNKNOWN",
        "claim": "证据不足，不能判定。",
        "evidence_refs": ["event:M13-E1"],
        "reason": "insufficient evidence",
        "confidence": 0.5,
    }, blocking=True, judge_name="M13")
    _assert_killed("M13", m13, "BLOCKING_UNKNOWN")

    # M14: a frozen exact-byte binding becomes stale after a bound trial byte changes.
    with tempfile.TemporaryDirectory(prefix="qz-phase-b-m14-") as tmp:
        root = Path(tmp)
        workspace = root / "case"
        workspace.mkdir(parents=True)
        (root / content_gate.core.CONTRACT_PATH).parent.mkdir(parents=True, exist_ok=True)
        _yaml_write(root / content_gate.core.CONTRACT_PATH, {
            "repository_reference_benchmark": {"usage_contract": "reference-usage.yaml"},
        })
        for path in (content_gate.core.PROCESS_PATH, content_gate.core.CHECKER_PATH, content_gate.core.HELPER_PATH):
            target = root / path
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text("fixture\n", encoding="utf-8")
        (root / "reference-usage.yaml").write_text("fixture\n", encoding="utf-8")
        sources: dict[str, str] = {}
        for role in content_gate.core.USER_ROLES:
            filename = f"{role}.md"
            (workspace / filename).write_text(f"{role} fixture\n", encoding="utf-8")
            sources[role] = filename
        manifest = {"case_id": "m14", "source": sources}
        manifest_path = workspace / "manifest.yaml"
        _yaml_write(manifest_path, manifest)
        for filename in content_gate.core.LEGACY_SEMANTIC_FILES.values():
            _yaml_write(workspace / filename, {})
        for filename in content_gate.core.ARCH_FILES.values():
            _yaml_write(workspace / filename, {})
        _yaml_write(workspace / content_gate.core.BOARD_PLAN, {})
        expected = content_gate.core.expected_submission_bindings(root, manifest_path, manifest, workspace, [])
        source_commit = "0" * 40
        _yaml_write(workspace / content_gate.core.FREEZE_FILENAME, {
            "schema_id": content_gate.core.FREEZE_SCHEMA,
            "case_id": "m14",
            "source_commit": source_commit,
            "bindings": expected,
        })
        (workspace / sources["trial"]).write_text("trial fixture changed after freeze\n", encoding="utf-8")
        m14 = content_gate.core.validate_submission_freeze(
            root, manifest_path, manifest, workspace, [], expected_source_commit=source_commit,
        )
        _assert_killed("M14", m14, "CONTENT_SUBMISSION_FREEZE_STALE:trial")

    # M15: fewer than two structural reference candidates cannot establish comparison.
    with tempfile.TemporaryDirectory(prefix="qz-phase-b-m15-") as tmp:
        workspace = Path(tmp)
        _yaml_write(workspace / "evidence.yaml", {"reference_learning": {
            "selected_case_receipts": ["missing/CASE.yaml"],
            "structural_candidate_comparison": {
                "candidates": [{"case_receipt": "missing/CASE.yaml", "case_receipt_sha256": "0" * 64}],
                "selected_case_receipt": "missing/CASE.yaml",
            },
        }})
        m15 = enforcement.validate_reference_candidates(workspace)
        _assert_killed("M15", m15, "CONTENT_REFERENCE_CANDIDATE_COMPARISON_INCOMPLETE")


def _sign_test_receipt(receipt: dict) -> dict:
    """Attach a test-only MAC; never usable as production signing authority."""
    out = deepcopy(receipt)
    out.pop("authenticator", None)
    mac = hmac.new(TEST_KEY, provenance.canonical_receipt_bytes(out), hashlib.sha256).hexdigest()
    out["authenticator"] = {
        "algorithm": provenance.AUTH_ALGORITHM,
        "key_id": KEY_ID,
        "mac_hex": mac,
    }
    return out


def _base_receipt() -> dict:
    receipt = {
        "schema_id": provenance.SCHEMA_ID,
        "controller": {
            "controller_id": CONTROLLER_ID,
            "controller_source_sha256": CONTROLLER_SOURCE,
            "runtime": dict(RUNTIME),
        },
        "run": {
            "run_id": RUN_ID,
            "nonce": NONCE,
            "issued_at": "2026-09-10T11:59:00Z",
            "expires_at": "2026-09-10T12:05:00Z",
            "case_id": CASE_ID,
            "semantic_input_digest": INPUT_DIGEST,
        },
        "judge_runs": [
            {
                "judge_id": provenance.SCIENCE_JUDGE_ID,
                "runner_id": RUNNERS[provenance.SCIENCE_JUDGE_ID],
                "producer_id": "semantic-producer-science",
                "session_id": "science-session-001",
                "semantic_input_digest": INPUT_DIGEST,
                "output": dict(OUTPUTS[provenance.SCIENCE_JUDGE_ID]),
            },
            {
                "judge_id": provenance.ENACTMENT_JUDGE_ID,
                "runner_id": RUNNERS[provenance.ENACTMENT_JUDGE_ID],
                "producer_id": "semantic-producer-enactment",
                "session_id": "enactment-session-001",
                "semantic_input_digest": INPUT_DIGEST,
                "output": dict(OUTPUTS[provenance.ENACTMENT_JUDGE_ID]),
            },
        ],
    }
    return _sign_test_receipt(receipt)


def _verify(receipt: dict, *, key: bytes = TEST_KEY) -> list[str]:
    return provenance.verify_controller_receipt(
        receipt,
        mac_key=key,
        expected_key_id=KEY_ID,
        expected_run_id=RUN_ID,
        expected_nonce=NONCE,
        expected_case_id=CASE_ID,
        expected_semantic_input_digest=INPUT_DIGEST,
        expected_controller_id=CONTROLLER_ID,
        expected_controller_source_sha256=CONTROLLER_SOURCE,
        expected_runtime=RUNTIME,
        expected_judge_runners=RUNNERS,
        expected_outputs=OUTPUTS,
        now=TRUSTED_NOW,
    )


def _resign(mutant: dict) -> dict:
    return _sign_test_receipt(mutant)


def _assert_killed(label: str, errors: list[str], token: str) -> None:
    if not any(token in error for error in errors):
        raise AssertionError(f"{label} escaped or failed for wrong reason: {errors}")


def _assert_differential_kill(
    label: str,
    mutant_errors: list[str],
    repaired_errors: list[str],
    token: str,
) -> None:
    """Require the named failure to disappear after only the target defect is repaired.

    Some full-core fixtures intentionally omit unrelated accepted-package receipts.
    A target token in the mutant alone therefore proves less than a differential
    oracle. The paired repair must remove the exact target failure without claiming
    that the synthetic fixture is a legal accepted package.
    """
    _assert_killed(label, mutant_errors, token)
    if any(token in error for error in repaired_errors):
        raise AssertionError(
            f"{label} target failure survives its focused repair: "
            f"mutant={mutant_errors} repaired={repaired_errors}"
        )


def _phase_a_permanent_mutants() -> None:
    """Execute the permanent Gate-A-derived mutants named by PROCESS §20."""
    content_gate._capability_removal_selftest()
    content_gate._phase_b_activation_selftest()

    m20_events = [{
        "event_id": "M20-E0",
        "type": "SPEAK",
        "cycle_id": "C1",
        "text": "同学们先观察一下。",
        "releases": ["K1"],
        "timing": {"speech_seconds": 1},
    }]
    m20 = enforcement._validate_release_claims(m20_events, ["K1"])
    _assert_killed("M20", m20, "BARE_METADATA_FORBIDDEN")

    m21_events = [{
        "event_id": "M21-E1",
        "type": "PARAPHRASE",
        "cycle_id": "C1",
        "text": "所以这个量可能有某种规律。",
        "releases": [],
        "release_claims": [{
            "knowledge_id": "K1",
            "visible_span": "这个量可能有某种规律",
        }],
        "timing": {"speech_seconds": 1},
    }]
    claims = enforcement._release_claims_from_events(m21_events)
    m21_judge = {
        "release_verifications": [{
            "knowledge_id": "K1",
            "event_id": "M21-E1",
            "visible_span": "这个量可能有某种规律",
            "verdict": "UNKNOWN",
            "reason": "visible span does not establish the target relation",
            "confidence": 0.4,
            "evidence_refs": ["event:M21-E1", "exact-text:这个量可能有某种规律"],
        }],
        "verdicts": [{
            "requirement_id": enforcement.RELEASE_SEMANTIC_REQUIREMENT_ID,
            "verdict": "UNKNOWN",
            "evidence_refs": ["event:M21-E1", "exact-text:这个量可能有某种规律"],
        }],
    }
    m21 = enforcement._release_verification_errors(claims, m21_judge)
    _assert_killed("M21", m21, "NOT_ESTABLISHED")

    with tempfile.TemporaryDirectory(prefix="qz-phase-b-p1-rra4-e-") as tmp:
        workspace = Path(tmp)
        enforcement._write_resource_mutant_fixture(workspace)
        visibility = enforcement.validate_resource_visibility(workspace)
        causality = enforcement.validate_resource_reveal_after_verified_formation(workspace)
        _assert_killed("P1-RRA4-E visibility", visibility, "FULL_RESOURCE_SHOW_FORBIDDEN")
        _assert_killed("P1-RRA4-E causality", causality, "FIRST_FULL_EXPOSURE_NOT_RESOURCE_REVEAL")


def _provenance_mutants() -> None:
    """P1-PROV + positive Gold: prove verifier discriminates, not always-fails."""
    gold = _base_receipt()
    gold_errors = _verify(gold)
    if gold_errors:
        raise AssertionError(f"POSITIVE_GOLD_FALSE_REJECT:{gold_errors}")

    forged_strings = {
        "reviewer_role": "SEMANTIC_JUDGE",
        "implementation_and_judge_separate": True,
        "science_evidence_judge_runner": RUNNERS[provenance.SCIENCE_JUDGE_ID],
        "enactment_student_judge_runner": RUNNERS[provenance.ENACTMENT_JUDGE_ID],
        "decision": "PASS",
    }
    _assert_killed("P1-PROV repository strings", _verify(forged_strings), "AUTHENTICATOR_MISSING")
    _assert_killed("P1-PROV wrong trusted key", _verify(gold, key=b"wrong-controller-key"), "MAC_MISMATCH")

    replay_run = deepcopy(gold)
    replay_run["run"]["run_id"] = "old-run-000"
    replay_run = _resign(replay_run)
    _assert_killed("P1-PROV wrong/replayed run", _verify(replay_run), "RUN_ID_MISMATCH")

    replay_nonce = deepcopy(gold)
    replay_nonce["run"]["nonce"] = "old-challenge-nonce"
    replay_nonce = _resign(replay_nonce)
    _assert_killed("P1-PROV wrong/replayed challenge", _verify(replay_nonce), "NONCE_MISMATCH")

    wrong_case = deepcopy(gold)
    wrong_case["run"]["case_id"] = "other-case"
    wrong_case = _resign(wrong_case)
    _assert_killed("P1-PROV wrong case", _verify(wrong_case), "CASE_ID_MISMATCH")

    wrong_input_digest = hashlib.sha256(b"other-input-set").hexdigest()
    wrong_input = deepcopy(gold)
    wrong_input["run"]["semantic_input_digest"] = wrong_input_digest
    for item in wrong_input["judge_runs"]:
        item["semantic_input_digest"] = wrong_input_digest
    wrong_input = _resign(wrong_input)
    _assert_killed("P1-PROV wrong input", _verify(wrong_input), "INPUT_DIGEST_MISMATCH")

    wrong_controller = deepcopy(gold)
    wrong_controller["controller"]["controller_source_sha256"] = hashlib.sha256(b"other-controller").hexdigest()
    wrong_controller = _resign(wrong_controller)
    _assert_killed("P1-PROV wrong controller", _verify(wrong_controller), "CONTROLLER_SOURCE_MISMATCH")

    wrong_runtime = deepcopy(gold)
    wrong_runtime["controller"]["runtime"]["version"] = "0.9"
    wrong_runtime = _resign(wrong_runtime)
    _assert_killed("P1-PROV wrong runtime", _verify(wrong_runtime), "RUNTIME_VERSION_MISMATCH")

    wrong_runner = deepcopy(gold)
    wrong_runner["judge_runs"][0]["runner_id"] = "author-forged-runner"
    wrong_runner = _resign(wrong_runner)
    _assert_killed("P1-PROV wrong runner", _verify(wrong_runner), "JUDGE_RUNNER_MISMATCH")

    split_input = deepcopy(gold)
    split_input["judge_runs"][1]["semantic_input_digest"] = hashlib.sha256(b"split-input").hexdigest()
    split_input = _resign(split_input)
    _assert_killed("P1-PROV split judge inputs", _verify(split_input), "JUDGE_INPUT_DIGEST_MISMATCH")

    output_drift = deepcopy(gold)
    output_drift["judge_runs"][0]["output"]["sha256"] = hashlib.sha256(b"changed-output").hexdigest()
    output_drift = _resign(output_drift)
    _assert_killed("P1-PROV output drift", _verify(output_drift), "JUDGE_OUTPUT_BINDING_MISMATCH")

    expired = deepcopy(gold)
    expired["run"]["issued_at"] = "2026-09-10T11:00:00Z"
    expired["run"]["expires_at"] = "2026-09-10T11:05:00Z"
    expired = _resign(expired)
    _assert_killed("P1-PROV stale receipt", _verify(expired), "EXPIRED")

    overlong = deepcopy(gold)
    overlong["run"]["issued_at"] = "2026-09-10T11:50:00Z"
    overlong["run"]["expires_at"] = "2026-09-10T12:10:01Z"
    overlong = _resign(overlong)
    _assert_killed("P1-PROV overlong authority window", _verify(overlong), "LIFETIME_INVALID")

    missing_producer = deepcopy(gold)
    missing_producer["judge_runs"][0]["producer_id"] = ""
    missing_producer = _resign(missing_producer)
    _assert_killed("P1-PROV missing producer", _verify(missing_producer), "JUDGE_PRODUCER_MISSING")


def selftest() -> None:
    _corpus_selftest()
    _semantic_mutant_materialization_selftest()
    _semantic_calibration_packet_selftest()
    _positive_semantic_gold_candidate_selftest()
    _positive_human_review_packet_selftest()
    _positive_human_review_result_selftest()
    _trusted_semantic_execution_input_selftest()
    _machine_mutants()
    _phase_a_permanent_mutants()
    _provenance_mutants()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--selftest", action="store_true")
    parser.add_argument("--verify-live-result", action="store_true")
    args = parser.parse_args()
    if args.selftest == args.verify_live_result:
        parser.error("choose exactly one of --selftest or --verify-live-result")
    if args.selftest:
        selftest()
        print("PASS: Teaching Demo Phase B source harness (M05-M15 machine mutants wired; permanent P0/P1/provenance mutants killed; controller Gold survives)")
        print("M01_M04_MATERIALIZED_REQUIRES_LIVE_TRUSTED_SEMANTIC_JUDGE")
        print("TRUSTED_SEMANTIC_EXECUTION_INPUT_SOURCE_BOUND_AWAITING_EXTERNAL_RUNTIME")
        print("GATE_B_NOT_AUTHORIZED_BY_SELFTEST")
        print("ACCEPTED_MODE_REMAINS_FAIL_CLOSED")
        return 0
    verify_live_semantic_execution_result()
    print("PASS: trusted semantic execution result verified against external invocation context")
    print("LIVE_SEMANTIC_RESULT_VERIFIED_GATE_B_STILL_NOT_AUTHORIZED")
    print("ACCEPTED_MODE_REMAINS_FAIL_CLOSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
