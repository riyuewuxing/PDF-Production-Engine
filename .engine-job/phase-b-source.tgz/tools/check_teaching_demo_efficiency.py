#!/usr/bin/env python3
"""Fail-closed, topic-agnostic checker for the finite teaching-demo efficiency experiment."""
from __future__ import annotations
import argparse
import hashlib
from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parents[1]
REQUIRED_TIMING = (
    "started_at", "finished_at", "wall_elapsed_seconds",
    "active_process_seconds", "external_wait_seconds",
    "human_review_orchestration_seconds", "measurement_method",
    "command_or_call_counts",
)
COUNT_LIMITS = {"correction_count": 1, "composition_build_count": 2, "final_full_render_count": 2}

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()

def _nonnegative_number(value) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and value >= 0

def derive_efficiency(data: dict, root: Path = ROOT) -> tuple[bool, list[str]]:
    reasons: list[str] = []
    rounds = data.get("rounds")
    if not isinstance(rounds, list) or not rounds:
        reasons.append("rounds must be a non-empty list")
        rounds = []
    cycles = data.get("global_generation_review_cycles")
    if not isinstance(cycles, int) or isinstance(cycles, bool) or cycles < 0 or cycles > 3:
        reasons.append("global generation/review cycles must be an integer in [0,3]")
    if isinstance(cycles, int) and cycles == 3 and data.get("status") not in {"STOP_AWAITING_USER", "STOP_LIMIT", "STOPPED_AWAITING_USER_REVIEW"}:
        reasons.append("third cycle requires a terminal status")
    topics: set[object] = set()
    warm_count = 0
    for index, round_data in enumerate(rounds, 1):
        if not isinstance(round_data, dict):
            reasons.append(f"round {index} must be a mapping"); continue
        topic = round_data.get("topic_id"); topics.add(topic)
        if not isinstance(topic, str) or not topic.strip(): reasons.append(f"round {index}: topic_id is required")
        path_class = round_data.get("path_class")
        if path_class not in {"cold_path", "warm_path"}: reasons.append(f"{topic}: path_class must be cold_path or warm_path")
        if path_class == "warm_path":
            warm_count += 1
            if round_data.get("generic_code_change_count") != 0: reasons.append(f"{topic}: warm generic code change count must be zero")
        for field, limit in COUNT_LIMITS.items():
            value = round_data.get(field)
            if not _nonnegative_number(value) or value > limit: reasons.append(f"{topic}: {field} must be non-negative and <= {limit}")
        for field in ("generic_code_change_count", "late_or_open_p0_count"):
            if not _nonnegative_number(round_data.get(field)): reasons.append(f"{topic}: {field} must be a non-negative number")
        if round_data.get("canonical_generic_publisher_used") is not True: reasons.append(f"{topic}: canonical generic publisher not proven")
        if round_data.get("manual_executable_source_reconstruction") is not False: reasons.append(f"{topic}: manual executable reconstruction is forbidden")
        if round_data.get("cache_reuse_evidence") is not True: reasons.append(f"{topic}: cache/reuse evidence missing")
        if round_data.get("late_or_open_p0_count") != 0: reasons.append(f"{topic}: late/open P0 exists")
        if round_data.get("all_final_pages_human_reviewed") is not True: reasons.append(f"{topic}: final pages were not all human reviewed")
        missing = [key for key in REQUIRED_TIMING if round_data.get(key) in (None, "", {})]
        if missing: reasons.append(f"{topic}: instrumentation incomplete: {','.join(missing)}")
        values = [round_data.get(key) for key in ("wall_elapsed_seconds", "active_process_seconds", "external_wait_seconds", "human_review_orchestration_seconds")]
        if any(value is not None and not _nonnegative_number(value) for value in values): reasons.append(f"{topic}: timing values must be null/UNKNOWN or non-negative")
        wall, active, external = values[:3]
        if all(_nonnegative_number(value) for value in (wall, active, external)) and active + external > wall: reasons.append(f"{topic}: active+external exceeds wall elapsed")
        counts = round_data.get("command_or_call_counts")
        if not isinstance(counts, dict) or not counts: reasons.append(f"{topic}: command_or_call_counts is required")
        for item in round_data.get("bound_files") or []:
            if not isinstance(item, dict): reasons.append(f"{topic}: bound_files entries must be mappings"); continue
            raw_path = str(item.get("path") or ""); candidate = (root / raw_path).resolve()
            try: candidate.relative_to(root.resolve())
            except ValueError: reasons.append(f"{topic}: bound path escapes repository: {raw_path}"); continue
            if not candidate.is_file(): reasons.append(f"{topic}: bound file missing: {raw_path}")
            elif item.get("sha256") != sha256(candidate): reasons.append(f"{topic}: bound hash mismatch: {raw_path}")
    if len(topics) != len(rounds): reasons.append("topic_id values must be unique")
    if len(rounds) > 3: reasons.append("round count must be <=3")
    structural = not reasons
    demonstrated = structural and len(topics) >= 2 and warm_count >= 1
    return demonstrated, reasons

def validate(data: dict, root: Path = ROOT) -> list[str]:
    derived, reasons = derive_efficiency(data, root.resolve())
    errors = []
    if data.get("efficiency_pass") != derived: errors.append(f"efficiency_pass must equal checker-derived value {derived}")
    if data.get("efficiency_demonstrated") != derived: errors.append(f"efficiency_demonstrated must equal checker-derived value {derived}")
    if data.get("warm_path_claim") is True and not derived: errors.append("warm_path_claim cannot be true unless efficiency is demonstrated")
    errors.extend(reasons)
    return errors

def selftest() -> int:
    def fixture(topic, path_class, cycle):
        return {"topic_id": topic, "path_class": path_class, "generation_review_cycle": cycle, "correction_count": 0, "composition_build_count": 1, "final_full_render_count": 1, "generic_code_change_count": 0, "canonical_generic_publisher_used": True, "manual_executable_source_reconstruction": False, "cache_reuse_evidence": True, "late_or_open_p0_count": 0, "all_final_pages_human_reviewed": True, "started_at": "2026-01-01T00:00:00Z", "finished_at": "2026-01-01T00:00:01Z", "wall_elapsed_seconds": 1, "active_process_seconds": .5, "external_wait_seconds": .2, "human_review_orchestration_seconds": .1, "measurement_method": "monotonic instrumentation", "command_or_call_counts": {"composition": 1, "render": 1}}
    good = {"status": "EARLY_STOPPED", "global_generation_review_cycles": 2, "efficiency_pass": True, "efficiency_demonstrated": True, "warm_path_claim": True, "rounds": [fixture("synthetic-a", "cold_path", 1), fixture("synthetic-b", "warm_path", 2)]}
    if validate(good): print("FAIL: valid cold+warm fixture rejected"); return 1
    fourth = {"status": "STOP_LIMIT", "global_generation_review_cycles": 4, "efficiency_pass": False, "efficiency_demonstrated": False, "warm_path_claim": False, "rounds": [fixture("synthetic-a", "cold_path", 1)]}
    if not validate(fourth): print("FAIL: fourth cycle accepted"); return 1
    claimed = {"status": "STOP_LIMIT", "global_generation_review_cycles": 1, "efficiency_pass": True, "efficiency_demonstrated": True, "warm_path_claim": True, "rounds": [fixture("synthetic-a", "cold_path", 1)]}
    if not validate(claimed): print("FAIL: self-reported pass accepted"); return 1
    unknown = {"status": "STOP_LIMIT", "global_generation_review_cycles": 1, "efficiency_pass": False, "efficiency_demonstrated": False, "warm_path_claim": False, "rounds": [{**fixture("synthetic-a", "cold_path", 1), "started_at": None}]}
    if not validate(unknown): print("FAIL: UNKNOWN instrumentation accepted"); return 1
    overflow = {"status": "STOP_LIMIT", "global_generation_review_cycles": 1, "efficiency_pass": False, "efficiency_demonstrated": False, "warm_path_claim": False, "rounds": [{**fixture("synthetic-a", "cold_path", 1), "composition_build_count": 3}]}
    if not validate(overflow): print("FAIL: per-topic build limit escaped"); return 1
    print("PASS: teaching-demo efficiency checker selftest (global cycle<=3, derived gate, UNKNOWN timing)"); return 0

def main() -> int:
    parser = argparse.ArgumentParser(); parser.add_argument("--record", type=Path); parser.add_argument("--root", type=Path, default=ROOT); parser.add_argument("--selftest", action="store_true"); args = parser.parse_args()
    if args.selftest: return selftest()
    if not args.record: parser.error("--record or --selftest is required")
    data = yaml.safe_load(args.record.read_text(encoding="utf-8")) or {}; errors = validate(data, args.root)
    if errors:
        print("FAIL: teaching-demo efficiency record")
        for error in errors: print("- " + error)
        return 1
    print("PASS: teaching-demo efficiency record (derived efficiency gate)"); return 0

if __name__ == "__main__": raise SystemExit(main())
