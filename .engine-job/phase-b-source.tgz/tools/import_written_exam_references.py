"""Import teacher written-exam references into a simple JSONL staging format.

Supported inputs: JSONL, JSON, YAML/YML, CSV, Markdown/TXT.
Markdown/TXT are intentionally conservative: each non-empty non-heading line becomes a partial
stem record. This importer never guesses answers, exam profiles or provenance.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Iterable

import yaml


def _as_records(data):
    if data is None:
        return []
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        for key in ("items", "questions", "records"):
            if isinstance(data.get(key), list):
                return data[key]
        return [data]
    raise ValueError(f"unsupported structured root type: {type(data).__name__}")


def read_file(path: Path) -> list[dict]:
    suffix = path.suffix.lower()
    if suffix == ".jsonl":
        rows = []
        for line_no, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            if not line.strip():
                continue
            value = json.loads(line)
            if not isinstance(value, dict):
                raise ValueError(f"{path}:{line_no}: JSONL row must be object")
            rows.append(value)
        return rows
    if suffix == ".json":
        return _as_records(json.loads(path.read_text(encoding="utf-8")))
    if suffix in {".yaml", ".yml"}:
        return _as_records(yaml.safe_load(path.read_text(encoding="utf-8")))
    if suffix == ".csv":
        with path.open("r", encoding="utf-8-sig", newline="") as fh:
            return [dict(row) for row in csv.DictReader(fh)]
    if suffix in {".md", ".txt"}:
        rows = []
        for line_no, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            text = raw.strip()
            if not text or text.startswith("#") or text.startswith("<!--"):
                continue
            rows.append({"status": "partial", "stem": text, "source_locator": f"line:{line_no}"})
        return rows
    raise ValueError(f"unsupported input suffix: {path}")


def iter_inputs(source: Path) -> Iterable[Path]:
    if source.is_file():
        yield source
        return
    if not source.is_dir():
        raise FileNotFoundError(source)
    supported = {".jsonl", ".json", ".yaml", ".yml", ".csv", ".md", ".txt"}
    for path in sorted(source.rglob("*")):
        if path.is_file() and path.suffix.lower() in supported:
            yield path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()

    imported: list[dict] = []
    for path in iter_inputs(args.source):
        for record in read_file(path):
            if not isinstance(record, dict):
                raise ValueError(f"{path}: imported row must be mapping")
            row = dict(record)
            row.setdefault("status", "partial")
            row.setdefault("source_path", str(path))
            imported.append(row)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as fh:
        for row in imported:
            fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
    print(f"imported={len(imported)} output={args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
