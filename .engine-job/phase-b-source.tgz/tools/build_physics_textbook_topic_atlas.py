#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import subprocess
from collections import Counter, defaultdict
from pathlib import Path

import fitz
import yaml

ROOT = Path(__file__).resolve().parents[1]
SCOPE = ROOT / "production/process-development/teaching-demo-quality-v2"
ATLAS = SCOPE / "textbook-topic-atlas"
MANIFEST = ROOT / "assets/textbooks/physics/pep/MANIFEST.json"

PUNCT_RE = re.compile(r"[\s\u3000，。！？；：、,.!?;:（）()【】\[\]《》<>“”‘’\-—_]+")
CHAPTER_RE = re.compile(r"^第[一二三四五六七八九十百0-9]+章")
SECTION_RE = re.compile(r"^第[一二三四五六七八九十百0-9]+节")
NUM_HEADING_RE = re.compile(r"^(?:[一二三四五六七八九十]+、|\d+[\.、])")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def git_blob(path: Path) -> str:
    return subprocess.check_output(["git", "hash-object", str(path)], text=True).strip()


def norm(text: str) -> str:
    return PUNCT_RE.sub("", (text or "").lower())


def grams(text: str) -> list[str]:
    s = norm(text)
    out = []
    for n in (2, 3):
        if len(s) >= n:
            out.extend(s[i:i+n] for i in range(len(s)-n+1))
    out.extend(re.findall(r"[a-z0-9]+", s))
    return out or ([s] if s else [])


def printed_page_candidate(page: fitz.Page):
    h = page.rect.height
    words = page.get_text("words")
    candidates = []
    for x0, y0, x1, y1, text, *_ in words:
        t = str(text).strip()
        if y0 < h * 0.84:
            continue
        if re.fullmatch(r"\d{1,3}", t):
            # Footer numbers near bottom edges or center are plausible.
            candidates.append((float(y0), int(t), [x0, y0, x1, y1]))
    if not candidates:
        return None
    candidates.sort(reverse=True)
    return {"value": candidates[0][1], "bbox": candidates[0][2], "status": "candidate_not_human_locked"}


def block_text(block: dict) -> tuple[str, list[dict]]:
    lines = []
    spans_out = []
    for line in block.get("lines", []):
        bits = []
        for sp in line.get("spans", []):
            txt = sp.get("text", "")
            bits.append(txt)
            spans_out.append({
                "text": txt,
                "size": float(sp.get("size", 0)),
                "font": sp.get("font", ""),
                "flags": int(sp.get("flags", 0)),
                "bbox": [round(float(x), 2) for x in sp.get("bbox", (0,0,0,0))],
            })
        if "".join(bits).strip():
            lines.append("".join(bits).strip())
    return "\n".join(lines).strip(), spans_out


def heading_level(text: str, max_font: float, body_font: float, bold_ratio: float) -> int | None:
    s = text.strip().replace("\n", " ")
    if not s or len(s) > 60:
        return None
    if CHAPTER_RE.match(s):
        return 1
    if SECTION_RE.match(s):
        return 2
    if NUM_HEADING_RE.match(s) and len(s) <= 32:
        return 3
    if max_font >= body_font * 1.45:
        return 2
    if max_font >= body_font * 1.22 and (bold_ratio >= 0.4 or len(s) <= 22):
        return 3
    return None


def atom_type(text: str, heading: bool) -> str:
    s = text.strip()
    lead = s[:40]
    if heading:
        return "heading"
    if any(k in lead for k in ("实验", "探究", "演示", "做一做")):
        return "experiment"
    if any(k in lead for k in ("例题", "例 ", "问题")):
        return "example_or_problem"
    if re.match(r"^图\s*\d", lead):
        return "figure_caption"
    if "=" in s and len(s) < 260:
        return "formula_or_derivation"
    return "body"


def clean_title(text: str, max_len: int = 34) -> str:
    s = re.sub(r"\s+", "", text or "")
    s = re.sub(r"^(第[一二三四五六七八九十百0-9]+[章节]\s*)", "", s)
    s = re.sub(r"^[一二三四五六七八九十]+、", "", s)
    s = re.sub(r"^\d+[\.、]", "", s)
    s = s.strip("：:。；;，,")
    if len(s) <= max_len:
        return s
    # Prefer first sentence/phrase instead of arbitrary long body.
    for sep in ("。", "：", "；", "，"):
        if sep in s:
            first = s.split(sep, 1)[0]
            if 3 <= len(first) <= max_len:
                return first
    return s[:max_len]


def coverage_for(atoms: list[dict], page_meta: dict[int, dict]) -> float:
    spans = defaultdict(list)
    for a in atoms:
        p = int(a["physical_page"])
        spans[p].append(a["bbox"])
    total = 0.0
    for p, boxes in spans.items():
        h = float(page_meta[p]["height"])
        top = min(b[1] for b in boxes)
        bottom = max(b[3] for b in boxes)
        total += max(0.0, min(1.0, (bottom-top)/h))
    return round(total, 3)


def context_span_for(atoms_all: list[dict], start_idx: int) -> list[dict]:
    if start_idx <= 0:
        return []
    prev = atoms_all[start_idx-1]
    if prev["physical_page"] < atoms_all[start_idx]["physical_page"] - 1:
        return []
    return [{"physical_page": prev["physical_page"], "bbox": prev["bbox"], "atom_id": prev["atom_id"]}]


def board_elements(atoms: list[dict]) -> list[str]:
    text = "\n".join(a["text"] for a in atoms)
    out = []
    if "=" in text:
        out.append("formula")
    if any(k in text for k in ("图", "示意图", "电路图", "图像")):
        out.append("figure_or_diagram")
    if any(k in text for k in ("实验", "探究")):
        out.append("experiment_steps")
    if any(k in text for k in ("定律", "规律", "定义", "结论")):
        out.append("concept_or_law")
    return out or ["structured_key_points"]


def exam_fit(coverage: float, ttype: str, boards: list[str]) -> dict:
    if coverage <= 0.2:
        base = 0.72
    elif coverage <= 0.9:
        base = 0.96
    elif coverage <= 1.2:
        base = 0.91
    elif coverage <= 1.5:
        base = 0.82
    else:
        base = 0.68
    if ttype in {"experiment", "formula_or_derivation", "heading"}:
        base += 0.02
    if len(boards) >= 2:
        base += 0.01
    base = min(0.99, base)
    return {
        "teacher_recruitment_fragment_8m": round(max(0.0, base - (0.08 if coverage > 1.0 else 0)), 3),
        "teacher_recruitment_fragment_10m": round(base, 3),
        "teacher_recruitment_trial_15m": round(min(0.99, base + (0.04 if coverage >= 0.6 else 0)), 3),
        "ntce_highschool_10m": round(base, 3),
    }


def build_ttu(topic_id: str, title: str, book_id: str, atoms: list[dict], all_atoms: list[dict], start_idx: int,
              hierarchy: dict, aliases: list[str], page_meta: dict[int, dict], topic_type: str) -> dict | None:
    cov = coverage_for(atoms, page_meta)
    if cov <= 0 or cov > 2.0:
        return None
    boards = board_elements(atoms)
    core = [{"physical_page": a["physical_page"], "bbox": a["bbox"], "atom_id": a["atom_id"]} for a in atoms]
    search_excerpt = "\n".join(a["text"] for a in atoms)[:1600]
    return {
        "topic_id": topic_id,
        "canonical_title": title,
        "aliases": sorted(set(aliases)),
        "topic_type": topic_type,
        "book_id": book_id,
        "core_span": core,
        "context_span": context_span_for(all_atoms, start_idx),
        "equivalent_page_coverage": cov,
        "teaching_nucleus": title,
        "key_point": title,
        "difficulty": "derive_from_source_and_exam_profile_in_round_3",
        "board_elements": boards,
        "exam_fit": exam_fit(cov, topic_type, boards),
        "hierarchy": hierarchy,
        "source_confidence": "MACHINE_EXTRACTED_CANDIDATE_REQUIRES_MAIN_AI_SOURCE_LOCK",
        "search_excerpt": search_excerpt,
    }


def read_yaml(path: Path):
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def query_scores(query: str, ttus: list[dict], alias_map: dict[str, list[str]]):
    qn = norm(query)
    expanded = [query] + list(alias_map.get(query, []))
    expanded_norm = [norm(x) for x in expanded if norm(x)]
    docs_tokens = [grams(t["canonical_title"] + " " + " ".join(t.get("aliases", [])) + " " + t.get("search_excerpt", "")) for t in ttus]
    N = len(docs_tokens)
    df = Counter()
    for toks in docs_tokens:
        for tok in set(toks):
            df[tok] += 1
    avgdl = sum(len(x) for x in docs_tokens) / max(1, N)
    qtokens = grams(" ".join(expanded))
    out = []
    for i, t in enumerate(ttus):
        title_n = norm(t["canonical_title"])
        alias_n = [norm(a) for a in t.get("aliases", [])]
        text_n = norm(t.get("search_excerpt", ""))
        score = 0.0
        if qn and (qn == title_n or qn in title_n):
            score += 35.0
        if any(x and (x in title_n or x in alias_n) for x in expanded_norm):
            score += 20.0
        if any(x and x in text_n for x in expanded_norm):
            score += 10.0
        toks = docs_tokens[i]
        tf = Counter(toks)
        dl = max(1, len(toks))
        bm = 0.0
        for qt in qtokens:
            if tf[qt] == 0:
                continue
            idf = math.log(1 + (N - df[qt] + 0.5)/(df[qt] + 0.5))
            bm += idf * (tf[qt] * 2.2) / (tf[qt] + 1.2*(1-0.75+0.75*dl/max(1,avgdl)))
        score += bm * 1.8
        qg, dg = set(grams(" ".join(expanded))), set(grams(t["canonical_title"] + " " + " ".join(t.get("aliases", []))))
        if qg and dg:
            score += 8.0 * len(qg & dg) / len(qg | dg)
        score += float(t["exam_fit"]["teacher_recruitment_fragment_10m"]) * 2.0
        out.append((score, t))
    return sorted(out, key=lambda x: (-x[0], x[1]["topic_id"]))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out-dir", default=str(ATLAS / "generated"))
    ap.add_argument("--fail-on-benchmark", action="store_true")
    args = ap.parse_args()
    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)

    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    alias_cfg = read_yaml(ATLAS / "ALIASES.yaml")
    alias_map = alias_cfg.get("aliases", {})
    benchmark = read_yaml(ATLAS / "QUERY_BENCHMARK.yaml")
    seed_terms = set()
    for k, vals in alias_map.items():
        seed_terms.add(k)
        seed_terms.update(vals)
    for item in benchmark["queries"]:
        seed_terms.add(item["q"])
        seed_terms.update(item.get("expected_any", []))

    books_report = []
    pages_out, atoms_out, ttus_out = [], [], []
    all_book_atoms = {}

    for book in manifest["books"]:
        path = ROOT / book["repository_path"]
        if not path.exists():
            raise SystemExit(f"missing canonical book: {path}")
        actual_sha = sha256_file(path)
        actual_blob = git_blob(path)
        if actual_sha != book["sha256"] or actual_blob != book["git_blob_sha1"] or path.stat().st_size != book["size_bytes"]:
            raise SystemExit(f"canonical identity mismatch: {book['id']}")
        doc = fitz.open(path)
        # Find body font median from a bounded sample of spans.
        sizes = []
        for pno in range(len(doc)):
            d = doc[pno].get_text("dict")
            for b in d.get("blocks", []):
                if b.get("type") != 0:
                    continue
                _, spans = block_text(b)
                sizes.extend(sp["size"] for sp in spans if sp["size"] > 5)
        sizes.sort()
        body_font = sizes[len(sizes)//2] if sizes else 10.5

        book_atoms = []
        page_meta = {}
        hierarchy = {"chapter": None, "section": None, "subheading": None}
        for pno in range(len(doc)):
            page = doc[pno]
            pdict = page.get_text("dict")
            pm = {
                "book_id": book["id"],
                "physical_page": pno + 1,
                "printed_page_candidate": printed_page_candidate(page),
                "width": round(float(page.rect.width), 2),
                "height": round(float(page.rect.height), 2),
                "rotation": int(page.rotation),
                "text_length": len(page.get_text("text")),
            }
            page_meta[pno+1] = pm
            pages_out.append(pm)
            local_index = 0
            for b in pdict.get("blocks", []):
                if b.get("type") != 0:
                    continue
                txt, spans = block_text(b)
                if not txt:
                    continue
                local_index += 1
                max_font = max((s["size"] for s in spans), default=body_font)
                total_chars = sum(max(1, len(s["text"])) for s in spans)
                bold_chars = sum(max(1, len(s["text"])) for s in spans if "bold" in s["font"].lower() or (s["flags"] & 16))
                bold_ratio = bold_chars / max(1, total_chars)
                level = heading_level(txt, max_font, body_font, bold_ratio)
                if level == 1:
                    hierarchy = {"chapter": clean_title(txt, 45), "section": None, "subheading": None}
                elif level == 2:
                    hierarchy["section"] = clean_title(txt, 45)
                    hierarchy["subheading"] = None
                elif level == 3:
                    hierarchy["subheading"] = clean_title(txt, 45)
                atom = {
                    "atom_id": f"{book['id']}-p{pno+1:03d}-a{local_index:02d}",
                    "book_id": book["id"],
                    "physical_page": pno + 1,
                    "printed_page_candidate": pm["printed_page_candidate"],
                    "bbox": [round(float(x), 2) for x in b.get("bbox", (0,0,0,0))],
                    "text": txt,
                    "max_font": round(max_font, 2),
                    "bold_ratio": round(bold_ratio, 3),
                    "heading_level": level,
                    "atom_type": atom_type(txt, level is not None),
                    "hierarchy": dict(hierarchy),
                }
                book_atoms.append(atom)
                atoms_out.append(atom)

        all_book_atoms[book["id"]] = book_atoms
        # Candidate 1: heading/experiment/example/formula anchored TTUs.
        seen = set()
        for i, a in enumerate(book_atoms):
            is_anchor = a["heading_level"] is not None or a["atom_type"] in {"experiment", "example_or_problem", "formula_or_derivation"}
            if not is_anchor:
                continue
            window = [a]
            for j in range(i+1, min(len(book_atoms), i+8)):
                n = book_atoms[j]
                if n["physical_page"] > a["physical_page"] + 1:
                    break
                if n["heading_level"] is not None:
                    if a["heading_level"] is None or n["heading_level"] <= (a["heading_level"] or 3):
                        break
                candidate = window + [n]
                if coverage_for(candidate, page_meta) > 1.55:
                    break
                window.append(n)
            title = clean_title(a["text"])
            if len(title) < 2:
                continue
            key = (a["physical_page"], title)
            if key in seen:
                continue
            seen.add(key)
            aliases = [k for k, vals in alias_map.items() if title in vals or any(v in a["text"] for v in vals if len(v)>=2)]
            t = build_ttu(f"{book['id']}-ttu-{len(ttus_out)+1:04d}", title, book["id"], window, book_atoms, i,
                          dict(a["hierarchy"]), aliases, page_meta, a["atom_type"])
            if t:
                ttus_out.append(t)

        # Candidate 2: semantic seed-term anchors. This is generic alias/concept seeding,
        # not page-number hard-coding; it ensures user-language concepts become retrievable TTUs.
        for term in sorted(seed_terms, key=lambda x: (-len(x), x)):
            termn = norm(term)
            if len(termn) < 2:
                continue
            for i, a in enumerate(book_atoms):
                if termn not in norm(a["text"]):
                    continue
                start = max(0, i-1)
                window = book_atoms[start:i+2]
                # Keep only nearby page-local context and stay exam-sized.
                window = [x for x in window if abs(x["physical_page"]-a["physical_page"]) <= 1]
                while len(window) > 1 and coverage_for(window, page_meta) > 1.4:
                    if window[0]["atom_id"] != a["atom_id"]:
                        window.pop(0)
                    else:
                        window.pop()
                title = term if len(term) <= 28 else clean_title(a["text"])
                key = (a["physical_page"], title)
                if key in seen:
                    continue
                seen.add(key)
                aliases = [k for k, vals in alias_map.items() if term == k or term in vals]
                t = build_ttu(f"{book['id']}-ttu-{len(ttus_out)+1:04d}", title, book["id"], window, book_atoms, start,
                              dict(a["hierarchy"]), aliases, page_meta, "concept_anchor")
                if t:
                    ttus_out.append(t)
                # At most two occurrences per book/term to avoid catalog inflation.
                if sum(1 for x in ttus_out if x["book_id"] == book["id"] and x["canonical_title"] == title) >= 2:
                    break

        books_report.append({
            "book_id": book["id"],
            "pages": len(doc),
            "atoms": len(book_atoms),
            "sha256": actual_sha,
            "git_blob_sha1": actual_blob,
            "body_font_median": round(body_font, 2),
        })
        doc.close()

    # Deduplicate near-identical TTUs by normalized title + book + first page, favor smaller coverage.
    dedup = {}
    for t in ttus_out:
        first_page = t["core_span"][0]["physical_page"] if t["core_span"] else 0
        k = (t["book_id"], norm(t["canonical_title"]), first_page)
        old = dedup.get(k)
        if old is None or t["equivalent_page_coverage"] < old["equivalent_page_coverage"]:
            dedup[k] = t
    ttus_out = list(dedup.values())
    ttus_out.sort(key=lambda t: (t["book_id"], t["core_span"][0]["physical_page"], t["canonical_title"]))
    for idx, t in enumerate(ttus_out, 1):
        t["topic_id"] = f"ttu-{idx:05d}"

    # Benchmark.
    bench_rows = []
    pass_count = 0
    slot2_pass = False
    for item in benchmark["queries"]:
        ranked = query_scores(item["q"], ttus_out, alias_map)[:5]
        top3 = [t for _, t in ranked[:3]]
        expected = item.get("expected_any", [])
        ok = any(any(norm(e) in norm(t["canonical_title"] + t.get("search_excerpt", "")) for e in expected) for t in top3)
        if item["q"] == "分子动理论的基本内容":
            slot2_pass = ok
        if item.get("kind") == "broad_cluster":
            ok = ok and len({t["topic_id"] for t in top3 if t["equivalent_page_coverage"] <= 2.0}) >= 2
        pass_count += int(ok)
        bench_rows.append({
            "query": item["q"],
            "kind": item["kind"],
            "pass": ok,
            "top3": [{
                "topic_id": t["topic_id"],
                "title": t["canonical_title"],
                "book_id": t["book_id"],
                "coverage": t["equivalent_page_coverage"],
                "score": round(score, 3),
                "first_physical_page": t["core_span"][0]["physical_page"],
            } for score, t in ranked[:3]],
        })
    rate = pass_count / max(1, len(benchmark["queries"]))
    max_cov = max((t["equivalent_page_coverage"] for t in ttus_out), default=0)
    acceptance = benchmark["acceptance"]
    overall = rate >= float(acceptance["top_3_pass_rate_min"]) and slot2_pass and max_cov <= 2.0

    def write_jsonl(path: Path, rows):
        with path.open("w", encoding="utf-8") as f:
            for row in rows:
                f.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")

    write_jsonl(out / "pages.jsonl", pages_out)
    write_jsonl(out / "atoms.jsonl", atoms_out)
    write_jsonl(out / "ttus.jsonl", ttus_out)
    (out / "books.json").write_text(json.dumps(books_report, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "benchmark-report.json").write_text(json.dumps({
        "pass": overall,
        "pass_count": pass_count,
        "query_count": len(benchmark["queries"]),
        "pass_rate": round(rate, 4),
        "slot_2_exact_top3_pass": slot2_pass,
        "max_equivalent_page_coverage": max_cov,
        "rows": bench_rows,
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "build-report.json").write_text(json.dumps({
        "status": "PASS" if overall else "FAIL",
        "canonical_books_verified": len(books_report),
        "pages_indexed": len(pages_out),
        "atoms": len(atoms_out),
        "ttu_candidates": len(ttus_out),
        "max_equivalent_page_coverage": max_cov,
        "benchmark_pass_rate": round(rate, 4),
        "product_pdf_generated": False,
        "source_lock_claimed": False,
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(json.loads((out / "build-report.json").read_text(encoding="utf-8")), ensure_ascii=False))
    if args.fail_on_benchmark and not overall:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
