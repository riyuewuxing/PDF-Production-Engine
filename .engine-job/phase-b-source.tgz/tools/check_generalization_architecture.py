"""Hard gate: generic execution may not know business-case/component identities.

Concrete lesson/question semantics live in business data or declarative assets.
Python execution may read and validate identity fields generically, but may not embed a
current/regression identity or compare an identity value against a case-specific literal.
"""
from __future__ import annotations

import ast
from pathlib import Path
import re
import tempfile

import yaml

ROOT = Path(__file__).resolve().parents[1]
BUSINESS_IDENTITY_FIELD_NAMES = {
    'title',
    'case_id',
    'topic',
    'topic_name',
    'lesson_title',
    'question',
    'question_text',
    'suite',
}


def _yaml_business_files(root: Path) -> list[Path]:
    """Discover business data without knowing a specific module/fixture path."""
    files: list[Path] = []
    for base in (root / 'production', root / 'content/job-search'):
        if not base.exists():
            continue
        files.extend(base.rglob('*.yaml'))
        files.extend(base.rglob('*.yml'))
    return sorted(set(files))


def _identity_values(node, source: str, out: list[tuple[str, str, str]]) -> None:
    """Collect scalar values stored under explicit business-identity keys.

    A schema declaration such as `question: {type: string}` is not an identity because
    its value is a mapping rather than a scalar.
    """
    if isinstance(node, dict):
        for key, value in node.items():
            key_text = str(key)
            if key_text in BUSINESS_IDENTITY_FIELD_NAMES and isinstance(value, (str, int, float)):
                token = str(value).strip()
                if len(token) >= 3:
                    out.append((source, key_text, token))
            _identity_values(value, source, out)
    elif isinstance(node, list):
        for value in node:
            _identity_values(value, source, out)


def _business_identities(root: Path) -> list[tuple[str, str, str]]:
    out: list[tuple[str, str, str]] = []
    for path in _yaml_business_files(root):
        try:
            data = yaml.safe_load(path.read_text(encoding='utf-8'))
        except Exception:
            continue
        if data is None:
            continue
        try:
            label = str(path.relative_to(root))
        except ValueError:
            label = str(path)
        _identity_values(data, label, out)
    seen: set[tuple[str, str, str]] = set()
    unique: list[tuple[str, str, str]] = []
    for item in out:
        if item not in seen:
            seen.add(item)
            unique.append(item)
    return unique


def _declarative_asset_paths(root: Path) -> list[Path]:
    """Flatten arbitrary declarative_assets groups without knowing group names."""
    route = root / 'tools/tooling-manifest.yaml'
    if not route.exists():
        return []
    data = yaml.safe_load(route.read_text(encoding='utf-8')) or {}
    raw = data.get('declarative_assets') or {}
    if not isinstance(raw, dict):
        return []
    paths: list[Path] = []
    for values in raw.values():
        if not isinstance(values, list):
            continue
        for rel in values:
            if isinstance(rel, str) and rel:
                paths.append(root / rel)
    return paths


def _component_identities(root: Path) -> list[tuple[str, str]]:
    """Discover identity-bearing figure registries by schema content."""
    out: list[tuple[str, str]] = []
    for path in _declarative_asset_paths(root):
        if not path.exists() or path.suffix not in {'.yaml', '.yml'}:
            continue
        try:
            data = yaml.safe_load(path.read_text(encoding='utf-8')) or {}
        except Exception:
            continue
        figures = data.get('figures') or {}
        if isinstance(figures, dict):
            for marker in figures:
                if isinstance(marker, str) and len(marker) >= 3:
                    try:
                        label = str(path.relative_to(root))
                    except ValueError:
                        label = str(path)
                    out.append((label, marker))
    return out


def _generic_execution_files(root: Path) -> list[Path]:
    tools = root / 'tools'
    route = tools / 'tooling-manifest.yaml'
    if not route.exists():
        return []
    data = yaml.safe_load(route.read_text(encoding='utf-8')) or {}
    names = list(data.get('canonical') or []) + list(data.get('compatibility_only') or [])
    files = [tools / str(name) for name in names if (tools / str(name)).exists()]
    workflow = root / '.github/workflows'
    if workflow.exists():
        files.extend(workflow.glob('*.yml'))
        files.extend(workflow.glob('*.yaml'))
    return sorted(set(files))


def _field_key(node: ast.AST) -> str | None:
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value if node.value in BUSINESS_IDENTITY_FIELD_NAMES else None
    return None


def _is_business_value_expr(node: ast.AST) -> bool:
    """True only when an expression evaluates to an identity *value*.

    Merely mentioning the key string `question` in `'question' in record` is not an
    identity-value expression and is intentionally allowed for generic validators.
    """
    if isinstance(node, ast.Name):
        return node.id in BUSINESS_IDENTITY_FIELD_NAMES
    if isinstance(node, ast.Attribute):
        return node.attr in BUSINESS_IDENTITY_FIELD_NAMES
    if isinstance(node, ast.Subscript):
        return _field_key(node.slice) is not None
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == 'get' and node.args:
        return _field_key(node.args[0]) is not None
    return False


def _contains_specific_literal(node: ast.AST) -> bool:
    """Detect a plausible hard-coded identity literal, excluding empty/sentinel keys."""
    for item in ast.walk(node):
        if not isinstance(item, ast.Constant):
            continue
        value = item.value
        if isinstance(value, str):
            text = value.strip()
            if len(text) >= 3 and text not in BUSINESS_IDENTITY_FIELD_NAMES:
                return True
        elif isinstance(value, (int, float)) and not isinstance(value, bool):
            return True
    return False


def _match_pattern_has_specific_literal(pattern: ast.pattern) -> bool:
    if isinstance(pattern, ast.MatchValue):
        return _contains_specific_literal(pattern.value)
    if isinstance(pattern, ast.MatchSingleton):
        return False
    if isinstance(pattern, ast.MatchOr):
        return any(_match_pattern_has_specific_literal(p) for p in pattern.patterns)
    return False


def _ast_literal_business_branch(text: str) -> bool:
    """Block only direct identity-value ↔ case-literal comparisons.

    This deliberately allows generic checks such as:
      - `if not record.get('question')`
      - `if 'question' not in record`
      - `if status == 'synthetic' and record.get('question')`
    because none compare the question/title/case value itself with a case literal.
    """
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return False
    for node in ast.walk(tree):
        if isinstance(node, ast.Compare):
            values = [node.left, *node.comparators]
            for left, right in zip(values, values[1:]):
                if _is_business_value_expr(left) and _contains_specific_literal(right):
                    return True
                if _is_business_value_expr(right) and _contains_specific_literal(left):
                    return True
        elif isinstance(node, ast.Match) and _is_business_value_expr(node.subject):
            if any(_match_pattern_has_specific_literal(case.pattern) for case in node.cases):
                return True
    return False


def architecture_errors(root: Path = ROOT) -> list[str]:
    errors: list[str] = []
    business_identities = _business_identities(root)
    component_identities = _component_identities(root)
    files = _generic_execution_files(root)
    if not files:
        errors.append('CANONICAL_TOOLING_ROUTE_EMPTY')
        return errors

    fields = '|'.join(re.escape(x) for x in sorted(BUSINESS_IDENTITY_FIELD_NAMES, key=len, reverse=True))
    literal_branch = re.compile(
        rf'\b(?:{fields})\b[^\n]{{0,100}}(?:==|!=)\s*[\'\"][^\'\"]{{3,}}[\'\"]'
        rf'|[\'\"][^\n]{{3,100}}[\'\"]\s*(?:==|!=)\s*[^\n]{{0,60}}\b(?:{fields})\b'
    )
    alias_symbol = ''.join(['MATH', '_MAP'])

    for path in files:
        text = path.read_text(encoding='utf-8')
        haystacks = [path.name, text]
        for source, key, token in business_identities:
            if any(token in hay for hay in haystacks):
                errors.append(
                    f'BUSINESS_IDENTITY_LEAK: source={source}: field={key}: '
                    f'token={token!r}: file={path.relative_to(root)}'
                )
        for registry, marker in component_identities:
            if any(marker in hay for hay in haystacks):
                errors.append(
                    f'COMPONENT_IDENTITY_LEAK: registry={registry}: marker={marker!r}: '
                    f'file={path.relative_to(root)}'
                )
        if literal_branch.search(text):
            errors.append(f'LITERAL_BUSINESS_IDENTITY_BRANCH: file={path.relative_to(root)}')
        if path.suffix == '.py' and _ast_literal_business_branch(text):
            errors.append(f'AST_LITERAL_BUSINESS_IDENTITY_BRANCH: file={path.relative_to(root)}')
        if alias_symbol in text:
            errors.append(f'TOPIC_FORMULA_ALIAS_SYMBOL_FORBIDDEN: file={path.relative_to(root)}')
    return errors


def selftest() -> None:
    with tempfile.TemporaryDirectory(prefix='qz-generalization-gate-') as tmp:
        root = Path(tmp)
        (root / 'production/regression/case-a').mkdir(parents=True)
        (root / 'production/components/figures').mkdir(parents=True)
        (root / 'production/contracts').mkdir(parents=True)
        (root / 'production/future').mkdir(parents=True)
        structured = root / 'content/job-search/teacher/interview/structured/training/cases'
        structured.mkdir(parents=True)
        (root / 'tools').mkdir()
        (root / '.github/workflows').mkdir(parents=True)

        (root / 'production/regression/case-a/case.yaml').write_text(
            'case_id: SYNTH-LESSON\ntitle: 合成课题\n', encoding='utf-8'
        )
        (root / 'production/current-run.yaml').write_text(
            'case_id: CURRENT-SYNTH\ntitle: 当前合成课题\n', encoding='utf-8'
        )
        (structured / 'cases.yaml').write_text(
            'suite: SYNTH-STRUCTURED-SUITE\ncases:\n'
            '  - case_id: SYNTH-QUESTION-CASE\n'
            '    question: 如果课堂出现合成事件，你怎么办？\n',
            encoding='utf-8',
        )
        (root / 'production/components/figures/registry.yaml').write_text(
            'version: 1\nfigures:\n  synthetic-shape:\n    tex: shape.tex\n', encoding='utf-8'
        )
        (root / 'production/components/figures/shape.tex').write_text('specific content is legal here\n', encoding='utf-8')
        (root / 'production/contracts/product.yaml').write_text('version: 1\nid: product\n', encoding='utf-8')
        (root / 'production/future/registry.yaml').write_text(
            'version: 1\nfigures:\n  future-shape:\n    tex: future.tex\n', encoding='utf-8'
        )
        (root / 'tools/build_generic.py').write_text("value = cfg.get('title')\nprint(value)\n", encoding='utf-8')
        (root / 'tools/publisher_core.py').write_text('ALIASES_DISABLED = True\n', encoding='utf-8')
        (root / 'tools/retired_old.py').write_text('TARGET = "historical only"\n', encoding='utf-8')
        (root / 'tools/tooling-manifest.yaml').write_text(
            'version: 10\npolicy: explicit-routing\ncanonical:\n'
            '  - build_generic.py\n  - publisher_core.py\n'
            'declarative_assets:\n'
            '  figures:\n    - production/components/figures/registry.yaml\n'
            '  contracts:\n    - production/contracts/product.yaml\n'
            '  arbitrary-future-family:\n    - production/future/registry.yaml\n'
            'retired:\n  - retired_old.py\n',
            encoding='utf-8',
        )
        (root / '.github/workflows/test.yml').write_text('run: python tools/build_generic.py\n', encoding='utf-8')
        if architecture_errors(root):
            raise AssertionError('generic + declarative asset/data discovery falsely rejected')

        # Generic field validation must be legal even when it branches on presence.
        (root / 'tools/build_generic.py').write_text(
            "if 'question' not in record: raise ValueError('missing')\n"
            "if not str(record.get('question') or '').strip(): raise ValueError('empty')\n"
            "if status == 'synthetic' and record.get('question'): pass\n",
            encoding='utf-8',
        )
        if architecture_errors(root):
            raise AssertionError('generic identity-field validation falsely rejected')

        (root / 'tools/build_generic.py').write_text('TARGET = "SYNTH-LESSON"\n', encoding='utf-8')
        found = architecture_errors(root)
        if not any('BUSINESS_IDENTITY_LEAK' in x for x in found):
            raise AssertionError('trial lesson identity leak escaped generic gate')

        (root / 'tools/build_generic.py').write_text('TARGET = "SYNTH-QUESTION-CASE"\n', encoding='utf-8')
        found = architecture_errors(root)
        if not any('BUSINESS_IDENTITY_LEAK' in x for x in found):
            raise AssertionError('structured case identity leak escaped generic gate')

        (root / 'tools/build_generic.py').write_text('TARGET = "如果课堂出现合成事件，你怎么办？"\n', encoding='utf-8')
        found = architecture_errors(root)
        if not any('BUSINESS_IDENTITY_LEAK' in x for x in found):
            raise AssertionError('structured question-text leak escaped generic gate')

        (root / 'tools/build_generic.py').write_text('TARGET = "synthetic-shape"\n', encoding='utf-8')
        found = architecture_errors(root)
        if not any('COMPONENT_IDENTITY_LEAK' in x for x in found):
            raise AssertionError('registered component marker escaped generic gate')

        (root / 'tools/build_generic.py').write_text('TARGET = "future-shape"\n', encoding='utf-8')
        found = architecture_errors(root)
        if not any('COMPONENT_IDENTITY_LEAK' in x for x in found):
            raise AssertionError('future component marker escaped schema-driven gate')

        field = ''.join(['ti', 'tle'])
        operator = ''.join(['=', '='])
        branch = f"if cfg.get('{field}') {operator} 'SPECIAL': pass\n"
        (root / 'tools/build_generic.py').write_text(branch, encoding='utf-8')
        found = architecture_errors(root)
        if not any(
            'LITERAL_BUSINESS_IDENTITY_BRANCH' in x or 'AST_LITERAL_BUSINESS_IDENTITY_BRANCH' in x
            for x in found
        ):
            raise AssertionError('literal business identity branch escaped generic gate')

        alias_name = ''.join(['MATH', '_MAP'])
        (root / 'tools/build_generic.py').write_text(alias_name + ' = {}\n', encoding='utf-8')
        found = architecture_errors(root)
        if not any('TOPIC_FORMULA_ALIAS_SYMBOL_FORBIDDEN' in x for x in found):
            raise AssertionError('topic formula alias symbol escaped generic gate')


def main() -> int:
    selftest()
    errors = architecture_errors(ROOT)
    if errors:
        print('\n'.join(errors))
        return 1
    print('cross-module generalization architecture gate: PASS')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
