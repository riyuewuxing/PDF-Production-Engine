"""Build NON-FORMAL regression PDFs from a selected shared product contract.

The builder is topic-agnostic and product-structure-agnostic: section order,
headings, source-role mapping, board placement and board-marker consumption come
from the same product-contract YAML used by formal publishing. Regression differs
only in provenance/status presentation and output naming.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import shutil

import yaml

import publisher_core as core
from latex_inline import selftest as inline_selftest
from physics_figures import selftest as figure_registry_selftest
from physics_notation import lint_text, selftest as notation_selftest
from regression_case import ROOT, load_case, validate_case


def _read(case_dir: Path, cfg: dict, role: str) -> str:
    rel = (cfg.get('source') or {}).get(role)
    if not rel:
        raise SystemExit(f'regression source role not bound: {role}')
    path = case_dir / str(rel)
    if not path.exists():
        raise SystemExit(f'regression source file missing: {role}: {rel}')
    return path.read_text(encoding='utf-8')


def _board_case(case_dir: Path, cfg: dict) -> dict:
    regression = cfg.get('regression_contract') or {}
    board_cfg = regression.get('board') or {}
    role = board_cfg.get('source_role')
    if not role:
        raise SystemExit('regression board.source_role is required when product sections use board output')
    data = yaml.safe_load(_read(case_dir, cfg, str(role))) or {}
    matches = [x for x in (data.get('cases') or []) if x.get('id') == cfg.get('case_id')]
    if len(matches) != 1:
        raise SystemExit(f'BOARD_PLAN must contain exactly one matching case: {cfg.get("case_id")}')
    return matches[0]


def _notice(cfg: dict) -> str:
    status = str(cfg.get('status') or 'non-formal-regression')
    return rf'''\begin{{notebox}}{{回归状态：非正式内容/出版回归}}
本 PDF 由通用 regression runner 生成，只验证 manifest + shared product contract 声明的内容、公式、图形、板书与出版规则。
当前状态：\texttt{{{core.latex_plain(status)}}}。若真实来源像素门禁尚未通过，本文件不得冒充正式交付。
\end{{notebox}}
'''


def _source_status_section(heading: str) -> str:
    return ''.join([
        r'\qzsection{' + core.latex_inline(heading) + '}' + '\n',
        r'\noindent 本回归 PDF 不伪造真实教材页；该 section 只占据产品合同规定的位置并陈述来源状态。真实教材像素仍以正式来源门禁为准。\par' + '\n',
    ])


def _needs_board(contract: dict) -> bool:
    for doc in (contract.get('documents') or {}).values():
        for section in doc.get('sections') or []:
            if section.get('include_total_board') or section.get('consume_board_markers'):
                return True
    return False


def regression_document_tex(cfg: dict, case_dir: Path, contract: dict, doc_role: str, board_case: dict) -> str:
    doc = core.contract_document(contract, doc_role)
    title = str(cfg.get('title') or '回归样例')
    header = f"{doc['header_kind']} · 回归（非正式）"
    subtitle = f"shared product contract: {contract.get('id')} · NON-FORMAL regression"
    out = [
        core.preamble(str(cfg.get('case_id') or ''), header),
        core.doc_title(f"{title}｜{doc['title_suffix']}回归测试", subtitle),
        _notice(cfg),
    ]

    sections = doc.get('sections')
    if sections:
        for idx, section in enumerate(sections):
            if idx:
                out.append(r'\newpage' + '\n')
            renderer = section.get('renderer')
            heading = str(section.get('heading') or section.get('role') or '')
            if renderer == 'source_pages':
                out.append(_source_status_section(heading))
                continue
            if renderer != 'markdown':
                raise SystemExit(f'unsupported regression section renderer: {renderer!r}')
            source_role = str(section.get('source_role') or '')
            md = _read(case_dir, cfg, source_role)
            out.append(r'\qzsection{' + core.latex_inline(heading) + '}' + '\n')
            out.append(core.render_md(md, board_case, bool(section.get('consume_board_markers')), nested=True))
            if section.get('include_total_board'):
                out.append(core.total_board(board_case, title + ' · 总板书'))
    else:
        renderer = doc.get('renderer')
        if renderer != 'markdown':
            raise SystemExit(f'unsupported regression document renderer: {renderer!r}')
        source_role = str(doc.get('source_role') or '')
        out.append(core.render_md(_read(case_dir, cfg, source_role), nested=True))

    out.append(r'\end{document}' + '\n')
    return ''.join(out)


def _generated_tex_gate(label: str, tex: str) -> None:
    if '**' in tex:
        raise SystemExit(f'MARKDOWN_LEAK_IN_GENERATED_TEX: {label}')
    issues = lint_text(tex, require_math_mode=False)
    if issues:
        rendered = '; '.join(f'{x.code}:${x.fragment}$' for x in issues[:20])
        raise SystemExit(f'PHYSICS_NOTATION_IN_GENERATED_TEX: {label}: {rendered}')


def build_case(case_arg: str | Path) -> tuple[Path, ...]:
    inline_selftest(); notation_selftest(); figure_registry_selftest(); core.product_contract_selftest()
    errors = validate_case(case_arg)
    if errors:
        raise SystemExit('\n'.join(errors))

    cfg, case_dir, _ = load_case(case_arg)
    if not cfg.get('not_formal_delivery'):
        raise SystemExit('generic regression builder only accepts not_formal_delivery=true cases')
    contract = core.load_product_contract(cfg)
    board_case = _board_case(case_dir, cfg) if _needs_board(contract) else {}

    slug = case_dir.name
    out = ROOT / 'outputs/regression' / slug
    tex_dir = ROOT / 'outputs/regression' / f'{slug}-tex'
    for path in (out, tex_dir):
        if path.exists():
            shutil.rmtree(path)
        path.mkdir(parents=True, exist_ok=True)

    built: list[Path] = []
    page_counts: list[tuple[str, int]] = []
    for doc_role, doc in (contract.get('documents') or {}).items():
        tex = regression_document_tex(cfg, case_dir, contract, str(doc_role), board_case)
        _generated_tex_gate(str(doc_role), tex)
        suffix = str(doc.get('title_suffix') or doc_role)
        pdf = out / f"{cfg['title']}｜{suffix}_回归测试_非正式.pdf"
        tex_path = tex_dir / str(doc.get('tex_filename') or f'{doc_role}.tex')
        pages = core.compile_tex(tex, tex_path, pdf)
        built.append(pdf); page_counts.append((str(doc_role), pages))

    if len(built) != len(contract.get('documents') or {}):
        raise SystemExit('regression document count drifted from shared product contract')
    print('regression built: ' + slug + ': ' + ', '.join(f'{role}={pages} pages' for role,pages in page_counts))
    print('NON-FORMAL: formal source/pixel gates remain authoritative')
    return tuple(built)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--case', required=True, help='case.yaml path or case directory')
    args = parser.parse_args()
    build_case(args.case)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
