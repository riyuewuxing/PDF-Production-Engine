#!/usr/bin/env python3
"""Deterministic Phase9 final acceptance validator. No network/LLM calls."""
from __future__ import annotations
from pathlib import Path
import sys
import yaml

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "content/job-search/teacher/position-research/materials/yunnan/r2"

def load(name: str):
    with (BASE / name).open("r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}

def req(ok: bool, msg: str, errors: list[str]) -> None:
    if not ok:
        errors.append(msg)

def main() -> int:
    errors: list[str] = []
    bench = load("benchmark-results.yaml")
    events = load("canonical-current-recruitment-events.yaml")
    fails = load("acquisition-failures.yaml")
    links = load("event-followup-links.yaml")
    routes = load("downstream-routing-sample.yaml")
    manifest = load("final-manifest.yaml")

    req(bench.get("decision") == "PASS", "benchmark decision must be PASS", errors)
    reg = bench.get("registry_driven") or {}
    base = bench.get("baseline") or {}
    req(reg.get("official_source_ratio") == 1.0, "official source ratio must be 1.0", errors)
    req(reg.get("source_locator_completeness") == 1.0, "source locator completeness must be 1.0", errors)
    req(reg.get("silent_failure_rate") == 0.0, "silent failure rate must be 0", errors)
    req(reg.get("gap_visibility") == 1.0, "gap visibility must be 1.0", errors)
    req((reg.get("source_surfaces_attempted") or 0) > (base.get("official_source_surfaces_directly_checked") or 0), "engine must check more official surfaces than baseline", errors)
    req((reg.get("canonical_official_events") or 0) > (base.get("canonical_official_events") or 0), "engine must yield more official canonical events than baseline", errors)
    req((reg.get("followups_linked") or 0) > (base.get("followups_linked") or 0), "engine must link more official followups than baseline", errors)
    req(reg.get("binary_attachments_captured") == 0, "binary attachment gap must remain explicit in this runtime", errors)
    req(str((bench.get("important_failure") or {}).get("attachment_binary_capture", "")).startswith("FAIL/"), "attachment failure must be explicit", errors)

    evs = events.get("events") or []
    req(len(evs) == reg.get("canonical_official_events"), "event count must match benchmark", errors)
    ids: set[str] = set()
    for event in evs:
        eid = event.get("event_id")
        req(bool(eid), "event missing id", errors)
        if eid:
            req(eid not in ids, f"duplicate event {eid}", errors)
            ids.add(eid)
        req(event.get("authority_level") in {"A0", "A1"}, f"{eid}: nonofficial authority in final pool", errors)
        req(str(event.get("source_url", "")).startswith("http"), f"{eid}: missing official source URL", errors)
        req(bool(event.get("source_locator")), f"{eid}: missing source locator", errors)
        req(isinstance(event.get("current_opening"), bool), f"{eid}: current_opening must be explicit bool", errors)

    failures = fails.get("failures") or []
    req(len(failures) == reg.get("failed_or_blocked_sources"), "failure count must match benchmark", errors)
    for failure in failures:
        fid = failure.get("failure_id")
        req(failure.get("silent_empty") is False, f"{fid}: failure must not be silent", errors)
        req(bool(failure.get("impact")), f"{fid}: missing impact", errors)
        req(bool(failure.get("next_action")), f"{fid}: missing next action", errors)

    followups = links.get("links") or []
    req(len(followups) == reg.get("followups_linked"), "followup count must match benchmark", errors)
    for link in followups:
        req(link.get("authority_level") in {"A0", "A1"}, "followup must be official", errors)
        req(bool(link.get("locator")), "followup missing locator", errors)

    samples = routes.get("samples") or []
    req(bool(samples), "downstream routing sample is empty", errors)
    for sample in samples:
        eid = sample.get("event_id")
        req(sample.get("eligibility_status") == "CANDIDATE_DATA_REQUIRED", f"{eid}: must not invent candidate eligibility", errors)
        req(bool(sample.get("source_locator")), f"{eid}: downstream route missing source locator", errors)

    req(manifest.get("status") == "PHASE9_COMPLETE", "manifest must close Phase9", errors)
    rounds = manifest.get("rounds") or {}
    req(rounds.get("round1") == "complete" and rounds.get("round2") == "complete", "both rounds must be complete", errors)
    req(str(rounds.get("round3", "")).startswith("forbidden"), "Round3 must remain forbidden", errors)
    req((manifest.get("benchmark") or {}).get("binary_attachment_capture") == "FAIL-EXPLICIT-GAP", "manifest must retain binary attachment gap", errors)

    if errors:
        print("FAIL: Phase9 final acceptance")
        for error in errors:
            print(f"- {error}")
        return 1

    print("PASS: Phase9 final acceptance")
    print(f"events={len(evs)} followups={len(followups)} failures={len(failures)} routes={len(samples)} official_ratio={reg.get('official_source_ratio')} locator={reg.get('source_locator_completeness')} silent_failure={reg.get('silent_failure_rate')}")
    print("attachment_binary_capture=FAIL-EXPLICIT-GAP (0 captured; not hidden)")
    return 0

if __name__ == "__main__":
    sys.exit(main())
