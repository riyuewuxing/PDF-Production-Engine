#!/usr/bin/env python3
"""Small telemetry writer for one Teaching Demo machine run.

This is machine timing evidence, not delivery acceptance. Durations use perf_counter;
wall timestamps are informational. Each run gets a unique history file; the runner
initializes it once and child adapters append stage records through QZ_PROCESS_TELEMETRY.
"""
from __future__ import annotations
from datetime import datetime, timezone
import os
from pathlib import Path
import tempfile
import time
from typing import Any
import yaml

from artifact_foundation import ROOT, safe_repo_path

ENV = "QZ_PROCESS_TELEMETRY"


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _run_id() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")


def path_for_manifest(manifest: str | None, *, root: Path = ROOT) -> Path:
    manifest_rel = manifest or "production/current-run.yaml"
    manifest_path = safe_repo_path(root, manifest_rel, must_exist=True)
    cfg = yaml.safe_load(manifest_path.read_text(encoding="utf-8")) or {}
    case_id = str(cfg.get("case_id") or "unknown-case")
    return safe_repo_path(root, f"qa/process-telemetry/{case_id}/{_run_id()}.yaml")


def active_path(*, root: Path = ROOT) -> Path | None:
    raw = os.environ.get(ENV)
    if not raw:
        return None
    return safe_repo_path(root, raw)


def reset(path: Path, *, manifest: str | None, scope: str, root: Path = ROOT) -> None:
    resolved = path.resolve()
    resolved.relative_to(root.resolve())
    if resolved.exists():
        raise ValueError(f"telemetry history file already exists: {resolved}")
    resolved.parent.mkdir(parents=True, exist_ok=True)
    data = {
        "version": 1,
        "kind": "teaching-demo-process-telemetry",
        "manifest": manifest or "production/current-run.yaml",
        "scope": scope,
        "started_at": _utc_now(),
        "status": "RUNNING",
        "stages": [],
    }
    resolved.write_text(yaml.safe_dump(data, allow_unicode=True, sort_keys=False), encoding="utf-8")


def _load(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise ValueError(f"telemetry file not initialized: {path}")
    data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    if data.get("version") != 1 or data.get("kind") != "teaching-demo-process-telemetry":
        raise ValueError("telemetry file schema drift")
    if not isinstance(data.get("stages"), list):
        raise ValueError("telemetry stages must be a list")
    return data


def record(stage: str, duration_seconds: float, status: str, *, detail: str | None = None, root: Path = ROOT) -> None:
    path = active_path(root=root)
    if path is None:
        return
    data = _load(path)
    entry: dict[str, Any] = {
        "sequence": len(data["stages"]) + 1,
        "stage": stage,
        "status": status,
        "duration_seconds": round(max(0.0, float(duration_seconds)), 6),
        "recorded_at": _utc_now(),
    }
    if detail:
        entry["detail"] = detail[:1000]
    data["stages"].append(entry)
    path.write_text(yaml.safe_dump(data, allow_unicode=True, sort_keys=False), encoding="utf-8")


def finish(status: str, overall_seconds: float, *, root: Path = ROOT) -> None:
    path = active_path(root=root)
    if path is None:
        return
    data = _load(path)
    data["status"] = status
    data["finished_at"] = _utc_now()
    data["overall_wall_seconds"] = round(max(0.0, float(overall_seconds)), 6)
    data["derived"] = {
        "stage_count": len(data["stages"]),
        "failed_stage_count": sum(1 for x in data["stages"] if x.get("status") != "PASS"),
        "prebuild_seconds": sum(float(x.get("duration_seconds") or 0) for x in data["stages"] if x.get("stage") == "prebuild"),
        "composition_seconds": sum(float(x.get("duration_seconds") or 0) for x in data["stages"] if x.get("stage") == "composition"),
        "check_seconds": sum(float(x.get("duration_seconds") or 0) for x in data["stages"] if x.get("stage") == "formal_check"),
        "render_seconds": sum(float(x.get("duration_seconds") or 0) for x in data["stages"] if x.get("stage") == "render"),
    }
    path.write_text(yaml.safe_dump(data, allow_unicode=True, sort_keys=False), encoding="utf-8")


def timed_call(stage: str, func, *args, **kwargs):
    start = time.perf_counter()
    try:
        value = func(*args, **kwargs)
    except BaseException as exc:
        record(stage, time.perf_counter() - start, "FAIL", detail=f"{type(exc).__name__}: {exc}")
        raise
    record(stage, time.perf_counter() - start, "PASS")
    return value


def selftest() -> None:
    old = os.environ.get(ENV)
    try:
        with tempfile.TemporaryDirectory(prefix="qz-telemetry-") as tmp:
            root = Path(tmp)
            (root / "production").mkdir()
            (root / "production/current-run.yaml").write_text("case_id: SYNTH\n", encoding="utf-8")
            generated = path_for_manifest(None, root=root)
            assert generated.parent.name == "SYNTH" and generated.suffix == ".yaml"
            path = root / "qa/process-telemetry/SYNTH/synthetic.yaml"
            os.environ[ENV] = "qa/process-telemetry/SYNTH/synthetic.yaml"
            reset(path, manifest="production/current-run.yaml", scope="preflight", root=root)
            record("prebuild", 1.25, "PASS", root=root)
            record("composition", 2.5, "PASS", root=root)
            record("formal_check", 0.5, "PASS", root=root)
            finish("PASS", 5.0, root=root)
            data = yaml.safe_load(path.read_text(encoding="utf-8"))
            assert data["status"] == "PASS"
            assert [x["sequence"] for x in data["stages"]] == [1, 2, 3]
            assert data["derived"]["prebuild_seconds"] == 1.25
            assert data["derived"]["composition_seconds"] == 2.5
            assert data["derived"]["check_seconds"] == 0.5
            assert data["derived"]["failed_stage_count"] == 0
            record("render", 0.1, "FAIL", detail="synthetic", root=root)
            finish("FAIL", 5.2, root=root)
            data = yaml.safe_load(path.read_text(encoding="utf-8"))
            assert data["status"] == "FAIL" and data["derived"]["failed_stage_count"] == 1
    finally:
        if old is None:
            os.environ.pop(ENV, None)
        else:
            os.environ[ENV] = old


if __name__ == "__main__":
    selftest()
    print("PASS: Teaching Demo process telemetry selftest")
