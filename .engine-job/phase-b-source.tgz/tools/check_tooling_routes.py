"""Fail-closed tooling route and protected-capability graph gate.

One manifest is authoritative for top-level tool lifecycle and execution role.  This
checker verifies that declaration against the actual source surface, module registry,
product contract and ADR-016 producer/consumer capability graph.  Relabelling a file
does not create authority: protected libraries must remain primitive-only and module-
contract consumer verifiers must be bound, non-executable libraries.
"""
from __future__ import annotations

import ast
from pathlib import Path
import re
import tempfile
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "tools/tooling-manifest.yaml"
LIFECYCLE_KEYS = ("canonical", "compatibility_only", "retired")
ROLE_KEYS = ("entry", "library", "entry_and_library", "compatibility_entry")
EXECUTABLE_ROLES = {"entry", "entry_and_library", "compatibility_entry"}


def load_manifest(path: Path = MANIFEST) -> dict[str, Any]:
    data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    if not isinstance(data, dict):
        raise ValueError("tooling manifest must be a mapping")
    if data.get("policy") != "explicit-routing":
        raise ValueError("tooling manifest must use policy=explicit-routing")
    if not isinstance(data.get("version"), int) or int(data["version"]) < 53:
        raise ValueError("tooling manifest version must be >= 53")
    return data


def _repo_file(root: Path, raw: str) -> Path:
    rel = Path(raw)
    if rel.is_absolute() or ".." in rel.parts:
        raise ValueError(f"repository-relative path required: {raw}")
    path = (root / rel).resolve()
    path.relative_to(root.resolve())
    if not path.is_file():
        raise ValueError(f"repository file missing: {raw}")
    return path


def _string_list(value: Any, label: str) -> list[str]:
    if not isinstance(value, list) or not all(isinstance(x, str) and x for x in value):
        raise ValueError(f"{label} must be list[str]")
    return list(value)


def _main_guard(node: ast.AST) -> bool:
    if not isinstance(node, ast.If):
        return False
    test = node.test
    if not isinstance(test, ast.Compare) or len(test.ops) != 1 or not isinstance(test.ops[0], ast.Eq):
        return False
    if len(test.comparators) != 1:
        return False
    left, right = test.left, test.comparators[0]

    def name(n: ast.AST) -> bool:
        return isinstance(n, ast.Name) and n.id == "__name__"

    def main(n: ast.AST) -> bool:
        return isinstance(n, ast.Constant) and n.value == "__main__"

    return (name(left) and main(right)) or (main(left) and name(right))


def _target_names(node: ast.AST) -> set[str]:
    if isinstance(node, ast.Name):
        return {node.id}
    if isinstance(node, (ast.Tuple, ast.List)):
        out: set[str] = set()
        for item in node.elts:
            out |= _target_names(item)
        return out
    return set()


def _surface(path: Path) -> tuple[set[str], bool, ast.Module]:
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=path.as_posix())
    except SyntaxError as exc:
        raise ValueError(f"Python surface syntax invalid: {path}: {exc}") from exc
    names: set[str] = set()
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            names.add(node.name)
        elif isinstance(node, ast.Import):
            for alias in node.names:
                names.add(alias.asname or alias.name.split(".", 1)[0])
        elif isinstance(node, ast.ImportFrom):
            for alias in node.names:
                if alias.name != "*":
                    names.add(alias.asname or alias.name)
        elif isinstance(node, ast.Assign):
            for target in node.targets:
                names |= _target_names(target)
        elif isinstance(node, ast.AnnAssign):
            names |= _target_names(node.target)
    direct_cli = any(_main_guard(node) for node in tree.body)
    return names, direct_cli, tree


def _call_tail(func: ast.AST) -> str | None:
    if isinstance(func, ast.Name):
        return func.id
    if isinstance(func, ast.Attribute):
        return func.attr
    return None


def _top_function_calls(tree: ast.Module, name: str) -> list[tuple[int, str]]:
    functions = [
        node for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == name
    ]
    if len(functions) != 1:
        return []
    calls: list[tuple[int, str]] = []
    for node in ast.walk(functions[0]):
        if isinstance(node, ast.Call):
            tail = _call_tail(node.func)
            if tail:
                calls.append((int(getattr(node, "lineno", 0)), tail))
    return sorted(calls)


def _classifications(data: dict[str, Any], tools: Path, errors: list[str]):
    lifecycle: dict[str, str] = {}
    groups: dict[str, list[str]] = {}
    for group in LIFECYCLE_KEYS:
        try:
            names = _string_list(data.get(group) or [], group)
        except ValueError as exc:
            errors.append(f"TOOL_ROUTE_GROUP_INVALID:{exc}")
            names = []
        groups[group] = names
        for name in names:
            if Path(name).name != name or not name.endswith(".py"):
                errors.append(f"TOOL_ROUTE_NAME_INVALID:{group}:{name}")
                continue
            if name in lifecycle:
                errors.append(f"TOOL_ROUTE_DUPLICATE:{name}:{lifecycle[name]}+{group}")
            lifecycle[name] = group
            target = tools / name
            if group != "retired" and not target.is_file():
                errors.append(f"TOOL_ROUTE_FILE_MISSING:{group}:{name}")
            if group == "retired" and target.exists() and not target.is_file():
                errors.append(f"TOOL_ROUTE_NOT_FILE:{group}:{name}")

    for path in sorted(tools.glob("*.py")):
        if path.name not in lifecycle:
            errors.append(f"UNCLASSIFIED_TOOL_PRESENT:{path.name}")

    raw_roles = data.get("execution_roles")
    if not isinstance(raw_roles, dict):
        errors.append("TOOL_EXECUTION_ROLES_INVALID")
        raw_roles = {}
    for key in raw_roles:
        if key not in ROLE_KEYS:
            errors.append(f"TOOL_EXECUTION_ROLE_UNKNOWN:{key}")
    roles: dict[str, str] = {}
    for role in ROLE_KEYS:
        try:
            names = _string_list(raw_roles.get(role) or [], f"execution_roles.{role}")
        except ValueError as exc:
            errors.append(f"TOOL_EXECUTION_ROLE_GROUP_INVALID:{exc}")
            names = []
        for name in names:
            if Path(name).name != name or not name.endswith(".py"):
                errors.append(f"TOOL_EXECUTION_ROLE_NAME_INVALID:{role}:{name}")
                continue
            if name in roles:
                errors.append(f"TOOL_EXECUTION_ROLE_DUPLICATE:{name}:{roles[name]}+{role}")
            roles[name] = role
            life = lifecycle.get(name)
            if life is None:
                errors.append(f"TOOL_EXECUTION_ROLE_FOR_UNCLASSIFIED:{role}:{name}")
            elif life == "retired":
                errors.append(f"RETIRED_TOOL_MUST_NOT_HAVE_EXECUTION_ROLE:{name}:{role}")
            elif life == "compatibility_only" and role != "compatibility_entry":
                errors.append(f"COMPATIBILITY_TOOL_ROLE_INVALID:{name}:{role}")
            elif life == "canonical" and role == "compatibility_entry":
                errors.append(f"CANONICAL_TOOL_ROLE_INVALID:{name}:{role}")

    for name, life in lifecycle.items():
        if life != "retired" and name not in roles:
            errors.append(f"TOOL_EXECUTION_ROLE_MISSING:{life}:{name}")

    # Role labels must match actual source shape.  Selftest-capable import modules use
    # entry_and_library rather than pretending a direct CLI does not exist.
    for name, role in sorted(roles.items()):
        path = tools / name
        if not path.is_file():
            continue
        try:
            _names, direct_cli, _tree = _surface(path)
        except Exception as exc:
            errors.append(f"TOOL_EXECUTION_ROLE_SHAPE_PARSE_FAILED:{name}:{exc}")
            continue
        if role == "library" and direct_cli:
            errors.append(f"TOOL_LIBRARY_DIRECT_CLI_ROLE_MISMATCH:{name}")
        if role == "entry_and_library" and not direct_cli:
            errors.append(f"TOOL_ENTRY_AND_LIBRARY_CLI_MISSING:{name}")
    return groups, lifecycle, roles


def _call_order_errors(capability: str, tree: ast.Module, rules: Any) -> list[str]:
    if rules is None:
        return []
    if not isinstance(rules, list):
        return [f"PROTECTED_OPERATION_CALL_ORDER_INVALID:{capability}"]
    errors: list[str] = []
    for rule in rules:
        if not isinstance(rule, dict):
            errors.append(f"PROTECTED_OPERATION_CALL_ORDER_RULE_INVALID:{capability}")
            continue
        function, before, required = rule.get("function"), rule.get("before"), rule.get("requires_before")
        if not isinstance(function, str) or not function or not isinstance(before, str) or not before:
            errors.append(f"PROTECTED_OPERATION_CALL_ORDER_RULE_INVALID:{capability}")
            continue
        if not isinstance(required, list) or not required or not all(isinstance(x, str) and x for x in required):
            errors.append(f"PROTECTED_OPERATION_CALL_ORDER_REQUIRED_INVALID:{capability}:{function}")
            continue
        calls = _top_function_calls(tree, function)
        if not calls:
            errors.append(f"PROTECTED_OPERATION_CALL_ORDER_FUNCTION_MISSING:{capability}:{function}")
            continue
        boundaries = [line for line, call in calls if call == before]
        if not boundaries:
            errors.append(f"PROTECTED_OPERATION_CALL_ORDER_TARGET_MISSING:{capability}:{function}:{before}")
            continue
        boundary = min(boundaries)
        for required_name in required:
            positions = [line for line, call in calls if call == required_name]
            if not positions:
                errors.append(f"PROTECTED_OPERATION_PRECONDITION_CALL_MISSING:{capability}:{function}:{required_name}")
            elif min(positions) >= boundary:
                errors.append(
                    f"PROTECTED_OPERATION_PRECONDITION_TOO_LATE:{capability}:{function}:"
                    f"{required_name}@{min(positions)}>={before}@{boundary}"
                )
    return errors


def _protected_errors(
    data: dict[str, Any], root: Path, lifecycle: dict[str, str], roles: dict[str, str]
) -> list[str]:
    errors: list[str] = []
    graph = data.get("protected_operations")
    if not isinstance(graph, dict):
        return ["PROTECTED_OPERATION_GRAPH_INVALID"]
    adr = graph.get("architecture_decision")
    contract_raw = graph.get("contract")
    operations = graph.get("operations")
    if not isinstance(adr, str) or not adr:
        errors.append("PROTECTED_OPERATION_ARCHITECTURE_DECISION_MISSING")
    else:
        try:
            _repo_file(root, adr)
        except Exception as exc:
            errors.append(f"PROTECTED_OPERATION_ARCHITECTURE_DECISION_INVALID:{exc}")
    if not isinstance(contract_raw, str) or not contract_raw:
        return errors + ["PROTECTED_OPERATION_CONTRACT_MISSING"]
    try:
        product = yaml.safe_load(_repo_file(root, contract_raw).read_text(encoding="utf-8")) or {}
    except Exception as exc:
        return errors + [f"PROTECTED_OPERATION_CONTRACT_INVALID:{exc}"]
    product_graph = product.get("protected_operations") or {}
    if not isinstance(product_graph, dict):
        return errors + ["PROTECTED_OPERATION_CONTRACT_GRAPH_INVALID"]
    if product_graph.get("architecture_decision") != adr:
        errors.append("PROTECTED_OPERATION_ARCHITECTURE_DECISION_DRIFT")
    if not isinstance(operations, dict) or not operations:
        return errors + ["PROTECTED_OPERATION_GRAPH_MISSING"]

    used_entries: dict[str, str] = {}
    for capability, spec in operations.items():
        if not isinstance(capability, str) or not capability or not isinstance(spec, dict):
            errors.append(f"PROTECTED_OPERATION_INVALID:{capability!r}")
            continue
        key = spec.get("contract_key")
        contract_spec = product_graph.get(key) if isinstance(key, str) else None
        if not isinstance(contract_spec, dict):
            errors.append(f"PROTECTED_OPERATION_CONTRACT_KEY_MISSING:{capability}:{key!r}")
            contract_spec = {}

        entry = spec.get("canonical_entry")
        if not isinstance(entry, str) or Path(entry).name != entry or not entry.endswith(".py"):
            errors.append(f"PROTECTED_OPERATION_AUTHORITY_INVALID:{capability}:{entry!r}")
            continue
        if entry in used_entries:
            errors.append(f"PROTECTED_OPERATION_AUTHORITY_REUSED:{entry}:{used_entries[entry]}+{capability}")
        used_entries[entry] = capability
        if lifecycle.get(entry) != "canonical":
            errors.append(f"PROTECTED_OPERATION_AUTHORITY_NOT_CANONICAL:{capability}:{entry}")
        if roles.get(entry) not in {"entry", "entry_and_library"}:
            errors.append(f"PROTECTED_OPERATION_AUTHORITY_ROLE_INVALID:{capability}:{entry}:{roles.get(entry)!r}")
        if contract_spec.get("canonical_entry") != f"tools/{entry}":
            errors.append(f"PROTECTED_OPERATION_CONTRACT_AUTHORITY_DRIFT:{capability}:{entry}")
        entry_path = root / "tools" / entry
        if not entry_path.is_file():
            errors.append(f"PROTECTED_OPERATION_AUTHORITY_MISSING:{capability}:{entry}")
            continue
        try:
            entry_names, _entry_cli, entry_tree = _surface(entry_path)
        except Exception as exc:
            errors.append(f"PROTECTED_OPERATION_AUTHORITY_SYNTAX_INVALID:{capability}:{exc}")
            continue
        required_symbols: list[str] = []
        one = contract_spec.get("complete_symbol")
        if isinstance(one, str) and one:
            required_symbols.append(one)
        many = contract_spec.get("complete_symbols") or []
        if many:
            if isinstance(many, list) and all(isinstance(x, str) and x for x in many):
                required_symbols.extend(many)
            else:
                errors.append(f"PROTECTED_OPERATION_CONTRACT_COMPLETE_SYMBOLS_INVALID:{capability}")
        if not required_symbols:
            errors.append(f"PROTECTED_OPERATION_CONTRACT_COMPLETE_SYMBOL_MISSING:{capability}")
        for symbol in sorted(set(required_symbols)):
            if symbol not in entry_names:
                errors.append(f"PROTECTED_OPERATION_AUTHORITY_SYMBOL_MISSING:{capability}:{entry}:{symbol}")

        try:
            libraries = _string_list(spec.get("implementation_libraries") or [], f"{capability}.implementation_libraries")
            contract_libraries_raw = _string_list(contract_spec.get("implementation_libraries") or [], f"{capability}.contract_libraries")
        except ValueError as exc:
            errors.append(f"PROTECTED_OPERATION_LIBRARIES_INVALID:{exc}")
            libraries, contract_libraries_raw = [], []
        contract_libraries = [Path(x).name for x in contract_libraries_raw]
        if sorted(libraries) != sorted(contract_libraries):
            errors.append(
                f"PROTECTED_OPERATION_LIBRARY_CONTRACT_DRIFT:{capability}:"
                f"manifest={sorted(libraries)}:contract={sorted(contract_libraries)}"
            )
        if entry in libraries:
            errors.append(f"PROTECTED_OPERATION_AUTHORITY_LISTED_AS_LIBRARY:{capability}:{entry}")

        try:
            forbidden = _string_list(spec.get("forbidden_library_complete_symbols") or [], f"{capability}.forbidden")
            contract_forbidden = _string_list(contract_spec.get("forbidden_library_complete_symbols") or [], f"{capability}.contract_forbidden")
        except ValueError as exc:
            errors.append(f"PROTECTED_OPERATION_FORBIDDEN_SYMBOLS_INVALID:{exc}")
            forbidden, contract_forbidden = [], []
        if not forbidden:
            errors.append(f"PROTECTED_OPERATION_FORBIDDEN_SYMBOLS_EMPTY:{capability}")
        if sorted(forbidden) != sorted(contract_forbidden):
            errors.append(f"PROTECTED_OPERATION_FORBIDDEN_SYMBOL_CONTRACT_DRIFT:{capability}")
        if spec.get("forbid_library_cli") is not True or contract_spec.get("forbid_library_cli") is not True:
            errors.append(f"PROTECTED_OPERATION_LIBRARY_CLI_POLICY_MISSING:{capability}")

        for library in libraries:
            if Path(library).name != library:
                errors.append(f"PROTECTED_OPERATION_LIBRARY_PATH_INVALID:{capability}:{library}")
                continue
            path = root / "tools" / library
            if not path.is_file():
                errors.append(f"PROTECTED_OPERATION_LIBRARY_MISSING:{capability}:{library}")
                continue
            if path.suffix == ".py":
                if lifecycle.get(library) != "canonical":
                    errors.append(f"PROTECTED_OPERATION_LIBRARY_NOT_CANONICAL:{capability}:{library}")
                if roles.get(library) != "library":
                    errors.append(f"PROTECTED_OPERATION_LIBRARY_ROLE_INVALID:{capability}:{library}:{roles.get(library)!r}")
            try:
                names, direct_cli, _tree = _surface(path)
            except Exception as exc:
                errors.append(f"PROTECTED_OPERATION_LIBRARY_SYNTAX_INVALID:{capability}:{library}:{exc}")
                continue
            for symbol in forbidden:
                if symbol in names:
                    errors.append(f"PROTECTED_LIBRARY_FORBIDDEN_SYMBOL:{capability}:{library}:{symbol}")
            if direct_cli:
                errors.append(f"PROTECTED_LIBRARY_DIRECT_CLI_FORBIDDEN:{capability}:{library}")

        try:
            forbidden_paths = _string_list(spec.get("forbidden_paths") or [], f"{capability}.forbidden_paths")
            contract_forbidden_paths_raw = _string_list(contract_spec.get("forbidden_paths") or [], f"{capability}.contract_forbidden_paths")
        except ValueError as exc:
            errors.append(f"PROTECTED_OPERATION_FORBIDDEN_PATHS_INVALID:{exc}")
            forbidden_paths, contract_forbidden_paths_raw = [], []
        contract_forbidden_paths = [Path(x).name for x in contract_forbidden_paths_raw]
        if sorted(forbidden_paths) != sorted(contract_forbidden_paths):
            errors.append(f"PROTECTED_OPERATION_FORBIDDEN_PATH_CONTRACT_DRIFT:{capability}")
        for name in forbidden_paths:
            if (root / "tools" / name).exists():
                errors.append(f"PROTECTED_OPERATION_FORBIDDEN_PATH_PRESENT:{capability}:{name}")

        errors.extend(_call_order_errors(capability, entry_tree, spec.get("required_call_order")))
    return errors


def _module_input_lock_contract_errors(
    data: dict[str, Any], root: Path, lifecycle: dict[str, str], roles: dict[str, str]
) -> list[str]:
    errors: list[str] = []
    registry_raw = data.get("module_registry")
    if not isinstance(registry_raw, str) or not registry_raw:
        return ["MODULE_REGISTRY_ROUTE_PATH_MISSING"]
    try:
        registry = yaml.safe_load(_repo_file(root, registry_raw).read_text(encoding="utf-8")) or {}
        artifact_contract = yaml.safe_load(_repo_file(root, "production/contracts/artifact-job-v1.yaml").read_text(encoding="utf-8")) or {}
    except Exception as exc:
        return [f"MODULE_INPUT_LOCK_CONTRACT_LOAD_FAILED:{exc}"]
    framework = artifact_contract.get("module_input_lock_verification") or {}
    modes = set(framework.get("allowed_modes") or []) if isinstance(framework, dict) else set()
    if framework.get("enforced_by") != "tools/check_artifact_job.py":
        errors.append("MODULE_INPUT_LOCK_FRAMEWORK_ENFORCER_DRIFT")

    for module_id, module in (registry.get("modules") or {}).items():
        if not isinstance(module, dict) or module.get("lifecycle") not in {"ACTIVE", "FROZEN"}:
            continue
        contract_raw = module.get("module_contract")
        if not isinstance(contract_raw, str) or not contract_raw:
            continue
        try:
            contract = yaml.safe_load(_repo_file(root, contract_raw).read_text(encoding="utf-8")) or {}
        except Exception as exc:
            errors.append(f"MODULE_INPUT_LOCK_MODULE_CONTRACT_INVALID:{module_id}:{exc}")
            continue
        profile = contract.get("artifact_job_profile") or {}
        if not isinstance(profile, dict):
            continue
        policy = profile.get("input_lock_verification")
        if policy is None:
            continue
        if not isinstance(policy, dict):
            errors.append(f"MODULE_INPUT_LOCK_POLICY_INVALID:{module_id}")
            continue
        mode = policy.get("mode")
        if mode not in modes:
            errors.append(f"MODULE_INPUT_LOCK_MODE_UNSUPPORTED:{module_id}:{mode!r}")
        verifier = policy.get("verifier") or {}
        path_raw = verifier.get("path") if isinstance(verifier, dict) else None
        callback = verifier.get("function") if isinstance(verifier, dict) else None
        binding_kind = verifier.get("binding_kind") if isinstance(verifier, dict) else None
        if not isinstance(path_raw, str) or not path_raw.startswith("tools/"):
            errors.append(f"MODULE_INPUT_LOCK_VERIFIER_PATH_INVALID:{module_id}:{path_raw!r}")
            continue
        name = Path(path_raw).name
        if lifecycle.get(name) != "canonical" or roles.get(name) != "library":
            errors.append(f"MODULE_INPUT_LOCK_VERIFIER_ROUTE_INVALID:{module_id}:{name}:{lifecycle.get(name)!r}:{roles.get(name)!r}")
        try:
            names, direct_cli, _tree = _surface(_repo_file(root, path_raw))
        except Exception as exc:
            errors.append(f"MODULE_INPUT_LOCK_VERIFIER_SURFACE_INVALID:{module_id}:{exc}")
            continue
        if not isinstance(callback, str) or callback not in names:
            errors.append(f"MODULE_INPUT_LOCK_VERIFIER_CALLBACK_MISSING:{module_id}:{callback!r}")
        if direct_cli:
            errors.append(f"MODULE_INPUT_LOCK_VERIFIER_CLI_FORBIDDEN:{module_id}:{name}")
        deps = profile.get("repository_dependencies") or []
        matches = [
            item for item in deps
            if isinstance(item, dict)
            and item.get("path") == path_raw
            and item.get("kind") == binding_kind
        ]
        if len(matches) != 1:
            errors.append(f"MODULE_INPUT_LOCK_VERIFIER_DEPENDENCY_BINDING_INVALID:{module_id}:{path_raw}:{binding_kind!r}")
    return errors


def _declarative_asset_errors(data: dict[str, Any], root: Path) -> list[str]:
    errors: list[str] = []
    raw = data.get("declarative_assets") or {}
    if not isinstance(raw, dict):
        return ["DECLARATIVE_ASSET_GROUPS_INVALID"]
    seen: dict[str, str] = {}
    for group, assets in raw.items():
        if not isinstance(group, str) or not group or not isinstance(assets, list) or not assets:
            errors.append(f"DECLARATIVE_ASSET_GROUP_INVALID:{group!r}")
            continue
        for rel in assets:
            if not isinstance(rel, str) or not rel:
                errors.append(f"DECLARATIVE_ASSET_PATH_INVALID:{group}:{rel!r}")
                continue
            if rel in seen:
                errors.append(f"DECLARATIVE_ASSET_DUPLICATE:{rel}:{seen[rel]}+{group}")
            seen[rel] = group
            path = Path(rel)
            if path.is_absolute() or ".." in path.parts:
                errors.append(f"DECLARATIVE_ASSET_PATH_INVALID:{group}:{rel}")
                continue
            full = root / path
            if not full.is_file():
                errors.append(f"DECLARATIVE_ASSET_MISSING:{group}:{rel}")
            if full.suffix == ".py" or (path.parts and path.parts[0] == "tools"):
                errors.append(f"DECLARATIVE_ASSET_EXECUTABLE_FORBIDDEN:{group}:{rel}")
    return errors


def route_errors(root: Path = ROOT, manifest_path: Path | None = None) -> list[str]:
    path = manifest_path or root / "tools/tooling-manifest.yaml"
    try:
        data = load_manifest(path)
    except Exception as exc:
        return [f"TOOL_ROUTE_MANIFEST_INVALID:{exc}"]
    tools = root / "tools"
    errors: list[str] = []

    for key in data:
        if str(key).startswith("declarative_") and key != "declarative_assets":
            errors.append(f"LEGACY_DECLARATIVE_ASSET_CLASSIFICATION_FORBIDDEN:{key}")
    if data.get("component_registries"):
        errors.append("LEGACY_EXECUTABLE_COMPONENT_REGISTRY_CLASSIFICATION_FORBIDDEN")

    groups, lifecycle, roles = _classifications(data, tools, errors)
    canonical, compatibility, retired = (
        groups["canonical"], groups["compatibility_only"], groups["retired"]
    )

    try:
        forbidden_current = _string_list(data.get("forbidden_current_paths") or [], "forbidden_current_paths")
    except ValueError as exc:
        errors.append(f"FORBIDDEN_CURRENT_PATHS_INVALID:{exc}")
        forbidden_current = []
    for name in forbidden_current:
        if Path(name).name != name:
            errors.append(f"FORBIDDEN_CURRENT_PATH_INVALID:{name}")
        elif (tools / name).exists():
            errors.append(f"FORBIDDEN_CURRENT_PATH_PRESENT:{name}")

    retired_modules = {Path(name).stem for name in retired}
    patterns: list[re.Pattern[str]] = []
    for module in sorted(retired_modules):
        patterns.extend([
            re.compile(rf"(?m)^\s*import\s+{re.escape(module)}\b"),
            re.compile(rf"(?m)^\s*from\s+{re.escape(module)}\s+import\b"),
        ])
    for name in canonical + compatibility:
        target = tools / name
        if not target.is_file():
            continue
        text = target.read_text(encoding="utf-8")
        for pattern in patterns:
            if pattern.search(text):
                prefix = "ACTIVE" if lifecycle.get(name) == "canonical" else "COMPATIBILITY"
                errors.append(f"{prefix}_TOOL_IMPORTS_RETIRED_TOOL:{name}:{pattern.pattern}")

    workflow_dir = root / ".github/workflows"
    call_re = re.compile(r"\bpython(?:3(?:\.\d+)?)?\s+tools/([A-Za-z0-9_.-]+\.py)\b")
    if workflow_dir.exists():
        for workflow in list(workflow_dir.glob("*.yml")) + list(workflow_dir.glob("*.yaml")):
            text = workflow.read_text(encoding="utf-8")
            for called in call_re.findall(text):
                role = roles.get(called)
                if role is None:
                    errors.append(f"WORKFLOW_CALLS_UNCLASSIFIED_TOOL:{workflow.relative_to(root)}:{called}")
                elif role not in EXECUTABLE_ROLES:
                    errors.append(f"WORKFLOW_CALLS_LIBRARY_TOOL:{workflow.relative_to(root)}:{called}")

    registry_raw = data.get("module_registry")
    if isinstance(registry_raw, str):
        try:
            registry = yaml.safe_load(_repo_file(root, registry_raw).read_text(encoding="utf-8")) or {}
            for module_id, module in (registry.get("modules") or {}).items():
                if not isinstance(module, dict) or module.get("lifecycle") not in {"ACTIVE", "FROZEN"}:
                    continue
                adapter = module.get("artifact_adapter") or {}
                if not isinstance(adapter, dict):
                    continue
                for port in ("build", "check", "render"):
                    raw = adapter.get(port)
                    if raw is None:
                        continue
                    name = Path(str(raw)).name
                    if roles.get(name) not in EXECUTABLE_ROLES:
                        errors.append(f"MODULE_ADAPTER_NOT_EXECUTABLE_ROLE:{module_id}.{port}:{name}:{roles.get(name)!r}")
        except Exception as exc:
            errors.append(f"MODULE_REGISTRY_ROUTE_CHECK_FAILED:{exc}")

    errors.extend(_protected_errors(data, root, lifecycle, roles))
    errors.extend(_module_input_lock_contract_errors(data, root, lifecycle, roles))
    errors.extend(_declarative_asset_errors(data, root))
    return errors


def selftest() -> None:
    with tempfile.TemporaryDirectory(prefix="qz-tool-routing-") as tmp:
        root = Path(tmp)
        tools = root / "tools"; tools.mkdir()
        (root / ".github/workflows").mkdir(parents=True)
        (root / "production/contracts").mkdir(parents=True)
        (root / "architecture/adr").mkdir(parents=True)
        adr = "architecture/adr/ADR-016.md"
        (root / adr).write_text("# synthetic\n", encoding="utf-8")
        (tools / "gate.py").write_text(
            "def validate():\n    precondition()\n    dangerous()\n    return []\n"
            "if __name__ == '__main__':\n    raise SystemExit(0)\n",
            encoding="utf-8",
        )
        (tools / "helper.py").write_text("def primitive():\n    return 1\n", encoding="utf-8")
        (tools / "public.py").write_text("if __name__ == '__main__':\n    pass\n", encoding="utf-8")
        (tools / "compat.py").write_text("if __name__ == '__main__':\n    pass\n", encoding="utf-8")
        (root / "production/contracts/artifact-job-v1.yaml").write_text(
            "module_input_lock_verification:\n  allowed_modes: [canonical-plan-reconstruction-v1]\n  enforced_by: tools/check_artifact_job.py\n",
            encoding="utf-8",
        )
        (root / "production/contracts/product.yaml").write_text(
            yaml.safe_dump({
                "protected_operations": {
                    "architecture_decision": adr,
                    "synthetic": {
                        "canonical_entry": "tools/gate.py",
                        "complete_symbol": "validate",
                        "implementation_libraries": ["tools/helper.py"],
                        "forbidden_library_complete_symbols": ["validate", "main"],
                        "forbid_library_cli": True,
                        "forbidden_paths": ["tools/old_gate.py"],
                    },
                }
            }, sort_keys=False), encoding="utf-8",
        )
        (root / "production/contracts/module-registry.yaml").write_text(
            "allowed_lifecycle: [ACTIVE]\nmodules: {}\n", encoding="utf-8"
        )
        manifest_path = tools / "tooling-manifest.yaml"

        def write_manifest(*, helper_role: str = "library", late: bool = False) -> None:
            (tools / "gate.py").write_text(
                ("def validate():\n    dangerous()\n    precondition()\n    return []\n" if late else
                 "def validate():\n    precondition()\n    dangerous()\n    return []\n")
                + "if __name__ == '__main__':\n    raise SystemExit(0)\n",
                encoding="utf-8",
            )
            entry = ["gate.py", "public.py"] + (["helper.py"] if helper_role == "entry" else [])
            library = [] if helper_role == "entry" else ["helper.py"]
            manifest_path.write_text(yaml.safe_dump({
                "version": 53,
                "policy": "explicit-routing",
                "module_registry": "production/contracts/module-registry.yaml",
                "canonical": ["gate.py", "helper.py", "public.py"],
                "compatibility_only": ["compat.py"],
                "retired": ["old_builder.py"],
                "forbidden_current_paths": ["old_gate.py"],
                "execution_roles": {
                    "entry": entry,
                    "library": library,
                    "entry_and_library": [],
                    "compatibility_entry": ["compat.py"],
                },
                "protected_operations": {
                    "architecture_decision": adr,
                    "contract": "production/contracts/product.yaml",
                    "operations": {
                        "SYNTHETIC": {
                            "contract_key": "synthetic",
                            "canonical_entry": "gate.py",
                            "implementation_libraries": ["helper.py"],
                            "forbidden_library_complete_symbols": ["validate", "main"],
                            "forbid_library_cli": True,
                            "forbidden_paths": ["old_gate.py"],
                            "required_call_order": [{
                                "function": "validate", "before": "dangerous",
                                "requires_before": ["precondition"],
                            }],
                        }
                    },
                },
                "declarative_assets": {"architecture": [adr]},
            }, sort_keys=False), encoding="utf-8")

        write_manifest()
        if route_errors(root):
            raise AssertionError("clean routing fixture rejected: " + repr(route_errors(root)))

        (tools / "unknown.py").write_text("# route\n", encoding="utf-8")
        if not any("UNCLASSIFIED_TOOL_PRESENT" in x for x in route_errors(root)):
            raise AssertionError("unclassified tool escaped")
        (tools / "unknown.py").unlink()

        write_manifest(helper_role="entry")
        if not any("PROTECTED_OPERATION_LIBRARY_ROLE_INVALID" in x for x in route_errors(root)):
            raise AssertionError("protected library relabel escaped")

        write_manifest()
        (tools / "helper.py").write_text("from x import validate\n", encoding="utf-8")
        if not any("PROTECTED_LIBRARY_FORBIDDEN_SYMBOL" in x for x in route_errors(root)):
            raise AssertionError("import/re-export aggregate escaped")

        (tools / "helper.py").write_text("def primitive():\n    return 1\nif __name__ == '__main__':\n    pass\n", encoding="utf-8")
        found = route_errors(root)
        if not any("TOOL_LIBRARY_DIRECT_CLI_ROLE_MISMATCH" in x for x in found):
            raise AssertionError("library CLI role lie escaped")
        if not any("PROTECTED_LIBRARY_DIRECT_CLI_FORBIDDEN" in x for x in found):
            raise AssertionError("protected library CLI escaped")

        (tools / "helper.py").write_text("def primitive():\n    return 1\n", encoding="utf-8")
        write_manifest(late=True)
        if not any("PROTECTED_OPERATION_PRECONDITION_TOO_LATE" in x for x in route_errors(root)):
            raise AssertionError("late protected precondition escaped")

        write_manifest()
        (root / ".github/workflows/test.yml").write_text(
            "steps:\n  - run: python tools/helper.py\n", encoding="utf-8"
        )
        if not any("WORKFLOW_CALLS_LIBRARY_TOOL" in x for x in route_errors(root)):
            raise AssertionError("workflow library route escaped")


def main() -> int:
    selftest()
    errors = route_errors(ROOT)
    if errors:
        print("\n".join(errors))
        return 1
    print("canonical tooling roles + ADR-016 protected capability graph: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
