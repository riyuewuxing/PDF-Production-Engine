#!/usr/bin/env python3
"""Single executable entry for preserved Teaching Demo process-evaluation governance.

Validation remains decomposed across common/policy/execution/regression libraries.
This file alone owns CLI composition; no second ``teaching_demo_process_eval_core``
complete entry is retained in the current tree.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from teaching_demo_process_eval_common import GateError
from teaching_demo_process_eval_policy import validate
from teaching_demo_process_eval_regression import selftest


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-root", default=".")
    parser.add_argument("--selftest", action="store_true")
    parser.add_argument("--no-git-history", action="store_true")
    parser.add_argument("--json", action="store_true", help="print the control-gate result as JSON")
    args = parser.parse_args()
    try:
        if args.selftest:
            selftest()
            return 0
        result = validate(Path(args.repo_root).resolve(), verify_git_history=not args.no_git_history)
    except (GateError, AssertionError) as exc:
        print(f"PROCESS_EVALUATION_CONTROL_GATE_FAIL {exc}")
        return 1
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
        return 0
    print(
        "PROCESS_EVALUATION_CONTROL_GATE_PASS "
        f"pool_topics={result['pool_topics']} slot_records={result['slot_records']} "
        f"consumed_slots={result['consumed_slots']} remaining_slots={result['remaining_slots']} "
        f"maturity={result['process_maturity_claim']} pool_sha256={result['pool_sha256']}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
