#!/usr/bin/env python3
"""Architecture Foundation v1 project-state gate. No network/LLM calls."""
from __future__ import annotations
from datetime import date
from pathlib import Path

from artifact_foundation import ROOT, load_yaml, safe_repo_path

STATE = ROOT / "CURRENT_STATE.yaml"
ARCH = ROOT / "architecture/README.md"
MIGRATION = ROOT / "architecture/MIGRATION.md"
MIGRATION_RECORD = ROOT / "production/architecture-foundation-v1-migration.yaml"
REGISTRY = ROOT / "production/contracts/module-registry-v1.yaml"
ARTIFACT = ROOT / "production/contracts/artifact-job-v1.yaml"
LEDGER = ROOT / "production/contracts/execution-ledger-v1.yaml"
PROVENANCE = ROOT / "production/contracts/repository-provenance-snapshot-v1.yaml"
QUAL = ROOT / "production/contracts/system-qualification-v1.yaml"
EFFICIENCY = ROOT / "production/resource-build-efficiency-policy-v1.yaml"
TOOLING = ROOT / "tools/tooling-manifest.yaml"
RESOURCE_RULES = ROOT / "RESOURCE_BUILD_RULES.md"
PROCESS_ADR = ROOT / "architecture/adr/ADR-009-process-as-product-and-agent-portability.md"
PROVENANCE_ADR = ROOT / "architecture/adr/ADR-010-durable-repository-provenance.md"
REUSE_ADR = ROOT / "architecture/adr/ADR-011-reuse-fingerprint-vs-audit-snapshot.md"

SCOPED_RULES = {
    "teacher": ROOT / "content/job-search/teacher/AGENTS.md",
    "teaching_demo": ROOT / "content/job-search/teacher/interview/teaching-demo/AGENTS.md",
    "structured_interview": ROOT / "content/job-search/teacher/interview/structured/AGENTS.md",
    "defense": ROOT / "content/job-search/teacher/interview/defense/AGENTS.md",
    "self_introduction": ROOT / "content/job-search/teacher/self-introduction/AGENTS.md",
    "resume_materials": ROOT / "content/job-search/teacher/resume-materials/AGENTS.md",
    "written_exam": ROOT / "content/job-search/teacher/written-exam/AGENTS.md",
    "position_research": ROOT / "content/job-search/teacher/position-research/AGENTS.md",
}
REQUIRED_MODULE_IDS = {
    "teacher_teaching_demo", "teacher_structured_interview", "teacher_defense",
    "teacher_self_introduction", "teacher_resume_materials", "teacher_written_exam",
    "teacher_position_research",
}
REQUIRED_FOUNDATION_TOOLS = {
    "artifact_foundation.py", "provenance_snapshot.py", "init_artifact_job.py",
    "manage_artifact_job.py", "lock_artifact_input_plan.py", "check_artifact_job.py",
    "check_artifact_provenance.py", "check_execution_ledger.py",
    "check_private_actions_boundary.py", "check_project_state.py", "check_tooling_routes.py",
    "check_generalization_architecture.py", "run_acceptance.py",
}
LIFECYCLE_VOCAB = {"ACTIVE", "FROZEN", "DEFERRED", "EXTERNAL", "RETIRED"}
CANONICAL_ARTIFACT_STATES = (
    "JOB_CREATED", "INPUTS_LOCKED", "BLOCKS_ACCEPTED", "BUILT",
    "MACHINE_VERIFIED", "HUMAN_ACCEPTED", "PUBLISHED",
)


def req(ok: bool, msg: str, errors: list[str]) -> None:
    if not ok:
        errors.append(msg)


def main() -> int:
    errors: list[str] = []
    required = [
        STATE, ARCH, MIGRATION, MIGRATION_RECORD, REGISTRY, ARTIFACT, LEDGER, PROVENANCE,
        QUAL, EFFICIENCY, TOOLING, RESOURCE_RULES, PROCESS_ADR, PROVENANCE_ADR, REUSE_ADR,
        *SCOPED_RULES.values(),
    ]
    for path in required:
        req(path.is_file(), f"required architecture file missing: {path.relative_to(ROOT)}", errors)
    if errors:
        print("\n".join(errors)); return 1

    state = load_yaml(STATE); registry = load_yaml(REGISTRY); artifact = load_yaml(ARTIFACT)
    ledger = load_yaml(LEDGER); provenance_contract = load_yaml(PROVENANCE)
    qualification = load_yaml(QUAL); efficiency = load_yaml(EFFICIENCY)
    tooling = load_yaml(TOOLING); migration = load_yaml(MIGRATION_RECORD)

    state_version = state.get("version")
    req(isinstance(state_version, int) and state_version >= 22, "CURRENT_STATE version must be integer >= 22", errors)
    req(state.get("authority") == "current-project-state", "CURRENT_STATE authority drift", errors)
    try:
        req(date.fromisoformat(str(state.get("as_of"))) <= date.today(), "CURRENT_STATE as_of is in future", errors)
    except ValueError:
        errors.append("CURRENT_STATE as_of must be ISO date")
    arch_state = state.get("architecture") or {}
    req(arch_state.get("foundation_version") == 1, "architecture foundation version drift", errors)
    req(arch_state.get("status") == "RELEASED_MAIN_CANONICAL", "architecture must remain released on main", errors)
    req(arch_state.get("definition") == "architecture/README.md", "architecture definition pointer drift", errors)
    essence = state.get("project_essence") or {}
    req(essence.get("authority") == "architecture/adr/ADR-009-process-as-product-and-agent-portability.md", "process-as-product pointer drift", errors)
    req((state.get("module_registry") or {}) == {"authority": "production/contracts/module-registry-v1.yaml"}, "CURRENT_STATE must not duplicate module lifecycle", errors)

    vcs = state.get("version_control") or {}; policy = vcs.get("branch_policy") or {}
    req(vcs.get("canonical_branch") == "main", "canonical branch must be main", errors)
    req((vcs.get("default_branch") or {}).get("status") == "CANONICAL", "main default branch must be CANONICAL", errors)
    req(policy.get("main_is_single_long_lived_authority") is True, "main single-authority policy missing", errors)
    req(policy.get("feature_fix_branches_short_lived") is True, "short-lived branch policy missing", errors)
    req(policy.get("force_update") == "forbidden", "force update must remain forbidden", errors)

    for number in range(1, 12):
        req(len(list((ROOT / "architecture/adr").glob(f"ADR-{number:03d}-*.md"))) == 1, f"ADR-{number:03d} missing or duplicated", errors)
    for path in (PROCESS_ADR, PROVENANCE_ADR, REUSE_ADR):
        req("Status: ACCEPTED" in path.read_text(encoding="utf-8"), f"{path.name} must remain ACCEPTED", errors)

    private_actions = ((state.get("runtime_constraints") or {}).get("private_github_hosted_actions") or {})
    req(private_actions.get("forbidden_as_normal_dependency") is True, "private Actions must remain forbidden", errors)
    req(private_actions.get("active_workflows_on_main") == 0, "CURRENT_STATE must record zero active private workflows", errors)
    workflow_dir = ROOT / ".github/workflows"
    active_workflows = list(workflow_dir.glob("*.yml")) + list(workflow_dir.glob("*.yaml")) if workflow_dir.exists() else []
    req(not active_workflows, "private GitHub Actions workflow exists while forbidden", errors)

    canonical = set(tooling.get("canonical") or []); compatibility = set(tooling.get("compatibility_only") or []); retired = set(tooling.get("retired") or [])
    req(not (canonical & compatibility or canonical & retired or compatibility & retired), "tool lifecycle groups must be disjoint", errors)
    req(REQUIRED_FOUNDATION_TOOLS <= canonical, "one or more foundation tools left canonical routing", errors)
    active_group = set((tooling.get("lifecycle_groups") or {}).get("ACTIVE") or [])
    req(REQUIRED_FOUNDATION_TOOLS <= active_group, "one or more foundation tools left ACTIVE group", errors)
    for tool in REQUIRED_FOUNDATION_TOOLS:
        req((ROOT / "tools" / tool).is_file(), f"foundation tool missing: tools/{tool}", errors)
    arch_assets = set((tooling.get("declarative_assets") or {}).get("architecture") or [])
    for path in (PROVENANCE_ADR, REUSE_ADR):
        req(path.relative_to(ROOT).as_posix() in arch_assets, f"{path.name} missing from tooling manifest", errors)
    foundation_assets = set((tooling.get("declarative_assets") or {}).get("artifact-foundation-contracts") or [])
    req(PROVENANCE.relative_to(ROOT).as_posix() in foundation_assets, "repository provenance contract missing from tooling manifest", errors)

    req(registry.get("authority") == "module-lifecycle-and-execution", "module registry authority drift", errors)
    req(set(registry.get("allowed_lifecycle") or []) == LIFECYCLE_VOCAB, "module lifecycle vocabulary drift", errors)
    modules = registry.get("modules") or {}
    req(REQUIRED_MODULE_IDS <= set(modules), "one or more teacher module entries missing", errors)
    for module_id, item in modules.items():
        if not isinstance(item, dict):
            errors.append(f"{module_id}: registry item must be mapping"); continue
        lifecycle = item.get("lifecycle"); req(lifecycle in LIFECYCLE_VOCAB, f"{module_id}: invalid lifecycle {lifecycle!r}", errors)
        entry = item.get("entry")
        if entry:
            try: req(safe_repo_path(ROOT, entry, must_exist=True).exists(), f"{module_id}: entry missing: {entry}", errors)
            except ValueError as exc: errors.append(f"{module_id}: {exc}")
        contract_path = item.get("module_contract")
        if contract_path:
            try: req(safe_repo_path(ROOT, contract_path, must_exist=True).is_file(), f"{module_id}: contract missing: {contract_path}", errors)
            except ValueError as exc: errors.append(f"{module_id}: {exc}")
        adapter = item.get("artifact_adapter")
        if isinstance(adapter, dict):
            expected_group = canonical if lifecycle in {"ACTIVE", "FROZEN"} else compatibility if lifecycle == "DEFERRED" else retired if lifecycle == "RETIRED" else set()
            for role in ("build", "check", "render"):
                tool_path = adapter.get(role)
                if tool_path is None: continue
                req(isinstance(tool_path, str) and tool_path.startswith("tools/"), f"{module_id}.{role}: adapter must be tools/* or null", errors)
                if isinstance(tool_path, str) and tool_path.startswith("tools/"):
                    name = Path(tool_path).name
                    req((ROOT / tool_path).is_file(), f"{module_id}.{role}: adapter file missing: {tool_path}", errors)
                    if expected_group: req(name in expected_group, f"{module_id}.{role}: adapter classification conflicts with lifecycle", errors)
    position = modules.get("teacher_position_research") or {}
    req(position.get("lifecycle") == "RETIRED" and position.get("execution_forbidden") is True, "Position Research must remain RETIRED/forbidden", errors)
    external = registry.get("external_systems") or {}
    req((external.get("recruitment_intelligence") or {}).get("lifecycle") == "EXTERNAL", "Recruitment Intelligence must be EXTERNAL", errors)
    req((external.get("pdf_production_engine") or {}).get("lifecycle") == "EXTERNAL", "PDF Engine must be EXTERNAL", errors)

    states = tuple(artifact.get("states") or [])
    req(states == CANONICAL_ARTIFACT_STATES, "Artifact lifecycle must remain canonical seven states", errors)
    req(artifact.get("authority") == "artifact-lifecycle", "Artifact contract authority drift", errors)
    req((artifact.get("state_authority") or {}).get("declared_state_must_equal_projection") is True, "Artifact state must be ledger projection", errors)
    req((artifact.get("binding") or {}).get("path_policy") == "repository-relative-only", "Artifact path policy drift", errors)
    build_prov = artifact.get("build_provenance") or {}
    req(build_prov.get("fingerprint_algorithm") == "sha256-canonical-json-v1", "Artifact fingerprint algorithm drift", errors)
    req("source_snapshot_binding" in set(build_prov.get("required_fields") or []), "new Artifact jobs must require source_snapshot_binding", errors)
    req(build_prov.get("source_snapshot_is_parallel_audit_record") is True, "source snapshot must remain a parallel audit record", errors)
    req(build_prov.get("source_snapshot_dependency_identity_must_not_be_double_counted_in_fingerprint") is True, "snapshot dependency identity must not be double-counted", errors)
    req(set(build_prov.get("fingerprint_exempt_input_kinds") or []) == {"input_plan"}, "input_plan fingerprint exemption drift", errors)
    req("source_snapshot_binding" not in set(build_prov.get("fingerprint_basis") or []), "snapshot audit binding leaked back into reuse fingerprint", errors)
    snapshot_policy = build_prov.get("source_snapshot") or {}
    req(snapshot_policy.get("contract") == "production/contracts/repository-provenance-snapshot-v1.yaml", "Artifact provenance snapshot contract pointer drift", errors)
    req(snapshot_policy.get("historical_verification_must_not_require_current_path_bytes") is True, "historical provenance must not depend on current paths", errors)
    req(snapshot_policy.get("legacy_missing_snapshot_backfill") == "forbidden", "legacy snapshot backfill must be forbidden", errors)
    req((artifact.get("verification_modes") or {}).get("live", {}).get("checker") == "tools/check_artifact_job.py", "live checker pointer drift", errors)
    req((artifact.get("verification_modes") or {}).get("historical", {}).get("checker") == "tools/check_artifact_provenance.py", "historical checker pointer drift", errors)
    req((artifact.get("qualification") or {}).get("part_of_delivery_state_machine") is False, "Qualification leaked into delivery", errors)

    req(provenance_contract.get("authority") == "durable-repository-provenance", "repository provenance contract authority drift", errors)
    snap = provenance_contract.get("snapshot") or {}
    req(snap.get("schema_id") == "qiuzhidaren-repository-snapshot-v1", "repository snapshot schema drift", errors)
    dep = snap.get("dependency_identity") or {}; record = snap.get("record_identity") or {}
    req(dep.get("algorithm") == "sha256-canonical-json-v1" and dep.get("excludes_source_commit") is True, "dependency identity policy drift", errors)
    req(record.get("algorithm") == "sha256-canonical-json-v1" and record.get("includes_source_commit") is True, "snapshot record identity policy drift", errors)
    relation = provenance_contract.get("artifact_fingerprint_relation") or {}
    req(relation.get("dependency_identity_is_double_counted_in_input_fingerprint") is False, "provenance contract reintroduced duplicate fingerprint identity", errors)
    req(snap.get("immutable_content_addressed") is True, "repository snapshots must remain content-addressed", errors)
    req((provenance_contract.get("live_execution_verification") or {}).get("source_commit_path_proof", {}).get("engine_private_repository_access_required") is False, "Engine must not need private repository access", errors)
    req((provenance_contract.get("historical_verification") or {}).get("current_path_bytes_required") is False, "historical verification must not require current path bytes", errors)
    req((provenance_contract.get("migration") or {}).get("synthetic_backfill_for_old_jobs") == "forbidden", "old jobs must not receive synthetic provenance backfill", errors)

    req(ledger.get("append_only") is True, "execution ledger must be append-only", errors)
    req(tuple(ledger.get("lifecycle_transition_types") or []) == states, "ledger lifecycle sequence must match Artifact contract", errors)
    req((ledger.get("legacy_missing_instrumentation") or {}).get("may_backfill_synthetic_events") is False, "legacy event backfill must remain forbidden", errors)
    req(qualification.get("separate_from_delivery") is True, "system qualification must remain separate", errors)
    req((qualification.get("series_policy") or {}).get("process_evaluation_full_cycle_limit") == 3, "qualification cycle limit must be 3", errors)

    process = efficiency.get("process_as_product") or {}; loop = efficiency.get("feedback_loop") or {}
    req(efficiency.get("authority") == "artifact-production-efficiency", "efficiency authority drift", errors)
    req(process.get("primary_product") == "reusable_agent_operable_process", "process must remain primary product", errors)
    req(process.get("single_artifact_pass_proves_system_maturity") is False, "single Artifact PASS must not prove maturity", errors)
    req(loop.get("target_full_generation_review_cycles") == 1, "process target cycle drift", errors)
    req(loop.get("max_full_generation_review_cycles") == 3, "process max cycle count must be 3", errors)
    req(loop.get("fourth_full_cycle") == "forbidden", "fourth process-evaluation cycle must remain forbidden", errors)

    for name, path in SCOPED_RULES.items():
        req("module-registry-v1.yaml" in path.read_text(encoding="utf-8"), f"{name}: scoped rules must reference module registry", errors)
    req("live recruitment execution route" in SCOPED_RULES["position_research"].read_text(encoding="utf-8"), "Position Research retirement boundary missing", errors)
    resource_text = RESOURCE_RULES.read_text(encoding="utf-8")
    req("FINAL_SCORE_PASS" not in resource_text, "legacy FINAL_SCORE_PASS leaked into active rules", errors)
    req("JOB_CREATED → INPUTS_LOCKED → BLOCKS_ACCEPTED → BUILT → MACHINE_VERIFIED → HUMAN_ACCEPTED → PUBLISHED" in resource_text, "unified Artifact lifecycle missing", errors)

    failure = (state.get("historical_failures") or {}).get("teaching_demo_efficiency_round1_mechanical_energy") or {}
    req(failure.get("status") == "STOP_LIMIT", "historical Round1 STOP_LIMIT must remain frozen", errors)
    req(failure.get("observed_generation_review_cycles") == 5, "historical Round1 cycle count must remain 5", errors)
    req(failure.get("quality_pass") is False and failure.get("efficiency_pass") is False, "historical failed experiment cannot become PASS", errors)
    req(failure.get("receipts_retroactive_backfill") == "forbidden", "retroactive receipt backfill must remain forbidden", errors)
    req((state.get("teacher_product_line") or {}).get("product_round3") == "forbidden", "Product Round3 must remain forbidden", errors)
    req(migration.get("status") == "RELEASED_MAIN_CANONICAL", "architecture migration record must remain released", errors)
    req((migration.get("verification") or {}).get("github_ci_pass_claimed") is False, "migration must not fabricate GitHub CI PASS", errors)

    durable = state.get("durable_repository_provenance") or {}
    req(durable.get("architecture_decision") == "architecture/adr/ADR-010-durable-repository-provenance.md", "CURRENT_STATE durable provenance ADR pointer drift", errors)
    req(durable.get("reuse_identity_decision") == "architecture/adr/ADR-011-reuse-fingerprint-vs-audit-snapshot.md", "CURRENT_STATE reuse identity ADR pointer drift", errors)
    req(durable.get("contract") == "production/contracts/repository-provenance-snapshot-v1.yaml", "CURRENT_STATE durable provenance contract pointer drift", errors)
    req(durable.get("engine_private_repository_access_required") is False, "CURRENT_STATE must preserve credential-free Engine boundary", errors)
    req(durable.get("source_commit_is_cache_key") is False, "source_commit must not become a cache key", errors)
    req(durable.get("repository_native_runtime_validation") == "NOT_RUN", "do not fabricate runtime validation", errors)

    if errors:
        print("FAIL: project architecture state")
        for error in errors: print("- " + error)
        return 1
    print("PASS: Architecture Foundation v1 + durable provenance project state")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())