"""Normalize imported structured-interview reference questions.

Normalization is deterministic and source-preserving. It does not infer missing official
facts or invent taxonomy labels. Missing required review metadata remains needs-review.
"""
from __future__ import annotations
import argparse,hashlib,json,re,sys,unicodedata
from pathlib import Path

TYPES={f'T{i}' for i in range(1,10)}
RISK_MAP={'普通':'normal','一般':'normal','normal':'normal','冲突':'conflict','conflict':'conflict','安全':'safety','safety':'safety','师德':'ethics-compliance','合规':'ethics-compliance','ethics-compliance':'ethics-compliance','unknown':'unknown','未知':'unknown'}
USAGE={'verbatim','paraphrased','summary','derived-scenario','synthetic','user-provided'}

def parse_args():
    p=argparse.ArgumentParser(description='Normalize imported structured-interview JSONL references.')
    p.add_argument('input',help='Imported JSONL path.')
    p.add_argument('--output',required=True,help='Normalized JSONL output.')
    return p.parse_args()

def clean(v): return re.sub(r'\s+',' ',str(v or '').replace('\ufeff',' ')).strip()

def norm_question(q):
    text=unicodedata.normalize('NFKC',clean(q)).lower()
    return ''.join(ch for ch in text if ch.isalnum())

def key(q): return hashlib.sha256(norm_question(q).encode('utf-8')).hexdigest()[:16]

def list_value(v):
    if isinstance(v,list): raw=v
    else: raw=re.split(r'[,，;；/、|]',clean(v)) if clean(v) else []
    out=[]
    for item in raw:
        x=clean(item)
        if x and x not in out: out.append(x)
    return out

def normalize_type(v):
    x=clean(v).upper().replace('T0','T')
    return x if x in TYPES else ''

def normalize_record(r):
    q=clean(r.get('question') or r.get('stem'))
    primary=normalize_type(r.get('primary_type'))
    secondary=[x for x in (normalize_type(v) for v in list_value(r.get('secondary_types'))) if x and x!=primary]
    usage=clean(r.get('source_usage')).lower()
    risk=RISK_MAP.get(clean(r.get('risk_level')).lower(),RISK_MAP.get(clean(r.get('risk_level')),'unknown'))
    source_id=clean(r.get('source_id'))
    rid=clean(r.get('id')) or ('REF-'+key(q) if q else '')
    status='ready' if q and source_id and usage in USAGE and primary in TYPES else 'needs-review'
    return {
        'id':rid,
        'status':status,
        'question':q,
        'normalized_question':norm_question(q),
        'exact_key':key(q) if q else '',
        'source_id':source_id,
        'source_usage':usage,
        'profile_id':clean(r.get('profile_id')),
        'primary_type':primary,
        'secondary_types':secondary,
        'risk_level':risk,
        'tags':list_value(r.get('tags')),
        'source_path':clean(r.get('source_path')),
        'source_type':clean(r.get('source_type')),
        'notes':clean(r.get('notes')),
    }

def load(path):
    out=[]
    with path.open('r',encoding='utf-8-sig') as f:
        for n,line in enumerate(f,1):
            if not line.strip(): continue
            obj=json.loads(line)
            if not isinstance(obj,dict): raise ValueError(f'{path}:{n}: record must be an object')
            out.append(obj)
    return out

def main():
    args=parse_args()
    try:
        rows=[normalize_record(r) for r in load(Path(args.input))]
        out=Path(args.output); out.parent.mkdir(parents=True,exist_ok=True)
        with out.open('w',encoding='utf-8') as f:
            for row in rows: f.write(json.dumps(row,ensure_ascii=False)+'\n')
    except Exception as exc:
        print(f'STRUCTURED_REFERENCE_NORMALIZE_FAIL: {exc}',file=sys.stderr); return 1
    ready=sum(x['status']=='ready' for x in rows)
    print(f'structured reference normalize: PASS records={len(rows)} ready={ready} needs_review={len(rows)-ready}')
    return 0

if __name__=='__main__': raise SystemExit(main())
