from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

from physics_figures import available_figures, figure_tex, selftest as figure_registry_selftest

CORE = {
    'PGF/TikZ': 'tikz.sty',
    'PGFPlots': 'pgfplots.sty',
    'CircuiTikZ': 'circuitikz.sty',
    'tkz-euclide': 'tkz-euclide.sty',
    'tikz-3dplot': 'tikz-3dplot.sty',
}

OPTIONAL = {
    'tikz-optics': 'tikzlibraryoptics.code.tex',
    'tikz-mirror-lens': 'tikz-mirror-lens.sty',
    'optikz': 'optikz.sty',
}


def kpsewhich(name):
    p = subprocess.run(['kpsewhich', name], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    return p.stdout.strip() if p.returncode == 0 else ''


def smoke_tex() -> str:
    registered = []
    for name in available_figures():
        tex = figure_tex(name)
        registered.append(r'\section*{registry: ' + name.replace('_', r'\_') + '}' + '\n' + tex)
    return r'''\documentclass[UTF8,10pt]{article}
\usepackage{ctex}
\usepackage{geometry,xcolor,tcolorbox}
\usepackage{tikz}
\usepackage{pgfplots}
\usepackage[american]{circuitikz}
\usepackage{tkz-euclide}
\usepackage{tikz-3dplot}
\usetikzlibrary{arrows.meta,positioning,calc,decorations.pathmorphing,patterns}
\tcbuselibrary{skins,breakable}
\pgfplotsset{compat=1.18}
\geometry{a4paper,margin=2cm}
\newtcolorbox{figurepanel}[1]{enhanced,colback=white,colframe=black!18,boxrule=.55pt,arc=2mm,left=9pt,right=9pt,top=6pt,bottom=7pt,title=\sffamily\bfseries #1,colbacktitle=black!5,coltitle=black,fonttitle=\small,before skip=7pt,after skip=8pt}
\tikzset{qzvector/.style={-{Latex[length=2.6mm]},line width=.8pt},qzsurface/.style={line width=.75pt},qzobject/.style={draw=black!75,fill=black!5,line width=.75pt},qzlabel/.style={fill=white,fill opacity=.9,text opacity=1,inner sep=1.5pt}}
\begin{document}
\section*{generic physics figure toolchain smoke}
\begin{tikzpicture}
\draw[-latex] (0,0)--(1.5,0) node[right,qzlabel] {$v_1$};
\end{tikzpicture}
\begin{tikzpicture}
\begin{axis}[width=5cm,height=3.4cm,axis lines=middle,samples=20]
\addplot[domain=0:2] {x^2};
\end{axis}
\end{tikzpicture}
\begin{tikzpicture}
\tkzDefPoints{0/0/A,2/0/B,1/1/C}
\tkzDrawPolygon(A,B,C)
\end{tikzpicture}
\tdplotsetmaincoords{60}{110}
\begin{tikzpicture}[tdplot_main_coords]
\draw[-latex] (0,0,0)--(1,0,0);
\draw[-latex] (0,0,0)--(0,1,0);
\draw[-latex] (0,0,0)--(0,0,1);
\end{tikzpicture}
''' + '\n'.join(registered) + r'''
\end{document}
'''


def compile_smoke():
    if not shutil.which('xelatex'):
        print('xelatex missing')
        return False
    figure_registry_selftest()
    with tempfile.TemporaryDirectory(prefix='qz-figure-smoke-') as tmp:
        tmpdir = Path(tmp)
        (tmpdir / 'smoke.tex').write_text(smoke_tex(), encoding='utf-8')
        p = subprocess.run(
            ['xelatex', '-interaction=nonstopmode', '-halt-on-error', 'smoke.tex'],
            cwd=tmpdir,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
        )
        if p.returncode:
            print('generic figure compile smoke FAILED')
            print(p.stdout[-6000:])
            return False
        pdf = tmpdir / 'smoke.pdf'
        if not pdf.exists() or pdf.stat().st_size < 5000:
            print('generic figure compile smoke produced invalid PDF')
            return False
    print(f'generic figure compile smoke: PASS ({len(available_figures())} registered components)')
    return True


def main():
    if not shutil.which('kpsewhich'):
        print('kpsewhich missing: TeX Live is not installed')
        return 1

    missing = []
    for label, filename in CORE.items():
        path = kpsewhich(filename)
        print(f'core {label}: {path or "MISSING"}')
        if not path:
            missing.append(f'{label} ({filename})')

    for label, filename in OPTIONAL.items():
        path = kpsewhich(filename)
        print(f'optional {label}: {path or "not installed"}')

    if missing:
        print('missing core figure packages: ' + ', '.join(missing))
        return 1
    if not compile_smoke():
        return 1

    print('physics figure core toolchain and all registered components compile-tested')
    return 0


if __name__ == '__main__':
    sys.exit(main())
