"""Discover every regression fixture and run the generic suite.

Coverage is declared by capability tags, never by lesson names. The suite must
retain an unrelated generalization fixture and multiple heterogeneous capability
families so one concrete lesson cannot masquerade as system generality.
"""
from __future__ import annotations
import argparse,tempfile
from pathlib import Path
from build_regression_case import build_case
from check_skeleton_density import check_case as check_skeleton_density_case
from regression_case import discover_cases,load_case,selftest,validate_case

MIN_COVERAGE_TAGS=4

def suite_structure_errors(cases:list[Path])->list[str]:
    errors=[]
    if len(cases)<4:
        errors.append(f'REGRESSION_SUITE_TOO_SMALL: need >=4 fixtures, got {len(cases)}'); return errors
    generalization=[]; ordinary=[]; seen_ids={}; coverage=set()
    for case in cases:
        cfg,_,_=load_case(case); case_id=str(cfg.get('case_id') or '')
        if not case_id: errors.append(f'REGRESSION_CASE_ID_MISSING: {case}')
        elif case_id in seen_ids: errors.append(f'REGRESSION_CASE_ID_DUPLICATE: {case_id}: {seen_ids[case_id]} + {case}')
        else: seen_ids[case_id]=case
        contract=cfg.get('regression_contract') or {}; tags=contract.get('coverage_tags') or []
        if not isinstance(tags,list) or not tags or not all(isinstance(x,str) and x for x in tags): errors.append(f'REGRESSION_COVERAGE_TAGS_MISSING: {case}')
        else: coverage.update(tags)
        if contract.get('generalization_fixture'):
            generalization.append(case)
            if not cfg.get('not_formal_delivery'): errors.append(f'GENERALIZATION_FIXTURE_MUST_BE_NONFORMAL: {case}')
        else: ordinary.append(case)
    if not generalization: errors.append('GENERALIZATION_FIXTURE_MISSING')
    if not ordinary: errors.append('NON_GENERALIZATION_FIXTURE_MISSING')
    if len(coverage)<MIN_COVERAGE_TAGS: errors.append(f'REGRESSION_HETEROGENEITY_TOO_LOW: {len(coverage)}<{MIN_COVERAGE_TAGS}: {sorted(coverage)}')
    return errors

def suite_selftest():
    with tempfile.TemporaryDirectory(prefix='qz-regression-suite-') as tmp:
        root=Path(tmp); cases=[]
        specs=[('a','A',True,'generic-architecture'),('b','B',False,'apparatus-circuit'),('c','C',False,'graph-data'),('d','D',False,'geometry-optics')]
        for dirname,cid,general,tag in specs:
            d=root/dirname; d.mkdir(); p=d/'case.yaml'; p.write_text(f'case_id: {cid}\nnot_formal_delivery: true\nregression_contract:\n  generalization_fixture: {str(general).lower()}\n  coverage_tags: [{tag}]\n',encoding='utf-8'); cases.append(p)
        clean=suite_structure_errors(cases)
        if clean: raise AssertionError('clean heterogeneous suite rejected: '+repr(clean))
        collapsed=cases[:3]
        found=suite_structure_errors(collapsed)
        if not any('SUITE_TOO_SMALL' in x or 'HETEROGENEITY_TOO_LOW' in x for x in found): raise AssertionError('collapsed coverage escaped suite gate')

def main()->int:
    parser=argparse.ArgumentParser(); parser.add_argument('--check-only',action='store_true'); args=parser.parse_args()
    selftest(); suite_selftest(); cases=discover_cases()
    if not cases: raise SystemExit('no regression case manifests found')
    structure=suite_structure_errors(cases)
    if structure: raise SystemExit('\n'.join(structure))
    for case in cases:
        errors=validate_case(case)
        if errors: raise SystemExit(str(case)+'\n'+'\n'.join(errors))
        print(f'regression contract PASS: {case}')
        if check_skeleton_density_case(str(case))!=0: raise SystemExit(f'regression skeleton density FAIL: {case}')
        if not args.check_only: build_case(case)
    generalization_count=sum(1 for case in cases if (load_case(case)[0].get('regression_contract') or {}).get('generalization_fixture'))
    coverage=sorted({tag for case in cases for tag in ((load_case(case)[0].get('regression_contract') or {}).get('coverage_tags') or [])})
    print(f'generic regression suite: PASS ({len(cases)} case(s), {generalization_count} generalization fixture(s), coverage={coverage})'); return 0

if __name__=='__main__': raise SystemExit(main())
