"""Import heterogeneous teacher structured-interview reference questions to JSONL.

Adapted-design after prior-art review; implementation is independent and intentionally
small. It imports records only and never infers missing exam facts or question types.
"""
from __future__ import annotations
import argparse,csv,json,re,sys
from pathlib import Path
import yaml

SUPPORTED={'.md','.markdown','.txt','.csv','.jsonl','.yaml','.yml'}
META=re.compile(r'^\s*@([A-Za-z0-9_-]+)\s*[:=]\s*(.*?)\s*$')
SPLIT=re.compile(r'^\s*---+\s*$')
LIST_FIELDS={'secondary_types','tags'}

def parse_args():
    p=argparse.ArgumentParser(description='Import structured-interview reference questions to JSONL.')
    p.add_argument('input',nargs='+',help='Input file(s) or directories.')
    p.add_argument('--output',required=True,help='Output JSONL path.')
    return p.parse_args()

def discover(inputs):
    out=[]
    for raw in inputs:
        p=Path(raw)
        if p.is_dir(): out.extend(x for x in sorted(p.rglob('*')) if x.is_file() and x.suffix.lower() in SUPPORTED)
        elif p.is_file() and p.suffix.lower() in SUPPORTED: out.append(p)
        else: raise FileNotFoundError(f'unsupported or missing input: {p}')
    if not out: raise FileNotFoundError('no supported reference files found')
    return out

def clean(value):
    return re.sub(r'\s+',' ',str(value or '').replace('\ufeff',' ')).strip()

def list_value(value):
    if isinstance(value,list): return [clean(x) for x in value if clean(x)]
    return [x.strip() for x in re.split(r'[,，;；/、|]',clean(value)) if x.strip()]

def normalize_record(record,path):
    out={str(k).strip():v for k,v in record.items() if str(k).strip()}
    if 'stem' in out and 'question' not in out: out['question']=out.pop('stem')
    out['question']=clean(out.get('question'))
    for field in LIST_FIELDS:
        if field in out: out[field]=list_value(out[field])
    out.setdefault('source_path',str(path))
    out.setdefault('source_type',path.suffix.lower().lstrip('.'))
    return out

def markdown_blocks(text):
    blocks=[]; current=[]
    for line in text.replace('\ufeff','').splitlines():
        if SPLIT.match(line):
            if any(x.strip() for x in current): blocks.append(current)
            current=[]
        else: current.append(line)
    if any(x.strip() for x in current): blocks.append(current)
    return blocks

def parse_markdown(path):
    items=[]
    for block in markdown_blocks(path.read_text(encoding='utf-8')):
        meta={}; question=[]
        for line in block:
            m=META.match(line)
            if m: meta[m.group(1)]=m.group(2)
            elif line.strip() and not line.lstrip().startswith('#'): question.append(line.strip())
        meta['question']=' '.join(question)
        rec=normalize_record(meta,path)
        if rec['question']: items.append(rec)
    return items

def parse_csv(path):
    with path.open('r',encoding='utf-8-sig',newline='') as f:
        return [normalize_record(dict(row),path) for row in csv.DictReader(f)]

def parse_jsonl(path):
    out=[]
    with path.open('r',encoding='utf-8-sig') as f:
        for n,line in enumerate(f,1):
            if not line.strip(): continue
            obj=json.loads(line)
            if not isinstance(obj,dict): raise ValueError(f'{path}:{n}: JSONL record must be an object')
            out.append(normalize_record(obj,path))
    return out

def parse_yaml(path):
    obj=yaml.safe_load(path.read_text(encoding='utf-8'))
    if isinstance(obj,dict) and isinstance(obj.get('items'),list): obj=obj['items']
    if isinstance(obj,dict): obj=[obj]
    if not isinstance(obj,list) or not all(isinstance(x,dict) for x in obj): raise ValueError(f'{path}: YAML must be mapping/list or items:list')
    return [normalize_record(x,path) for x in obj]

def parse_file(path):
    ext=path.suffix.lower()
    if ext in {'.md','.markdown','.txt'}: return parse_markdown(path)
    if ext=='.csv': return parse_csv(path)
    if ext=='.jsonl': return parse_jsonl(path)
    if ext in {'.yaml','.yml'}: return parse_yaml(path)
    raise ValueError(f'unsupported file: {path}')

def main():
    args=parse_args()
    try:
        records=[]
        for path in discover(args.input): records.extend(parse_file(path))
        output=Path(args.output); output.parent.mkdir(parents=True,exist_ok=True)
        with output.open('w',encoding='utf-8') as f:
            for rec in records: f.write(json.dumps(rec,ensure_ascii=False)+'\n')
    except Exception as exc:
        print(f'STRUCTURED_REFERENCE_IMPORT_FAIL: {exc}',file=sys.stderr); return 1
    print(f'structured reference import: PASS records={len(records)} output={args.output}')
    return 0

if __name__=='__main__': raise SystemExit(main())
