#!/usr/bin/env python3
"""Deterministically publish the final Yunnan teacher-defense material pack.

The publisher is scoped to teacher/interview/defense. It does not call an LLM/API,
does not rewrite the teaching-demo Page-to-Plan assets, and does not infer exam rules.
"""
from __future__ import annotations

import argparse
import html
import re
import subprocess
from pathlib import Path

import yaml

try:
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.platypus import HRFlowable, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
except ImportError as exc:
    raise SystemExit('ReportLab is required: pip install reportlab') from exc

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'content/job-search/teacher/interview/defense'
DEFAULT_MANIFEST = BASE / 'materials/yunnan/r2/final-manifest.yaml'
FOOTER_TITLE = '云南省教师招聘答辩资料'


def yload(path: Path) -> dict:
    data = yaml.safe_load(path.read_text(encoding='utf-8'))
    if not isinstance(data, dict):
        raise SystemExit(f'Invalid YAML: {path}')
    return data


def _font_match(pattern: str) -> Path | None:
    try:
        out = subprocess.check_output(['fc-match', '-f', '%{file}', pattern], text=True).strip()
    except Exception:
        return None
    path = Path(out) if out else None
    return path if path and path.exists() else None


def _first_existing(candidates: list[Path | None]) -> Path | None:
    return next((path for path in candidates if path and path.exists()), None)


def register_cjk_fonts() -> None:
    body = _first_existing([
        _font_match('AR PL SungtiL GB'),
        Path('/usr/share/fonts/truetype/arphic-gbsn00lp/gbsn00lp.ttf'),
        Path('/usr/share/fonts/truetype/wqy/wqy-zenhei.ttf'),
    ])
    head = _first_existing([
        _font_match('AR PL KaitiM GB'),
        Path('/usr/share/fonts/truetype/arphic-gkai00mp/gkai00mp.ttf'),
        body,
    ])
    if not body:
        raise SystemExit(
            'No embeddable CJK TrueType font found. Install an AR PL/WenQuanYi CJK font package; '
            'font files are runtime dependencies and are never stored or shared by this repo.'
        )
    pdfmetrics.registerFont(TTFont('CJK', str(body)))
    pdfmetrics.registerFont(TTFont('CJKHead', str(head or body)))


def inline_md(text: str) -> str:
    value = html.escape(text.strip())
    value = re.sub(r'`([^`]+)`', r'<font name="CJK">\1</font>', value)
    value = re.sub(r'\*\*([^*]+)\*\*', r'<font name="CJKHead">\1</font>', value)
    return value


def make_styles() -> dict[str, ParagraphStyle]:
    base = getSampleStyleSheet()
    return {
        'title': ParagraphStyle(
            'title', parent=base['Title'], fontName='CJKHead', fontSize=19,
            leading=25, alignment=TA_CENTER, spaceAfter=7 * mm,
            textColor=colors.HexColor('#1f2937'), wordWrap='CJK'
        ),
        'h1': ParagraphStyle(
            'h1', parent=base['Heading1'], fontName='CJKHead', fontSize=15,
            leading=20.5, spaceBefore=5.5 * mm, spaceAfter=2.8 * mm,
            textColor=colors.HexColor('#111827'), wordWrap='CJK'
        ),
        'h2': ParagraphStyle(
            'h2', parent=base['Heading2'], fontName='CJKHead', fontSize=11.2,
            leading=16.2, spaceBefore=4.2 * mm, spaceAfter=2.0 * mm,
            textColor=colors.HexColor('#1f2937'), wordWrap='CJK'
        ),
        'h3': ParagraphStyle(
            'h3', parent=base['Heading3'], fontName='CJKHead', fontSize=9.8,
            leading=14.2, spaceBefore=2.8 * mm, spaceAfter=1.1 * mm,
            textColor=colors.HexColor('#374151'), wordWrap='CJK'
        ),
        'body': ParagraphStyle(
            'body', parent=base['BodyText'], fontName='CJK', fontSize=8.6,
            leading=13.4, spaceAfter=2.0 * mm, wordWrap='CJK',
            textColor=colors.HexColor('#30343b')
        ),
        'bullet': ParagraphStyle(
            'bullet', parent=base['BodyText'], fontName='CJK', fontSize=8.5,
            leading=13.0, leftIndent=5 * mm, firstLineIndent=-2.6 * mm,
            spaceAfter=1.1 * mm, wordWrap='CJK'
        ),
        'quote': ParagraphStyle(
            'quote', parent=base['BodyText'], fontName='CJK', fontSize=8.25,
            leading=12.6, leftIndent=4 * mm, rightIndent=4 * mm,
            borderPadding=(2 * mm, 3 * mm, 2 * mm, 3 * mm),
            backColor=colors.HexColor('#f4f5f7'), borderColor=colors.HexColor('#e5e7eb'),
            borderWidth=0.5, borderRadius=2, spaceAfter=2.2 * mm, wordWrap='CJK'
        ),
        'small': ParagraphStyle(
            'small', parent=base['BodyText'], fontName='CJK', fontSize=7.7,
            leading=11.3, textColor=colors.HexColor('#6b7280'), wordWrap='CJK'
        ),
    }


def table_from_markdown(lines: list[str], styles: dict[str, ParagraphStyle]) -> Table:
    rows: list[list[str]] = []
    for line in lines:
        cells = [cell.strip() for cell in line.strip().strip('|').split('|')]
        if cells and all(re.fullmatch(r':?-{3,}:?', cell or '') for cell in cells):
            continue
        rows.append(cells)
    columns = max(len(row) for row in rows)
    data = []
    for row_index, row in enumerate(rows):
        rendered = []
        for column_index in range(columns):
            cell = row[column_index] if column_index < len(row) else ''
            style = ParagraphStyle(
                f'tcell-{row_index}-{column_index}', parent=styles['small'],
                fontName='CJKHead' if row_index == 0 else 'CJK',
                fontSize=8.2 if row_index == 0 else 8.0, leading=11.8,
            )
            rendered.append(Paragraph(inline_md(cell), style))
        data.append(rendered)
    width = 174 * mm
    widths = [50 * mm, 124 * mm] if columns == 2 else [width / columns] * columns
    table = Table(data, colWidths=widths, repeatRows=1, hAlign='LEFT')
    table.setStyle(TableStyle([
        ('GRID', (0, 0), (-1, -1), 0.4, colors.HexColor('#d1d5db')),
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#f3f4f6')),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('LEFTPADDING', (0, 0), (-1, -1), 4),
        ('RIGHTPADDING', (0, 0), (-1, -1), 4),
        ('TOPPADDING', (0, 0), (-1, -1), 4),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
    ]))
    return table


def markdown_flowables(text: str, document_title: str):
    styles = make_styles()
    story = [Paragraph(inline_md(document_title), styles['title'])]
    lines = text.splitlines()
    index = 0
    paragraph: list[str] = []

    def flush() -> None:
        nonlocal paragraph
        if paragraph:
            joined = ' '.join(part.strip() for part in paragraph if part.strip())
            if joined:
                story.append(Paragraph(inline_md(joined), styles['body']))
            paragraph = []

    while index < len(lines):
        stripped = lines[index].strip()
        if stripped.startswith('|'):
            flush()
            block = []
            while index < len(lines) and lines[index].strip().startswith('|'):
                block.append(lines[index])
                index += 1
            story.append(table_from_markdown(block, styles))
            story.append(Spacer(1, 3 * mm))
            continue
        if not stripped:
            flush(); index += 1; continue
        if stripped == '---':
            flush()
            story.append(Spacer(1, 1 * mm))
            story.append(HRFlowable(width='100%', thickness=0.45, color=colors.HexColor('#e5e7eb')))
            story.append(Spacer(1, 1 * mm))
            index += 1
            continue
        heading = re.match(r'^(#{1,3})\s+(.*)$', stripped)
        if heading:
            flush()
            level = len(heading.group(1)); title = heading.group(2)
            if level == 1 and len(story) > 1:
                story.append(PageBreak())
            story.append(Paragraph(inline_md(title), styles[f'h{level}']))
            index += 1
            continue
        if stripped.startswith('>'):
            flush()
            story.append(Paragraph(inline_md(stripped.lstrip('>').strip()), styles['quote']))
            index += 1
            continue
        if re.match(r'^[-*]\s+', stripped):
            flush()
            item = re.sub(r'^[-*]\s+', '', stripped)
            story.append(Paragraph('• ' + inline_md(item), styles['bullet']))
            index += 1
            continue
        if re.match(r'^\d+\.\s+', stripped):
            flush(); story.append(Paragraph(inline_md(stripped), styles['body'])); index += 1; continue
        paragraph.append(stripped); index += 1
    flush()
    return story


def footer(canvas, doc) -> None:
    canvas.saveState()
    canvas.setFont('CJK', 7.5)
    canvas.setFillColor(colors.HexColor('#7b8190'))
    canvas.drawString(doc.leftMargin, 9 * mm, FOOTER_TITLE)
    canvas.drawRightString(A4[0] - doc.rightMargin, 9 * mm, str(doc.page))
    canvas.restoreState()


def build_pdf(markdown: str, output: Path, title: str) -> None:
    first_heading = f'# {title}'
    stripped = markdown.lstrip()
    if stripped.startswith(first_heading):
        markdown = stripped[len(first_heading):].lstrip('\n')
    document = SimpleDocTemplate(
        str(output), pagesize=A4, leftMargin=18 * mm, rightMargin=18 * mm,
        topMargin=17 * mm, bottomMargin=16 * mm, title=title, author='qiuzhidaren'
    )
    document.build(markdown_flowables(markdown, title), onFirstPage=footer, onLaterPages=footer)


def read_repo_path(raw: str) -> str:
    path = ROOT / raw
    if not path.exists():
        raise SystemExit(f'Missing publication source: {raw}')
    return path.read_text(encoding='utf-8')


def compose_core(manifest: dict) -> str:
    pieces: list[str] = []
    pieces.append(read_repo_path('content/job-search/teacher/interview/defense/materials/yunnan/r2/00_最终总览.md'))
    pieces.append('\n# 第一部分｜Lesson-linked 通用答辩母题\n')
    for raw in manifest['common_bank']['markdown_files']:
        pieces.append(read_repo_path(raw))
    pieces.append('\n# 第二部分｜Official source-bound 招聘专属训练包\n')
    for pack in manifest['source_bound_packs']['packs']:
        pieces.append(read_repo_path(pack['markdown']))
    pieces.append('\n# 第三部分｜高中物理课题专属答辩生成规则\n')
    pieces.append(read_repo_path('content/job-search/teacher/interview/defense/materials/yunnan/r1/20_高中物理课题专属答辩生成规则_v1.md'))
    pieces.append('\n# 第四部分｜来源与真题身份边界\n')
    pieces.append(read_repo_path('content/job-search/teacher/interview/defense/sources/recalled-question-scan-2026-08-final.md'))
    return '\n\n'.join(pieces)


def main() -> int:
    parser = argparse.ArgumentParser(description='Publish final Yunnan teacher-defense materials.')
    parser.add_argument('--manifest', type=Path, default=DEFAULT_MANIFEST)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()

    manifest = yload(args.manifest)
    if manifest.get('status') != 'final-content-closed':
        raise SystemExit('Defense final manifest is not content-closed')
    source_bound = manifest.get('source_bound_packs') or {}
    if int(manifest['common_bank']['count']) != 32:
        raise SystemExit('Final defense common-bank count drifted')
    if int(source_bound.get('total_cards') or 0) != 18 or int(source_bound.get('pack_count') or 0) != 3:
        raise SystemExit('Final defense source-bound publication counts drifted')
    if len(source_bound.get('packs') or []) != 3:
        raise SystemExit('Final defense source-bound pack list drifted')

    register_cjk_fonts()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    core = manifest['products']['core_pdf']
    quick = manifest['products']['quick_pdf']
    build_pdf(compose_core(manifest), args.output_dir / core['filename'], core['title'])
    build_pdf(read_repo_path(manifest['quick_reference']['markdown']), args.output_dir / quick['filename'], quick['title'])
    print(f'published defense materials to {args.output_dir}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
