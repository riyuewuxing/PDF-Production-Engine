#!/usr/bin/env python3
"""Fail-closed validator for hash-bound teaching-demo delivery jobs.

The checker is deliberately topic-agnostic. It validates the declared state
machine, ordered receipt chain, reviewer roles, canonical receipt hashes, and
raw SHA-256 bindings for every local input/output/evidence file.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re
import shutil
import sys
import tempfile
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONTRACT = Path("production/contracts/teaching-demo-delivery-state-machine-v1.yaml")
HEX64 = set("0123456789abcdef")
JOB_ID_PATTERN = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:-]{0,127}\Z")
EXPECTED_STAGE_IDS = (
    "JOB_INITIALIZED",
    "SOURCE_IDENTITY_LOCKED",
    "SOURCE_PIXELS_REVIEW_PASS",
    "TEACHING_BOUNDARY_REVIEW_PASS",
    "POINT_CHAIN_REVIEW_PASS",
    "BOARD_PLAN_REVIEW_PASS",
    "EXAM_SKELETON_REVIEW_PASS",
    "TRIAL_SCRIPT_REVIEW_PASS",
    "CONTENT_PACKAGE_REVIEW_PASS",
    "FIGURE_BLOCKS_REVIEW_PASS",
    "SOURCE_PAGES_BLOCK_REVIEW_PASS",
    "COMPOSITION_MACHINE_PASS",
    "FINAL_PDF_MACHINE_PASS",
    "FINAL_PDF_REVIEW_PASS",
    "PUBLISHED",
)


class ValidationError(Exception):
    """Raised after a job fails one or more fail-closed checks."""


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def canonical_json(value: Any) -> bytes:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")


def canonical_receipt(receipt: dict[str, Any], fields: list[str]) -> bytes:
    # The contract explicitly names the fields included in this object. Missing
    # fields are rejected before this function is used, so omission cannot
    # create two different hashes for the same logical receipt.
    return canonical_json({key: receipt[key] for key in fields})


def receipt_sha256(receipt: dict[str, Any], fields: list[str]) -> str:
    return sha256_bytes(canonical_receipt(receipt, fields))


def is_sha256(value: Any) -> bool:
    return isinstance(value, str) and len(value) == 64 and set(value) <= HEX64


def load_yaml(path: Path, label: str) -> dict[str, Any]:
    try:
        value = yaml.safe_load(path.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError) as exc:
        raise ValidationError(f"{label}: cannot parse YAML: {exc}") from exc
    if not isinstance(value, dict):
        raise ValidationError(f"{label}: top-level YAML value must be a mapping")
    return value


def safe_repo_path(root: Path, raw: Any, context: str) -> Path:
    if not isinstance(raw, str) or not raw:
        raise ValidationError(f"{context}: path must be a non-empty repository-relative string")
    candidate = Path(raw)
    if candidate.is_absolute() or ".." in candidate.parts:
        raise ValidationError(f"{context}: absolute/traversal path forbidden: {raw!r}")
    resolved = (root / candidate).resolve()
    try:
        resolved.relative_to(root.resolve())
    except ValueError as exc:
        raise ValidationError(f"{context}: path escapes repository root: {raw!r}") from exc
    return resolved


def validate_binding_list(
    root: Path, bindings: Any, label: str, errors: list[str]
) -> list[dict[str, Any]]:
    if not isinstance(bindings, list) or not bindings:
        errors.append(f"{label}: must be a non-empty list")
        return []
    valid: list[dict[str, Any]] = []
    for index, binding in enumerate(bindings):
        context = f"{label}[{index}]"
        if not isinstance(binding, dict):
            errors.append(f"{context}: binding must be a mapping")
            continue
        path_raw = binding.get("path")
        declared = binding.get("sha256")
        kind = binding.get("kind")
        if not isinstance(kind, str) or not kind:
            errors.append(f"{context}: kind must be a non-empty typed binding kind")
            continue
        try:
            path = safe_repo_path(root, path_raw, context)
        except ValidationError as exc:
            errors.append(str(exc))
            continue
        if not is_sha256(declared):
            errors.append(f"{context}: sha256 must be a lowercase 64-character SHA-256")
            continue
        if not path.is_file():
            errors.append(f"{context}: evidence file is missing: {path_raw}")
            continue
        actual = sha256_file(path)
        if actual != declared:
            errors.append(
                f"{context}: SHA-256 mismatch for {path_raw}: declared={declared} actual={actual}"
            )
        valid.append(binding)
    return valid


def validate_job(job_path: Path, contract_path: Path, root: Path) -> list[str]:
    errors: list[str] = []
    if not contract_path.is_file():
        return [f"contract: file is missing: {contract_path}"]
    try:
        contract_rel = contract_path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return [f"contract: path must stay inside repository root: {contract_path}"]
    try:
        contract = load_yaml(contract_path, "contract")
        job = load_yaml(job_path, "job")
    except ValidationError as exc:
        return [str(exc)]

    contract_hash = sha256_file(contract_path)
    required_product_contract = contract.get("required_product_contract")
    product_contract_path: Path | None = None
    if not isinstance(required_product_contract, str) or not required_product_contract:
        errors.append("contract: required_product_contract must be a repository-relative path")
    else:
        try:
            product_contract_path = safe_repo_path(
                root, required_product_contract, "contract/required_product_contract"
            )
        except ValidationError as exc:
            errors.append(str(exc))

    if job.get("contract") != contract_rel:
        errors.append(
            "job: contract must exactly reference the selected repository-relative contract "
            f"{contract_rel}"
        )
    if job.get("status") not in (contract.get("job_rules") or {}).get(
        "allowed_job_states", []
    ):
        errors.append(f"job: invalid status: {job.get('status')!r}")

    stage_rules = contract.get("stage_rules")
    if not isinstance(stage_rules, list) or not stage_rules:
        return ["contract: stage_rules must be a non-empty ordered list"]
    stage_ids: list[str] = []
    rules: dict[str, dict[str, Any]] = {}
    for index, rule in enumerate(stage_rules, start=1):
        if not isinstance(rule, dict) or not isinstance(rule.get("id"), str):
            errors.append(f"contract: stage_rules[{index - 1}] is malformed")
            continue
        stage_id = rule["id"]
        stage_ids.append(stage_id)
        rules[stage_id] = rule
        if rule.get("order") != index:
            errors.append(f"contract: stage {stage_id} has non-contiguous order")
    if len(stage_ids) != len(set(stage_ids)):
        errors.append("contract: duplicate stage id")
    if tuple(stage_ids) != EXPECTED_STAGE_IDS:
        errors.append(
            "contract: stage sequence must be the complete non-skippable teaching-demo sequence: "
            + " -> ".join(EXPECTED_STAGE_IDS)
        )
    engine_states = contract.get("engine_may_emit_states")
    if engine_states != ["MACHINE_PASS", "REVIEW_REQUIRED"]:
        errors.append(
            "contract: engine_may_emit_states must be exactly "
            "[MACHINE_PASS, REVIEW_REQUIRED]"
        )
    for stage_id in stage_ids:
        rule = rules[stage_id]
        for field in ("allowed_states", "required_input_kinds", "required_output_kinds", "required_evidence_kinds"):
            if not isinstance(rule.get(field), list) or not rule[field]:
                errors.append(f"contract/{stage_id}: {field} must be a non-empty typed list")
        if rule.get("success_actor") == "ENGINE":
            allowed_engine_states = rule.get("allowed_states") or []
            if "MACHINE_FAIL" in allowed_engine_states:
                errors.append(f"contract/{stage_id}: Engine stage cannot allow MACHINE_FAIL")
            if allowed_engine_states != ["MACHINE_PASS", "REVIEW_REQUIRED"]:
                errors.append(
                    f"contract/{stage_id}: Engine stage allowed_states must be exactly "
                    "[MACHINE_PASS, REVIEW_REQUIRED]"
                )
        if stage_id == "JOB_INITIALIZED":
            if rule.get("success_actor") != "PROJECT":
                errors.append("contract/JOB_INITIALIZED: success_actor must be PROJECT")
            if rule.get("allowed_states") != ["MACHINE_PASS", "BLOCKED"]:
                errors.append(
                    "contract/JOB_INITIALIZED: allowed_states must be exactly "
                    "[MACHINE_PASS, BLOCKED]"
                )
    canonical_fields = (
        (contract.get("canonicalization") or {}).get("object_rules") or {}
    ).get("include_in_receipt_hash")
    if not isinstance(canonical_fields, list) or not canonical_fields:
        errors.append("contract: canonical receipt field list is missing")
        canonical_fields = []
    if "receipt_sha256" in canonical_fields:
        errors.append("contract: receipt_sha256 must be excluded from canonical payload")
    if (contract.get("canonicalization") or {}).get("algorithm") != "SHA-256":
        errors.append("contract: SHA-256 is required")
    if (contract.get("predecessor_rule") or {}).get(
        "first_stage_predecessor_receipt_sha256", "MISSING"
    ) is not None:
        errors.append("contract: first predecessor rule must be null")
    lineage = contract.get("lineage_rule") or {}
    if lineage.get("later_stage_inputs_must_include_all_immediate_predecessor_outputs") is not True:
        errors.append("contract: predecessor output lineage rule is missing")
    binding_identity_fields = lineage.get("binding_identity_fields")
    if binding_identity_fields != ["path", "sha256", "kind"]:
        errors.append("contract: binding identity must be path+sha256+kind")

    receipts = job.get("receipts")
    if not isinstance(receipts, list):
        errors.append("job: receipts must be a list")
        return errors
    if receipts:
        job_id = job.get("job_id")
        if not isinstance(job_id, str) or not JOB_ID_PATTERN.fullmatch(job_id):
            errors.append(
                "job: non-empty receipts require job_id matching "
                "[A-Za-z0-9][A-Za-z0-9._:-]{0,127}"
            )
        if job.get("product_contract") != required_product_contract:
            errors.append(
                "job: product_contract must exactly match contract required_product_contract "
                f"{required_product_contract!r}"
            )
        if product_contract_path is not None and not product_contract_path.is_file():
            errors.append(
                "job: required product contract file is missing: "
                f"{required_product_contract}"
            )
    elif job.get("product_contract") not in (None, required_product_contract):
        errors.append(
            "job: product_contract must match contract required_product_contract "
            f"{required_product_contract!r} when supplied"
        )
    if not receipts and job.get("status") not in (
        (contract.get("job_rules") or {}).get("empty_receipts_allowed_only_when") or []
    ):
        errors.append("job: empty receipts are only valid for NOT_STARTED/PENDING jobs")
    if len(receipts) > len(stage_ids):
        errors.append("job: receipt count exceeds contract stage count")

    previous_hash: str | None = None
    previous_outputs: list[dict[str, Any]] = []
    successful_prefix = True
    for index, receipt in enumerate(receipts):
        context = f"receipt[{index}]"
        if not isinstance(receipt, dict):
            errors.append(f"{context}: receipt must be a mapping")
            successful_prefix = False
            continue
        expected_stage = stage_ids[index] if index < len(stage_ids) else None
        stage_id = receipt.get("stage_id")
        if stage_id != expected_stage:
            errors.append(
                f"{context}: stage order mismatch: expected={expected_stage} actual={stage_id}"
            )
            successful_prefix = False
        rule = rules.get(stage_id, {})
        state = receipt.get("state")
        allowed = rule.get("allowed_states") or []
        if state not in allowed:
            errors.append(f"{context}/{stage_id}: invalid state {state!r}")
            successful_prefix = False
        required_fields = {
            "stage_id",
            "state",
            "reviewer",
            "reviewer_role",
            "reviewed_at",
            "contract_sha256",
            "predecessor_receipt_sha256",
            "input_bindings",
            "output_bindings",
            "evidence_ref",
            "evidence_sha256",
            "receipt_sha256",
        } | set(canonical_fields)
        missing = sorted(key for key in required_fields if key not in receipt)
        if missing:
            errors.append(f"{context}/{stage_id}: missing required fields: {', '.join(missing)}")
            successful_prefix = False
            continue
        if receipt.get("contract_sha256") != contract_hash:
            errors.append(
                f"{context}/{stage_id}: contract hash mismatch: "
                f"declared={receipt.get('contract_sha256')} actual={contract_hash}"
            )
        predecessor = receipt.get("predecessor_receipt_sha256")
        if index == 0:
            if predecessor is not None:
                errors.append(f"{context}/{stage_id}: first predecessor must be null")
        elif predecessor != previous_hash:
            errors.append(
                f"{context}/{stage_id}: stale predecessor hash: "
                f"declared={predecessor} expected={previous_hash}"
            )
        reviewer = receipt.get("reviewer")
        reviewer_role = receipt.get("reviewer_role")
        required_actor = rule.get("success_actor")
        if state == "REVIEW_REQUIRED" and (
            reviewer != "PDF-Production-Engine" or reviewer_role != "ENGINE"
        ):
            errors.append(
                f"{context}/{stage_id}: REVIEW_REQUIRED must be emitted by "
                "PDF-Production-Engine with reviewer_role=ENGINE"
            )
        if state in {"MACHINE_PASS", "REVIEW_REQUIRED"} and required_actor == "ENGINE":
            if reviewer != "PDF-Production-Engine" or reviewer_role != "ENGINE":
                errors.append(
                    f"{context}/{stage_id}: engine state requires reviewer="
                    "PDF-Production-Engine and reviewer_role=ENGINE"
                )
        if state in {"MACHINE_PASS", "REVIEW_REQUIRED"} and required_actor == "PROJECT":
            if reviewer != "qiuzhidaren-checker" or reviewer_role != "PROJECT_MACHINE":
                errors.append(
                    f"{context}/{stage_id}: project state requires reviewer="
                    "qiuzhidaren-checker and reviewer_role=PROJECT_MACHINE"
                )
        if state == "BLOCKED" and required_actor == "PROJECT":
            if reviewer != "qiuzhidaren-checker" or reviewer_role != "PROJECT_MACHINE":
                errors.append(
                    f"{context}/{stage_id}: project BLOCKED state requires reviewer="
                    "qiuzhidaren-checker and reviewer_role=PROJECT_MACHINE"
                )
        if state in {"REVIEW_PASS", "REVIEW_FAIL", "PUBLISHED"}:
            if reviewer != "ChatGPT" or reviewer_role != "HUMAN":
                errors.append(
                    f"{context}/{stage_id}: human state requires reviewer=ChatGPT "
                    "and reviewer_role=HUMAN"
                )
        if required_actor == "ENGINE" and state in {"REVIEW_PASS", "PUBLISHED"}:
            errors.append(f"{context}/{stage_id}: engine stage cannot have human acceptance")
        if required_actor == "HUMAN" and state == "MACHINE_PASS":
            errors.append(f"{context}/{stage_id}: human review stage cannot be MACHINE_PASS")
        try:
            datetime.fromisoformat(str(receipt.get("reviewed_at")).replace("Z", "+00:00"))
        except ValueError:
            errors.append(f"{context}/{stage_id}: reviewed_at must be ISO-8601")
        evidence_ref = receipt.get("evidence_ref")
        try:
            evidence_path = safe_repo_path(root, evidence_ref, f"{context}/{stage_id}/evidence_ref")
            if not evidence_path.is_file():
                errors.append(f"{context}/{stage_id}: evidence_ref file is missing: {evidence_ref}")
            else:
                actual_evidence = sha256_file(evidence_path)
                if receipt.get("evidence_sha256") != actual_evidence:
                    errors.append(
                        f"{context}/{stage_id}: evidence SHA-256 mismatch: "
                        f"declared={receipt.get('evidence_sha256')} actual={actual_evidence}"
                    )
        except ValidationError as exc:
            errors.append(str(exc))
        if not is_sha256(receipt.get("evidence_sha256")):
            errors.append(f"{context}/{stage_id}: evidence_sha256 is not a SHA-256")
        evidence_kind = receipt.get("evidence_kind")
        required_evidence_kinds = rule.get("required_evidence_kinds") or []
        if evidence_kind not in required_evidence_kinds:
            errors.append(
                f"{context}/{stage_id}: evidence_kind={evidence_kind!r} does not satisfy "
                f"required_evidence_kinds={required_evidence_kinds}"
            )
        inputs = validate_binding_list(
            root, receipt.get("input_bindings"), f"{context}/{stage_id}/input_bindings", errors
        )
        outputs = validate_binding_list(
            root, receipt.get("output_bindings"), f"{context}/{stage_id}/output_bindings", errors
        )
        if index == 0 and product_contract_path is not None and product_contract_path.is_file():
            expected_product_binding = (
                required_product_contract,
                sha256_file(product_contract_path),
                "product_contract",
            )
            if not any(
                (item.get("path"), item.get("sha256"), item.get("kind"))
                == expected_product_binding
                for item in inputs
            ):
                errors.append(
                    f"{context}/{stage_id}: first receipt must bind the exact product contract "
                    f"{expected_product_binding[0]} with its actual SHA-256"
                )
        output_kinds = {item.get("kind") for item in outputs}
        input_kinds = {item.get("kind") for item in inputs}
        required_output_kinds = set(rule.get("required_output_kinds") or [])
        required_input_kinds = set(rule.get("required_input_kinds") or [])
        if not required_output_kinds <= output_kinds:
            errors.append(
                f"{context}/{stage_id}: required output binding kinds missing: "
                f"{sorted(required_output_kinds - output_kinds)}"
            )
        if not required_input_kinds <= input_kinds:
            errors.append(
                f"{context}/{stage_id}: required input binding kinds missing: "
                f"{sorted(required_input_kinds - input_kinds)}"
            )
        if index > 0:
            current_identity = {
                (item.get("path"), item.get("sha256"), item.get("kind")) for item in inputs
            }
            for predecessor_output in previous_outputs:
                identity = (
                    predecessor_output.get("path"),
                    predecessor_output.get("sha256"),
                    predecessor_output.get("kind"),
                )
                if identity not in current_identity:
                    errors.append(
                        f"{context}/{stage_id}: predecessor output is not inherited: "
                        f"{identity}"
                    )
        if stage_id == "FINAL_PDF_REVIEW_PASS":
            final_inputs = [item for item in inputs if item.get("kind") == "final_pdf"]
            final_outputs = [item for item in outputs if item.get("kind") == "final_pdf"]
            if not any(
                (item.get("path"), item.get("sha256"), item.get("kind"))
                in {
                    (candidate.get("path"), candidate.get("sha256"), candidate.get("kind"))
                    for candidate in final_inputs
                }
                for item in final_outputs
            ):
                errors.append(f"{context}/{stage_id}: output final_pdf must match accepted input final_pdf")
        if stage_id == "PUBLISHED":
            prior_final = [item for item in previous_outputs if item.get("kind") == "final_pdf"]
            current_final = [item for item in inputs if item.get("kind") == "final_pdf"]
            if not any(
                (item.get("path"), item.get("sha256"), item.get("kind"))
                == (candidate.get("path"), candidate.get("sha256"), candidate.get("kind"))
                for item in current_final for candidate in prior_final
            ):
                errors.append(f"{context}/{stage_id}: published input must match final_pdf review output")
            published_outputs = [item for item in outputs if item.get("kind") == "final_pdf"]
            if not any(
                (item.get("path"), item.get("sha256"), item.get("kind"))
                == (candidate.get("path"), candidate.get("sha256"), candidate.get("kind"))
                for item in published_outputs for candidate in current_final
            ):
                errors.append(f"{context}/{stage_id}: published output must match published input final_pdf")
        expected_hash = receipt_sha256(receipt, canonical_fields)
        if receipt.get("receipt_sha256") != expected_hash:
            errors.append(
                f"{context}/{stage_id}: receipt hash mismatch: "
                f"declared={receipt.get('receipt_sha256')} actual={expected_hash}"
            )
        previous_hash = expected_hash
        previous_outputs = outputs
        if state != rule.get("required_success_state"):
            successful_prefix = False
            errors.append(
                f"{context}/{stage_id}: stage is not successful: "
                f"state={state} required={rule.get('required_success_state')}"
            )
        if not successful_prefix and index + 1 < len(receipts):
            errors.append(
                f"{context}/{stage_id}: later receipt exists after a failed/non-successful stage"
            )

    if not receipts:
        if job.get("status") not in {"NOT_STARTED", "PENDING"}:
            errors.append("job: empty receipt chain requires status NOT_STARTED or PENDING")
    elif len(receipts) < len(stage_ids):
        last = receipts[-1] if isinstance(receipts[-1], dict) else {}
        last_rule = rules.get(last.get("stage_id"), {})
        last_success = last.get("state") == last_rule.get("required_success_state")
        if last_success and job.get("status") != "RUNNING":
            errors.append("job: successful partial chain requires status RUNNING")
        if not last_success and job.get("status") != "FAILED":
            errors.append("job: partial failed/blocked chain requires status FAILED")
        if job.get("status") == "PUBLISHED":
            errors.append("job: PUBLISHED status requires the full 15-stage chain")
    if len(receipts) == len(stage_ids):
        if job.get("status") != "PUBLISHED":
            errors.append("job: complete receipt chain must have status PUBLISHED")
        published = receipts[-1] if receipts and isinstance(receipts[-1], dict) else {}
        if published.get("state") != "PUBLISHED":
            errors.append("job: complete chain must end with PUBLISHED")
        output_bindings = published.get("output_bindings") or []
        if not any(
            isinstance(item, dict)
            and item.get("kind") == "final_pdf"
            and str(item.get("path", "")).lower().endswith(".pdf")
            for item in output_bindings
        ):
            errors.append("job: PUBLISHED must bind a final_pdf output ending in .pdf")
    return errors


def check_or_raise(job_path: Path, contract_path: Path, root: Path) -> None:
    errors = validate_job(job_path, contract_path, root)
    if errors:
        raise ValidationError("\n".join(errors))


def _selftest_job(root: Path, contract_path: Path) -> dict[str, Any]:
    contract = load_yaml(contract_path, "self-test contract")
    contract_hash = sha256_file(contract_path)
    stage_rules = contract["stage_rules"]
    (root / "inputs").mkdir()
    (root / "outputs").mkdir()
    (root / "evidence").mkdir()
    product_contract_rel = contract["required_product_contract"]
    product_contract_path = root / product_contract_rel
    product_contract_path.parent.mkdir(parents=True, exist_ok=True)
    product_contract_path.write_text(
        "id: synthetic-teacher-trial-product-contract-v1\nversion: 1\n",
        encoding="utf-8",
    )
    final_pdf = root / "outputs" / "final.pdf"
    final_pdf.write_bytes(b"%PDF-1.4\nsynthetic final pdf\n")
    receipts: list[dict[str, Any]] = []
    previous: str | None = None
    previous_outputs: list[dict[str, Any]] = []
    fields = contract["canonicalization"]["object_rules"]["include_in_receipt_hash"]
    for index, rule in enumerate(stage_rules, start=1):
        stage_id = rule["id"]
        required_input_kinds = rule.get("required_input_kinds") or ["stage_input"]
        output_kind = (rule.get("required_output_kinds") or ["stage_output"])[0]
        evidence_kind = (rule.get("required_evidence_kinds") or ["stage_evidence"])[0]
        inp = root / "inputs" / f"{index}.txt"
        out = final_pdf if output_kind == "final_pdf" else root / "outputs" / f"{index}.txt"
        evidence = root / "evidence" / f"{index}.json"
        inp.write_text(f"input-{index}\n", encoding="utf-8")
        if out != final_pdf:
            out.write_text(f"output-{index}\n", encoding="utf-8")
        evidence.write_text(json.dumps({"stage": stage_id, "index": index}), encoding="utf-8")
        input_bindings = deepcopy(previous_outputs)
        for input_kind in required_input_kinds:
            if input_kind == "product_contract":
                input_bindings.append(
                    {
                        "path": product_contract_rel,
                        "sha256": sha256_file(product_contract_path),
                        "kind": "product_contract",
                    }
                )
            else:
                input_bindings.append(
                    {
                        "path": str(inp.relative_to(root)),
                        "sha256": sha256_file(inp),
                        "kind": input_kind,
                    }
                )
        output_binding = {
            "path": str(out.relative_to(root)),
            "sha256": sha256_file(out),
            "kind": output_kind,
        }
        if rule["success_actor"] == "PROJECT":
            reviewer, reviewer_role = "qiuzhidaren-checker", "PROJECT_MACHINE"
        elif rule["success_actor"] == "ENGINE":
            reviewer, reviewer_role = "PDF-Production-Engine", "ENGINE"
        else:
            reviewer, reviewer_role = "ChatGPT", "HUMAN"
        receipt = {
            "stage_id": stage_id,
            "state": rule["required_success_state"],
            "reviewer": reviewer,
            "reviewer_role": reviewer_role,
            "reviewed_at": f"2026-08-23T00:{index:02d}:00Z",
            "contract_sha256": contract_hash,
            "predecessor_receipt_sha256": previous,
            "input_bindings": input_bindings,
            "output_bindings": [output_binding],
            "evidence_ref": str(evidence.relative_to(root)),
            "evidence_kind": evidence_kind,
            "evidence_sha256": sha256_file(evidence),
            "notes": "",
        }
        receipt["receipt_sha256"] = receipt_sha256(receipt, fields)
        receipts.append(receipt)
        previous = receipt["receipt_sha256"]
        previous_outputs = [output_binding]
    return {
        "version": 1,
        "id": "synthetic-job",
        "contract": str(contract_path.relative_to(root)),
        "product_contract": product_contract_rel,
        "job_id": "self-test-job",
        "status": "PUBLISHED",
        "receipts": receipts,
    }


def _rechain(job: dict[str, Any], contract: dict[str, Any]) -> None:
    fields = contract["canonicalization"]["object_rules"]["include_in_receipt_hash"]
    previous: str | None = None
    for receipt in job["receipts"]:
        receipt["predecessor_receipt_sha256"] = previous
        receipt["receipt_sha256"] = receipt_sha256(receipt, fields)
        previous = receipt["receipt_sha256"]


def _write_job(path: Path, job: dict[str, Any]) -> None:
    path.write_text(yaml.safe_dump(job, allow_unicode=True, sort_keys=False), encoding="utf-8")


def self_test() -> None:
    with tempfile.TemporaryDirectory(prefix="teaching-demo-governance-") as tmp:
        root = Path(tmp)
        contract_path = root / DEFAULT_CONTRACT
        contract_path.parent.mkdir(parents=True)
        shutil.copy2(ROOT / DEFAULT_CONTRACT, contract_path)
        job_path = root / "job.yaml"
        job = _selftest_job(root, contract_path)
        _write_job(job_path, job)
        check_or_raise(job_path, contract_path, root)
        partial_success = deepcopy(job)
        partial_success["receipts"] = partial_success["receipts"][:3]
        partial_success["status"] = "RUNNING"
        _write_job(root / "partial-running.yaml", partial_success)
        check_or_raise(root / "partial-running.yaml", contract_path, root)

        def expect_fail(label: str, candidate: dict[str, Any]) -> None:
            candidate_path = root / f"{label}.yaml"
            _write_job(candidate_path, candidate)
            errors = validate_job(candidate_path, contract_path, root)
            if not errors:
                raise AssertionError(f"self-test expected FAIL: {label}")

        skipped = deepcopy(job)
        skipped["receipts"] = skipped["receipts"][:2] + skipped["receipts"][3:]
        expect_fail("skip", skipped)

        partial_published = deepcopy(job)
        partial_published["receipts"] = partial_published["receipts"][:3]
        partial_published["status"] = "PUBLISHED"
        expect_fail("partial-published", partial_published)

        changed = deepcopy(job)
        (root / "inputs/1.txt").write_text("changed\n", encoding="utf-8")
        expect_fail("content-changed", changed)
        (root / "inputs/1.txt").write_text("input-1\n", encoding="utf-8")

        product_contract_path = root / job["product_contract"]
        product_contract_bytes = product_contract_path.read_bytes()
        product_contract_path.write_bytes(product_contract_bytes + b"changed: true\n")
        expect_fail("product-contract-changed", deepcopy(job))
        product_contract_path.write_bytes(product_contract_bytes)

        wrong_product_path = root / "production/contracts/wrong-product-contract.yaml"
        wrong_product_path.write_text("id: wrong-product-contract\n", encoding="utf-8")
        wrong_product = deepcopy(job)
        wrong_product["product_contract"] = str(wrong_product_path.relative_to(root))
        wrong_product["receipts"][0]["input_bindings"] = [
            item for item in wrong_product["receipts"][0]["input_bindings"]
            if item.get("kind") != "product_contract"
        ] + [{
            "path": str(wrong_product_path.relative_to(root)),
            "sha256": sha256_file(wrong_product_path),
            "kind": "product_contract",
        }]
        _rechain(wrong_product, load_yaml(contract_path, "self-test contract"))
        expect_fail("wrong-product-contract", wrong_product)

        project_review_required = deepcopy(job)
        project_review_required["receipts"][0]["state"] = "REVIEW_REQUIRED"
        _rechain(project_review_required, load_yaml(contract_path, "self-test contract"))
        expect_fail("project-review-required", project_review_required)

        anonymous_active = deepcopy(job)
        anonymous_active["job_id"] = None
        expect_fail("anonymous-active-job", anonymous_active)

        stale = deepcopy(job)
        stale["receipts"][1]["notes"] = "changed predecessor source receipt"
        stale["receipts"][1]["receipt_sha256"] = receipt_sha256(
            stale["receipts"][1],
            load_yaml(contract_path, "self-test contract")["canonicalization"]["object_rules"]["include_in_receipt_hash"],
        )
        expect_fail("stale-predecessor", stale)

        fake_contract = deepcopy(job)
        fake_contract["receipts"][0]["contract_sha256"] = "f" * 64
        _rechain(fake_contract, load_yaml(contract_path, "self-test contract"))
        expect_fail("fake-contract-hash", fake_contract)

        lineage_break = deepcopy(job)
        lineage_break["receipts"][2]["input_bindings"] = [
            item for item in lineage_break["receipts"][2]["input_bindings"]
            if item.get("kind") != "source_identity"
        ]
        _rechain(lineage_break, load_yaml(contract_path, "self-test contract"))
        expect_fail("data-lineage-break", lineage_break)

        missing = deepcopy(job)
        (root / "evidence/1.json").unlink()
        expect_fail("missing-evidence", missing)
        (root / "evidence/1.json").write_text(json.dumps({"stage": "JOB_INITIALIZED", "index": 1}), encoding="utf-8")

        wrong_reviewer = deepcopy(job)
        wrong_reviewer["receipts"][1]["reviewer"] = "PDF-Production-Engine"
        wrong_reviewer["receipts"][1]["reviewer_role"] = "ENGINE"
        _rechain(wrong_reviewer, load_yaml(contract_path, "self-test contract"))
        expect_fail("engine-review-pass", wrong_reviewer)

        engine_machine_fail = deepcopy(job)
        engine_machine_fail["receipts"][11]["state"] = "MACHINE_FAIL"
        _rechain(engine_machine_fail, load_yaml(contract_path, "self-test contract"))
        expect_fail("engine-machine-fail", engine_machine_fail)

        other_pdf = root / "outputs" / "other.pdf"
        other_pdf.write_bytes(b"%PDF-1.4\nwrong final\n")
        review_output_mismatch = deepcopy(job)
        review_output_mismatch["receipts"][13]["output_bindings"] = [
            {"path": "outputs/other.pdf", "sha256": sha256_file(other_pdf), "kind": "final_pdf"}
        ]
        _rechain(review_output_mismatch, load_yaml(contract_path, "self-test contract"))
        expect_fail("final-review-output-mismatch", review_output_mismatch)

        published_input_mismatch = deepcopy(job)
        published_input_mismatch["receipts"][-1]["input_bindings"] = [
            item for item in published_input_mismatch["receipts"][-1]["input_bindings"]
            if item.get("kind") != "final_pdf"
        ] + [{"path": "outputs/other.pdf", "sha256": sha256_file(other_pdf), "kind": "final_pdf"}]
        _rechain(published_input_mismatch, load_yaml(contract_path, "self-test contract"))
        expect_fail("published-input-mismatch", published_input_mismatch)

        no_pdf = deepcopy(job)
        no_pdf["receipts"][-1]["output_bindings"] = [
            {"path": "outputs/12.txt", "sha256": sha256_file(root / "outputs/12.txt"), "kind": "stage_output"}
        ]
        _rechain(no_pdf, load_yaml(contract_path, "self-test contract"))
        expect_fail("published-no-final-pdf", no_pdf)
    print("PASS: teaching-demo delivery governance self-test")
 
 
def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--job", type=Path)
    parser.add_argument("--contract", type=Path, default=DEFAULT_CONTRACT)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return 0
    if not args.job:
        parser.error("--job PATH is required unless --self-test is used")
    root = args.root.resolve()
    job_path = args.job if args.job.is_absolute() else root / args.job
    if args.contract.is_absolute() or ".." in args.contract.parts:
        print("FAIL: teaching-demo delivery governance")
        print("--contract must be a repository-relative path without traversal")
        return 1
    contract_path = (root / args.contract).resolve()
    try:
        contract_path.relative_to(root)
    except ValueError:
        print("FAIL: teaching-demo delivery governance")
        print("--contract escapes repository root")
        return 1
    try:
        check_or_raise(job_path.resolve(), contract_path.resolve(), root)
    except ValidationError as exc:
        print("FAIL: teaching-demo delivery governance")
        print(str(exc))
        return 1
    print("PASS: teaching-demo delivery governance")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
