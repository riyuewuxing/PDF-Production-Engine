"""CLI for manifest-driven regression validation."""
from __future__ import annotations

import argparse
import sys

from regression_case import selftest, validate_case


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--case', help='case.yaml path or case directory')
    parser.add_argument('--selftest', action='store_true')
    args = parser.parse_args()

    if args.selftest:
        selftest()
        print('generic regression checker selftest: PASS')
        if not args.case:
            return 0
    if not args.case:
        parser.error('--case is required unless --selftest is used alone')

    errors = validate_case(args.case)
    if errors:
        print('\n'.join(errors))
        return 1
    print(f'regression case: PASS: {args.case}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
