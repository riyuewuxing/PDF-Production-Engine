#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path
import yaml

from curate_physics_topic_atlas_retrieval import query_scores

ROOT = Path(__file__).resolve().parents[1]
ATLAS = ROOT / "production/process-development/teaching-demo-quality-v2/textbook-topic-atlas"
GEN = ATLAS / "generated"


def read_jsonl(path: Path):
    rows = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                rows.append(json.loads(line))
    return rows


def main():
    ap = argparse.ArgumentParser(description="Search exam-sized TTUs from the six-book physics Topic Atlas")
    ap.add_argument("--query", required=True)
    ap.add_argument("--top-k", type=int, default=5)
    ap.add_argument("--book-id")
    args = ap.parse_args()
    ttus = read_jsonl(GEN / "retrieval-ttus.jsonl")
    if args.book_id:
        ttus = [t for t in ttus if t["book_id"] == args.book_id]
    aliases = yaml.safe_load((ATLAS / "ALIASES.yaml").read_text(encoding="utf-8"))["aliases"]
    ranked = query_scores(args.query, ttus, aliases)[:max(1, args.top_k)]
    result = {
        "query": args.query,
        "authority": "retrieval-candidate-only-main-ai-source-inspection-required",
        "results": [
            {
                "rank": i + 1,
                "score": round(score, 3),
                "topic_id": t["topic_id"],
                "canonical_title": t["canonical_title"],
                "book_id": t["book_id"],
                "equivalent_page_coverage": t["equivalent_page_coverage"],
                "core_span": t["core_span"],
                "context_span": t["context_span"],
                "hierarchy": t["hierarchy"],
                "exam_fit": t["exam_fit"],
                "source_confidence": t["source_confidence"],
            }
            for i, (score, t) in enumerate(ranked)
        ],
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
