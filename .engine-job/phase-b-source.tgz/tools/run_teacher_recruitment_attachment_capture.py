#!/usr/bin/env python3
"""Canonical Phase9 maintenance orchestrator for official recruitment attachments."""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TOOLS = ROOT / "tools"


def run_cmd(args: list[str], tolerate: bool = False) -> int:
    print("+", " ".join(args))
    proc = subprocess.run(args, cwd=ROOT)
    if proc.returncode and not tolerate:
        raise SystemExit(proc.returncode)
    return proc.returncode


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--skip-browser", action="store_true")
    args = ap.parse_args()

    out = args.out
    out.mkdir(parents=True, exist_ok=True)
    manifest = args.manifest

    # Primary is deliberately static/session only. Browser escalation is handled by
    # the dedicated fallback so anchor text/source metadata are preserved.
    run_cmd([
        sys.executable, str(TOOLS / "fetch_teacher_recruitment_attachments.py"),
        "--manifest", str(manifest), "--out", str(out), "--no-browser-fallback",
    ], tolerate=True)

    if not args.skip_browser:
        run_cmd([
            sys.executable, str(TOOLS / "fetch_teacher_recruitment_attachments_browser.py"),
            "--manifest", str(manifest), "--out", str(out),
        ], tolerate=True)

    integrity_rc = run_cmd([
        sys.executable, str(TOOLS / "sanitize_teacher_recruitment_attachment_artifacts.py"),
        "--out", str(out),
    ], tolerate=True)

    result_path = out / "attachment-capture-manifest.json"
    if not result_path.exists():
        print("FAIL: no attachment capture manifest produced")
        return 2
    result = json.loads(result_path.read_text(encoding="utf-8"))
    summary = result.get("summary") or {}
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    if integrity_rc:
        return 2
    return 0 if summary.get("minimum_pass") is True else 2


if __name__ == "__main__":
    sys.exit(main())
