"""Validate teacher written-exam Knowledge/Method/Question relations.

This is a deterministic offline gate. It resolves the eight existing 2026 recalled ready questions
against the canonical link registry, checks source/card identities, validates reciprocal question
links, and keeps F2/F3 source activation boundaries explicit. It does not call any LLM/API.
"""
from __future__ import annotations

import json
from pathlib import Path
import sys

import yaml

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "content/job-search/teacher/written-exam"

QUESTION_FILES = [
    BASE / "reference-bank/normalized/dclass-2026-recalled-seed-v1.jsonl",
    BASE / "reference-bank/normalized/dclass-2026-recalled-primary-supplement-v1.jsonl",
]
KNOWLEDGE_FILES = [
    BASE / "knowledge-bank/dclass-f1-v1.yaml",
    BASE / "knowledge-bank/f2-junior-physics-v1.yaml",
    BASE / "knowledge-bank/f3-high-school-physics-v1.yaml",
]
METHOD_FILES = [
    BASE / "method-bank/dclass-f1-v1.yaml",
    BASE / "method-bank/physics-subject-v1.yaml",
]
LINK_FILE = BASE / "reference-bank/links/dclass-2026-ready-links-v1.yaml"
SOURCE_FILE = BASE / "sources/source-registry.yaml"
COVERAGE_FILE = BASE / "coverage/phase6-coverage-matrix-v1.yaml"
STRATEGY_QUEUE = BASE / "reference-bank/queues/dclass-strategy-source-gap-v1.yaml"


class LinkValidationError(ValueError):
    pass


def yload(path: Path) -> dict:
    if not path.exists():
        raise LinkValidationError(f"missing {path.relative_to(ROOT)}")
    value = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise LinkValidationError(f"{path.name}: expected yaml mapping")
    return value


def load_questions() -> dict[str, dict]:
    rows: dict[str, dict] = {}
    for path in QUESTION_FILES:
        if not path.exists():
            raise LinkValidationError(f"missing {path.relative_to(ROOT)}")
        for line_no, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            if not line.strip():
                continue
            row = json.loads(line)
            qid = str(row.get("id") or "")
            if not qid:
                raise LinkValidationError(f"{path.name}:{line_no}: missing id")
            if qid in rows:
                raise LinkValidationError(f"duplicate question id {qid}")
            rows[qid] = row
    return rows


def collect_cards(paths: list[Path], id_field: str) -> dict[str, dict]:
    out: dict[str, dict] = {}
    for path in paths:
        raw = yload(path)
        for card in raw.get("cards") or []:
            cid = str(card.get(id_field) or "")
            if not cid:
                raise LinkValidationError(f"{path.name}: card missing {id_field}")
            if cid in out:
                raise LinkValidationError(f"duplicate {id_field} {cid}")
            card = dict(card)
            card["_file"] = str(path.relative_to(ROOT))
            out[cid] = card
    return out


def require_known_sources(cards: dict[str, dict], source_ids: set[str], field: str) -> None:
    for cid, card in cards.items():
        if card.get("status") != "active":
            continue
        refs = list(card.get(field) or [])
        if not refs:
            raise LinkValidationError(f"{cid}: active card missing {field}")
        unknown = [sid for sid in refs if sid not in source_ids]
        if unknown:
            raise LinkValidationError(f"{cid}: unknown source ids {unknown}")


def validate_family_boundaries(knowledge: dict[str, dict]) -> None:
    for kid, card in knowledge.items():
        families = set(card.get("profile_families") or [])
        if "YN-WE-F2" in families:
            if "初中" not in set(card.get("stages") or []) or "物理" not in set(card.get("subjects") or []):
                raise LinkValidationError(f"{kid}: F2 physics card must be junior-secondary physics")
        if "YN-WE-F3" in families:
            if "高中" not in set(card.get("stages") or []) or "物理" not in set(card.get("subjects") or []):
                raise LinkValidationError(f"{kid}: F3 physics card must be high-school physics")
            if not card.get("activated_by_source_ids"):
                raise LinkValidationError(f"{kid}: F3 card missing source-specific activation")


def validate_question_links(
    questions: dict[str, dict],
    knowledge: dict[str, dict],
    methods: dict[str, dict],
) -> int:
    raw = yload(LINK_FILE)
    links = raw.get("question_links") or {}
    ready = {qid for qid, row in questions.items() if row.get("status") == "ready"}
    if set(links) != ready:
        missing = sorted(ready - set(links))
        extra = sorted(set(links) - ready)
        raise LinkValidationError(f"question link coverage mismatch missing={missing} extra={extra}")

    for qid, rel in links.items():
        kids = list(rel.get("knowledge_ids") or [])
        mids = list(rel.get("method_ids") or [])
        if not kids:
            raise LinkValidationError(f"{qid}: no knowledge_ids")
        if not mids:
            raise LinkValidationError(f"{qid}: no method_ids")
        for kid in kids:
            card = knowledge.get(kid)
            if card is None:
                raise LinkValidationError(f"{qid}: unknown knowledge_id {kid}")
            if qid not in set(card.get("linked_question_ids") or []):
                raise LinkValidationError(f"{qid}<->{kid}: knowledge reciprocal link missing")
        for mid in mids:
            card = methods.get(mid)
            if card is None:
                raise LinkValidationError(f"{qid}: unknown method_id {mid}")
            if qid not in set(card.get("linked_question_ids") or []):
                raise LinkValidationError(f"{qid}<->{mid}: method reciprocal link missing")
    return len(links)


def validate_card_refs(knowledge: dict[str, dict], methods: dict[str, dict]) -> None:
    for kid, card in knowledge.items():
        for mid in card.get("linked_method_ids") or []:
            if mid not in methods:
                raise LinkValidationError(f"{kid}: unknown linked method {mid}")
    for mid, card in methods.items():
        for kid in card.get("linked_knowledge_ids") or []:
            if kid not in knowledge:
                raise LinkValidationError(f"{mid}: unknown linked knowledge {kid}")


def validate_coverage(questions: dict[str, dict], knowledge: dict[str, dict], methods: dict[str, dict]) -> None:
    matrix = yload(COVERAGE_FILE)
    assets = matrix.get("knowledge_assets") or {}
    actual_f1 = sum("YN-WE-F1" in set(c.get("profile_families") or []) and c.get("status") == "active" for c in knowledge.values())
    actual_f2 = sum("YN-WE-F2" in set(c.get("profile_families") or []) and c.get("status") == "active" for c in knowledge.values())
    actual_f3 = sum("YN-WE-F3" in set(c.get("profile_families") or []) and c.get("status") == "active" for c in knowledge.values())
    expected = {
        "YN-WE-F1": actual_f1,
        "YN-WE-F2": actual_f2,
        "YN-WE-F3": actual_f3,
    }
    for family, count in expected.items():
        declared = int((assets.get(family) or {}).get("active_knowledge_cards") or 0)
        if declared != count:
            raise LinkValidationError(f"coverage matrix {family} card count {declared}!={count}")
    ready_count = sum(row.get("status") == "ready" for row in questions.values())
    if int((assets.get("YN-WE-F1") or {}).get("linked_ready_questions") or 0) != ready_count:
        raise LinkValidationError("coverage matrix F1 ready count drift")
    if len(methods) < 12:
        raise LinkValidationError("method bank unexpectedly small")

    queue = yload(STRATEGY_QUEUE)
    if queue.get("status") != "source-extraction-pending":
        raise LinkValidationError("strategy source gap status drift")
    text = STRATEGY_QUEUE.read_text(encoding="utf-8")
    for token in ("do not use 2026 prediction", "do not reconstruct missing option", "ready_strategy_question_count above zero"):
        if token not in text:
            raise LinkValidationError(f"strategy no-fabrication guard missing: {token}")


def main() -> int:
    sources = set((yload(SOURCE_FILE).get("sources") or {}).keys())
    questions = load_questions()
    knowledge = collect_cards(KNOWLEDGE_FILES, "knowledge_id")
    methods = collect_cards(METHOD_FILES, "method_id")

    require_known_sources(knowledge, sources, "authority_source_ids")
    require_known_sources(methods, sources, "evidence_source_ids")
    validate_family_boundaries(knowledge)
    validate_card_refs(knowledge, methods)
    linked = validate_question_links(questions, knowledge, methods)
    validate_coverage(questions, knowledge, methods)

    by_family = {
        family: sum(family in set(c.get("profile_families") or []) for c in knowledge.values())
        for family in ("YN-WE-F1", "YN-WE-F2", "YN-WE-F3")
    }
    print("teacher written-exam knowledge/method links: PASS")
    print(
        f"questions={len(questions)} linked={linked} knowledge={len(knowledge)} "
        f"methods={len(methods)} families={json.dumps(by_family, ensure_ascii=False)}"
    )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (LinkValidationError, json.JSONDecodeError, yaml.YAMLError) as exc:
        print(f"WRITTEN_EXAM_LINK_FAIL: {exc}", file=sys.stderr)
        raise SystemExit(1)
