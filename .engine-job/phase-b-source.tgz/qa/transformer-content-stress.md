# 下一盲测候选：变压器｜内容/角标/图形压力测试

状态：`content-stress-only`，**尚未切换 current-run**。

本轮不是为了替代正式随机选题，而是定向打最容易暴露系统缺陷的一类课题：大量 `$U_1/U_2/n_1/n_2$` 角标、器件结构、实验控制变量、理想模型和标准电气示意图同时出现。

## 1. Canonical 来源身份已经锁定

教材：人教版高中物理选择性必修第二册。

GitHub 上游：`TapXWorld/ChinaTextbook`

- commit：`5a80345f2043ba6f8db8d7be9cf3db82725ff1f7`
- path：`高中/物理/人教版-人民教育出版社/普通高中教科书·物理选择性必修 第二册.pdf`
- Git blob SHA：`0c3afecd87fee080aee47ec913942ad4fd76d6cd`
- size：`14339668` bytes

印刷页边界继续确认是 **56–57**。当前可检索教材副本的目录明确列出“3. 变压器 56 / 4. 电能的输送 61”，并且正文连续出现：

- 第56页：课题问题、闭合铁芯/原线圈/副线圈、互感原理、探究电压与匝数关系、可拆变压器；
- 第57页：两轮控制变量、低压交流与电表安全、数据分析、实际损耗、理想变压器、`$\frac{U_1}{U_2}=\frac{n_1}{n_2}$`、升压/降压判断；
- 电流与匝数关系在该页是进一步追问，不是这两页已经完成推导的正文结论。

因此当前内容边界不再依赖“课题名猜测”，而是有逐页文字证据。

## 2. 大 PDF 取得问题：不再把连接器当二进制下载器

此前“不能直接读取”具体表现为：连接器对十几 MB PDF blob 可能尝试按 UTF-8 解码二进制而失败。这是接口/传输问题，不是教材源身份漂移。

当前 publisher 的 locked-source 获取层已经要求：

1. 固定 `repo + commit ref + path + blob_sha + size_bytes`；
2. 依次尝试配置 URL、GitHub raw、GitHub media、GitHub API raw；
3. 端点失败自动重试并切换；
4. 成功后重新验证 `%PDF-`、精确 size 和 Git blob SHA；
5. verified cache 可复用，损坏缓存自动删除；
6. 全部失败则停止，不用未校验镜像顶替 canonical 文件。

当前执行容器本身没有可用外网 DNS，GitHub-hosted Actions 又仍受 Billing/runner 限制，所以这轮还无法在本环境取得真实 14.3 MB blob；但生产设计已经不再依赖 ChatGPT/GitHub 连接器能否“直接打开大 PDF”。

## 3. 已建立独立 regression 工作区

新增：

`production/regression/transformer-p56-57/`

其中已经有：

- `case.yaml`
- `evidence.yaml`
- `BOARD_PLAN.yaml`
- `01_训练参考教案.md`
- `02_考场骨架教案.md`
- `03_逐字稿.md`
- `04_课题专属答辩.md`
- `05_教材到骨架提炼解析.md`
- `README.md`

这一整套只用于**内容压力测试**，明确标记 `blocked-on-canonical-page-pixels`，不能冒充正式交付。

## 4. 当前 Point Chain

1. 为什么需要改变交流电压？
2. 变压器的结构：闭合铁芯、原线圈、副线圈。
3. 为什么没有导线相连仍能工作？——互感。
4. 怎样探究电压和匝数关系？——两轮控制变量、测量与安全。
5. 为什么真实数据不严格成比例？——实际损耗。
6. 忽略损耗建立理想变压器，得到 `$\frac{U_1}{U_2}=\frac{n_1}{n_2}$`。

主线压成：

`改变交流电压 → 结构 → 互感 → 实验 → 理想模型 → 电压/匝数规律`

## 5. 板书压力测试

总板书采用“路线 + 三块编号”，而不是把所有句子塞进同一个灰框：

1. 结构与原理
2. 探究电压与匝数
3. 理想模型与规律

同步板书使用 P0–P5 内部映射，但用户成品只显示同源的 1/2/3 编号和课堂路线。

## 6. 图形压力测试

本课至少要求两图：

1. `transformer-structure`：真正**闭合**铁芯，左侧原线圈接交流电源、右侧副线圈接负载，标 `$U_1,n_1,U_2,n_2$`；
2. `transformer-experiment`：突出可变匝数、测量 `$U_1/U_2$` 与控制变量关系。

之前 smoke 已经否掉“用两条竖线冒充闭合铁芯”的画法。图库 smoke 也已经从“检查包是否安装”升级为实际 XeLaTeX 编译 TikZ / PGFPlots / CircuiTikZ / tkz-euclide / tikz-3dplot。

本轮 200dpi 进一步发现实验图第一版的交流电源符号只是放在导线上，没有真正跨接原线圈两端；已修成原边并联电压表 + 真正跨两端的低压交流源。结构图说明文字也补了明确换段，避免与图在同一行横向流动。

这些可复用图已经独立到 `tools/physics_figures.py`，canonical publisher 先查物理图组件，再回退到旧 case 内置图。

## 7. 角标压力测试

必须正确通过：

- `$\frac{U_1}{U_2}=\frac{n_1}{n_2}$`
- `$U_1I_1=U_2I_2$`（notation fixture）
- `$\frac{I_1}{I_2}=\frac{n_2}{n_1}$`（notation fixture，不代表56–57页必讲）
- `$P_{\text{入}}=P_{\text{出}}$`

必须被机器拒绝：

- `$U1/U2=n1/n2$`
- `$I1/I2=n2/n1$`
- `$P入=P出$`
- `$T1/R2/B1$`

新增 `tools/check_transformer_content_stress.py`，对 regression 内容做 notation、边界、图形 marker、骨架长度、板书编号、答辩题数和“不得猜物理页”的门禁。

## 8. 全稿回归又抓出一个 publisher 真问题：粗体里含公式时会泄漏 `**`

第一次把完整 transformer regression 编成 11 页训练稿 + 3 页提炼解析，并全部按 200dpi 打开后，在提炼解析第2页发现若源码形如：

`**互感链：$I_1$变 → 磁场变**`

旧 renderer 会先按 `$...$` 切碎字符串，再分别识别 `**...**`，导致粗体边界跨越数学片段时无法闭合，最终把原始 `**` 直接印进 PDF。

这说明“源码里没有明显 Markdown 问题”不够，publisher 的 inline parser 本身也必须被回归测试。

已经修复：

- 新增 `tools/latex_inline.py`，先解析粗体跨度，再在粗体内部保留 `$math$` / `` `code` `` 原子；
- canonical `build_current_run.py` 将 `core.latex_inline` 统一路由到新 parser；
- `tools/check_current_run.py` 现在只要生成 TeX 仍包含字面 `**` 就 Hard Fail；
- `tools/build_transformer_content_stress.py` 在 XeLaTeX 前也会执行 inline/notation selftest，并对生成 TeX 再检查 Markdown 泄漏和角标。

修复后重新生成全部 14 页，生成 TeX 中 `**` 为 0；200dpi 重新逐页查看后，粗体、`$U_1/U_2/n_1/n_2$`、中文语义、图中文字均正常。

## 9. 当前非正式内容视觉回归结果

本地 regression 结果：

- 训练稿：11 页；
- 提炼解析：3 页；
- 总计：14 页；
- 全局沿用 `2.5cm / 1.6` 基线；
- 顶层模块均新页开始；
- 结构图与实验图已实际显示；
- 考场骨架保持短提示，不靠缩排版；
- 板书为主路线 + 1/2/3 三块，并在逐字稿中同源生成；
- 7 道答辩均是本课专属问题；
- `U_1/U_2/n_1/n_2` 角标实际显示正常；
- 未再发现 Markdown 星号泄漏、图形接线错误、标签遮挡、裁切或乱码。

仍存在一项**后续模板优化而非当前内容 Hard Fail**：逐字稿结束后的总板书可能自然单独占一页，页下方留白较多。用户已明确当前先关注内容，因此不为了压这一页而重新缩行距/缩字号；后续模板升级时再做更优的分页策略。

## 10. 印刷页 → PDF物理页不再靠经验猜

新增加 `tools/locate_locked_textbook_pages.py`。它的目标不是自动宣布页码正确，而是把之前最容易犯错的“印刷页与 PDF 物理页映射”改成稳定流程：

`locked binary → 全 PDF 文本扫描 → 课题/页码/上下文锚点打分 → 连续页候选排序 → top candidates 按200dpi渲染 → 人工实际打开确认`

transformer regression 的 `case.yaml` 已加入定位锚点：`变压器 / 原线圈 / 副线圈 / 互感 / 电压与匝数的关系 / 理想变压器`，并要求候选为连续两页。

定位器只负责缩小候选范围，**永远不会自动把 `physical_pages` 写回 manifest，也不会自动把 `page_pixels_verified` 改成 true**。它生成的 report 固定标记 `HUMAN_PIXEL_CONFIRMATION_REQUIRED`。

用合成页文本做了自测：当真正内容位于物理页4–5时，定位器把 `[4,5]` 排在第一；说明连续页评分、印刷页号和内容锚点的组合逻辑按预期工作。

这一步把之前《动能和动能定理》出现过的“只凭页码偏移猜 87–88”问题进一步系统化封死：以后先让程序找候选，再实际看像素，最后才允许写回物理页。

## 11. 目前仍然不能宣布通过的部分

状态仍然必须保持：

- `pdf_physical_pages_verified: false`
- `page_pixels_verified: false`

正式提升还缺：

`取得固定 Git blob → size/blob 校验 → 定位器找候选物理页 → 200dpi真实查看 → 确认印刷56/57 → 再切换正式 current-run → 两PDF全页验收`

在真实像素门禁通过前，当前 regression 只证明**内容链、角标链、板书链、图形链、publisher inline 渲染链和页码定位流程已经通过压力测试**，不证明教材页二进制闭环已经完成。
