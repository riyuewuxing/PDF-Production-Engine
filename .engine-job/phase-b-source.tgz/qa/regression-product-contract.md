# Regression product-contract migration QA

日期：2026-08-17

本记录验证的是**回归链自身是否仍然偷偷复制正式产品结构**，不是验证任何具体物理课题。

## 发现的结构性问题

正式 current-run 已经由共享 `production/contracts/*.yaml` 驱动，但旧 `build_regression_case.py` 仍在 Python 中重新手写：

`来源状态 → 训练参考 → 考场骨架 → 逐字稿 → 答辩`

同时旧 `regression_case.py` 还维护固定的 source-role tuple，例如 `reference_plan / exam_skeleton / trial / defense / analysis / board / evidence`。

这意味着未来产品合同调整、source role 改名或新增一个合法模块时，正式 publisher 与 regression publisher 会再次分叉；这不符合“所有修复必须通用、结构性”的硬规则。

## 通用修复

### regression case

每个 fixture 现在显式选择：

`product_contract: teacher-trial-two-pdf-v1`

`regression_case.py` 不再维护固定 source-role tuple，而是自动求并集：

`shared product contract 引用的 source roles + regression_contract 断言引用的 roles`

其中 board / defense / evidence 等 regression-only 语义通过：

- `board.source_role`
- `defense.source_role`
- `evidence_source_role`

显式声明，不再靠 Python 猜固定名字。

### regression publisher

`build_regression_case.py` 现在遍历共享 product contract 的 documents / sections：

- section 顺序来自 contract；
- heading 来自 contract；
- Markdown source role 来自 contract；
- `consume_board_markers` 来自 contract；
- `include_total_board` 来自 contract；
- `source_pages` renderer 在 regression 中只替换成清楚的 NON-FORMAL 来源状态说明，不伪造教材像素。

因此正式 publisher 与 regression publisher 共享同一产品结构；回归层只改变 provenance/status 表达和非正式输出命名。

## 与正式 role 名无关的 selftest

`regression_case.selftest()` 使用完全 synthetic 的 source role：

`ref_role / skel_role / talk_role / qa_role / analysis_role / board_role / evidence_role`

以及 synthetic product contract。测试证明：

- 正常动态 role 集合通过；
- forbidden token 能被通用断言捕获；
- 删除 product contract 所需的 `qa_role` 后必须失败。

因此 checker 不依赖正式项目里的 `reference_plan` 等固定名称。

## 结构性 PDF 视觉回归

另使用两个完全 synthetic fixture（generalization + ordinary）和同一 synthetic shared contract 执行：

`2 fixtures × 2 contract documents → XeLaTeX ×2 → 200dpi render → 实际查看全部 12 页`

生成结果：

- 每个 primary document 5 页；
- 每个 secondary document 1 页；
- 两个 fixture 使用不同内容/公式，仍走同一 builder；
- primary 的 5 个 section 均按共享 contract 独立起页；
- 同步板书与总板书位置正常；
- 四个 PDF 的 `pdffonts` 均显示字体 embedded/subset/unicode 为 yes；
- 200dpi 合并总览逐页检查未见裁切、重叠、乱码、section 串页或内部 marker 泄漏。

该视觉回归只验证 contract-driven regression 架构；不替代真实教材页 canonical pixel QA。
