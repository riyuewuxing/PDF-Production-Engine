# 通用化 / 结构化修复验收记录

本文件只记录**跨课题架构**，不以任何具体课题的“能不能过”作为系统完成标准。

## 1. 已建立的硬规则

- 根 `AGENTS.md` 与 teaching-demo `AGENTS.md` 已明确：所有修复先归纳失败类别，再修改共享 schema / registry / publisher / checker / renderer。
- generic execution 禁止按 `title`、`case_id`、课题目录名做字面分支。
- 具体课题只能作为 content / fixture；长期生产逻辑不得新增 `build_<课题>.py`、`check_<课题>.py`。
- 公式错误修 symbol/lint/math-mode 合同；图形错误修声明式 component contract；来源错误修 locked-source；页码错误修 locator；Markdown 错误修 parser。

## 2. 单一 canonical 执行路径

Canonical 主线：

`topic manifest/content + shared product contract → publisher_core.py → build_current_run.py → check_current_run.py → render_current_run.py`

其中：

- `publisher_core.py` 不识别课题名/case id，也不再保留任何 plain-text formula alias map；
- `build_current_run.py` 只增加 locked remote PDF 的通用多传输取得与 blob 校验；
- `check_tooling_routes.py` 禁止 CI / canonical tool 重新引用 retired stack，并禁止把 Python 伪装成 declarative component；
- `check_generalization_architecture.py` 禁止 canonical tool 泄漏 current-run/regression 的 title/case id、fixture slug、已注册 figure marker、字面课题分支；任何公式 alias-map 符号重新出现也直接失败；
- `render_current_run.py` 遍历 manifest 的 `deliverables`，数量、额外文件和渲染 DPI 由 contract/manifest 共同校验。

旧 ReportLab / exact-page batch publisher 保留为历史考古文件，不属于当前执行路径，也不再接受新修复。

## 3. 产品结构也已从课题 manifest / Python 硬编码中抽离

发现一个结构性问题：此前两 PDF 虽然是通用 publisher，但“五个顶层模块的标题/顺序”“第三段就是骨架、第四段就是逐字稿”“提炼解析必须出现哪些章节”等产品结构同时散落在：

- `current-run.yaml`；
- `publisher_core.py`；
- `check_current_run.py`；
- `check_current_run_core.py`。

这会造成**同一产品合同多处复制**：未来任何产品级调整都要同步改多份代码，而且 checker 过去曾通过位置 `[2] / [3]` 猜骨架与逐字稿。

现已新增共享合同：

`production/contracts/teacher-trial-two-pdf-v1.yaml`

其中统一声明：

- document role / deliverable role；
- TeX 输出文件名；
- 文档 header、title suffix、subtitle；
- section role、heading、renderer、source role；
- 哪些 section 累积总板书；
- 哪个 section 消费同步板书 marker；
- training / extraction 的 QA document role；
- skeleton / trial / defense / homework solution 的 QA section role；
- required training section roles 与 extraction 必需章节。

随后做了三处结构迁移：

1. `current-run.yaml` 已删除 `top_level_section_headings`、`required_training_text`、`required_extraction_sections`、`require_top_level_section_new_page` 等产品结构复制，只保留本次课题数据和可变阈值。
2. `publisher_core.py` 通过 `product_contract` id 加载共享 YAML，按 `renderer + role` 循环构建文档；不再硬编码“五个 section 的 Python 拼接”。
3. 两层 formal checker 与 publisher 读取**同一份 contract**，按 role 定位骨架、逐字稿、答辩、作业解析和分页，不再依赖“第3段/第4段”等位置假设。

`publisher_core.py` 还包含完全 synthetic 的 product-contract selftest：使用非 `training/extraction` 的 document role 名验证 contract id/path、role 唯一性、deliverable/source binding 与路径穿越拒绝。

### 2026-08-17 产品合同结构视觉回归

为了验证这次迁移不是“只改 YAML”，又使用完全无真实课题语义的 synthetic contract 生成：

- 5 页 primary document；
- 1 页 secondary document。

执行：

`contract role iteration → XeLaTeX ×2 → pdffonts → 200dpi render → 实际逐页查看`

结果：

- 5 个 section 严格按 contract 顺序独立起页；
- source / reference / skeleton / spoken / questions 使用的是 synthetic role 名，证明不是依赖正式课题或固定 Python 索引；
- 页眉、页脚、2.5cm 页边距、1.6 行距保持原正式视觉基线；
- 同步板书与总板书框正常；
- 两个 PDF 字体均全部嵌入；
- 未见裁切、重叠、乱码或跨模块串页。

该回归证明的是**产品结构层**，不替代真实教材页像素验收。

## 4. Regression 机制

`production/regression/*/case.yaml` 是 fixture 数据。差异写在 `regression_contract`，通用工具自动发现：

- `regression_case.py`
- `check_regression_case.py`
- `build_regression_case.py`
- `run_regression_suite.py`
- `render_regression_suite.py`

结构门禁已经进一步收紧：

- 至少保留 2 个 fixture；
- 至少 1 个 fixture 必须声明 `generalization_fixture: true`，并且必须是 non-formal；
- 同时至少保留 1 个普通 fixture；
- case id 不允许重复。

因此回归套件不能再次退化成“当前课题自己证明自己”。目前 synthetic-generalization 是无关通用 fixture，另有真实历史课题 regression 作为第二类验证。

## 5. 图形系统已去课题代码化

过去 `physics_figures.py` 虽然通过 registry 避免 publisher 分支，但具体图形实现仍然写在 Python 函数里；这仍意味着新增图形要改执行代码。

现已迁移为：

`[[FIGURE:<marker>]] → physics_figures.py generic loader → production/components/figures/registry.yaml → *.tex declarative asset`

硬门禁：

- `physics_figures.py` 只负责 marker/path/schema/figurepanel/qzlabel 校验，不含任何真实课题图实现；
- 真实图形实现全部移到 `production/components/figures/*.tex`；
- 新图只增加 `.tex + registry` 数据，不修改 publisher/checker/renderer Python；
- unknown marker Hard Fail；路径穿越/绝对路径/重复 asset/非 `.tex` asset Hard Fail；
- `check_generalization_architecture.py` 会读取 declarative registry，并禁止已注册 marker 字面泄漏回 generic execution；
- `check_tooling_routes.py` 会拒绝 `.py` declarative component。

### 2026-08-17 图形组件迁移视觉验收

迁移后的 4 个既有组件使用同一个 generic loader 自动发现并执行：

`XeLaTeX → PDF → 200dpi render → 实际查看整页`

同一页同时包含 4 个组件，实际检查结果：

- 变压器结构图与实验图的线圈、铁芯、电压标签、磁通箭头显示正常；
- 多力小车图、恒力做功模型图的受力/速度/位移箭头与标签间距正常；
- `qzlabel` 白底隔离仍有效，没有标签压线；
- 4 个 figurepanel 均无裁切、重叠、乱码或公式破损。

## 6. Figure toolchain 与正式 publisher 已做结构一致性修复

发现一个跨课题风险：`check_figure_toolchain.py` 支持 PGFPlots / CircuiTikZ / tkz-euclide / tikz-3dplot，但正式 publisher 过去只加载 TikZ + CircuiTikZ。这样未来某课题新增函数图、几何图或三维图时，会出现“组件 smoke 能过，正式 PDF 反而编译失败”。

修复方式不是给某个课题加包，而是让正式 publisher 统一加载同一套 core figure stack，并在 `check_publisher_core.py` 中使用**完全 synthetic 的图形**同时调用 PGFPlots、tkz-euclide、tikz-3dplot，并保留 CircuiTikZ 环境。

2026-08-17 已用正式页边距/字体/header/figurepanel 进行：

`XeLaTeX ×2 → pdffonts → 200dpi render → 实际查看`

结果：四类图形能力同页正常显示，字体全部嵌入，无裁切、重叠、乱码。该验证不依赖任何真实课题文本。

## 7. 公式与 inline parser

- 正式源中的物理等式必须已经处于 `$...$` 数学模式；
- publisher 不再把普通文本 alias 猜成公式，旧 alias map 已从 canonical publisher 删除；
- generalization gate 禁止未来重新引入 alias-map 符号；
- source lint 使用 `require_math_mode=True`；
- generated TeX lint 使用 `require_math_mode=False`，避免把 `left=2.5cm` 等 TeX 配置误判成物理公式；
- 数字下标、中文语义下标、组合状态下标由共享 `physics_notation.py` 处理；
- `latex_inline.py` 是 delimiter-safe parser：未闭合 `**bold**` / `$math$` / `` `code` `` 直接失败，不把坏源码交给 XeLaTeX；
- `**粗体 + $公式$ + 文字**` 可以跨 math atom 正确闭合；math/code 内出现 `**` 不改变粗体状态；
- plain text 可用反斜线转义字面 `$` / `` ` `` / `*` / `\`；
- `publisher_core.latex_plain` 对普通 `$` 做 LaTeX 安全转义，数学 `$...$` 只由 parser 作为 atom 原样保留。

## 8. 板书与 QA

- `board_contract.py` 不再识别 `R3-C...` 命名，也不制造用户可见 `B0/B1`；
- 产品级 module/section 结构由共享 product contract 提供；
- manifest 只保留课题数据和可变阈值，例如骨架最大长度、答辩题数、板书数量、图形数量、来源锁定和字体/公式 gate；
- `check_current_run.py` 同时执行 tooling-route、generalization、product-contract、board、notation、inline、figure component gates。

## 9. 与课题无关的视觉回归

2026-08-17 使用完全 synthetic / topic-agnostic 的 5 页结构样例执行：

`XeLaTeX ×2 → A4/font preflight → 200dpi render → 实际逐页查看`

检查结果：

- 5 个顶层模块各自新页开始；
- 2.5cm / 1.6 全局视觉基线正常；
- 公式上下标实际显示正常；
- `qzlabel` 标签与箭头/线条保持间隔；
- 同步板书与总板书层级清楚；
- 未见裁切、标签压线、Markdown 泄漏、乱码或字体未嵌入。

inline parser 改造后又单独做了一次**无具体课题**的 XeLaTeX + 200dpi smoke，同时覆盖粗体包公式、不同数字下标比值、字面 `\$5`、字面星号和代码路径。实际页面确认粗体边界、数学上下标、字面美元/星号、代码原子与字体嵌入均正常。

这些都是**通用结构视觉回归**，不替代任何正式课题的真实题面/教材像素验收。

## 10. 当前外部阻塞

GitHub Actions workflow 已接入上述通用门禁，但 GitHub runner 当前仍在 job 启动前被账户 Billing / spending limit 拦截。最新 `c1d762c9...` push 对应的 run 也是 job 尚未启动即被 Billing/spending-limit 拦截，因此该状态不能被记作代码测试失败，也不能被记作 CI 已通过。

在 runner 恢复前，本地/synthetic 编译与视觉检查用于发现结构问题；正式 CI 结论仍保持 pending / externally blocked。
