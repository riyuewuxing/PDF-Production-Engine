# Post-freeze route-completeness audit

日期：2026-08-17

## 发现

第二轮删除式审计后再次检查 `tools/`，发现 `check_latex_release.py` 仍留在工作树。它属于旧 exact-page / 六 PDF 时代的 release checker，检查 `ExactPage5A/5B`、30份历史 TeX 和旧输出目录，不属于当前两个正式 PDF 产品合同。

更重要的是，这暴露出一个**结构类别漏洞**：旧版 `check_tooling_routes.py` 能阻止 workflow 调用未分类工具，却不能阻止“文件仍留在 `tools/`、暂时没人调用”的未分类 Python。这样工作树仍可能悄悄保留第二执行入口。

## 通用修复

1. 删除 `tools/check_latex_release.py`；Git history 保留历史实现。
2. `tools/tooling-manifest.yaml` 升级到 version 6，并把该名称加入 `retired`。
3. `check_tooling_routes.py` 新增 repo-wide top-level `tools/*.py` classification gate：
   - canonical / compatibility / retired 三类之外的任何 Python 文件 → `UNCLASSIFIED_TOOL_PRESENT` Hard Fail；
   - selftest 会临时创建 `unknown.py`，验证即使 workflow 没调用它也必须失败；
   - workflow 若真的调用未分类脚本，仍由 `WORKFLOW_CALLS_UNCLASSIFIED_TOOL` 单独失败。
4. `tools/README.md` 更新为当前 frozen architecture，删除旧 `declarative_components` 表述，并把唯一入口收成 `python tools/run_acceptance.py --scope full`。

## 本地出版重放

本次修复只触及 route gate / 文档，没有改 publisher、内容或 figure component。仍重新执行现有本地重放：

- graph fixture：PASS
- convex-lens fixture：PASS
- post-refactor formal replay：training 10页 / extraction 3页
- formal replay render：13页
- `pdffonts`：未发现未嵌入字体
- `pdfinfo`：A4，Creator=`XeLaTeX - qiuzhidaren`，Producer=`xdvipdfmx`
- `pdftotext` leak scan：`[[BOARD:` / `[[FIGURE:` / `**` / 字面 `$...$` / `Pn` / `Bn` 均未命中

由于这次没有修改出版实现，前一轮已经完成的200dpi全页视觉结论仍成立；本地重放再次证明输出可编译/可渲染。

## GitHub-hosted CI

最新可见 workflow run `32039678167`（head `36734cdb...`）仍在约4秒内结束为 failure，延续此前 hosted runner 外部阻塞状态。当前连接器仍无法读取该 run 的 jobs endpoint，因此本记录不把它解释为代码测试结果；正式状态仍为：

`local/structural acceptance PASS; GitHub-hosted CI not certified`

## 结论

Route completeness 最后一处漏洞已经补齐：

> **不仅 workflow 不能调用第二路线，工作树本身也不能存在未分类 Python 第二入口。**

从此正常课题迭代只允许变化 manifest / content / BOARD_PLAN / declarative figure assets；generic execution 继续冻结。
