# Product-contract role gate QA

日期：2026-08-17

本记录只验证**跨课题产品结构**，不把任何真实课题当成系统正确性的证明。

## 失败类型

共享产品合同虽然已经把 document / section 结构从课题 manifest 与 publisher 中抽离，但 QA 层仍可能通过“固定知道某几个 key 名”的方式重新形成第二套隐藏合同。例如未来新增 `xxx_section_role`，如果 checker 还要手工新增 Python key 列表，结构就再次分叉。

## 通用修复

`tools/check_current_run.py` 新增后缀驱动的 QA role gate：

- 任意 `qa.*_deliverable_role` 必须唯一解析到一个 document；
- 任意 `qa.*_section_role` 必须唯一解析到一个带 `source_role` 的 Markdown section；
- `required_training_section_roles` 中的 role 必须属于 `training_deliverable_role` 指向的同一 document；
- `required_extraction_sections` 必须是有效字符串列表。

这套检查不识别正式产品的具体课题，也不维护 `skeleton / trial / defense / homework` 的固定 Python key 列表；未来新建符合后缀约定的 QA role 会自动进入门禁。

## 无关 synthetic negative selftest

使用 `primary / secondary`、`alpha / beta`、`body / spoken / foreign` 等完全合成 role 验证：

1. 正常合同通过；
2. 新增未知 `future_semantic_section_role` 必须失败；
3. 新增未知 `future_output_deliverable_role` 必须失败；
4. 把 `source_pages` section 当作单值语义 `*_section_role` 必须失败；
5. 把 secondary document 的 section 填入 `required_training_section_roles` 必须失败。

本地同构 selftest 结果：`suffix-driven QA role gate selftest: PASS`。

## 结构性视觉回归

虽然本次改动只改变机器门禁、不改变 publisher 输出，仍按项目硬规则重新执行了 synthetic product-contract acceptance：

`XeLaTeX ×2 → pdffonts → 200dpi render → 实际逐页查看`

结果：

- primary document：5 页；5 个 contract section 继续各自独立起页；
- secondary document：1 页；
- 字体全部嵌入；
- 总板书 / 同步板书框正常；
- 未发现裁切、重叠、乱码、跨 section 串页或视觉基线漂移。

该验收只证明产品结构门禁改动没有引入视觉回归；**不替代真实教材页的 canonical pixel QA**。
