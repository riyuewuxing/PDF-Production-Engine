# Shared source-role migration QA

日期：2026-08-17

本记录验证的是**跨课题 source-role 路由**，不以任何真实课题作为系统正确性的证明。

## 失败类型

产品 document / section 已由 shared product contract 驱动后，仍发现一类隐性重复：

- formal publisher 曾直接取 `source.board`；
- formal checker 曾直接取 `source.board` / `source.evidence`；
- regression checker / builder 曾在每个 fixture 的 `regression_contract` 中重复声明 board / evidence / defense 的 source role。

这会导致 source key 一旦重命名，需要同步修改 Python 和多个 fixture；属于结构性硬编码。

## 通用修复

共享合同现在声明：

```yaml
runtime:
  board_source_role: board
qa:
  evidence_source_role: evidence
  defense_section_role: defense
```

其中 defense 不直接保存 source role，而是统一经过：

`qa.defense_section_role → contract section → section.source_role`

`publisher_core.contract_source_roles()` 会收集 document/section source role 与 `runtime/qa` 中所有单值 `*_source_role`，`validate_manifest_binding()` 统一检查 manifest 是否绑定这些角色。

formal publisher：

- 需要哪些源文件由 `contract_source_roles()` 推导；
- board 路径由 `runtime.board_source_role` 推导；
- 不再固定读取 `BOARD_PLAN.yaml`。

formal checker：

- evidence 路径由 `qa.evidence_source_role` 推导；
- board 路径由 `runtime.board_source_role` 推导；
- skeleton / defense / homework 继续由 `*_section_role → section.source_role` 推导；
- notation lint 的源集合由全部 Markdown document/section + shared board source 自动推导，未新增一份 role 列表。

regression：

- `regression_case.py` 的共享角色集合直接使用 `product.contract_source_roles()`；
- board / evidence / defense 均从 shared product contract 推导；
- fixture 已删除 `evidence_source_role`、`board.source_role`、`defense.source_role` 的重复声明；
- `regression_contract.board` / `defense` 只保留本 fixture 的断言阈值和结构条件。

## 无关 role 重命名 selftest

使用完全 synthetic 名称：

`boardx / evidx / refx / skelx / talkx / defx / analysisx`

验证：

- contract 能自动收集全部 source role；
- defense 能通过 section role 找到 `defx`；
- 把 board/evidence/defense source role 再次重命名后，不修改算法仍能得到新的角色集合；
- 删除 contract 所需的 defense binding 时 regression validator 必须失败。

本地同构测试结果：`shared source-role derivation selftest: PASS`。

## PDF 结构复验

本轮 source-role 改造不改变视觉模板，但仍重新执行 synthetic product acceptance：

`XeLaTeX ×2 → pdfinfo/pdffonts → 200dpi render → 实际查看全部页面`

结果：

- primary：5 页；secondary：1 页；
- A4；字体全部嵌入；
- 5 个 contract section 保持独立起页；
- 同步板书 / 总板书正常；
- 未发现裁切、重叠、乱码、跨 section 串页或视觉基线漂移。

该验收仅证明共享 source-role 路由没有引入结构/视觉回归；**真实教材 canonical page pixels 仍未在本环境完成验收，不能据此标记为通过。**
