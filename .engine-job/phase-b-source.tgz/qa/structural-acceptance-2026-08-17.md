# Structural acceptance — 2026-08-17

本记录只验收**通用执行架构**。正式 current-run 的教材页在本次本地验收中由两张明确标记的 synthetic A4 source pages 替代，因此本记录**不能**把真实教材 canonical pixels 标记为通过。

## 1. 实际检出仓库并运行 canonical gates

在 `codex/round-3-page-to-plan` 最新分支检出上执行：

```bash
python -m py_compile \
  tools/publisher_core.py \
  tools/check_current_run.py \
  tools/check_current_run_core.py \
  tools/regression_case.py \
  tools/build_regression_case.py \
  tools/render_current_run.py \
  tools/render_regression_suite.py \
  tools/check_tooling_routes.py \
  tools/check_generalization_architecture.py

python tools/check_tooling_routes.py
python tools/check_generalization_architecture.py
python tools/check_regression_case.py --selftest
python tools/check_publisher_core.py
python tools/check_figure_toolchain.py
python tools/run_regression_suite.py
python tools/render_regression_suite.py
```

上述命令全部完成，无 Python syntax failure、tooling-route failure、generalization failure、product-contract smoke failure 或 figure-toolchain failure。

## 2. Regression 全套真实执行

当前全部已登记 regression fixtures 均由通用 runner 自动发现、构建并渲染；没有逐课题执行入口。

人工查看 `qa/regression-rendered/` 全部生成页的 contact sheets：

- `synthetic-generalization`：未见裁切、重叠、乱码、板书框破损或 section 串页；
- `transformer-p56-57`：未见裁切、重叠、乱码、图形 panel 破损或标签压线。

该结果只说明 regression 出版链结构正常；transformer fixture 仍保持 `blocked-on-canonical-page-pixels`，不能升级为正式来源验收。

## 3. Formal current-run 离线结构验收

为了验证最新 formal builder/checker/renderer 的**实际组合运行**，创建两张 A4 synthetic source page，页面上明确写有：

`SYNTHETIC SOURCE PAGE / Layout regression only - NOT textbook evidence`

然后执行：

```bash
QZ_OFFLINE_SOURCE_DIR=<synthetic-pages> python tools/build_current_run.py
QZ_ALLOW_OFFLINE_REGRESSION=1 python tools/check_current_run.py
python tools/render_current_run.py
```

结果：

- formal product contract 成功驱动全部正式 documents；
- machine gate 通过 offline-regression 模式；
- expected/actual PDF 集由 product contract + manifest roles 校验；
- 总板书数量由 `include_total_board` section 数自动推导；
- 同步板书数量由实际 `[[BOARD:Pn]]` markers 自动推导；
- board marker 均能在 BOARD_PLAN increments 中解析；
- render DPI 来自 `product_contract.render.dpi`，不来自课题 manifest 固定数字。

随后实际查看 `qa/current-run-rendered/` 的全部 200dpi 页面：未见裁切、重叠、乱码、section 串页、Markdown/board marker 泄漏或明显视觉基线漂移。

## 4. 本轮结构性结论

以下内容现在不再由具体课题 manifest 或课题专属 Python 决定：

- PDF/document 数；
- document/section 顺序与标题；
- board/evidence/defense 的共享 source-role 路由；
- 总板书份数；
- 同步板书份数；
- renderer DPI；
- skeleton 长度/页数规则；
- defense 题数规则；
- homework solution policy；
- XeLaTeX / typography / notation / engineering-label policy。

`current-run.yaml` 只保留当前教材来源/课题内容以及真正会随课题变化的 `board_sections_min`、`figure_count_min`。

## 5. 仍未通过的正式来源门禁

本记录没有检查真实上游 textbook PDF 的 canonical page pixels。真实教材页下载、物理页定位和逐页像素视觉验收完成以前：

- 不得把 synthetic source pages 当教材证据；
- 不得把 `canonical_pdf_pixels_inspected` 改为 true；
- 不得宣称真实题面视觉 QA 已通过。
