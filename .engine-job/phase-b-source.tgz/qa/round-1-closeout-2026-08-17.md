# Round 1 / 2 — 收口前第一轮验收记录

日期：2026-08-17

本轮目标不是继续扩功能，而是把“从当前状态到收口”的第一批风险压实：**考场骨架手写密度、跨课题复用证明、真实来源阻塞边界、CI 状态真实性**。

## 1. 考场骨架：从单一字符上限升级为通用密度合同

用户提供的真实约10分钟手写教案仍是最高视觉参考。机器门禁只负责拒绝明显异常，不能用一个字符数替代人工判断。

新增通用工具：

- `tools/skeleton_density.py`
- `tools/check_skeleton_density.py`

共享产品合同 `teacher-trial-two-pdf-v1` 新增 `qa.skeleton_density`，检查维度包括：

- 可见非空字符总量；
- 实际内容行数；
- 平均/单行可见长度；
- 完整句比例；
- 关键词/箭头/公式型 cue line 比例；
- 长段 prose line 数。

当前共享 hard-fail guardrail：

- `max_nonspace_chars: 800`
- `min_content_lines: 7`
- `max_content_lines: 28`
- `max_avg_visible_chars_per_line: 46`
- `max_single_line_visible_chars: 96`
- `max_full_sentence_ratio: 0.30`
- `min_cue_line_ratio: 0.60`
- `max_long_prose_lines: 2`

这些阈值是**宽松的机器异常检测线**，不是“超过/低于某个数就自动等价于真实手写质量”。

### 通用 selftest

使用完全无关的 synthetic 内容验证：

1. 关键词 + 箭头 + 公式型导航纸通过；
2. 多个完整长句组成的“小作文骨架”被 `SKELETON_TOO_PROSE_LIKE / SKELETON_CUE_RATIO_LOW` 类门禁拒绝；
3. 大量密集 bullet 即使不是完整句，也会被总手写负载门禁拒绝。

本地执行：`skeleton density selftest: PASS`。

## 2. 两个不同课题的密度回归

同一算法、同一共享 profile 分析两个完全不同内容类型，没有修改 Python。

### 动能和动能定理

- visible nonspace：227
- content lines：9
- 平均可见长度：25.22
- 单行最大长度：39
- 完整句比例：0.111
- cue line 比例：1.000
- long prose lines：0
- 结果：PASS

### 变压器

- visible nonspace：261
- content lines：10
- 平均可见长度：26.10
- 单行最大长度：48
- 完整句比例：0.200
- cue line 比例：0.900
- long prose lines：0
- 结果：PASS

这只证明两份骨架没有落入“详细教案压缩成一页”的明显失败类型；最终仍需视觉上与真实10分钟手写样本对照。

## 3. Regression 路由已经纳入密度门禁

`tools/run_regression_suite.py` 现在在每个自动发现的 fixture 上同时执行：

`regression contract → shared skeleton-density gate → build`

因此未来新增课题 fixture 不需要再写 `check_<课题>_density.py`，也不需要在 workflow 中添加该课题名字。

GitHub Actions 只保留：

- 通用 density selftest；
- 通用 regression runner；
- 当前 formal skeleton density gate。

没有逐课题密度步骤。

## 4. 《变压器》真实 blind-run 的来源状态

《变压器》fixture 继续锁定：

- repo：`TapXWorld/ChinaTextbook`
- commit：`5a80345f2043ba6f8db8d7be9cf3db82725ff1f7`
- path：`高中/物理/人教版-人民教育出版社/普通高中教科书·物理选择性必修 第二册.pdf`
- blob：`0c3afecd87fee080aee47ec913942ad4fd76d6cd`
- size：`14339668`
- printed pages：56–57
- physical pages：仍为 `null`

本轮再次确认当前 GitHub connector 对该 PDF blob 的直接获取仍会在二进制→UTF-8阶段失败。这是**连接器二进制能力限制**，不能据此更换教材身份或猜物理页。

同时检查到另一个公开教材仓库中存在同名选择性必修第二册 PDF，但其 blob / size 与当前锁定 canonical 源不同，因此明确拒绝把它当成 canonical 替身。

结论：本轮允许继续使用《变压器》做 NON-FORMAL 内容/公式/图形/骨架 regression，但在以下链条完成前不得晋升正式 current-run：

`锁定二进制取得 → blob/size 校验 → locator 候选 → 200dpi实际打开 → 印刷56/57人工确认`

## 5. 真实手写视觉参考状态

规则与仓库 README 已明确：用户本人严格掐表约10分钟完成的 5 张手写教案，是考场骨架密度最高视觉参考。

本轮尝试通过 Files / GitHub 恢复原始照片或 SVG 内嵌像素；当前环境只能稳定读到仓库 SVG 的文本/base64 外壳，未能把其完整私有仓库二进制安全物化到本地查看。因此本轮**不宣称重新完成了手写样本像素级视觉复核**。

这不影响机器密度合同的通用化落地，但第二轮最终 freeze 前必须把“真实手写视觉对照是否完成”作为单独验收项，而不是用机器指标替代。

## 6. GitHub Actions 状态

最新 workflow 仍在 runner 分配前失败：

- `runner_id = 0`
- `steps = []`
- GitHub annotation 明确提示近期账户付款失败或 spending limit 需要提高。

因此当前状态必须写成：

**local / structural validation available；GitHub-hosted CI externally blocked。**

不得写成代码 CI 失败，也不得写成 CI 已通过。

## 7. 第一轮完成结论

本轮已经完成：

- 考场骨架从单一字符上限升级为通用、多维、课题无关的机器门禁；
- 共享 product contract 持有密度 policy，不由具体课题 manifest 决定；
- regression runner 自动对全部 fixture 使用同一门禁；
- 当前力学课题 + 电磁课题均在同一规则下通过；
- 《变压器》真实来源门仍保持 fail-closed，没有用替代 PDF 或经验页码绕过；
- CI 外部 Billing blocker 再次得到真实确认；
- 明确记录本轮没有伪称重新打开真实手写像素。

## 8. 第二轮只做收口，不再扩张

第二轮固定任务：

1. 完成 1–2 个异构课题的最终通用性回归（优先图像/光学/实验型，避免继续堆同类推导课）；
2. 删除式架构审计：清理 duplicate route、retired/compatibility 回流、文档与真实代码不一致；
3. 将 formal machine gate / regression gate / visual gate 的入口收成唯一协议；
4. 能取得真实二进制时完成《变压器》canonical physical-page + 200dpi像素闭环；不能取得时明确保留为外部 blocker，绝不伪通过；
5. 尝试恢复用户真实10分钟手写参考的实际视觉对照；
6. 从空 outputs 开始做最终全量重建、全页视觉验收；
7. 生成 `FINAL_ACCEPTANCE.md` 并冻结当前产品合同/唯一执行入口。

第二轮完成后停止继续“预防性扩架构”，只对真实使用中新出现的失败类别再迭代。
