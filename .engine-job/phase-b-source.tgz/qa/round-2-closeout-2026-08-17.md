# Round 2 / 2 — 最终收口验收记录

日期：2026-08-17

本轮按照既定计划只做**收口**：异构回归、删除式架构审计、唯一验收协议、正式产物重放、外部 blocker 明确化。没有为某个具体课题新增专属 publisher/checker/renderer。

## 1. 共享产品 policy 已真正收回 Product Contract

Round 2 重新核对运行代码后发现：此前文档已经提出“共享 policy 进入 product contract”，但实际 `current-run.yaml` 与 renderer/checker 仍有部分共享数字/开关，设计与运行时存在漂移。本轮按失败类别修复，而不是为当前课题打补丁。

现在 `production/contracts/teacher-trial-two-pdf-v1.yaml` 是共享产品 policy 的唯一 authority，统一保存：

- 两个正式 PDF 的 document/section 结构；
- 200dpi render policy；
- XeLaTeX / 全局旧版 typography / notation lint；
- source lock + resilient transport policy；
- 5 个顶层模块新页规则；
- 考场骨架单 section 页跨度；
- 多维手写密度 guardrail；
- 答辩 5–8 题；
- 作业参考解析 policy；
- required training/extraction sections。

`production/current-run.yaml` 只保留当前课题事实、锁定来源和两个真正会随课题变化的断言：

- `board_sections_min`
- `figure_count_min`

`publisher_core.validate_manifest_binding()` 会拒绝共享 policy 再泄漏回某课题 manifest。

## 2. 异构通用性回归已扩到 4 个 fixture / 5 类能力

Regression suite 现在至少要求 4 个自动发现的 fixture，并按**能力标签**而不是课题名检查异构覆盖。当前覆盖：

1. `synthetic-generalization` → `generic-architecture`
2. `transformer-p56-57` → `apparatus-circuit`、`experimental-control`
3. `kinematics-vt-graph` → `graph-data`
4. `convex-lens-ray` → `geometry-optics`

新增图像/数据型和几何光学型 fixture 时，没有增加 `build_<课题>.py`、`check_<课题>.py` 或 generic `if title == ...`。

### 图像/数据型

`速度—时间图像的斜率与面积` 测试：

- PGFPlots 图像；
- 横纵轴/折点读取；
- 斜率→加速度；
- 有向面积→位移；
- 板书、逐字稿、答辩中的同图复用。

### 几何光学型

`凸透镜成像的光路判断` 测试：

- 主光轴、光心 O、F、2F；
- 两条典型光线；
- 实际交点→实像；
- 代表性 `u>2f → f<v<2f`；
- 标签避让与黑白打印可读性。

两类 fixture 都通过同一 generic publisher 在本地实际 XeLaTeX 编译，并按约200dpi查看。图像 QA 过程中还实际发现并修复：

- PGFPlots 默认蓝色不利于黑白打印 → 共享图组件改为黑色；
- 第一版光学说明文字压线/拥挤 → 减少图内长标签，把说明移入 caption；
- 光心 O 最初没有显式标注 → 共享光学组件补 O。

这些修复全部落在可复用 figure component，不是某页临时挪坐标。

## 3. 又发现一个公式出版类别错误，并做成通用门禁

异构回归第一次实际渲染时发现：如果源 Markdown 写成 `` `$a=0$` ``，即把 `$...$` 整体放进 code span，publisher 会正确把它当代码，最终 PDF 就会出现字面 `$`、`\Delta`、花括号等。

本轮没有只修两份 fixture，而是在 `tools/physics_notation.py` 新增通用 Hard Fail：

`PHYSICS_MATH_MARKUP_INSIDE_CODE`

规则：

- `` `F=ma` `` 作为真正代码示例可以存在；
- 任何 code span 内再包含 `$` 数学 delimiter 直接失败。

随后 synthetic / graph / optics 源全部改回真正数学模式。重新编译后 PDF 不再泄漏 `$...$` 或 LaTeX 原文。

## 4. 删除式架构审计完成

收口目标是减少入口，而不是保留“双轨以防万一”。本轮已删除工作树中的重复/退役实现：

- `build_current_run_core.py`
- `check_current_run_core.py`
- `build_exact_page_latex.py`
- `publish_exact_page_latex.py`
- `build_exact_page_pdf.py`
- `build_pdf.py`
- `pdf_engine_v2.py`
- `check_content.py`

Git history 保留历史实现。`tools/tooling-manifest.yaml` 当前 `compatibility_only: []`；retired 条目只负责阻止它们重新成为执行依赖，不要求旧文件继续留在工作树。

Formal checker 已收成 `tools/check_current_run.py` 一层，不再在尾部再调用第二套 checker。

## 5. 唯一 canonical acceptance CLI 已建立

新增：

`python tools/run_acceptance.py --scope full`

固定调用顺序：

1. tooling route gate
2. generalization architecture gate
3. board contract
4. skeleton-density selftest
5. generic publisher integration smoke
6. figure toolchain smoke
7. locked-page locator selftest
8. auto-discovered regression suite
9. regression 200dpi render
10. formal build
11. formal machine gate
12. formal 200dpi render

最后固定输出：

`HUMAN_PIXEL_CONFIRMATION_REQUIRED`

因此机器/编译/render 和“人工视觉通过”仍严格分开。

`.github/workflows/build-pdf.yml` 也已经收成只调用这个 generic acceptance runner，不再在 workflow 里逐条维护十几份重复命令，更不识别课题名。

## 6. Post-refactor 正式产物本地重放

由于 GitHub-hosted Actions 仍受 Billing 外部阻塞，本轮用**此前已经 canonical 人工确认过的教材 84/85 像素**做 post-refactor publication replay，而不是用空白 synthetic 页冒充教材。

这次重放验证的是：共享 contract / publisher / board / figures / typography 重构以后，正式产物还能否保持正确显示。它**不是一次新的远程 canonical 下载/provenance 验收**。

实际结果：

- `动能和动能定理｜面试训练稿.pdf`：10 页
- `动能和动能定理｜教材到骨架提炼解析.pdf`：3 页
- A4：595.28 × 841.89 pt
- Creator：`XeLaTeX - qiuzhidaren`
- Producer：`xdvipdfmx`
- 字体：未发现未嵌入字体
- `pdftotext` leak scan：未发现字面 `$`、`[[BOARD:`、`[[FIGURE:`、`**`、`Pn/Bn` 工程标记
- 顶层模块起始页：1 / 3 / 6 / 7 / 10
- 考场骨架与总板书：同在第6页

### 200dpi 全页人工查看

实际逐页查看 10 + 3 = 13 页：

- 教材84/85：页面内容和印刷页码仍正确，无裁切；
- 训练参考教案：角标、单位、作业图和完整解析正常；
- 总板书：路线 + 1/2/3 编号结构清晰；
- 考场骨架：一页完成，非小作文，板书同页；
- 逐字稿：同步板书按形成时序出现，示意图清晰；
- 答辩：7题，图形没有压线；
- 提炼解析3页：公式、图、章节层级正常；
- 未发现裁切、重叠、黑块、乱码、数学角标漂移或工程 marker 泄漏。

参考教案结束后的总板书单独占一页、提炼解析末页存在较多自然留白，但这是全局 `2.5cm / 1.6` 基线与自然分页的结果；本轮按用户规则不为了减少页数重新压缩 typography。

## 7. 仍然保持 fail-closed 的三项外部限制

### A. GitHub-hosted CI

已知最新可核实 Actions 状态仍是 runner 分配前被 Billing/spending-limit 拒绝：`runner_id=0`、`steps=[]`。因此不能写“云端 CI 已通过”，也不能把它写成代码失败。

### B. 《变压器》canonical physical-page pixels

锁定教材 identity 不变；GitHub connector 对该 PDF 二进制仍会在 UTF-8 文本通道失败。另一个公开仓库里的同名 PDF blob/size 不同，已明确拒绝作为 canonical 替身。

因此《变压器》仍为 NON-FORMAL regression，直到：

`取得锁定二进制 → blob/size → locator → 200dpi → 人工确认印刷56/57`

### C. 用户真实10分钟手写照片

Round 2 再次通过 Files / repo 路径寻找原始 `IMG_20260816_23410*.jpg`，当前环境没有返回可直接物化的原图；仓库 SVG 又是内嵌 base64 的私有资源，连接器只能稳定提供文本外壳。

所以本轮**没有伪称重新逐张打开原始手写照片**。共享 density gate 只能作为机器异常线，不能替代用户手写视觉 authority。

## 8. Round 2 收口结论

结构性目标已经完成：

- 共享 product policy 单一 authority；
- 课题 manifest 只保留课题事实与真正课题变量；
- 4 fixture / 5 capability tags 异构回归；
- formula/code-span 新失败类别已进入通用 lint；
- graph / optics 图形组件真实编译 + 200dpi QA；
- 重复/退役 Python 路径从工作树删除；
- formal checker 单层；
- CI 与人工本地都统一到一个 canonical acceptance protocol；
- post-refactor 正式两 PDF 用已验收教材像素完成13页实际视觉重放。

从这里开始**冻结架构**。新增课题正常情况下只能变化：

`manifest/source facts + Markdown content + BOARD_PLAN + declarative figure assets`

只有未来真实使用暴露新的**跨课题失败类别**时，才允许修改 publisher/checker/renderer；不再继续做预防性的架构扩张。
