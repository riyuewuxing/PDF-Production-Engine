# 无关 synthetic fixture｜通用化验收

目的：验证“换掉课题后不改 Python”这一硬规则，而不是验证任何真实课题内容。

## Fixture

新增：

`production/regression/synthetic-generalization/`

它只包含：

- `case.yaml`
- `evidence.yaml`
- `BOARD_PLAN.yaml`
- 训练参考教案 / 考场骨架 / 逐字稿 / 答辩 / 提炼解析

没有新增任何 `build_<课题>.py`、`check_<课题>.py`，也没有修改 generic publisher 去识别这个 fixture。`run_regression_suite.py` 与 `render_regression_suite.py` 通过 `*/case.yaml` 自动发现它。

## 覆盖的共享能力

- manifest-driven regression contract；
- source Markdown 公式必须进入真正数学模式；
- `$F=ma$` 的通用 notation path；
- route-numbered BOARD_PLAN；
- P0/P1/P2 内部同步板书映射；
- 通用非正式双 PDF regression builder；
- 通用 regression renderer；
- defense heading / length / required-token 等断言来自 fixture contract，而非 Python 课题分支。

## 本地视觉回归

2026-08-17 对等价 synthetic 数据执行：

`XeLaTeX ×2 → A4/font preflight → 200dpi render → 实际逐页查看`

实际查看：

- 训练回归稿 5 页；
- 提炼解析 1 页；
- 5 个训练顶层模块各自新页开始；
- 2.5cm / 1.6 视觉基线正常；
- `$F=ma$` 数学模式、上下标/斜体显示正常；
- 同步板书与总板书层级清晰；
- 未见裁切、重叠、乱码、Markdown marker 泄漏或字体未嵌入。

这项验收的意义是：**通用化证明来自第二个无关 fixture + synthetic 编译/视觉回归，而不是来自把当前真实课题修到能过。**

## CI 状态

GitHub Actions 仍受账户 Billing / spending-limit 阻塞；因此上述本地验收不能写成“CI 通过”。Runner 恢复后，workflow 会自动发现并执行该 fixture，无需再添加课题专属 step。
