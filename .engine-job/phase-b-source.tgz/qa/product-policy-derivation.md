# Product policy derivation QA

日期：2026-08-17

本记录验证**跨课题共享 publication / source / QA policy 是否真正只有一个 authority**，而不是文档说已经迁移、运行时代码却仍读具体课题 manifest。

## 1. Round 2 发现的真实漂移

Round 2 开始时重新对照代码发现：此前文档虽然已经提出“共享 policy 进入 product contract”，但 `production/current-run.yaml` 与部分 renderer/checker 仍保存或读取共享数字/开关。也就是说，设计意图与真实执行路径并未完全一致。

这类漂移本身就是收口前必须修复的结构性缺陷，因为它会导致：

- 换课题时复制无关 policy；
- 同一规则在 contract / manifest / Python 三处漂移；
- 某个案例的同步板书数量、DPI、答辩数量等被误当成系统常量。

## 2. 当前唯一共享 authority

`production/contracts/teacher-trial-two-pdf-v1.yaml` 现在实际保存：

- `render.dpi`；
- `publication.publisher`、全局 typography、notation lint、engineering-label policy；
- `source_policy`：真实题面、锁定 identity、resilient transport；
- `manifest_constraints.allowed/required`；
- 顶层 section 新页规则；
- 考场骨架单 section 最大页跨度；
- 多维 skeleton-density guardrail；
- 答辩题数与 heading regex；
- 作业参考解析 policy；
- required training/extraction roles。

`production/current-run.yaml` 只保留当前课题事实和真正随课题变化的两个断言：

- `board_sections_min`
- `figure_count_min`

`publisher_core.validate_manifest_binding()` 会拒绝任何共享 policy 重新泄漏回课题 manifest。

## 3. 数量全部由结构推导

不再手填：

- 正式 PDF 数 = `len(product_contract.documents)`；
- 总板书份数 = `include_total_board: true` 的 section 数；
- 同步板书份数 = `consume_board_markers: true` section 中实际 `[[BOARD:Pn]]` marker 数；
- marker 必须能在当前 `BOARD_PLAN` increments 中解析；
- renderer DPI = `product_contract.render.dpi`；
- source-pages 是否必需 = product contract 是否存在 `renderer: source_pages`。

因此换课题、增减同步板书 marker、未来调整产品 section，不需要给某个课题新增 Python 分支或复制共享数字。

## 4. Shared policy 自测

`publisher_core.product_contract_selftest()` 当前包含负例：

- 课题 manifest 偷塞 `visual_render_dpi` → Hard Fail；
- DPI 低于产品范围 → Hard Fail；
- 非法 engineering regex → Hard Fail；
- defense min/max 反转 → Hard Fail；
- product contract path traversal → Hard Fail。

`regression_case.py` 同时拒绝 regression fixture 自己声明 `visual_render_dpi / publisher / global_typography / symbol_notation_policy`。

## 5. 执行入口

formal renderer 与 regression renderer 都从同一个 product contract 读取 DPI；formal checker 不再链到第二份 core checker。

新增 `tools/run_acceptance.py` 作为 canonical machine/render acceptance CLI，顺序固定为：

`tool route / generalization / board / skeleton selftest / publisher smoke / figure smoke / locator selftest → all regression → regression render → formal build → formal machine gate → formal render`

最后仍输出 `HUMAN_PIXEL_CONFIRMATION_REQUIRED`：自动 render 只为人工视觉验收准备页面，不自动宣布视觉通过。

## 6. 删除式收口

重复正式入口 `build_current_run_core.py`、`check_current_run_core.py` 已从工作树删除并列入 retired；Git history 保留历史实现。`tooling-manifest.yaml` 的 compatibility 路径已清空。

## 7. 当前验收事实

Round 2 本地隔离执行已证明：

- generic publisher + shared-policy integration smoke：PASS；
- 新增 graph-data 与 geometry-optics 两类 fixture 均通过同一 generic publisher 编译；
- XeLaTeX / A4 / 2.5cm / 1.6 / 字体嵌入保持；
- 两类新图均实际 200dpi 查看，并修复了图像颜色与光学标签/光心标识问题；
- 实际查看发现“把 `$...$` 放进 Markdown code span 会把美元符号和 LaTeX 原文印到 PDF”，因此新增通用 `PHYSICS_MATH_MARKUP_INSIDE_CODE` 门禁，并把 fixture 源修回真正数学模式。

未完成的事实不能用本记录覆盖：GitHub-hosted runner 仍受 Billing 阻塞；《变压器》canonical 二进制/physical-page pixels 与用户真实10分钟手写照片的本轮重新像素对照仍是独立 blocker。
