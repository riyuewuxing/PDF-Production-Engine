# RESOURCE_BUILD_RULES.md — Unified Artifact / Resource Build Rules

本文件解释 Artifact 生产原则；可执行状态以 `production/contracts/artifact-job-v1.yaml` 和 `production/contracts/execution-ledger-v1.yaml` 为准。

## 1. 系统边界

`qiuzhidaren` 保存业务内容、Module Contract、source identity、Artifact Job、ledger、review evidence 与最终私有产物。

`riyuewuxing/PDF-Production-Engine` 是公共、无状态机械执行环境，只负责 TeX/Typst/ReportLab、图形编译、PDF preflight/render、字体/媒体检查、hash、contact sheet、binary acquisition 等机械任务。

固定链路：

`qiuzhidaren → ChatGPT/session → Public Engine → ChatGPT HUMAN review → qiuzhidaren`

禁止跨仓 PAT/Secret/deploy key、checkout、push、状态保存和自动写回。Engine 不得作业务判断或产生 HUMAN `REVIEW_PASS`。

私库 GitHub-hosted Actions 已无可用免费构建资源，禁止作为正常 build/staging/transport/verification 依赖。私库执行内容必须由 ChatGPT/session 按当前 authority 物化为无秘密或加密的 Execution Package 后交给 Stateless Engine。

## 2. 一个 Artifact Pipeline

所有模块统一使用：

`JOB_CREATED → INPUTS_LOCKED → BLOCKS_ACCEPTED → BUILT → MACHINE_VERIFIED → HUMAN_ACCEPTED → PUBLISHED`

模块自己的内容步骤进入 Module Contract/block checklist，不再复制全局 state machine。

新 job 必须由 `tools/init_artifact_job.py` 创建；后续状态与 ledger 操作使用 `tools/manage_artifact_job.py`。禁止为单个模块再创建平行 lifecycle runner。

旧 `teaching-demo-delivery-state-machine-v1`、final-score/three-pass/efficiency-experiment 合同只用于历史兼容和失败实验审计，不再定义普通生产。

## 3. Block-first

复杂可交付物按需要拆为：

- Content block；
- Figure/visual block；
- Source-page/external-resource block；
- Composition；
- Final artifact。

Content 通常由 ChatGPT 直接审查。图形/外部资源需真实像素/内容证据。Composition 只能消费 required `REVIEW_PASS` block。最终文档必须 preflight、全页 render、机器 evidence 和 ChatGPT 实际逐页检查。

下游失败只失效最小因果 block 及 downstream；hash 未变化的无关 `REVIEW_PASS` block 必须复用。

## 4. Binding / Durable Provenance / Reuse Identity

普通文件 binding 统一为：

```yaml
path: repository/relative/path
sha256: <64 lowercase hex>
kind: <typed-kind>
```

`INPUTS_LOCKED` 还必须冻结：Module Contract binding、build adapter binding、runtime name/version、Repository Snapshot binding 与 canonical `input_fingerprint`。

Repository Snapshot authority 为 `production/contracts/repository-provenance-snapshot-v1.yaml`。每个覆盖的私库文件额外记录 Git blob SHA-1，并保存 exact `source_commit`。它同时具有两类 identity：

- `dependency_identity_sha256`：只由相关 repository dependency bytes/identity 构成，不含 source commit，用于判断两个 snapshot 是否覆盖同一依赖集合；
- `snapshot_identity_sha256`：包含 exact source commit，用于不可变历史审计和 content-addressed snapshot path。

**Reuse identity 与 audit identity 永久分离。** `input_fingerprint` 直接由真正影响执行的 Module Contract bytes、builder bytes、runtime 和 execution-relevant input bytes 推导。Repository Snapshot 是对这些相同私库依赖的平行历史证明，不能把 snapshot record hash/source commit 再次塞回 reuse fingerprint，否则无关 Git commit 会错误清空 warm-path cache。

生成的 `input_plan` 仍作为 exact `path + SHA-256 + kind=input_plan` 绑定并接受历史审计，但它只是已经显式列出的执行依赖的控制/审计记录，因此不进入 reusable `input_fingerprint`。plan 中 source commit 或 snapshot record 的变化不能单独导致 cache miss；任何真正 dependency bytes 变化仍会改变 fingerprint。

硬规则：

- 只允许 repository-relative path；
- absolute path / `..` / repo escape fail closed；
- live execution 时 SHA-256 和 Git blob identity 必须对当前物化 bytes 重算；
- source snapshot 必须覆盖 Module Contract、builder 和除 contract-declared exempt kind 外的 repository inputs；
- input / Module Contract / builder / runtime 任一真正执行依赖变化都会改变 fingerprint；
- source commit 本身不是 cache key；snapshot record hash 本身不是 cache key；
- 只有 fingerprint 相同且先前 output 已 HUMAN accepted 才允许复用；
- hash 变化使对应 HUMAN acceptance 失效；
- final publication 必须消费与 HUMAN_ACCEPTED 完全相同的 output set；
- 历史审计不得拿旧 Job 去比较今天同路径 bytes，而应使用 immutable snapshot + exact source commit；
- old job 缺 snapshot 不允许事后补造。

通用路径/hash/fingerprint primitive 位于 `tools/artifact_foundation.py`；Repository Snapshot 工具位于 `tools/provenance_snapshot.py`；历史审计入口为 `tools/check_artifact_provenance.py`。

架构决策：ADR-005、ADR-010、ADR-011。

## 5. Execution Ledger

Lifecycle transition 与 Build/Render/Review/Reject 等运行事实写入 append-only ledger。`tools/check_execution_ledger.py` 投影 job state，并从事件派生：

- `generation_review_cycles`；
- `build_count`；
- `final_render_count`；
- `review_reject_count`。

人工摘要不能覆盖派生事实。历史缺 instrumentation 的运行保持 `UNKNOWN_MISSING_INSTRUMENTATION`，不得补造 events/receipts/timing。

详细运行事件通过 `manage_artifact_job.py record-event` 进入 ledger；lifecycle transition 不允许用 generic record-event 绕过顺序门禁。

关键状态还要求 execution evidence **先于 transition 出现**：

- `BUILD_COMPLETED` → `BUILT`；event bindings 覆盖当前 outputs；
- `MACHINE_VERIFICATION_PASSED` → `MACHINE_VERIFIED`；event 绑定当前 `module_check` evidence；
- `HUMAN_REVIEW_ACCEPTED` → `HUMAN_ACCEPTED`；event 绑定 exact accepted outputs；
- 可视最终 artifact：`FINAL_RENDER_COMPLETED` 必须在 `HUMAN_ACCEPTED` 前完成并绑定当前 `final_render_manifest`。

因此，不能先推进状态、再事后补一条证据事件来“修历史”。

## 6. Machine / HUMAN Acceptance

- `MACHINE_VERIFIED` 必须绑定 module-check evidence + 先行 `MACHINE_VERIFICATION_PASSED`；
- 对 PDF/DOCX/PPTX/图片等可视最终 artifact，`HUMAN_ACCEPTED` 前必须绑定 final-render evidence + `FINAL_RENDER_COMPLETED`；
- render/preflight/command success 永远不等于 HUMAN `REVIEW_PASS`；
- `human-accept` 只绑定当前 exact output hash set，并生成 `HUMAN_REVIEW_ACCEPTED` 后再进入 `HUMAN_ACCEPTED`；
- `publish` 只消费同一 HUMAN-accepted output set。

final render evidence 可以在已到 `MACHINE_VERIFIED` 后继续追加；缺证据时 `human-accept` 必须事务失败并保持原状态，不以状态回退掩盖失败。

## 7. Cold / Warm

- cold path：只有真实缺通用 capability/contract/adapter/gate 时允许改通用实现，并必须留下 selftest/regression；
- warm path：已知类型任务原则上只变 business content / manifest / source binding / receipts，不改 generic implementation。

效率来自 content-addressed reuse、最小 rerun、机械 batching 和 failure-class gate，而不是削弱 HUMAN review。无关 Git commit、audit record hash 或 source_commit 不得制造虚假 cache miss。

## 8. Module Adapter

`production/contracts/module-registry-v1.yaml` 是 adapter/lifecycle authority。现有 `publish_*` / `build_current_run.py` 等是 Module Adapter，不再拥有独立项目级生命周期。

新模块应提供 Module Contract + adapter，并接入 Unified Artifact Pipeline；禁止复制一套 job/score/receipt 系统。

## 9. Delivery / Qualification

Artifact Job 只决定单个交付能否发布。跨案例评分、连续通过、效率证明属于 `production/contracts/system-qualification-v1.yaml`，独立于 delivery。

Qualification 失败不得反向否定已按 hash 接受的 immutable delivery。

## 10. Local Codex

Local Codex 只用于 Public Engine/当前环境确实无法完成的特殊兼容/debug fallback。不得承担 Recruitment Intelligence、source authority、Candidate Facts 或最终业务判断。
