# PROJECT_MEMORY_RULES.md — 持久记忆 / 计划 / 记录协议

## 目的

长周期项目不得依赖单个 Chat、模型记忆或“上一轮应该还记得”。仓库必须让一个**完全失忆的新会话**在较短时间内恢复：当前 authority、项目为什么这样设计、已经做到哪里、哪些路走过且不能再走、下一步应该做什么，以及上一轮真实完成了什么。

本协议适用于所有持续多轮、存在实现/验收/外部 runtime 的工作流。它不是新的业务状态机；它规定如何维护项目知识。

## 1. 五层知识结构

### 1.1 Rules — 规范层

规范只由已有 authority 承担：根/局部 `AGENTS.md`、ACCEPTED ADR、contracts、policy。规则回答“必须怎样做 / 禁止怎样做”。

禁止把临时进度、一次性结论、会话摘要塞进规则文件。`AGENTS.md` 应主要作为地图和硬约束入口，详细知识放在结构化文件中。

### 1.2 Memory — 快速回忆层

每个长期 workstream 应维护 `MEMORY.md`。它允许非常具体，目标是减少下一轮重新考古时间。应记录：

- 当前架构路线及外部执行资源；
- 当前案例/模块关键模型；
- 已验证的设计技巧与质量认识；
- 重要历史决策的“为什么”；
- 已经踩过的坑、错误前提、被否决路线及原因；
- 关键分支/commit/run/receipt 的定位信息；
- 哪些历史产物只能参考、不能再作为 current authority；
- 下一步接手时最容易误判的地方。

`MEMORY.md` **不是 executable authority**。若它与 `CURRENT_STATE.yaml`、ADR、contract、当前代码/receipt 冲突，authority 胜出，并且必须先修正 Memory 再继续施工。

Memory 不得存 secret、token、密码、私钥或其他敏感凭证。

### 1.3 Status — 当前状态层

长期 workstream 应维护一个机器可读 `STATUS.yaml`（若已有等价 authority 则复用）。Status 只回答“现在是什么状态 / 当前 gate 是什么”，不承担长篇历史。

全局 `CURRENT_STATE.yaml` 仍是已发布项目状态 authority；feature workstream 的 `STATUS.yaml` 记录尚未集成到 main 的活动开发状态。两者必须明确作用域，不互相伪装。

### 1.4 Plan — 执行计划层

长期 workstream 应维护 `PLAN.md`。要求：

- 把计划拆成可验证步骤；
- 每一步使用 checklist：`[ ]` 未完成、`[x]` 已完成；阻塞项用文字标注 `BLOCKED`，不得用勾选伪装完成；
- `[x]` 后必须写证据路径、commit/run/receipt 或可复核说明；
- 已完成步骤不得因后续改计划而静默删除；若被 supersede，保留并注明替代项；
- Plan 是执行路线，不得创建第二套 Artifact / Module 状态机。

### 1.5 Records — 追加式记录层

长期 workstream 应维护 `RECORDS.md` 或等价 append-only 日志。每轮有实质修改后必须追加一条记录，至少包括：

- 日期/会话职责；
- 工作分支与开始时的已知 HEAD；
- 本轮目标；
- 实际修改的文件/范围；
- 执行的测试/gate/外部 run；
- 结果与证据；
- 写入完成后的独立复查范围、发现和修复；
- 哪些计划项被勾选；
- 哪些状态/Memory 事实发生变化；
- blocker（若有）及是否处于**当前关键路径**；
- 下一步。

历史记录不原地改写。发现旧记录判断错误时，追加 correction/superseding record，并链接旧记录。

## 2. 每次修改前的强制 Refresh Loop

收到任何“继续、修改、改进、施工、修复、实现”请求，只要当前 workstream 有 Durable Memory Pack，就必须在写代码/内容前完成：

1. 读根 `AGENTS.md`；
2. 读 `CURRENT_STATE.yaml` 和相关 ADR/contracts；
3. 读当前任务目录最近的 `AGENTS.md`；
4. 读该 workstream 的 `MEMORY.md`；
5. 读 `STATUS.yaml`；
6. 读 `PLAN.md`；
7. 至少读 `RECORDS.md` 最新一条记录；
8. 再读本轮将修改的真实代码/内容/receipt。

随后做一次一致性检查：

- Memory 是否过期？
- Status 是否与代码/证据冲突？
- Plan 的 next step 是否仍处于当前关键路径？
- 是否存在已经证明错误但仍被旧记录重复引用的路线？

若发现不一致，**先修记忆/状态/计划，再施工**。不得把聊天记忆用于覆盖仓库 authority。

## 3. 每次修改后的强制 Close-out Loop

一次工作只有同时完成以下动作才可以说“完成”：

1. 重新读取实际写入后的文件或 diff；API 返回 success 本身不算验收；
2. 运行适用的 syntax/test/machine gate；无法执行真实 runtime 时必须明确记录 `NOT_EXECUTED`，不得用代码存在、逻辑 replay 或 Git read-back 冒充 runtime PASS；
3. **执行一次 Mandatory Post-Write Independent Re-review**：写入阶段结束后重新从最新 authority / 最新真实字节出发主动攻击，而不是继续沿用实现时的假设；至少复查 authority、规则与代码一致性、绕过路径、状态/receipt/stale binding、受保护历史与下游边界；
4. 若第 3 步发现任何当前阶段 blocking / P0 / P1 bypass，自动回到当前阶段原地修复；修复后必须再次执行 Post-Write Independent Re-review，直到不再存在新的 blocking finding；
5. `PLAN.md` 对真实完成项打勾，并附证据；
6. 若当前状态变化，更新 `STATUS.yaml`；
7. 若产生了可复用知识、路线纠正、重要坑点，更新 `MEMORY.md`；
8. 向 `RECORDS.md` 追加本轮记录；
9. 若角色将切换（实现 → 独立验收等），再生成精简 handoff；handoff 不能替代 Memory/Plan/Records。

**铁则：项目实际写完 ≠ 本轮完成；写完之后必须复查一遍。** 实现者自己的“已完成/PASS”不能替代写后独立复查，更不能替代后续职责分离 Gate/HUMAN 验收。

禁止出现“代码已经提交，所以计划/记录下次再补”。记录与写后独立复查都是 Definition of Done 的一部分。

## 4. Blocked Path 纪律

AI 很容易把“发现一个真实问题”误写成“整个项目被阻塞”。宣布 BLOCKED 前必须同时证明：

1. blocker 位于**当前阶段**而非未来阶段；
2. blocker 位于当前 gate 的**关键路径**；
3. 当前阶段不存在仍可独立完成的工作；
4. 有机器/文件证据，而不是推测；
5. optional fallback 的失败没有被误当成 canonical path 的失败。

若只影响未来阶段或备用通道，应记录为 `WARNING / FUTURE_BLOCKER / OPTIONAL_FALLBACK_UNAVAILABLE`，并继续完成当前可独立工作。

## 5. 外部执行资源与项目语义分离

`qiuzhidaren` 的业务语义、内容、rules、Artifact state、receipt 留在私库；机械资源执行由已批准的外部 Engine/runtime 承担。

对 `riyuewuxing/PDF-Production-Engine`：

- canonical 模型是 `consumer project -> ChatGPT/session orchestration -> Engine code/runtime -> ChatGPT review -> consumer project`；
- Engine 是公共、通用、无状态机械执行资源；
- Engine 不读私库、不持有私库凭证、不写回私库、不签 HUMAN PASS；
- session-mediated ephemeral execution 是正常私有项目路线；
- sealed GitHub Actions 是 optional fallback，缺少 sealed key **不得**被解释为 ordinary Engine runtime 被阻塞；
- Local Codex/container 只可作为明确的 compatibility/debug fallback，不能冒充正式 Engine evidence。

若 Engine 自己的当前 authority 文档发生变更，以 Engine authority 为准，并同步更新本项目 Memory；不得凭历史聊天继续沿旧路线。

## 6. 防止“记忆文件”反过来制造第二套事实源

- Rules 决定规范；Status 决定当前状态；Plan 决定下一步；Records 保存历史；Memory 负责快速回忆。
- 同一事实不要在五个文件里各自维护不同版本。
- Memory 中的状态性文字必须尽量链接到 Status/receipt/commit，而不是自立结论。
- Plan 中的完成状态必须有证据；Status 不从 Plan 的勾选反推。
- 任何 correction 都保留旧证据并显式 supersede，不篡改历史。

## 7. 设计目标

合格的 Durable Memory Pack 应满足：

> 一个完全失忆的新会话，先按 Rules 读取 Memory + Status + Plan + 最新 Records，再读相关代码，即可理解项目细节、知道为什么不能走旧路、知道当前只该做哪一步，并能在修改后把新的事实继续留给下一轮；任何实际施工在写入后还必须经过独立复查，才能进入下一 gate。
