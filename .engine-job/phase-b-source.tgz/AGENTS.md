# AGENTS.md — 求职达人全局执行规则

## 0. 接手顺序

任何 AI / Agent / 会话接手时按以下顺序读取：

1. `CURRENT_STATE.yaml` — 当前项目状态唯一 authority；
2. `architecture/README.md` 与已 ACCEPTED ADR — 底层架构 authority；
3. `production/contracts/module-registry-v1.yaml` — 模块生命周期/执行适配 authority；
4. 当前任务目录最近的 `AGENTS.md` — 业务语义规则；
5. 若涉及任何 artifact，读取 `production/contracts/artifact-job-v1.yaml`、`production/contracts/execution-ledger-v1.yaml`、`production/resource-build-efficiency-policy-v1.yaml` 与 `RESOURCE_BUILD_RULES.md`；
6. 若当前 workstream 存在 Durable Memory Pack，再按 `PROJECT_MEMORY_RULES.md` 读取其 `MEMORY.md`、`STATUS.yaml`、`PLAN.md` 与最新 `RECORDS.md`；
7. `ROADMAP.md` 只用于方向/历史摘要，不覆盖上述 authority。

### Teaching Demo 内容/逐字稿唯一入口

凡任务涉及试讲的训练参考教案、考场骨架、逐字稿、课题专属答辩、教材到骨架提炼解析，**只允许从 `main` 当前树进入以下唯一内容线**：

- `production/process/teaching-demo-content/PROCESS.md`
- `production/contracts/teaching-demo-content.yaml`
- `production/process/teaching-demo-content/STATUS.yaml`
- `tools/check_teaching_demo_content.py`
- `tools/check_teaching_demo_inputs.py`

不得通过历史分支、旧 `planning/`、旧 `NEXT_IMPLEMENTATION_SESSION.md`、旧 M1/M2、旧 v2/v3 content contract/checker 或历史 case 重新建立逐字稿生产路线。历史 Git commit 只能证明历史事实，不能成为 runtime authority。以后逐字稿流程升级直接原地修改上述唯一当前文件，禁止复制出日期版、版本版、legacy、backup、experimental、compatibility 或 branch-specific 第二条内容线。

`production/process-development/teaching-demo-quality-v2/` 中仍保留的 process-evaluation、textbook-topic-atlas、runtime closure 属于其他既有评估/下游资料；它们不得反向定义逐字稿内容流程。

正常执行不得依赖未写入仓库的历史会话记忆。历史 `PHASE*_STATUS.md`、`FINAL_ACCEPTANCE.md`、旧 state machine、旧实验合同和旧分支 README 只能证明历史事实。

`PROJECT_MEMORY_RULES.md` 是长期工作流的持久记忆/计划/记录维护协议。**任何继续、修改、改进、施工、修复、实现请求，在写入前必须先完成其中的 Refresh Loop；有实质修改后必须完成 Close-out Loop，计划/状态/记忆/记录未按规则更新时不得宣称本轮完成。**

## 1. 项目本质：Process as Product

首要产品是**任何获授权 AI 只读仓库 authority 后都能快速、稳定、可审计地操控的生产流程**。具体 PDF/逐字稿/简历/题库是用户交付物，也是流程验证样本；把一个样本反复修到通过不能单独证明项目成功。

模型能力决定语义质量上限；架构负责质量下限和可重复性。强 AI 可以写得更好，但不得建立另一条专属流程；较弱 AI 仍必须受到 Module Contract、Golden Path、source/provenance、machine gates、Execution Ledger、HUMAN acceptance 与 fail-closed 规则约束。

执行优先级：`复用已有 Golden Path > 修最小实例缺陷 > 发现通用失败时修共享流程 > 为单个样本手工特判`。最后一项默认禁止。

process-evaluation 的完整 `generation → final render → HUMAN review` 目标 1 次、最多 3 次；第 3 次仍失败即 `STOP_LIMIT_PROCESS_FAILURE`，不得为了交差继续第 4 次。墙钟时间记录但不单独作硬门槛。具体 authority：`architecture/adr/ADR-009-process-as-product-and-agent-portability.md` 与 `production/resource-build-efficiency-policy-v1.yaml`。

## 2. 固定底层架构

`qiuzhidaren` 是模块化单体业务仓库。四层为：Domain / Application / Artifact / Adapters。

只有两个架构级外部系统：

- Recruitment Intelligence：输出 `Validated Opportunity Package`；
- `riyuewuxing/PDF-Production-Engine`：公共、无状态、机械资源执行。

ChatGPT/session 是跨仓库编排与 HUMAN 验收者。两个仓库不得建立 PAT、Secret、deploy key、checkout、push、状态存储或自动写回耦合。

已 ACCEPTED ADR 不原地改写；如基础假设真实失效，新增 superseding ADR。

## 3. 单一事实源

一个 concern 只能有一个 executable authority：

- 当前状态 → `CURRENT_STATE.yaml`；
- 架构 → `architecture/adr/`；
- 模块生命周期与 adapter → `module-registry-v1.yaml`；
- Artifact 生命周期 → `artifact-job-v1.yaml`；
- 执行事实 → execution ledger；
- Artifact 效率/反馈循环 → `resource-build-efficiency-policy-v1.yaml`；
- 工具生命周期 → `tools/tooling-manifest.yaml`。

禁止在多个 README/AGENTS/YAML 中复制第二套状态机、模块状态或 score lane。

Durable Memory Pack 也必须遵守单一事实源：Memory 负责回忆、Plan 负责路线、Records 负责历史、workstream `STATUS.yaml` 负责未集成 feature 的活动状态；它们不得覆盖上述全局 authority。

## 4. 模块生命周期

生命周期词汇由 module registry 定义，当前为 `ACTIVE / FROZEN / DEFERRED / EXTERNAL / RETIRED`。

- FROZEN 模块可按冻结合同执行新的具体实例，但不得无系统性证据改底层；
- DEFERRED 模块不进入当前施工或正常执行；
- EXTERNAL 只消费外部合同；
- RETIRED 只保留历史参考，不得进入正常 route。

实时岗位请求必须从外部 `Validated Opportunity Package` 开始；不得恢复仓库内 Position Research/current-source acquisition 主线。

## 5. 统一 Artifact Pipeline

所有 PDF/DOCX/PPT/未来资源统一使用：

`JOB_CREATED → INPUTS_LOCKED → BLOCKS_ACCEPTED → BUILT → MACHINE_VERIFIED → HUMAN_ACCEPTED → PUBLISHED`

模块内部的 Point Chain、板书、逐字稿、题库、简历字段等属于 Module Contract/block，不得成为新的全局状态机。

业务差异进入 Module Contract/data；通用 pipeline/publisher/checker 禁止按课题名、地区名、case_id 或模块名写长期特判。

新 job 用 `tools/init_artifact_job.py` 创建，后续统一由 `tools/manage_artifact_job.py` 操作。warm path 原则上禁止改 generic implementation；cold path 只有形成可复用实现 + test/regression + warm reuse plan 才算完成。

## 6. Execution Ledger / 效率

Build / Render / Review / Reject / Publish 事件必须先进入 append-only execution ledger。attempt/cycle/build/render/reject 数及效率指标从 ledger 派生，禁止信任手填摘要。

每次拒绝先分类为 instance/content defect 或 reusable process defect。后者应修共享 contract/adapter/gate 并留下 regression；禁止不找根因地重复完整生成。

历史缺 instrumentation 的失败保持 `UNKNOWN_MISSING_INSTRUMENTATION`；禁止补造事件、receipt 或精确耗时。

效率优化只能减少重复工作、复用 hash-stable block、批量机械执行和提前机器发现失败；不得降低内容、来源或最终视觉门槛。

## 7. Artifact / Review

所有 binding 使用 repository-relative path + SHA-256。absolute path、`..` traversal、仓库外路径一律 fail closed。

复杂 artifact 仍执行 block-first：内容 → 图形/外部资源 → composition → final artifact。已接受 block bytes 未变化时必须复用；hash 变化使对应 acceptance 失效。

Machine verification 与 HUMAN acceptance 永久分离。Engine/command success/render success 不等于 `REVIEW_PASS`。最终可视文档必须实际查看全部最终页面。

## 8. Delivery 与 Qualification

单个 artifact 的发布由 Artifact Job 决定。跨多个案例的质量、效率、warm-path 复用和 agent portability 属于独立 `system-qualification-v1.yaml`；不得插入普通发布状态机，不得因 qualification 失败否定已接受的不可变单题交付。

System Qualification 证明“流程可被不同接手 AI 重复操控”，而不是证明“同一个 AI 最终磨出了三个好样本”。未经用户明确授权不得启动 qualification。

## 9. Source / Facts

- no fabrication；
- specific official source > user material > official attachment > traceable public material > historical example > general knowledge；
- Candidate Fact 不得由岗位要求反推；
- fetch failure != no result；
- official attachment binary 未取得时不得假装已解析；
- live opportunity 必须由外部 VOP 明确 current/authority 状态。

## 10. Runtime / Git

`qiuzhidaren` 私库 GitHub-hosted Actions 已无可用免费构建资源，不得成为正常 build/stage/transport/verification 依赖。

Public Engine 承担机械 runtime；Local Codex 只作特殊兼容/debug fallback。

对私有项目，`PDF-Production-Engine` 的正常执行模型是 **ChatGPT/session-mediated ephemeral execution**；sealed GitHub Actions 只是 Engine 自己定义的 optional fallback。备用 sealed key 缺失不得被提升为 ordinary Engine runtime blocker。

`main` 已是唯一长期 Git authority。其他模块的 feature/fix work 使用短生命周期分支，完成验证后再收回 `main`；逐字稿内容工作按用户明确要求直接修改 main 当前唯一线，禁止为此新建分支或副本；force update 永久禁止。历史迁移分支不得再被当作当前 authority。**对逐字稿内容功能，任何新会话先从 `main` 的唯一内容路径恢复，不得自行挑选历史 Teaching Demo 分支作为接手起点。**

## 11. 写入责任

仓库写入由当前会话中**用户明确授权的实现者**执行；角色名（Sol/Luna/Codex）不是底层架构约束。未获写入授权时只读，获授权后仍须遵守本文件、CURRENT_STATE、ADR 与 contracts。

## 12. Blocked Path 不能成为“安全型偷懒”

宣布 BLOCKED 前必须按 `PROJECT_MEMORY_RULES.md` 证明 blocker 位于当前阶段、当前关键路径，而且当前阶段没有仍可独立完成的工作。未来阶段问题、optional fallback 故障、尚未选择的 transport 失败只能记录，不能让更早的独立 gate 停工。
