# AGENTS.md — 教师简历与报名材料作用域

本文件只约束 `content/job-search/teacher/resume-materials/`。

**Lifecycle：`DEFERRED`。** 生命周期唯一 authority 是 `production/contracts/module-registry-v1.yaml`。当前只保留 Phase8 历史资产、合同和兼容工具，不进入当前建设/生产门禁。除非用户显式解冻该模块，否则不得继续扩建或发布新的简历/报名材料产品。未来重新启用时，specific Application Requirement 必须来自外部 `Validated Opportunity Package` 或用户明确提供且经过等价验证的 source，不得恢复内部 `position-research` 采集链。

## 1. 产品定义

本模块不是“做一张漂亮简历”。目标是建立可复用的：

`Candidate Fact → Evidence Asset → specific Application Requirement → Resume/Application Variant`

模块解冻后，默认 Artifact First：先替用户建立可填写、可核验、可组装的事实主档、证据库、报名材料包与简历变体；没有真实个人材料时只生产 placeholder/template，不要求用户先接受模拟面试或回答问题。

## 2. 事实与证据硬规则

1. 用户姓名、学历、专业、成绩、证书、任教经历、教学成绩、获奖、科研、学生干部、工作年限、政治面貌等个人事实不得推断。
2. 所有可进入正式简历/报名表的事实必须有 `candidate_fact_id`；需要证明的事实必须能链接 `evidence_asset_id`。
3. “会某技能”“获得某荣誉”“提高X%”“带出多少学生”等量化语句，没有证据不得生成。
4. 简历 bullet 可以改写表达，但不能提高事实强度；`参与` 不得改成 `主导`，`获奖` 不得改成 `一等奖`。
5. 证据状态必须区分：`verified / user-asserted / pending / missing / expired / not-applicable`。
6. 敏感个人材料默认只登记类型、状态、日期和 locator，不把身份证号、住址、证件完整号码等写入公开模板或日志。

## 3. specific source 决定报名材料

报名材料清单必须由 specific 招聘公告/岗位表/报名表决定。当前机会的权威入口是外部 `Validated Opportunity Package`；本模块只消费已经验证的 requirement/evidence，不负责招聘发现和 source acquisition。

禁止：
- 把某校某年的报名清单外推全云南；
- 把“常见材料”写成“必交材料”；
- 把资格复审材料和初次报名材料混成一包；
- 把应届生材料要求套到在编公开选调；
- 用模板补猜报名截止时间、PDF命名、邮箱、盖章、复印份数、照片规格；
- 调用或恢复 `position-research/` 作为实时岗位采集服务。

允许建立 `common_prepare` 预备清单，但必须明确它不是 specific requirement。

## 4. 四层资产

### Candidate Fact
个人事实的 canonical source of truth。

### Evidence Asset
证明材料与可提交文件：证件、学历学位、成绩单、就业推荐表、教师资格、职称、普通话、外语/计算机、荣誉、科研、教学成绩、考核表、照片、工作/服务证明等。

### Application Requirement
从已验证 specific source / VOP 提取：材料名称、阶段、是否必需、条件、格式、份数、盖章、命名、提交渠道、deadline、source locator。

### Resume Variant
从 Fact/Evidence 中筛选并排序，按 specific 岗位生成简历版本；简历不是事实源。

## 5. 复用边界

- 可读取 `self-introduction/` 的 Fact/Story Bank 作为候选事实线索，但必须重新做 evidence/status 校验后才能进入报名材料主档。
- 外部 Recruitment Intelligence 负责机会发现与验证，并输出 `Validated Opportunity Package`；本模块只定义消费 requirement 的接口。
- `position-research/` 是 RETIRED 历史参考，不得进入 live routing。
- 笔试/试讲/结构化/答辩产物可作为能力证据线索，但不能自动转换成真实工作经历或荣誉。

## 6. Prior-Art

未来解冻并新增实现时必须遵守根规则 Prior-Art First。既有参考包括：
- JSON Resume：结构化主档/schema；
- Reactive Resume：数据与模板分离、多格式输出；
- OpenResume：本地隐私与可解析性思想；AGPL实现仅 reference-only。

## 7. Artifact / PDF

未来重新启用时，任何新可交付视觉文档统一进入根级 Artifact Pipeline：`JOB_CREATED → INPUTS_LOCKED → BLOCKS_ACCEPTED → BUILT → MACHINE_VERIFIED → HUMAN_ACCEPTED → PUBLISHED`。正式简历/报名材料包在没有真实用户事实时不得伪造为已填写成品，module adapter 也不得自行宣称 Human Acceptance 或 Published。

## 8. 当前状态：DEFERRED

Phase8 历史成果继续保留为参考与未来可重用资产。是否恢复本模块，由 `CURRENT_STATE.yaml` 与 `production/contracts/module-registry-v1.yaml` 的显式变更决定；在此之前不继续施工。
