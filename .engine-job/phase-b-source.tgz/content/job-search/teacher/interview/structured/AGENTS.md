# AGENTS.md — 教师结构化面试

本文件是 `teacher/interview/structured/` 的 canonical scoped rule。

**Lifecycle：`FROZEN`。** 生命周期唯一 authority 是 `production/contracts/module-registry-v1.yaml`。本模块的两轮建设已经完成；本文只保存领域规则与可复用产品合同。新实例可复用冻结适配器，但必须由外部 `Validated Opportunity Package` 进入，并统一通过根级 Artifact Pipeline；不得在本文件中宣布新的建设轮次、下一开发模块或独立 delivery lifecycle。

## 1. 模块定位：资料生产优先，不以用户现场作答为前提

本模块的默认目的，是**替用户整理、生产、维护可识记的结构化面试资料**，而不是把用户强制拉进互动模拟。

默认主链固定为：

`Validated Opportunity Package / 官方证据 → prior-art → reference bank → T1–T9覆盖 → 高频母题/题库 → 答题骨架 → 参考口语答案 → 追问变式 → 失分点/边界 → 速记版 → module adapter → Unified Artifact Pipeline`

**用户不需要先真实作答，资料才能继续生产。**

互动 `mock / drill / review` 只在用户明确要求模拟、主动提交回答希望诊断，或内部 synthetic/regression QA 时启用。禁止把“请用户先回答一道题”当成资料生产的默认下一步。

资料产品合同读取：`contracts/structured-material-pack-v1.yaml`。

## 2. 与试讲隔离

结构化面试不得继承试讲的教材页/Page-to-Plan、Point/Edge、10分钟手写教案、约15分钟试讲逐字稿、固定两 PDF、试讲 publisher/figure/board 等业务合同。

结构化最终可以发布 PDF，但只能基于自己的 material-pack contract 和 scoped adapter，不得为了省事套试讲业务结构；Artifact 生命周期统一由 `production/contracts/artifact-job-v1.yaml` 定义。

## 3. Prior-art first：先找前人仓库，再自研

结构化新增任何重要能力前（题库导入、资料组织、模拟面试、追问、评分、个性化、进度跟踪、语音训练、报告、出版等），必须先读取 `references/prior-art.md`；涉及出版还要读取 `references/publishing-prior-art.md`。

固定顺序：

`搜索 GitHub/官方项目 → 至少比较3个候选 → 深读 README/关键文件/LICENSE → 记录复用决策 → 优先连接/借用成熟机制 → 最后只补缺口`

禁止因为实现更快而跳过 prior-art；AGPL/GPL 等强 copyleft 仓库若边界不适合，只学习架构思想，不直接复制代码。

## 4. Source-aware

来源优先级：

1. 外部 `Validated Opportunity Package` 中已验证的当前招聘证据，或用户当前明确提供的招聘公告、考试通知、现场规则、题目原文
2. 对应地区/单位/年份的官方材料
3. 用户提供的培训材料或真题
4. 项目内已登记且有来源的历史题/reference-bank
5. 通用训练框架

不得凭模型记忆编造考试时长、题数、评分权重、追问形式或用户个人经历。官方未披露的字段保持 unknown/null。实时岗位 discovery/acquisition 不在本模块内恢复。

## 5. 当前地理基线：云南省内教师招聘

冻结基线读取：

`scopes/yunnan-teacher-recruitment-v1.yaml`

硬规则：

- **云南是地理题库范围，不是统一 exam profile。** 不得创造“云南统一题数/时长/权重”。
- 州、市、县、学校、年份的真实面试形式继续由具体官方来源/profile 约束。
- NTCE、公务员/普通事业单位结构化、省外教师招聘只可作为边界/比较资料，不统计为云南教师结构化核心题库频率。
- 纯说课、纯试讲题不进入结构化核心题库；试讲后可迁移的通用教师职业问答可单独纳入。
- 当前核心冻结产品是 `materials/yunnan/r2/` 下的稳定版云南题库与速记资料。

云南地域情境层作为 T1–T9 的 overlay：民族团结/国家通用语言文字、山区边境农村/寄宿制、控辍保学、校园安全欺凌、心理健康家校、县域教育均衡/教师交流等。本地情境必须有云南官方/公开来源支撑，不能靠刻板印象生成。

## 6. 题型与资料覆盖

题型 taxonomy 以 `question-taxonomy.md` 为 authority。允许一题多标签，但必须标记 `primary_type`，并尽量补充 `secondary_types / scenario_role / time_horizon / risk_level`。

稳定版共有 120 个高价值母题，最终 primary 分布为：

- T1 11
- T2 14
- T3 20
- T4 15
- T5 15
- T6 10
- T7 10
- T8 15
- T9 10

这些数字是项目内部覆盖结果，不是云南官方命题比例。后续禁止为了题量增长而机械扩库；只有新真实来源、真实考试变化或覆盖缺口出现时才调整。

## 7. 单题资料卡合同

单题资料卡至少包含：

1. 题目与来源身份
2. 题型与评价目标
3. 读题抓手
4. 3–5点答题骨架
5. 参考口语答案
6. 速记/背诵锚点
7. 可能追问与变式
8. 常见失分点
9. 必要的师德/安全/政策边界

参考答案是**资料资产**，可以由项目基于来源情境和通用框架生成；不要求用户先回答。

涉及“为什么当老师、优缺点、成功失败经历”等个人事实题时，用户未提供的学校、奖项、实习、成绩、故事不得编造，只生成高质量骨架和待填槽位。

## 8. 答题骨架

默认结构：

`立场/目标 → 判断与原因 → 具体行动 → 沟通协同 → 跟进复盘`

不同题型可覆盖默认结构。情境处置题优先检查：安全与权益、事实核实、教师角色边界、秩序/情绪、必要上报协同、后续教育复盘。

框架是压缩工具，不是万能话术；发现空话时应修框架选择/QA，不为某一道题长期特判。

## 9. Reference Bank 与 provenance

新题源必须优先经过：

`reference-bank/raw → import → normalize → validate → reference_id → material card`

公开备考文章、公开/回忆题、政策派生情境、用户真题、官方格式公告必须标清不同身份。material card 尽量通过 `reference_id` 复用 provenance，避免重复维护来源元数据。

**政策支持某个情境 ≠ 该题真实考过。** `derived-scenario` 必须一直显式保留，最终 PDF 也不能洗成“云南真题”。

公开回忆题必须继续说明“可追溯公开考生/网络回忆、非官方原卷”。高校/职教/特殊教育样本只作教师职业情境补充，不单独推断 K12 高频率。

## 10. 互动训练是可选层

`mock / drill / review / training-state / hint ladder / adaptive drill` 保留，但属于**可选训练层**，不是结构化 workflow 的入口条件。

只有用户要求互动训练时，才执行“一题一答、动态追问、评分、记录 state”。不得为了验证 workflow 强迫用户参与。

## 11. QA

资料生产硬性 QA：

- 不编造官方规则；
- 不把项目 T1–T9 称为官方分类；
- 不把公开备考/政策派生情境称为官方真题；
- 不把云南地理范围包装成统一考试 profile；
- 个人经历不造假；
- 高风险题必须明确安全/师德/权益边界；
- 参考答案必须贴题、可执行、口语化，不堆空话；
- 题库不得大量近重复；
- profile 规则不得串线；
- 可交付视觉文档必须经过 machine verification 与 ChatGPT 实际视觉验收。

评分体系只用于资料中的“考点/失分点/训练评分说明”，没有官方权重时不得伪装成官方评分表。

## 12. 两轮建设规则：已履行并冻结

云南教师招聘结构化面试建设大阶段只使用两个内容轮次，现已全部完成：

### 第一轮：内容地基与 60 题基线 —— 完成

`范围冻结 → 来源地图 → 60 道 normalized reference → T1–T9 完整题卡 → 第一版速记框架 → 云南政策/来源边界 → source/type 缺口分析 → ROUND1_ACCEPTANCE`

### 第二轮：最终内容 + 出版 + 验收 —— 完成

`60 → 120高价值母题 → 按缺口补来源和地域覆盖 → 120题卡统一编辑 → 高频追问/速记压缩 → source-density/type/context/dedup QA → 独立结构化 publisher → 核心题库 PDF + 速记框架 PDF → render → 人工视觉 QA → FINAL_ACCEPTANCE`

**不存在第三轮建设。** 以后真实使用暴露的新问题只按冻结模块维护/解冻规则处理，不能重新包装为第三轮架构开发。

最终 acceptance：`materials/yunnan/r2/FINAL_ACCEPTANCE.md`。

## 13. FROZEN 模块复用规则

结构化建设阶段已经结束。新实例仅在明确任务需要时复用既有合同与 adapter：

1. 当前机会必须来自外部 `Validated Opportunity Package` 或用户明确提供且经过等价验证的 source；
2. 新题进入 reference bank，完成 normalization / provenance / dedup；
3. 只有真实覆盖新增时才建立或替换母题，不为“总数更大”加题；
4. 更新对应题卡、速记和边界说明；
5. scoped adapter 只负责模块机械装配，不定义发布状态；
6. 新可交付物统一进入 `JOB_CREATED → INPUTS_LOCKED → BLOCKS_ACCEPTED → BUILT → MACHINE_VERIFIED → HUMAN_ACCEPTED → PUBLISHED`；
7. 用户主动要求时才启用 mock/training-state；
8. 不预防性扩语音/UI/LLM 平台。

## 14. 项目路由

本文件不再指定“下一开发模块”。项目当前优先级与模块生命周期只读取 `CURRENT_STATE.yaml` 和 `production/contracts/module-registry-v1.yaml`。答辩、试讲、自我介绍等并列模块均按各自合同和统一 Artifact Pipeline 工作。
