# AGENTS.md — 教师面试答辩

本文件是 `content/job-search/teacher/interview/defense/` 的 canonical scoped rule。

**Lifecycle：`FROZEN`。** 生命周期唯一 authority 是 `production/contracts/module-registry-v1.yaml`。Teacher Product Round1 / Round2 均已完成并冻结；不存在当前 Product Round2 施工轮次，也没有 Product Round3。本文保留已验收产品的领域规则与后续实例化约束，但不得自行定义新的模块生命周期或独立 delivery state machine。新交付实例统一进入根级 Artifact Pipeline。

## 1. Artifact First

默认替用户生产可直接阅读、识记、抽练、复盘的教师招聘答辩资料，不把用户真实作答、模拟、录音或人工确认作为资料生产前置条件。

正式主链：

`Validated Opportunity Package / 当前试讲证据 / 学科事实 → 路由 → canonical question bank → detail / practice / quick-reference views → module adapter → Unified Artifact Pipeline → Public Engine mechanical build → ChatGPT 全页视觉/使用质量验收`

## 2. Canonical 路由：先 source，再 semantic

### A. lesson-linked defense

问题依赖刚才试讲/模拟课堂/说课、教材、题面、教学设计、学习证据或学科事实。

### B. official source-designated defense

若 specific official recruitment source 明确把某一环节命名为“答辩”并发布 `defense_content_scope`，该内容在这个招聘/年份内使用 `topic_dependency: source-bound` 保留在 defense。

source scope 可以是课堂管理情境、职业认知、专业知识或其他官方定义内容，不限于 situational。

### C. structured

没有 specific official source designation 时，脱离具体课题仍能原样成立的一般家校、同事、职业认知、教育现象、通用应急等优先进入 `structured/`。

### 硬边界

- source designation 只在对应招聘/年份有效；
- 不把某地 source-bound 题型外推为云南统一答辩；
- 不把 structured bank 批量复制进 defense；
- 只写“问答/Q&A”但内容未公开时保持 unknown；
- NTCE 只作 lesson-linked 形态边界，其时长/题数不套招聘。

## 3. 历史 Product Round2 最终产品结构（FROZEN baseline）

Round1 已经重新定义最终产品：旧的 **32 lesson-linked mother templates + 18 source-bound cards** 继续保留为 `validated-core-layer`，但**不再是最终题库规模上限**。

Round2 canonical source 从 `materials/yunnan/final-quality-r1/question-seed-bank-v1.yaml` 的 120 个高价值 seed 出发完成 v2 题卡字段：

- `examiner_intent`
- `compact_skeleton`
- `answer_points`（3–5）
- `followups`（至少2个训练差异，不做同义改写）
- `red_flags`
- `self_score_dimensions`
- `evidence_anchor`
- `volume`
- `views`

120 个 canonical 主问题由 72 个教学答辩 + 48 个高中物理 D7 构成。每题至少 2 个可独立抽练的 followup/counterfactual prompt，所以 Product Round2 的 **effective training prompts = 360**；这是项目训练规模，不是云南官方题量或频率。

18 个已验证 source-bound cards 另作为 `source-bound-special` 专卷保留，不纳入 360 的数量口径，也不升级为真题。

### 最终分册

1. `V0 教师答辩总纲与速记`
2. `V1 教学设计与试讲答辩·上`：D1/D2/D3
3. `V2 教学实施与反思答辩·下`：D4/D5/D6/D8
4. `V3 高中物理专业答辩·力学与热学`：D7
5. `V4 高中物理专业答辩·电磁/光学/近代/实验`：D7
6. `V5 来源专属情境答辩`：source-bound only
7. `抽题训练册`：从同一 canonical bank 生成 retrieval-practice view；答案延迟到节末/卷末。

不再生产一个超长混合大 PDF。

## 4. D1–D8

Authority：`question-taxonomy.md`。

- D1 教材/课题定位与内容边界
- D2 教学目标、重难点与素养落点
- D3 教学设计、方法与环节意图
- D4 学情、学生反应与生成性调整
- D5 评价、练习、作业与学习证据
- D6 试讲复盘、失误纠正与替代设计
- D7 学科专业知识与概念辨析
- D8 教学理念、教师角色与专业发展

`topic_dependency`：`lesson-bound / topic-adaptable / generic-anchored / source-bound`。

Frozen baseline 下不得重开 taxonomy。只有真实多题失败证明 D1–D8 无法表达一个通用答辩能力，并通过新的 ADR/模块变更决策后才允许解冻。

## 5. 题卡合同

v2 authority：`schemas/defense-question-card-v2.yaml`。

正式题卡至少包含：

`question / source_identity / source_basis / defense_type / topic_dependency / examiner_intent / evidence_anchor / compact_skeleton / answer_points / followups / red_flags / self_score_dimensions / volume / views`

条件字段：

- D7 或学科事实 → `subject_fact_source`；
- lesson-bound instantiated card → `current_lesson_reference`；
- source-bound card → `format_source_reference`，必须解析到 nonempty `defense_content_scope` 的 official-format source。

### Round2 variant 规则（历史冻结基线）

- 主问题 + followup 必须增加训练差异；纯同义改写禁止；
- 可接受差异：证据约束、时间约束、学生回应、反例/边界、失败情境、表征转换、替代方案；
- 不为了题量复制 structured 问题；
- 不把一个回答拆成三个措辞不同的问题凑数量。

## 6. 回答质量

lesson-linked 默认：

`先回答 → 本课证据 → 教学/学科理由 → 边界/不足 → 改进/验证`

source-bound 默认：

`先读官方考察范围 → 给专业判断 → 给可执行行为/知识依据 → 说明边界 → 必要时给后续/验证`

课堂管理突发类再优先：

`安全/秩序 → 现场动作 → 恢复学习 → 后续沟通 → 复盘预防`

共同规则：

- **answer points 优先于长篇标准答案**；用户要能说出口，不要把资料写成作文；
- 证据先于口号；
- 学生学习/课堂结果先于教师表演；
- 学科事实不能编；
- 无生试讲不得伪造真实学生反馈；
- 真实不足可以承认，但必须给 concrete correction path；
- official source 只公布范围而没有题目时，项目题始终是 `derived-defense-question`。

## 7. Lesson-linked 高中物理

当前成熟 subject leaf 为高中物理。

Evidence interface 直接复用：

- regression：`production/regression/<case>/case.yaml`；
- formal：`production/current-run.yaml → workspace + source roles`。

禁止新建平行 `defense-manifest.yaml` 或第二套教材解析链。

D7 的产品职责不是重写高中物理教材，而是训练：

`准确结论 → 使用条件/系统边界 → 图像/公式/实验表征 → 典型误区 → 教学转化`

Round2 的 48 个 D7 seed 已按可靠 subject source 约束。最低基线包括：教育部《普通高中物理课程标准（2017年版2020年修订）》以及当前课题实际教材/可靠学科资料；涉及具体公式/结论时不能只用“教师专业标准”代替学科事实来源。

## 8. 来源纪律

来源身份至少区分：

`official-format / official-standard / official-qualification-boundary / public-format-mirror / public-training / public-recalled-question / derived-defense-question / user-provided`

最终 `public-recalled-question` admitted count 为0，是 provenance gate 结果。以后只有同时具备“云南目标招聘 + 招聘单位/地区 + 日期/年份 + 明确回忆身份 + defense-stage evidence”的题才可增量加入。

Round2 已验证 source-bound 基线：

- 镇康2025：8道；
- 华宁2024：4道；
- 文山2026：6道；
- 合计18道。

它们只证明“项目依据官方公布范围生成训练题”，不证明真实考过。

## 9. PDF / Typst 最终版式

Round1 同内容 ReportLab / Typst 公共 Engine 双原型已经完成真实 200dpi 比较，正式产品栈冻结为 **Typst**；ReportLab 仍是 Engine 既有能力，但本产品不再反复比较。

PDF 硬规则：

- 题目是视觉中心；
- 分类色只承担导航，不堆装饰；
- 不强制一题一页；
- 完整题卡尽量不拆；
- 章节标题不得孤立；
- 禁止无条件 section PageBreak 制造大空白；
- 长卷必须有可见 TOC + PDF bookmarks；
- detail / practice / quick-reference 来自同一 canonical bank；
- Public Engine 只做 mechanical build，不能授予 Human Acceptance；
- 每份最终 PDF 必须进入 review/render 流程；
- ChatGPT 必须逐页打开最终 render 并做使用质量判断后才可进入 `HUMAN_ACCEPTED`。

## 10. Private/Public 执行边界

`qiuzhidaren` 私库 GitHub-hosted Actions 资源已耗尽，不属于生产资源。

唯一正常链路：

`qiuzhidaren → ChatGPT/session → Public Engine → ChatGPT review → qiuzhidaren`

禁止：

- 依赖私库 hosted Actions 做 stage/build/transport；
- Engine checkout 私库；
- Engine 持有私库 PAT/key；
- 两仓直接互相写入。

ChatGPT 可从私库读取最小输入，在会话临时目录执行 consumer publisher/assembly，再把机械输入交给 Public Engine generic capability。

## 11. 历史 Product Round2 Closure — COMPLETE_FROZEN

该轮已经完成并冻结，历史范围为：

1. 120 canonical cards enrichment；
2. 360 effective training prompts 形成；
3. source-bound special volume；
4. V0–V5 + practice 产品族；
5. Public Engine Typst build / Review Pack / 全页验收；
6. 与 Self-introduction、Teacher Quick Start / Master Index 的最终组合验收。

后续禁止在没有真实失败类别和显式架构/模块解冻决策时：

- 再扩 D1–D8 taxonomy；
- 把 D7 做成完整高中物理教材/笔试题库；
- 把培训题包装成云南真题；
- 重启 Resume Materials；
- 重启完整 Written Exam；
- 在本项目重建 Recruitment Intelligence；
- 创建 Product Round3。
