# AGENTS.md — 教师面试作用域

本文件只约束教师求职的 `interview/`。

## 面试分类

1. `teaching-demo/`：试讲、无生授课、片段教学。
2. `structured/`：职业认知、教育情境、组织协调、应急处理等结构化问题。
3. `defense/`：试讲后答辩、专业追问与跨课题通用答辩库。

自我介绍属于教师求职的平级模块 `../self-introduction/`，不并入这里。

## 当前阶段

阶段二已经完成 `teaching-demo/high-school/physics/` 的 Page-to-Plan 生产链收口。该方向进入**稳定生产**：正常新增课题只增加内容/来源/manifest/声明式图形资产，不再预防性修改 publisher、checker、renderer 或 workflow。

阶段三的新开发叶子为：

`structured/`

结构化面试与试讲并列，必须建立自己的输入、题型、答题结构、追问、评分与训练合同，**不得套用“教材页→Point/Edge→考场骨架”的试讲规则**。

## 路由规则

### 进入试讲

继续读取：

`teaching-demo/AGENTS.md`

其中真实任务仍以当前题面/教材页为 authority，执行两 PDF 合同与既有 acceptance 规则。

### 进入结构化面试

继续读取：

`structured/AGENTS.md`

结构化模块必须遵守：

- 先识别题型和评价目标，再组织回答；
- 不把万能模板当成内容答案；
- 情境题优先处理角色、事实、目标、约束、行动与复盘；
- 职业认知题必须区分个人事实与通用观点，禁止编造用户经历；
- 地区/招聘单位/考试年份相关规则必须以用户公告或官方材料为 authority；
- 评分必须能解释“缺了什么、为什么扣分、如何改”，而不是只给总分。

### 进入答辩

`defense/` 维护试讲后的通用追问、专业追问和长期答辩资产；单课高度专属问题仍归对应试讲任务。

## 跨模块隔离

- 试讲的 PDF 数量、15分钟逐字稿、教材页来源合同不自动适用于 structured/defense。
- structured 的题型模板、评分维度不得反向进入试讲 publisher。
- 可复用能力进入共享 `skills/` 或独立数据合同；业务规则保持 scoped。
- 新模块必须先建立 contract/schema/QA，再进行大规模内容扩充。
