# 教师面试 / 试讲入口

试讲只是求职达人教师招聘模块的一个功能块。

模块生命周期与入口权威统一引用 `production/contracts/module-registry-v1.yaml`；本目录不得自行复制或重定义 module lifecycle。

## 内容工作

任何教案、骨架、逐字稿、课题专属答辩、教材到骨架提炼任务，只从 GitHub `main` 当前版本读取：

- `production/process/teaching-demo-content/PROCESS.md`
- `production/contracts/teaching-demo-content.yaml`
- `production/process/teaching-demo-content/STATUS.yaml`
- 同目录 `PLAN.md`、`MEMORY.md` 和最新 `RECORDS.md`

本目录不再定义内容顺序、时长、教学评分或返修流程。不得从历史分支、旧提交、旧成品或修订副本恢复内容规则。所有修改直接发生在上述唯一线上，不新建分支、日期路线、版本路线或备份。

## 机械交付

独立内容验收通过后，按 `production/contracts/teacher-trial-two-pdf-v1.yaml` 与统一 Artifact/Execution Ledger 合同交付两份 PDF。本课题专属答辩属于试讲训练资料；试讲后的独立答辩模块位于 `content/job-search/teacher/interview/defense/`。

排版/资源说明仅使用 `references/product-contract.md`、`references/visual-style.md`、`references/physics-symbols.md`、`references/figure-system.md`。这些文件不得另设内容生产与评分规则。用户购买参考资料由唯一 PROCESS 中的参考入口访问。

新会话先解析 main 最新 HEAD；写入前再查一次。历史交付和下游运行记录不是当前内容入口。内容未通过独立验收，不启动 PDF。
