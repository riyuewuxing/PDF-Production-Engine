# AGENTS.md — 教师求职 / 笔试

本文件约束 `content/job-search/teacher/written-exam/`。

**Lifecycle：`DEFERRED`。** 生命周期唯一 authority 是 `production/contracts/module-registry-v1.yaml`。当前只保留 Phase6/7 历史资产、合同和兼容工具，不进入当前建设/生产门禁。除非用户显式解冻该模块，否则不得继续“第一阶段”、扩题库、跑内部招聘 source scan 或发布新的笔试产物。重新启用后，当前机会必须来自外部 `Validated Opportunity Package`，并统一走根级 Artifact Pipeline。

## 1. 模块定位：Artifact First

模块解冻后，默认替用户生产**可直接阅读、识记、练习、复盘的教师招聘笔试资料**，不要求用户先答题、先模拟考试或先提交错题才能继续建设资料。

领域主链：

`Validated Opportunity Package / verified source evidence → exam profile/family → official outline / subject authority → reference bank → knowledge/method map → question cards/practice → answer analysis → rapid review → module adapter → Unified Artifact Pipeline`

笔试与 `interview/`、`self-introduction/` 平级。试讲、结构化、答辩的题型、时长、评分法不得默认套入笔试。

## 2. 云南不是统一笔试 profile

历史云南研究范围至少存在三类已证实 family：

- `YN-WE-F1`：事业单位分类考试 **中小学教师类 D 类**；
- `YN-WE-F2`：中央特岗教师 **分学科专业基础知识**；
- `YN-WE-F3`：学校/地区/具体招聘单位 **source-specific 学科或混合笔试**。

硬规则：

1. specific announcement/岗位表标注的笔试类别优先于地理经验；
2. 不把 D 类写成“云南所有教师招聘笔试”；
3. 不把特岗学科卷写成 D 类；
4. 不把某所高中自命题范围外推到其他学校；
5. 科目、题型、时长、分值、权重、合格线彼此独立记录；未知字段保持 `null/unknown`；
6. 同一学校跨年份也不静默继承规则。

## 3. 已建立 family 边界

### YN-WE-F1｜事业单位 D 类

历史基线 authority：`事业单位公开招聘分类考试公共科目笔试考试大纲（2026年版）`，且 specific 云南招聘公告明确采用时才实例化。未来解冻时必须重新核验现行版本，不永久继承旧年措辞。

D 类再分小学教师岗位和中学教师岗位；不得合并成一套无子类试卷。

- 《职业能力倾向测验（D类）》：常识判断、言语理解与表达、数量分析、判断推理、策略选择；
- 《综合应用能力（D类）》：师德践行能力、教育教学核心能力、教师自主发展能力；主要题型包括辨析题、案例分析题、教育方案设计题等。

### YN-WE-F2｜中央特岗教师

历史证据显示云南特岗按小学/初中和报考学科分卷，2024 龙陵官方明确“不再单独考查教育学和教育心理学知识内容”。因此既有特岗物理基线是**初中物理/义务教育课程标准语境**，不得拿高中物理知识库直接冒充特岗物理范围；未来实例必须由当期 source 重新确认。

### YN-WE-F3｜具体招聘单位笔试

包括但不限于：

- 高中校园招聘按现行高中教材/大纲命题；
- 学校公开选调主要考学科专业知识；
- specific source 明确出现“学科专业知识 + 教法技能”或“学科专业知识 + 教育理论知识”的混合卷。

F3 必须绑定 `format_source_id`，不能建立云南统一时长或统一知识比例。

## 4. Source / provenance 分层

来源身份至少区分：

- `official-outline`：官方现行考试大纲；
- `official-format`：specific 官方招聘公告/岗位表；
- `official-question`：若未来获得可验证官方公开试题；
- `public-recalled-question`：有招聘/年份/回忆身份的公开回忆题；
- `public-training`：公开培训资料；
- `derived-practice`：根据大纲/知识点自行构造的练习题；
- `user-provided`：用户提供的真实题目/材料。

禁止：

- 把 `derived-practice` 包装成“真题”；
- 把培训题升级成官方题；
- 只凭题目风格猜考试来源；
- 未核验答案就进入正式 reference bank；
- 在本模块恢复 Recruitment Intelligence / current-source discovery。

## 5. Prior-Art First

模块未来解冻并新增题库 importer/normalizer、错题机制、题型 schema、组卷、publisher 前，先读 `references/prior-art.md`。

固定顺序：

`GitHub/官方生态检索 → >=3候选 → 实际 README/关键文件/LICENSE → reuse decision → registry → 只补剩余缺口`

AGPL 或许可证不明项目默认只学习架构/数据思想，不复制实现文本或代码。

## 6. Reference Bank

笔试 reference bank 必须 raw / normalized 分层。

每题至少能表达：

`id / status / profile_family / profile_id / stage / subject / module / question_type / stem / options(or null) / answer / analysis / knowledge_tags / source_id / source_usage / source_locator / risk`

选择题还要检查答案唯一性；主观题必须保存 `answer_points/rubric`，不能只有一段泛泛参考答案。

去重至少覆盖 exact normalized stem；相似题保留时要说明迁移价值或来源差异。

## 7. 资料产品不等于刷题网站

该模块即使未来解冻，也仍以 GitHub 中的可追溯资料和确定性 artifact 为主，不建设登录、会员、排行榜、在线支付、运行时 AI 讲解等平台功能。

可吸收前人项目的：题型 schema、题库分类、错题标签、知识点专项、固定/随机组卷、导入/标准化/验证流程。

只有用户以后明确需要交互刷题平台且有真实需求时才重新评估技术路线。

## 8. 高中物理叶子

高中物理是既有成熟学科叶子，但必须先路由 exam family：

- D 类：按 D 类公共科目准备，不因为目标岗位是高中物理就擅自增加高中物理专业卷；
- 特岗物理：既有基线对应初中物理/义务教育范围；
- F3 高中学科笔试：按 specific 招聘 source + 现行高中课程/教材/可靠学科事实建设。

试讲仓库中的物理教材/公式/图形组件可以作为学科事实与教材定位资产，但不能反向定义笔试题型和分值。

## 9. QA

未来重新启用时，每次内容验收至少检查：

- profile family 是否路由正确；
- source identity 是否准确；
- current outline version 是否明确；
- 题型与 subject/stage 是否冲突；
- 答案是否可验证、解析是否闭环；
- 主观题答题点是否可评分；
- 真题/回忆/培训/派生练习是否清楚标注；
- 高中物理是否误混入特岗初中物理；
- 未实际执行 machine gate 时不得写 PASS。

## 10. Artifact / PDF

任何新可交付视觉文档必须进入统一 Artifact Pipeline：先锁定输入和 block，再 build / machine verification，之后由 ChatGPT 实际查看最终页面才能 `HUMAN_ACCEPTED`。模块 adapter 不得自行宣称 `PUBLISHED`。

## 11. 当前状态：DEFERRED

Phase6/7 的历史成果、source registry、schema、knowledge/method bank、publisher/checker 仅作为保留资产。当前没有“第一阶段”待办。后续是否恢复笔试模块，由 `CURRENT_STATE.yaml` 与 `production/contracts/module-registry-v1.yaml` 的显式变更决定；在此之前不得继续施工。
