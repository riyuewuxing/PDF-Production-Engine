# AGENTS.md — 教师求职作用域

本文件只定义教师业务语义；**模块生命周期以 `production/contracts/module-registry-v1.yaml` 为唯一 authority**，不得在这里维护第二套状态。

## 1. 当前路由

外部 `Validated Opportunity Package`
→ package validation
→ Candidate Facts / Eligibility
→ Application / Preparation
→ 对应教师模块。

实时岗位发现、current-source scan、学校 universe、公告附件采集均属于外部 Recruitment Intelligence。`position-research/` 现为 RETIRED 历史参考/接口素材，不得作为 live request 的执行入口。

## 2. 教师模块

- `interview/teaching-demo/`
- `interview/structured/`
- `interview/defense/`
- `self-introduction/`
- `resume-materials/`
- `written-exam/`
- `position-research/`（历史参考）

具体生命周期只从 module registry 读取。FROZEN 模块按冻结合同执行新实例；DEFERRED 模块必须由用户明确重启；RETIRED 模块禁止进入正常 route。

## 3. 来源与候选人事实

`specific official source / Validated Opportunity Package > 用户材料 > official attachment > traceable public material > historical case > general knowledge`。

- 招聘条件、材料、考试/面试流程必须 source-bound；
- 用户个人事实不得从招聘公告或模板推断；
- 无 Candidate Fact/Evidence 时 eligibility 保持 unknown/needs-candidate-data；
- attachment binary 未取得时附件内部字段保持 unknown；
- failed/degraded source 不得静默当“无岗位”。

## 4. Artifact

任何教师模块产生可交付物时，都进入仓库级 Unified Artifact Pipeline：

`JOB_CREATED → INPUTS_LOCKED → BLOCKS_ACCEPTED → BUILT → MACHINE_VERIFIED → HUMAN_ACCEPTED → PUBLISHED`。

本模块目录只定义业务内容和 Module Contract，不创建新的全局 delivery state machine。
