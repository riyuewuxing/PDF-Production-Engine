# AGENTS.md — 教师求职 / 自我介绍

本文件约束 `content/job-search/teacher/self-introduction/`。

**Lifecycle：`FROZEN`。** 生命周期唯一 authority 是 `production/contracts/module-registry-v1.yaml`。两个内容轮次已经完成并冻结；Canonical final manifest：`materials/yunnan/r2/final-manifest.yaml`，final acceptance：`materials/yunnan/r2/FINAL_ACCEPTANCE.md`。本文保存领域规则与冻结产品合同，不定义独立 delivery lifecycle。新实例从外部 `Validated Opportunity Package` / 用户真实材料进入，并统一走根级 Artifact Pipeline。

## 1. 模块定位：Artifact First

默认生产**可直接填写、背诵、改写、按岗位装配的教师求职自我介绍资料**，不要求用户先参加模拟面试。

稳定领域主链：

`Validated Opportunity Package / verified source → 用户真实材料 → Fact Bank → Story/Evidence Bank → 填空式模板 → 多时长装配 → claim/evidence/follow-up QA → source时长/匿名适配 → module adapter → Unified Artifact Pipeline`

自我介绍与 `interview/` 平级。试讲、结构化、答辩可读取本模块的事实/故事，但不得反向定义本模块合同。

## 2. No fabrication

事实优先级：

`用户明确提供材料 > 简历/证书/报名材料 > 可验证的个人历史资产 > 已验证招聘/学校岗位要求 > 项目模板`

硬规则：

- 不编造学历、专业、教师资格、实习、支教、竞赛、获奖、班主任、教学成绩、科研、论文、学生反馈、学校经历、数字或个人动机；
- 没有真实个人事实时，只保留槽位、降级表达或删句，不生成虚假“我曾经……”；
- 数字、排名、提分、奖项、课时、学生人数等必须有来源；
- 强句必须能回到 Fact/Story；
- “热爱教育、责任心强、沟通能力强”等不能替代证据；
- 仓库中的试讲/结构化/答辩备考资产默认不是用户真实经历。

## 3. 云南 source-first

冻结基线读取 `scopes/yunnan-teacher-self-introduction-v1.yaml` 与 `sources/source-registry.yaml`。当前实时机会的 source authority 由外部 `Validated Opportunity Package` 提供；本模块不得恢复内部招聘发现/采集链。

云南是地理研究范围，不是统一自我介绍 exam profile。具体招聘是否设置自我介绍、时长、评分、匿名禁项、是否与试讲/模拟课堂共享总时长，全部 source-bound。

特别规则：

- source 没写自我介绍，不推断正式存在；
- public employer mirror 可证明公开招聘流程，但不升级政府 authority；
- 高校/职院自我介绍时长和匿名规则只作格式边界，不外推K12频率；
- **combined duration 只代表组合总时长，不能改写成自我介绍单独时长；**
- unknown 字段保持 unknown。

## 4. Prior-Art First

新增或重构 Fact/Story、模板、事实校验、岗位匹配、publisher 等 generic 能力前，先读 `references/prior-art.md`。

流程固定：

`GitHub/官方检索 → >=3候选 → README/关键文件/LICENSE → reuse decision → registry → 只补剩余缺口`

未声明许可证的项目默认 reference-only，不复制实现/文本。

## 5. 填空式模板是 generic 主产品

Canonical 槽位语法：`【填写：slot_id｜提示】`。

槽位来源：

- `fact.*`：候选人真实 Fact Bank；
- `story.*`：真实 Story/Evidence Bank；
- `source.*`：招聘/岗位公开来源；
- `choice.*`：从已有证据选择表达角度；
- `optional.*`：无真实材料可删除。

冻结规模：**18种 `SI-FILL-001..018` + M1–M10**。没有真实失败类别和显式解冻决策时禁止为凑数量扩模板。

Unresolved slot 只能：保留 / 降级 / 删除。Never invent。

## 6. B1–B6 与五档版本

- B1 定位
- B2 资格
- B3 教学证据
- B4 育人/协作
- B5 岗位匹配
- B6 职业收束

准备版本：30 / 60 / 90 / 120 / 180秒。Specific source 有明确时长时以 source 为准。各版本按信息优先级独立装配，不从3分钟稿机械删字。

## 7. Story / Evidence Bank

Story 是证据资产，不是背诵全文。至少保存：

`事实来源 / 场景 / 本人责任 / 本人动作 / 结果 / 可验证数字 / 能力标签 / 可用于哪些块 / likely followups / 风险与未知项`

STAR/CAR 只整理真实事实，不创造缺失 Task/Action/Result。

## 8. Anonymous-safe

若 source 禁止姓名、毕业学校、导师、联系方式、工作单位等：

- 使用 anonymous-safe 版本；
- 真正删除禁项，不用“某知名大学/某导师”等规避；
- 可把真实身份标签改成非识别性能力描述；
- `source.prohibited` 是装配 authority。

## 9. Claim → Evidence → Follow-up

最终个人成稿必须检查：

`claim → evidence required → current evidence → likely follow-up → downgrade if unverified`

风险等级：

- R0：岗位/流程低风险；
- R1：简单经历；
- R2：能力型强主张；
- R3：数字、奖项、任职、成绩、学校了解、长期动机等高风险主张。

R2/R3 无足够证据时降级或删除。

## 10. 高中物理 P1–P6

高中物理可从真实个人证据中选择：

- P1 学科基础/概念边界
- P2 实验/测量/证据
- P3 图像/模型/多表征
- P4 教学设计/重难点
- P5 评价/学习证据
- P6 育人/课堂/协作

60秒通常只选两类互补证据。没有 P6 真实经历时不硬凑。

## 11. Personalized-ready

只有同时满足以下条件才可标记个性化完成：

- 目标岗位明确；
- source 已知时长/匿名已应用，未知项保持 unknown；
- 所有个人槽位已解析或删除；
- 至少一条岗位相关强证据；
- 强数字全部有来源；
- 所有主张可回 Fact/Story；
- 追问风险已生成；
- 没把备考资产冒充真实经历；
- 读出后不是简历朗读。

用户无需重新口述全部经历：优先从已有简历、证书、报名材料、作品和明确陈述抽取 Fact Bank。

## 12. Artifact / PDF 硬规则

新可交付视觉文档必须进入统一 Artifact Pipeline：锁定输入与 blocks，运行 module adapter，完成 machine verification，然后由 ChatGPT 实际查看最终页面后才能 `HUMAN_ACCEPTED`，最后才可 `PUBLISHED`。

既有 module adapter：

`python tools/publish_yunnan_self_introduction.py`

冻结产品：

1. 《云南教师求职自我介绍核心资料.pdf》
2. 《教师自我介绍填空模板册.pdf》

历史版本已验收不代表新实例自动通过；hash 变化必须重新 machine/human acceptance。

## 13. Machine gate

既有 scoped static checker：

`python tools/check_teacher_self_introduction.py`

没有实际执行时不得写 machine PASS。Static checker 与 Human Acceptance 分开记录；adapter/checker 均不得自行宣称 `PUBLISHED`。

## 14. FROZEN 解冻条件

只有以下真实变化可作为提出解冻的证据：

- 新招聘 source 明确改变是否有自我介绍、时长、匿名或组合时长；
- 用户真实材料暴露现有 Fact/Story/模板无法装配的类别；
- 新候选人类型出现真实通用失败；
- artifact render 暴露 generic adapter/版式失败。

即使出现上述变化，也先提交模块解冻/架构决策，再修改 generic 层。没有真实失败时禁止：预防性扩模板、创造“云南统一时长”、编用户经历、绕过统一 Artifact QA。
