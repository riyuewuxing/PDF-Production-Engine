# AGENTS.md — 教师岗位情报历史作用域

**Lifecycle: RETIRED.** 唯一 authority：`production/contracts/module-registry-v1.yaml`。

本目录保存 Phase9 历史研究、schema、source registry、fixtures、benchmark 与失败证据，用于理解未来外部 Recruitment Intelligence 的接口与既往经验；**不得作为 qiuzhidaren 的 live recruitment execution route。**

## 当前边界

实时招聘发现、学校 universe、current-source scan、公告/附件采集、版本跟踪和 opportunity validation 已外部化到 Recruitment Intelligence。

`qiuzhidaren` 当前只消费：

`Validated Opportunity Package`

然后进入：

`package validation → Candidate Facts / Eligibility → Application / Preparation → teacher modules`

## 历史资料如何使用

允许：

- 作为 external Recruitment Intelligence 的 schema/interface/prior-art 参考；
- 解释 Phase9 历史 benchmark、失败类别和 source authority 思路；
- 复核旧 acceptance/evidence；
- 在未来独立 Recruitment Intelligence 项目中经重新评估后迁移思路。

禁止：

- 在本仓库运行新的 source acquisition/current opening search；
- 把历史 canonical event pool 当成当前岗位；
- 调用本目录 RETIRED acquisition tools 生产实时结果；
- 用搜索片段、历史附件状态或旧 event 推断当前报名资格；
- 重新启用 private GitHub-hosted Actions 做附件采集。

## 历史 source 原则

Phase9 曾采用 `A0 issuing official authority > A1 official repost > discovery source > commercial/community lead`，并强调 fetch failure != no result、official attachment first-class、学校名录作为覆盖分母。这些内容属于历史研究结论，不改变当前 EXTERNAL 边界。

历史官方附件 binary gap、benchmark 和 source failures 必须原样保留，不得为了架构迁移改写成 PASS。
