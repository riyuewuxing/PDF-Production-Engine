# 求职达人底层架构（Architecture Foundation v1）

状态：**RELEASED / `main` CANONICAL**。当前项目状态仍以 `CURRENT_STATE.yaml` 为唯一 authority。

## 0. 项目本质：Process as Product

本项目首先要交付的是一条**任何获授权 AI 只读仓库 authority 后都能快速、稳定、可审计地操控的求职生产流程**；PDF、逐字稿、简历、题库等是用户需要的具体 deliverable，同时也是验证流程的样本，不是底层项目本身。

模型能力决定语义质量上限；架构通过 Module Contract、Golden Path、source/provenance、machine gates、Execution Ledger、HUMAN acceptance 和 fail-closed 规则保障最低质量与可重复性。单个 artifact 被反复修到通过不等于系统成熟。详细决策见 `ADR-009-process-as-product-and-agent-portability.md`。

Teaching Demo Content 在 ADR-012 中进一步采用 Evidence-Carrying Teaching Script Compiler：这是一套**模块内部的内容形成 gate controller**，用于把实际课堂事实、状态迁移和语义证据变成可验证输入；它不替代本 README 第 5 节的全局 Artifact lifecycle，也不创建第二个项目级状态机。ADR-013 固定 Phase-A accepted-mode fail-closed、repository-local Gate-B 自激活禁令与 semantic-judge producer provenance 边界。独立 Gate A 随后证明 ADR-013 关于“caller/path/function metadata 可作为 deny-only aggregate isolation”的局部假设仍不足；ADR-014 因此 supersede 该局部假设，改为 **capability removal / composition locality**：internal core、enforcement 与 checker stage helper 不得保留第二个 aggregate acceptance capability，唯一完整编排只存在于 canonical checker `validate`；同时 answer-bearing resource 的完整暴露只能由 explicit `RESOURCE_REVEAL` 产生，且 first full exposure 必须严格晚于 verified formation。RRA4 独立 Gate A 又证明同一缺陷仍可在下游复现：严格 content gate 并不能阻止一个仍持有完整 PDF composition / Artifact plan-write 能力的 current helper 绕过 canonical wrapper。ADR-015 因此把 capability-removal 原则扩展成 **Protected Operation Capability Graph**：Teaching Demo 的 content acceptance、Artifact plan write 与 product PDF composition 各自只能有一个完整 canonical orchestrator；tool lifecycle 与 execution role 分离，implementation library 只能保留 primitive capability，并由 `tools/check_tooling_routes.py` 与 `production/contracts/teacher-trial-two-pdf-v1.yaml#protected_operations` 交叉约束。RRA5 继续从 consumer 侧攻击后发现：唯一 producer 仍不足以阻止 generic Artifact locker 消费手工构造 plan，formal render 也能在独立调用时重新产生下游写入。ADR-016 因此把同一图扩展为 **producer + consumer closure**：Module Contract 可声明 live input-lock verifier，由 generic `check_artifact_job.py` 在事务提交前重建 canonical plan；formal render 也成为受保护 operation，accepted-content gate 必须早于任何正式 QA render mutation。RRA5 Follow-up Independent Gate A PASS 后，ADR-017 将下一阶段明确收敛为 **Phase-B Semantic Controller Provenance + Eval Harness First**：semantic judge payload 与 producer identity 分离，仓库只保留 provenance verification/evaluation 能力，production controller authority 由可信 runtime 持有，accepted mode 在独立 Gate B 之前继续 fail closed。

## 1. 固定拓扑

`qiuzhidaren` 是模块化单体（Modular Monolith）和业务 authority。

外部系统只有两个：

1. `Recruitment Intelligence`：发现、验证岗位并输出 `Validated Opportunity Package`；
2. `PDF-Production-Engine`：公共、无状态、纯机械执行资源。

跨系统编排由 ChatGPT/session 完成。Engine 不 checkout 私库、不持有私库 PAT、不写回私库，也不保存业务状态。ChatGPT 从私库 authority 组装**已物化、hash-bound 的 Execution Package**交给 Engine；Engine 返回 machine evidence，由 ChatGPT 验证后写回 `qiuzhidaren`。

## 2. 仓库内四层

1. **Domain**：职业/模块业务规则、内容、事实、Module Contract；
2. **Application**：Opportunity → Candidate → Eligibility → Application → Preparation；
3. **Artifact**：统一 Artifact Job / Block / Manifest / Review / Publish；
4. **Adapters**：GitHub、Recruitment Intelligence、PDF-Production-Engine、文件与网络运行时。

业务差异只能进入 Domain/Module Contract；不得进入通用 Artifact 执行器的课题/地区/模块名分支。

## 3. 单一事实源

| Concern | 唯一 authority |
|---|---|
| 当前项目状态 | `CURRENT_STATE.yaml` |
| 架构决策 | `architecture/adr/*.md` |
| 模块生命周期/执行适配 | `production/contracts/module-registry-v1.yaml` |
| Artifact 生命周期 | `production/contracts/artifact-job-v1.yaml` |
| 执行事件与生命周期投影 | `production/contracts/execution-ledger-v1.yaml` |
| 长期 repository provenance | `production/contracts/repository-provenance-snapshot-v1.yaml` |
| Artifact 生产效率/反馈循环 | `production/resource-build-efficiency-policy-v1.yaml` |
| 工具生命周期与执行角色 | `tools/tooling-manifest.yaml` |

README、AGENTS、ROADMAP 只能引用这些事实，禁止复制另一套可执行定义。

## 4. 模块生命周期

允许词汇由 module registry 定义；当前架构固定为 `ACTIVE / FROZEN / DEFERRED / EXTERNAL / RETIRED`。

- `ACTIVE`：当前允许建设和执行；
- `FROZEN`：已有验收基线，可按既有合同执行新实例；
- `DEFERRED`：保留资产，不进入当前建设/执行；
- `EXTERNAL`：由外部系统提供，本仓库只消费合同；
- `RETIRED`：历史参考，不得进入正常路由。

具体模块取值只从 `module-registry-v1.yaml` 读取。

## 5. 统一 Artifact Pipeline

Artifact lifecycle 只由 `production/contracts/artifact-job-v1.yaml` 定义：

`JOB_CREATED → INPUTS_LOCKED → BLOCKS_ACCEPTED → BUILT → MACHINE_VERIFIED → HUMAN_ACCEPTED → PUBLISHED`

模块内部的教学边界、Point Chain、板书、逐字稿、题库、简历字段等属于 Module Contract 的 block/checklist，不升级为全局状态机阶段。ADR-012 的 `SOURCE_LOCKED → … → HUMAN_ACCEPTED` 仅用于 Teaching Demo Content 内部的内容资格形成与证据 gate，不改变 Artifact Job lifecycle。

新 job 使用 `tools/init_artifact_job.py` 同步创建 Artifact Job 与 ledger；后续统一通过 `tools/manage_artifact_job.py` 锁定输入、登记 block/output/evidence、记录执行事件和推进状态。Job `state` 必须等于 execution ledger 中 lifecycle transition 的投影；跳阶段和重复 transition fail closed。对于声明 `artifact_job_profile.input_lock_verification` 的 Module Contract，generic live Artifact checker 还必须在 `INPUTS_LOCKED+` 执行 contract-declared verifier；因此 direct generic `lock-inputs` 不能绕过模块自己的 canonical input-plan 约束。

## 6. Execution Ledger

运行事实使用 append-only ledger。生命周期 transition 与 Build/Render/Review/Reject 等详细事件先入账，再由 checker 投影 artifact state，并派生 attempts、cycles、build/render 数、拒绝数和效率指标；禁止由人工摘要字段反向宣称运行事实。

历史失败实验不补造逐事件记录，只保留原始 frozen evidence。

## 7. Artifact / Provenance / Reuse

ADR-005 定义 content-addressed Artifact provenance；ADR-010 补齐 repository bytes 随时间演化后的长期证明；ADR-011 将**执行复用 identity**与**历史审计 identity**明确分离。

### 7.1 新 Job 的输入冻结

`INPUTS_LOCKED` 必须冻结：

- 显式 input bindings；
- Module Contract bytes；
- module build adapter bytes；
- runtime name/version；
- `source_snapshot_binding`；
- canonical SHA-256 `input_fingerprint`。

Repository Snapshot 是 content-addressed YAML，记录 exact `source_commit`，以及每个被覆盖仓库文件的：

`path + kind + SHA-256 + git_blob_sha1`

Snapshot 有两个不同 identity：

- `dependency_identity_sha256`：只描述相关 repository dependency 集合，排除 `source_commit`；
- `snapshot_identity_sha256`：包含 exact `source_commit`，用于不可变历史审计与 content-addressed snapshot path。

### 7.2 Reuse identity 不得被 audit record 污染

`input_fingerprint` 只由真正影响执行的内容推导：Module Contract binding、builder binding、runtime identity 与 execution-relevant input bindings。

Repository Snapshot 是对同一批私库 dependency bytes 的**平行历史证明**，不能再把 snapshot record hash/source commit 重复塞入 reuse fingerprint；否则一次与本任务无关的 Git commit 就会制造虚假 cache miss。

生成的 `input_plan` 仍按 exact `path + SHA-256 + kind=input_plan` 绑定和审计，但它只是已经显式列出的依赖的控制记录，因此由 Artifact Contract 明确排除在 reusable fingerprint 之外。

因此：

- source commit 改变、但所有 execution-relevant bytes 完全相同 → 允许得到相同 `input_fingerprint`；
- snapshot audit record 因 source commit 不同而不同 → 历史仍可精确追溯；
- 任一真正 dependency bytes 或 runtime 改变 → `input_fingerprint` 改变并失效复用。

### 7.3 Live Verification 与 Historical Verification 必须分开

**Live execution verification** 用于“现在能不能执行”：当前 materialized package 中的 repository bytes 必须同时符合 snapshot 的 SHA-256 与 Git blob identity；任何 stale/modified bytes 都 fail closed。Canonical checker 是 `tools/check_artifact_job.py`。如果 Module Contract 声明 input-lock verifier，则 verifier 自身必须先作为 current input binding 被 live hash 验证，随后才允许执行；Teaching Demo verifier 进一步通过 canonical plan reconstruction 重新建立 accepted-content authority。

**Historical verification** 用于“以后还能不能证明当时用了什么”：旧 Job 只对 immutable Repository Snapshot + exact source commit 验证，不再要求当前同一路径仍保存旧 bytes。Canonical checker 是 `tools/check_artifact_provenance.py`；Git-aware 环境可用 `git-history` 模式把 snapshot 中每个 path 在记录的 commit 上重新解析并核对 SHA-256/Git blob。

这两个模式不能互相替代：历史验证不能因为 current path 已变化而误报旧 Job 失败；live execution 也不能因为历史 snapshot 存在就放过当前 package 的 stale bytes。

### 7.4 Engine 边界

source commit/path 的私库证明由 ChatGPT/orchestrator 或 Git-aware checkout/GitHub object fetch 完成。Public Stateless Engine 只接收已经物化或 sealed 的 Execution Package、snapshot metadata、命令和预期绑定；它不需要、也禁止获得私库凭证或私库 checkout 权限。

外部 locked source（如教材 PDF）继续使用自己的 immutable source identity；generated input plan 是 source commit 之后形成的 content-addressed execution record，由自身 SHA-256 直接验证，不伪装成 source-commit file。

旧 Artifact Job 没有 Repository Snapshot 时只保留 historical compatibility；禁止事后合成 snapshot/backfill 来把旧历史伪装成新协议。

## 8. Machine / HUMAN 与 Delivery / Qualification

Machine verification 与 Human acceptance 永久分离。MACHINE_VERIFIED 必须绑定 module-check evidence；最终可视 artifact 在 HUMAN_ACCEPTED 前必须存在 final-render evidence，并由 ChatGPT 实际查看。Engine 不得产生 HUMAN `REVIEW_PASS`。

单个交付物能否发布属于 Delivery Acceptance。系统是否达到连续多案例质量/效率/复用/agent portability 标准属于独立 System Qualification。Qualification 永不插入普通发布状态机，也不反向否定已接受的 immutable delivery。

System Qualification 验证的是生产流程，不是把几个样本磨到好看：不同 case 必须证明质量与效率同时通过，warm path 不改 generic implementation，执行事实来自 ledger，正常接手不得依赖未写入仓库的历史会话记忆。

## 9. Runtime 与 Git

私库 GitHub-hosted Actions 当前不可作为正常生产依赖，活动 workflow 已从 canonical tree 移除，并由 `check_private_actions_boundary.py` fail closed。

机械构建资源是 Public Stateless `PDF-Production-Engine`。私库没有 hosted runner 不等于系统没有执行资源；正确路径是 `qiuzhidaren → ChatGPT materialized/sealed execution package → Engine → machine evidence → ChatGPT review/writeback`。

`main` 是唯一长期 Git authority。feature/fix 分支必须短生命周期；允许正常 fast-forward/merge，但 force update 永久禁止。

## 10. ADR 冻结与变更规则

当前 ACCEPTED 架构决策为 **ADR-001 至 ADR-017**。已 ACCEPTED ADR 不原地改写；发现已接受 ADR 的局部决策需要纠正时，必须通过新的 superseding/extension ADR 覆盖，而不是改写历史。ADR-013 不替换 ADR-012 的 Teaching Demo compiler/state-machine 绑定；ADR-014 只 supersede ADR-013 中已被独立 Gate A 实证推翻的 metadata-based aggregate isolation 局部假设，并保留 ADR-013 的 Phase-B fail-closed / semantic producer provenance 边界；ADR-015 把 ADR-014 的 capability-removal/composition-locality 原则扩展到 downstream protected operations 与 tooling execution-role governance；ADR-016 再将同一能力图闭合到 consumer state transition 与 formal render boundary；ADR-017 在 Gate A PASS 后把 Phase B 收敛为 controller-attested semantic producer provenance + adversarial eval harness，并明确 Gate B 前 accepted mode 继续 fail closed。未来只有真实新边界、系统性失败、外部协议失效或明确证据证明基础假设错误时，才新增 ADR。
