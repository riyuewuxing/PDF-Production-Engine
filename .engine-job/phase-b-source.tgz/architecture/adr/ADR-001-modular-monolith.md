# ADR-001 — Modular Monolith

Status: ACCEPTED

`qiuzhidaren` 采用模块化单体。职业/模块以明确边界和合同隔离，但默认共享一个业务仓库与发布边界。除非出现独立扩缩容、安全、团队或发布生命周期需求，不拆微服务。

Supersedes: none.
