# ADR-004 — Append-only Execution Ledger

Status: ACCEPTED

Actual Build/Render/Review/Reject/Publish events are recorded append-only. Attempts, generation-review cycles, build/render counts and efficiency metrics are checker-derived from the ledger rather than trusted from summary fields.

This is not whole-project Event Sourcing. Business state remains normal domain state; only execution/audit facts use the ledger.

Historical runs without instrumentation remain explicitly legacy/unknown and are never backfilled with fabricated events.
