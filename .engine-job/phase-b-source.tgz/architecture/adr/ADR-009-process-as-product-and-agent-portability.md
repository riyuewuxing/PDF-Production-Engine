# ADR-009 — Process as Product and Agent Portability

Status: ACCEPTED

## Decision

`qiuzhidaren` 的首要产品不是某一批 PDF、逐字稿、简历或题库，而是一个**任何获授权 AI 在只读取仓库 authority 后，都能快速、稳定、可审计地操控的求职生产流程**。具体 artifact 是用户交付物，也是验证这条流程的样本与证据；“某个 artifact 最终被反复修到通过”不能单独证明项目成功。

模型能力决定语义质量上限；架构负责质量下限、可重复性、路由正确性、来源纪律、机械正确性和失败收敛。较强 AI 可以写得更好；较弱但能遵循合同的 AI 仍应被 Module Contract、Golden Path、machine gates、provenance、HUMAN acceptance 与 fail-closed 规则约束在可接受下限之上。架构不能替代模型的专业判断，因此无法保证所有模型达到同一质量上限。

## Golden Path

正常任务必须优先走仓库已经铺好的端到端路径：

`read authority → resolve module → lock inputs → accept required blocks → build once → machine verify → HUMAN review → publish`

已知类型任务属于 warm path：原则上只改变业务内容、manifest/source bindings 和 receipts，不修改 generic implementation。只有真实缺少可复用 capability、contract、adapter 或 failure-class gate 时才进入 cold path；cold path 的完成条件不是“当前样本过了”，而是形成可复用实现 + selftest/regression + 明确 warm reuse path。

## Failure Learning

每次拒绝先分类为 instance/content defect 或 reusable process defect。若属于可泛化的 process defect，应修复共享 contract/adapter/gate 并留下回归证据；不得在同一 artifact 上无限手工抛光而不产生永久流程改进。

process-evaluation case 的完整 `generation → final render → HUMAN review` 循环默认目标为 1 次，最多 3 次。达到第 3 次仍未通过时必须停止，把结果记为 process failure / STOP_LIMIT 并做根因归类；不得为了交差继续第 4 次。墙钟时间是观测指标，不作为单独硬门槛，因为外部等待与 HUMAN 编排时间可能不可控。

## Agent Portability

正常执行不得依赖某个历史会话的隐含记忆。接手 AI 应只靠仓库中的 `CURRENT_STATE.yaml`、Architecture/ADR、Module Registry、当前 Module Contract、Artifact contracts 和必要 source/input 就能确定：做什么、不能做什么、如何构建、如何验收、何时停止。

System Qualification 验证的是这个流程，而不是三个漂亮样本：必须使用不同 case，证明 warm-path 复用、质量与效率同时通过、无隐藏会话依赖，并从 Execution Ledger 读取真实执行事实。

## Rationale

本决策采用成熟的软件交付/平台工程经验：DORA 强调小批次、快速反馈和自动化；Google SRE 将重复、可自动化且不产生永久改进的工作视为 toil，并主张从系统中消除；Platform Engineering 的 Golden Path 目标是把正确做法变成最容易执行的端到端路径；Evolutionary Architecture 使用 automated fitness functions 把架构目标转成持续机器约束。

## Consequences

- 单次 Delivery PASS 只证明该 artifact 可以发布，不证明生产系统成熟。
- 重复人工返修次数本身是流程缺陷信号，不能被“最后过了”掩盖。
- 项目开发优先级按未来重复节省、失败预防和 agent portability 排序，而不是按当前 artifact 完成度排序。
- 最终 HUMAN review 继续保留，它负责不可完全机械化的内容、视觉与使用质量判断；流程优化不得通过降低这一门槛换速度。
