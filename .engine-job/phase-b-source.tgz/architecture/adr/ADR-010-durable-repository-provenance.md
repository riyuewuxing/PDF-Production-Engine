# ADR-010 — Durable Repository Provenance

Status: ACCEPTED

## Context

ADR-005 established content-addressed Artifact provenance using repository-relative `path + SHA-256` bindings. That is correct for **live execution fail-closed verification**, but mutable working-tree paths are not a durable historical proof: after shared code or content changes, an old job must not be judged by the new bytes currently found at the same path.

The project also has an explicit external execution boundary. `PDF-Production-Engine` is public/stateless mechanical execution and must not receive a private-repository token or checkout. Therefore durable provenance cannot depend on the Engine retaining private repository history.

## Decision

For every new Artifact Job, repository provenance is split into two deliberately different verification modes:

1. **Live execution verification** — before execution, current materialized repository bytes must match the declared SHA-256 and Git blob identity. Any mismatch fails closed.
2. **Historical verification** — after repository paths change, the old job is verified against an immutable content-addressed Repository Snapshot plus the exact source commit, never against mutable current-path bytes.

A Repository Snapshot records:

- repository identity;
- canonical branch;
- exact `source_commit`;
- every covered repository file as `path + kind + SHA-256 + git_blob_sha1`;
- a canonical SHA-256 snapshot identity;
- an immutable content-addressed snapshot path.

`build_provenance.source_snapshot_binding` binds the exact snapshot file used by the Artifact Job. The normal input fingerprint includes this snapshot binding in addition to Module Contract, builder, runtime identity and explicit input bindings.

The source commit/path proof is performed by the orchestrator or a Git-aware checkout. A stateless Engine only receives materialized execution-package bytes and the snapshot metadata needed to verify those bytes; it never needs private Git credentials or private repository history.

Historical verification may use a Git checkout or GitHub object fetch at the recorded commit to prove that each recorded path resolves to bytes matching both SHA-256 and Git blob identity. The current working tree is irrelevant to that historical proof.

External locked sources keep their own immutable source identity contracts; generated outputs are governed by Artifact output/evidence hashes and are not forced into the repository snapshot.

## Consequences

- Shared code can evolve without making old accepted jobs falsely invalid merely because current paths changed.
- Current execution remains strict: stale or locally modified bytes cannot be silently accepted.
- Provenance becomes portable across AI sessions because source commit and file identities are explicit data rather than hidden conversation state.
- The public Engine remains stateless and credential-free.
- New jobs require durable snapshot provenance; old jobs without it remain historical compatibility evidence and are never retroactively backfilled.

## Relationship to ADR-005

This ADR **extends** ADR-005; it does not rewrite or weaken it. ADR-005 remains the decision that artifacts are content-addressed and reproducible. ADR-010 defines how repository inputs remain verifiable after mutable paths evolve.
