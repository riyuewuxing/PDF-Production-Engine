# ADR-007 — Single Authority and Lifecycle Taxonomy

Status: ACCEPTED

Each concern has one authoritative representation. Derived prose may explain but must not redefine executable truth.

Module/tool lifecycle vocabulary is fixed to `ACTIVE / FROZEN / DEFERRED / EXTERNAL / RETIRED`.

`CURRENT_STATE.yaml` is current-state authority; the module registry is module lifecycle/execution authority; the tooling manifest is executable tool lifecycle authority.
