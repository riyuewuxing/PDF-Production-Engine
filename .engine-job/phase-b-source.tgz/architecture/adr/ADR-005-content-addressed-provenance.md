# ADR-005 — Content-addressed Artifact Provenance

Status: ACCEPTED

Reusable artifacts are bound by explicit inputs, Module Contract, builder/runtime identity and SHA-256. Unchanged accepted bindings may be reused; changed bytes invalidate the corresponding acceptance.

Every final artifact retains provenance sufficient to answer: what inputs/contract/builder produced these bytes, what machine evidence was generated, and which HUMAN acceptance bound the final hash.
