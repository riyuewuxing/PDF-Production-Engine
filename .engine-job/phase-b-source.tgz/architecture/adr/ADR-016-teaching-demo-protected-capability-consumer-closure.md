# ADR-016 — Teaching Demo Protected Capability Consumer Closure

- Status: **ACCEPTED**
- Date: 2026-09-10
- Scope: `teacher_teaching_demo` downstream protected-operation consumption
- Extends: `ADR-015-teaching-demo-protected-operation-capability-graph.md`
- Supersedes: none

## Context

ADR-015 removed complete Teaching Demo PDF-composition and Artifact-plan-write capability from lower-level publisher/planner libraries and required one canonical complete producer for each protected operation. Post-write adversarial review found that producer uniqueness alone is not a complete authority boundary.

Several consumer-side weaknesses remained possible:

1. `tools/lock_artifact_input_plan.py` could validate a plan's self-declared identity, snapshot and bindings without proving that the plan was the exact result of the canonical Teaching Demo planner.
2. `tools/manage_artifact_job.py#lock_inputs` is a generic public Artifact operator; without a module-contract-driven invariant, a direct generic `lock-inputs` path could try to reach `INPUTS_LOCKED` without the Teaching Demo plan adapter.
3. `tools/render_current_run.py` could write formal current-run QA render artifacts without independently rechecking the accepted Teaching Demo content boundary.
4. A consumer verifier that reconstructs through a normal current-process import can inherit a forged/preloaded `sys.modules` alias. RRA3 already established that module-name/path metadata is not authority.
5. Even a correctly reconstructed plan is not complete provenance if it freezes only user source files and repository runtime dependencies while omitting the evidence that actually authorized downstream use. For Teaching Demo that authorization is post-freeze and consists of `SUBMISSION_FREEZE.yaml`, `INDEPENDENT_CONTENT_REVIEW.yaml` and `HUMAN_ACCEPTANCE_RECEIPT.yaml`.
6. The Artifact plan `source_commit` must not be an arbitrary 40-hex label independent of the source commit bound by the accepted-content evidence. Otherwise exact accepted bytes could be attached to false repository provenance.
7. A rollback-after-validation design is insufficient if the canonical Execution Ledger is mutated *before* the module consumer verifier runs. A process crash between the speculative ledger write and rollback could leave an unverified lifecycle/evidence event in the authority file.
8. Exact verifier-file binding is still incomplete if the verifier must first execute another repository-local helper and then uses that helper to establish its own integrity/binding facts. Exact path removes ambient alias ambiguity but does not solve this bootstrap cycle. The small primitives needed to inspect a plan before canonical reconstruction must therefore be self-contained in the already-bound verifier.

These are consumer-side forms of the same architectural failure addressed by ADR-014/ADR-015: a guarded preferred producer is insufficient while another current route can consume, materialize or relabel protected state without re-establishing the same authority.

## Decision

### 1. Protected capability graphs are producer + consumer graphs

A protected operation is closed only when both are true:

- exactly one current complete producer owns the operation; and
- every current consumer that can materialize, lock, render, publish or advance protected state either revalidates the canonical precondition itself or passes through a lower invariant that does so.

Naming, caller identity, CLI convention, route labels and a plan's self-declared fields are not authority.

### 2. Module-specific input-lock policy is enforced at the generic live Artifact validator

The unified Artifact Pipeline remains generic. It must not contain a hard-coded `teacher_teaching_demo` branch.

A Module Contract may declare `artifact_job_profile.input_lock_verification`. When present and active from `INPUTS_LOCKED`, `tools/check_artifact_job.py` must:

1. read the policy from the exact module contract selected by the module registry and bound by the Job;
2. require exactly one input binding of the declared plan kind;
3. require the verifier file itself to be present exactly once in live Job input bindings and validate its current hash before execution;
4. load only the repository-relative verifier module/function declared by that contract;
5. require the verifier to return a fail-closed `list[str]`;
6. reject the live Job if the verifier cannot run, reports errors, or its interface is malformed.

This invariant applies equally to the dedicated plan locker, direct generic `lock-inputs`, import callers and future lock adapters. No caller token or stack inspection is used.

### 3. Artifact transaction candidates are validated before the first canonical mutation

`tools/manage_artifact_job.py` must not make the canonical ledger temporarily authoritative and rely on rollback to compensate for a later gate failure.

For any operation that changes both Job and Execution Ledger:

1. construct `new_job` and `new_ledger` in memory;
2. validate the candidate ledger;
3. run the complete live Job rules against the candidate pair, including any Module-Contract-declared input-lock verifier;
4. if any error exists, perform **zero canonical Job/Ledger writes**;
5. only after candidate PASS may canonical writes begin.

Ledger-only evidence/review events use the same precommit validation rule. Rollback remains write-failure recovery after a candidate has already passed; it is not gate enforcement.

This does not claim impossible two-file ACID semantics. A process or host failure between the two post-PASS file writes can still leave a temporarily inconsistent Job/Ledger pair. The public persisted-state validator must then fail closed because Job state and ledger projection disagree. Such a failure is a recoverability/availability concern, not an authorization path for a candidate that never passed validation.

The persisted public `check_artifact_job.validate()` continues to read the canonical ledger file. Any internal candidate-pair validation path is explicitly precommit-only and must execute the same complete live rules; it is not a persisted-state authority.

### 4. Teaching Demo live plan verification uses exact canonical reconstruction

The Teaching Demo verifier is a non-executable library. For every live `INPUTS_LOCKED+` Teaching Demo Job it must prove all of the following from current repository bytes:

- the bound plan file has valid content-addressed identity and canonical storage path;
- plan `module_id`, module-contract binding and builder binding equal the Job's bound authority;
- plan repository-snapshot binding equals the Job source-snapshot binding;
- the Job input-binding set is exactly the plan's declared input set plus exactly one binding for the plan itself;
- the profile-declared canonical planner is itself present exactly once as the expected `input_planner` binding and its current hash validates;
- the protected-operation graph names that same planner as the only Artifact-plan-write entry;
- the plan's `manifest` and `source_commit` can be fed back into that exact planner;
- fresh reconstruction succeeds and produces a plan exactly equal to the consumed plan.

A self-consistent hand-authored YAML plan therefore has no authority.

### 5. Verifier bootstrap primitives are self-contained

The verifier is already hash-bound and live-validated by the generic Artifact gate before its callback is executed. The small primitives it needs before canonical reconstruction must not introduce a second repository-code bootstrap dependency.

`artifact_job_profile.input_lock_verification.verifier.repository_bootstrap` is therefore fixed to `self-contained-no-repository-imports-v1`.

`tools/verify_teaching_demo_artifact_plan.py` must implement locally the narrow bootstrap operations required to inspect the live plan: repository-safe path resolution, YAML top-level mapping load, SHA-256 file hashing, canonical JSON SHA-256, binding-key projection and live binding validation. Their semantics must remain compatible with the generic Artifact foundation contract, but the verifier must not import or dynamically execute a repository-local helper to obtain them.

Its selftest must inspect the verifier's own import surface and fail if a repository-local bootstrap import is reintroduced. A forged ambient `sys.modules['artifact_foundation']` must not influence the verifier's bootstrap primitives.

`tools/artifact_foundation.py` remains a normal exact repository dependency for the manager/locker/provenance paths that actually use it. Removing it from verifier bootstrap does not remove it from Artifact provenance generally.

### 6. Canonical reconstruction executes the exact planner file in an isolated fresh process

Normal current-process import identity is not an authorization primitive. The verifier must not establish canonicality by `import plan_teaching_demo_artifact_job` and trusting whichever object currently occupies that module name.

The Module Contract therefore fixes `canonical_reconstruction_execution.mode = isolated-fresh-python-file-subprocess-v1`. The verifier:

1. reads the canonical planner path from the bound Module Contract;
2. requires a matching live planner binding and validates its current hash;
3. starts Python in isolated mode (`-I`), explicitly inserts the canonical repository `tools` directory first, and executes the exact repository planner file without `--write`;
4. requires the canonical no-product-PDF completion marker;
5. parses one plan mapping and compares it exactly with the consumed plan.

A fake current-process `sys.modules['plan_teaching_demo_artifact_job']`, fake `sys.modules['artifact_foundation']`, module alias or monkeypatched imported planner cannot redefine this reconstruction/bootstrap boundary.

### 7. Artifact plan provenance freezes the complete accepted-content evidence capsule

Canonical reconstruction alone proves what the current planner would produce. The plan must also carry durable evidence of **why** the content was allowed to enter downstream state.

For Teaching Demo, `artifact_job_profile.content_acceptance_capsule` is mandatory and contains exactly three live input bindings:

1. `SUBMISSION_FREEZE.yaml` — exact frozen content/gate evidence set;
2. `INDEPENDENT_CONTENT_REVIEW.yaml` — exact independent review over that freeze;
3. `HUMAN_ACCEPTANCE_RECEIPT.yaml` — post-freeze transition receipt binding the freeze and review.

The canonical planner and live consumer verifier both independently require:

- all three files to be current exact bindings in the plan;
- the HUMAN receipt `case_id` to equal the manifest/plan case;
- the freeze and HUMAN receipt `source_commit` to equal the Artifact plan `source_commit`;
- the HUMAN receipt's `submission_freeze` and `independent_content_review` SHA-256 values to equal the exact current capsule bindings;
- the plan not to contain a self-declared `downstream_released` authority flag.

The plan may summarize a content decision, but that summary is not authority. Authority is the accepted-content gate plus this exact evidence capsule and fresh consumer reconstruction.

The capsule intentionally does not duplicate every pre-freeze sidecar in the Artifact plan. `SUBMISSION_FREEZE.yaml` already binds the complete canonical submission/gate evidence set, and the later review/receipt bind that freeze. This preserves one content evidence authority rather than creating a second planner-maintained inventory.

### 8. Formal visual QA render is a protected operation

Add `TEACHING_DEMO_FORMAL_RENDER` to the Teaching Demo protected-operation graph.

- canonical complete entry: `tools/render_current_run.py#render_product`;
- direct CLI and import invocation must converge on this function;
- accepted-content/prebuild validation must complete before the first `qa/current-run-rendered` (or manifest-selected render directory) delete, create, PNG write or render-manifest write;
- module import must not parse CLI arguments or select mutable output globals.

Low-level one-PDF rasterization and occupancy analysis may remain primitives, but they do not authorize a complete formal current-run QA render.

### 9. Non-formal regression PDF capability remains separate

`tools/build_regression_case.py` may continue to build bounded regression PDFs only while all of these structural restrictions hold:

- the case requires `not_formal_delivery: true`;
- output is confined to the regression output namespace;
- generated artifacts identify themselves as non-formal regression material;
- the route cannot target the formal current-run output/render namespace or advance a formal Artifact lifecycle.

This is not a second formal product-PDF composition authority.

### 10. Routing and contract binding are fail closed

`tools/tooling-manifest.yaml`, the Teaching Demo product contract, the module registry and route checker must agree on protected canonical entries, implementation libraries, execution roles and forbidden complete surfaces. Repository-local relabeling cannot turn a primitive library into a second protected entry.

The live plan verifier itself is a canonical library/control dependency and must be bound by the Teaching Demo plan/snapshot dependency set. Its bootstrap is self-contained specifically to avoid an unverified second repository-code authority. The canonical content checker's dynamic/internal runtime files (`_teaching_demo_content_core.inc`, architecture facade/impl and enforcement helper) remain explicit repository dependencies because static Python import-closure analysis alone cannot discover all of them.

Planning/provenance/locking/live-state-verification operators may be excluded from Engine runtime import-closure semantics only when they remain exact repository bindings for provenance and their control dependency closure remains fail closed.

### 11. Mandatory adversarial regressions

At minimum, future review must attack:

- direct `manage_artifact_job.py lock-inputs` for a Teaching Demo Job with no input plan;
- a failing module input-lock verifier while both pair and ledger-only transaction write functions are instrumented to fail if any canonical write is attempted before the rejection;
- a hand-authored self-consistent Teaching Demo plan with forged review/release fields;
- a plan carrying `downstream_released: true` as self-declared authority;
- a valid-looking plan whose Job inputs differ by one binding;
- a copied plan at a non-canonical path or a case id that escapes the configured output root;
- a plan whose module/builder/snapshot binding differs from the Job;
- a plan missing any of freeze / independent review / HUMAN acceptance receipt;
- a HUMAN receipt whose case/source_commit or freeze/review hash differs from the plan;
- a plan whose `source_commit` differs from the accepted-content freeze/HUMAN receipt source commit;
- a fake current-process `sys.modules['plan_teaching_demo_artifact_job']` that attempts to redefine reconstruction;
- a fake current-process `sys.modules['artifact_foundation']` that attempts to redefine verifier bootstrap primitives;
- any repository-local import reintroduced into the Teaching Demo live verifier bootstrap surface;
- a plan that cannot be freshly reconstructed while accepted content is locked;
- direct import invocation of formal `render_product` while accepted content is locked, with render-directory mutation instrumented to fail if reached;
- direct CLI formal render while accepted content is locked;
- reintroduction of a second process-evaluation complete CLI or a protected publisher/planner aggregate;
- tooling-manifest relabeling intended to bless a protected implementation library as an executable route.

## Phase and evidence boundaries

- RRA4 independent Gate A remains `GATE_A_REJECT` for the bytes it reviewed.
- This ADR records later RRA5 implementer findings and repair direction; it is not an independent Gate-A acceptance.
- Round1/Round2 first-complete packages and REJECT scores remain immutable.
- Process calibration remains `NOT_CALIBRATED`.
- Phase B, fresh topics, automatic third topic, formal PDF/Artifact execution and downstream QA remain blocked until a new independent Gate A accepts the final repaired bytes.
- Historical Artifact/PDF evidence remains historical evidence only.
- Without an exact private-repository checkout shell, source inspection/read-back/selftest-code review must not be reported as runtime PASS.

## Consequences

Teaching Demo protection now follows authority through production, consumption, self-contained verifier bootstrap, precommit transaction validation, evidence provenance and formal render. The invariant is no longer merely "the preferred producer called the gate". It is:

**no current repository route may produce or consume protected Teaching Demo state unless the canonical accepted-content condition is re-established before the first authoritative mutation at the committing boundary, and the bound consumer must not execute a second repository-local bootstrap authority before it has established the plan facts used for canonical reconstruction.**
