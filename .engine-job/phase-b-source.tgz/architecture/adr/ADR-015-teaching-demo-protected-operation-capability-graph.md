# ADR-015 — Teaching Demo Protected Operation Capability Graph

- Status: **ACCEPTED**
- Date: 2026-09-09
- Scope: `teacher_teaching_demo` protected content/downstream operations
- Extends: `ADR-012-evidence-carrying-teaching-script-compiler.md`, `ADR-014-teaching-demo-capability-removal-and-first-full-exposure.md`
- Supersedes: none

## Context

RRA4 independent Gate A accepted the source-level closure of the previous content-gate findings, but rejected the repository because the same architectural defect still existed one layer downstream.

The canonical content path correctly failed closed in accepted mode, and `tools/build_current_run.py` correctly called the accepted-content prebuild gate before composition. However current repository helpers still exposed complete protected operations outside those canonical wrappers:

- `publisher_core_legacy.py#main` plus its direct CLI could perform the complete manifest-to-PDF build sequence;
- `publisher_core.py#main` delegated to that complete legacy build;
- `plan_teaching_demo_artifact_job_legacy.py` could independently build and `--write` a complete content-addressed Artifact input plan without the canonical accepted-content precondition;
- `tools/tooling-manifest.yaml` classified tool lifecycle but did not model the difference between a public execution entry and an implementation library, and several current top-level Python modules were not classified at all.

This is not four unrelated missing checks. It is the same root failure that ADR-014 addressed inside the content checker: a strict wrapper is not an authority boundary while a lower-level current module still possesses the complete protected capability.

## Decision

### 1. Protected operations are explicit capabilities

For the active Teaching Demo module, the current repository recognizes at least these protected operations:

1. `TEACHING_DEMO_CONTENT_ACCEPT`
   - complete canonical composition: `tools/check_teaching_demo_content.py#validate`
   - Phase-A accepted mode remains fail closed until the later Phase-B controller/provenance gate is legitimately implemented and accepted.

2. `TEACHING_DEMO_ARTIFACT_PLAN_WRITE`
   - complete canonical planner/writer: `tools/plan_teaching_demo_artifact_job.py`
   - accepted-content validation is a mandatory precondition before a complete plan can be formed or written.

3. `TEACHING_DEMO_PRODUCT_PDF_COMPOSE`
   - complete canonical builder: `tools/build_current_run.py`
   - accepted-content prebuild validation is a mandatory precondition before output cleanup, TeX materialization, XeLaTeX execution, PDF write, or formal product composition begins.

A future protected operation must be added to this graph before an alternate repository entry is introduced.

### 2. One complete orchestrator per protected operation

For each protected operation, exactly one current repository module may contain the complete orchestration semantics.

Implementation libraries may expose reusable primitives such as:

- schema/contract validators;
- source-page resolution;
- Markdown/TeX rendering;
- one-document `compile_tex`;
- binding/hash helpers;
- figure discovery;
- repository snapshot construction helpers.

But a library may not independently perform the entire protected operation. In particular:

- publisher libraries must not expose a generic manifest-to-complete-product `main` or direct build CLI;
- planner libraries must not expose a complete `build_plan`, complete content-addressed plan writer, or direct `--write` CLI;
- a strict canonical wrapper must not delegate to a hidden complete aggregate and call that isolation.

The security basis is **capability removal / composition locality**, not caller identity, stack inspection, module names, source paths, closure identity, or convention.

### 3. Accepted-content preconditions belong inside the complete canonical operation

The accepted-content precondition must execute inside the public complete operation itself, before the first protected side effect.

It is insufficient for only one CLI wrapper to call the gate if an import caller can invoke an ungated complete function.

Therefore:

- direct CLI and import invocation of the canonical builder must converge on the same gated build function;
- direct CLI and import invocation of the canonical planner must converge on the same gated planning/writing function;
- no hidden raw complete function may be stored in a closure/module alias for later recovery.

### 4. Tool routing must distinguish lifecycle classification from execution role

`tools/tooling-manifest.yaml` remains the lifecycle authority for top-level tools, but lifecycle labels alone are not enough.

Every current top-level `tools/*.py` must be classified in exactly one lifecycle group already supported by the architecture (`canonical`, `compatibility_only`, or `retired`) **and** current non-retired tools must have an explicit execution role such as:

- `entry`: supported executable/public orchestration surface;
- `library`: import/helper surface, not an independent public execution route;
- `entry_and_library`: an intentionally dual-use module whose executable behavior is itself canonical for its own non-conflicting capability;
- `compatibility_entry`: compatibility-only executable surface.

These roles describe routing; they do not promote a helper into a new protected operation.

The manifest must additionally declare the protected-operation graph: canonical entry plus implementation libraries. Route enforcement must fail closed when:

- a current top-level Python file is unclassified;
- a current non-retired file lacks an execution role;
- a protected implementation library exposes a forbidden complete aggregate or `__main__` route;
- a protected operation names more than one complete canonical entry;
- a protected canonical entry is absent or not classified as canonical.

Dangerous second routes must be removed, not relabeled `canonical` merely to silence the routing checker.

### 5. Mandatory adversarial regressions

At minimum the source-level regression set must attack:

- direct execution/import of the former publisher legacy implementation;
- direct `publisher_core.main` recovery;
- direct execution/import of the former legacy planner `build_plan` / `write_content_addressed_plan` / `--write` path;
- an unclassified top-level Python file;
- a protected library that reintroduces `main` or direct `__main__` execution;
- a protected library that reintroduces a complete forbidden planner aggregate;
- canonical builder import invocation while accepted content is locked;
- canonical planner import invocation while accepted content is locked;
- manifest relabeling that attempts to legalize a dangerous implementation library as a second protected entry.

The test objective is not “the preferred command is guarded”. The objective is that no current repository-provided alternate route can perform the protected operation.

## Phase and evidence boundaries

- RRA4 independent Gate A remains `GATE_A_REJECT` for its reviewed bytes.
- The previous P0-04/P1-05 repairs remain source-level held findings; this ADR does not reopen them unless new evidence appears.
- Round1/Round2 first-complete packages and their REJECT scores remain immutable.
- Process calibration remains `NOT_CALIBRATED`.
- Phase B, fresh topics, automatic third topic, PDF/Artifact execution and downstream QA remain blocked until a new independent Gate A accepts the repaired current bytes.
- Existing historical published Artifact/PDF evidence is historical evidence only and does not authorize current blocked composition.
- If an exact private-repository checkout shell is unavailable, source/read-back/regression-code inspection must not be reported as runtime PASS.

## Consequences

The Teaching Demo architecture now applies the same rule from content formation through downstream execution: **protected authority is a capability graph, not a naming convention**.

This deliberately moves complete orchestration upward into canonical entries and pushes helpers downward into primitives. It also makes tooling-route review actionable: lifecycle answers whether a file belongs in the current tree, while execution role answers whether it is allowed to be an entry, a library, or compatibility surface.

A future reviewer should attack the graph from the operation outward: start with the protected side effect, enumerate every current route capable of reaching it, and prove that each route either converges on the canonical gated operation or lacks the complete capability.