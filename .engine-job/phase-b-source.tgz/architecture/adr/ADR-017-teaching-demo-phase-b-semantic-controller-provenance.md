# ADR-017 — Teaching Demo Phase-B Semantic Controller Provenance

- Status: **ACCEPTED**
- Date: 2026-09-10
- Scope: `teacher_teaching_demo_content_formation`
- Extends: ADR-012 / ADR-013 / ADR-014 / ADR-015 / ADR-016
- Trigger: RRA5 Follow-up Independent Gate A **PASS** → `PHASE_B_EVAL_HARNESS_FIRST`

## Context

ADR-013 deliberately kept Teaching Demo accepted mode fail-closed because repository-authored fields such as `reviewer_role`, `implementation_and_judge_separate`, runner names, hashes and a self-computed digest can prove only what a file claims, not who or what produced the semantic judgment.

RRA5 Gate A has now accepted the Phase-A architecture/control boundary. The next missing capability is therefore not another round of abstract hardening. It is an executable Phase-B controller provenance boundary plus an adversarial evaluation harness that can distinguish:

1. a genuinely controller-attested semantic execution over the exact intended inputs and judge outputs; from
2. a repository author filling plausible PASS/role/runner strings or replaying stale/wrong execution evidence.

The current `check_teaching_demo_content.py` accepted path must remain locked until this Phase-B capability is implemented, exercised and independently Gate-B reviewed.

## Decision

### 1. Semantic verdict payload and producer provenance remain separate concerns

`SCIENCE_EVIDENCE_JUDGE.yaml` and `ENACTMENT_STUDENT_JUDGE.yaml` continue to carry evidence-bound semantic verdict payloads. Their internal role/separation fields remain declarations only.

Phase B introduces a separate **Semantic Controller Execution Receipt**. The receipt attests the execution facts around both judge payloads; it does not replace or weaken the existing semantic evidence checks.

The receipt must bind at least:

- exact `case_id`;
- one canonical semantic-input-set digest shared by both judges;
- exact controller identity and exact controller implementation/source identity expected by the trusted runtime;
- exact runtime identity/version;
- one fresh controller `run_id` and nonce;
- issuance and expiry timestamps with a short bounded lifetime;
- both required judge identities;
- exact allowed runner identity for each judge;
- non-empty producer/session identity for each judge execution;
- the same semantic-input digest for each judge execution;
- exact output path and SHA-256 for each judge payload;
- an integrity authenticator covering the complete receipt payload.

### 2. Repository-authored strings cannot create controller authority

The production repository contains **verification capability only**. It must not contain the production controller secret or a production signing command/function that ordinary repository code can invoke to mint acceptance authority.

For the first Phase-B implementation the integrity authenticator is `HMAC-SHA256`, with the MAC key supplied by the trusted controller runtime at verification time. The repository may contain a test-only synthetic key inside the adversarial harness solely to prove verifier behavior. That test key has no production authority.

This is a runtime capability boundary, not a claim of cryptographic human identity. Its security premise is explicit: Gate B must bind and review the exact trusted controller/runtime configuration that owns the live MAC capability. If the controller secret is exposed to unreviewed repository code, the provenance boundary is not satisfied.

A future asymmetric-signature controller may supersede this mechanism if the external runtime provides a stable signing identity without exposing signing authority to repository execution. That is not required to begin Phase-B evaluation.

### 3. Exact expected values come from the trusted invocation, not from the receipt itself

The verifier must receive expected controller/runtime identity, expected case/input digest, expected judge runners and expected judge output bindings from the trusted invocation context. It must not accept those values merely because the receipt repeats them.

Therefore a self-consistent but wrong receipt still fails when it binds:

- the wrong case;
- stale/expired time;
- the wrong semantic input set;
- the wrong controller implementation;
- the wrong runtime;
- the wrong judge runner;
- a changed judge output hash/path;
- different input digests across the two judges.

### 4. Gate B activation remains unavailable in the repository

This ADR does **not** authorize `GATE_B_ACTIVATION.yaml`, a repository-local PASS switch, or any other data-only accepted-mode unlock.

Until an Independent Gate B accepts actual Phase-B execution evidence:

- `check_teaching_demo_content.py --mode accepted` remains fail-closed;
- repository-local activation remains explicitly forbidden;
- fresh topics, automatic third topic, formal PDF/Artifact/Engine production and `CALIBRATED` remain blocked.

After Gate B PASS, the accepted-mode lock may be replaced only by a minimal reviewed change that consumes the verified controller provenance boundary. Gate B PASS itself must not be inferred from the existence of this ADR or from source-level selftests.

### 5. Eval Harness First is mandatory

The canonical Phase-B harness must attack at least the permanent known set:

- `M20` — non-empty bare `releases` cannot manufacture hard formation truth;
- `M21` — structurally valid but semantically insufficient visible-span formation cannot PASS;
- `P0-RRA4-A` — loaded internal core has no `validate/main` aggregate;
- `P0-RRA4-B` — alternate `co_filename` compilation still has no aggregate;
- `P0-RRA4-D` — no recoverable checker stage collector/guard closure;
- `P1-RRA4-E` — post-response FULL SHOW before verified formation is killed;
- `P0-H` — forged repository Gate-B activation does not unlock accepted mode;
- `P1-PROV` — plausible role/separation/runner strings without valid controller provenance do not create accepted authority.

The harness must also include at least one **positive Gold** controller receipt that survives verification. `100% mutant kill` obtained by rejecting everything is invalid.

For provenance specifically, the negative set must cover missing/invalid authenticator, wrong trusted key, expiry/replay boundary, wrong case/input, wrong controller/runtime, wrong runner, changed judge output binding and split judge input identity.

## Canonical implementation boundaries

- Provenance verifier library: `tools/verify_teaching_demo_semantic_provenance.py`
- Phase-B eval entry: `tools/check_teaching_demo_phase_b_eval.py`
- Phase-B machine entry: `python tools/run_acceptance.py --scope phase-b`
- Existing content accepted-mode lock: remains in `tools/check_teaching_demo_content.py` until independent Gate B permits a targeted replacement.

The provenance verifier is a pure library. The eval harness is an executable test/evaluation entry. Neither becomes a second Teaching Demo content acceptance orchestrator.

## Gate-B evidence requirements

Before Gate B can PASS, evidence must show at minimum:

1. known P0/P1 semantic/provenance mutants are killed;
2. positive Gold survives;
3. false-PASS, stale-runtime, wrong-runner, wrong-input, fabricated-review/self-activation attacks fail;
4. the exact controller/runtime identity and verifier bytes under review are bound;
5. actual semantic judge outputs used by the controller are exact-bound to the same input set;
6. current canonical source/tooling/foundation runtime checks are executed when an exact repository shell is available, or explicitly retained as `NOT_EXECUTED` debt without fabrication;
7. accepted mode remains locked until the independent Gate-B decision is durable.

## Consequences

Phase B now has a concrete, testable trust boundary instead of a documentary identity claim. The repository can develop and adversarially test the verifier without prematurely opening accepted mode. Runtime secret ownership and independent Gate-B review remain external authority responsibilities, preserving ADR-013's original fail-closed principle while allowing the project to progress.