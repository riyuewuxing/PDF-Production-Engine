# ADR-003 — Unified Artifact Pipeline

Status: ACCEPTED

All deliverable-producing modules use one repository-level Artifact Job model and one lifecycle:

`JOB_CREATED → INPUTS_LOCKED → BLOCKS_ACCEPTED → BUILT → MACHINE_VERIFIED → HUMAN_ACCEPTED → PUBLISHED`.

Module-specific semantics live in Module Contracts and block definitions. Module names, topics, regions, or lesson titles must not become branches in the generic pipeline.

Legacy teaching-demo 15/16-stage governance remains historical compatibility evidence and is not the active cross-project execution model.
