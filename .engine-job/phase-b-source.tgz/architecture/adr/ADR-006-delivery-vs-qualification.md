# ADR-006 — Delivery Acceptance vs System Qualification

Status: ACCEPTED

Delivery Acceptance answers whether one artifact/job may be published. System Qualification answers whether the production system has demonstrated a broader quality/efficiency target across multiple attempts.

They are separate lanes. A score/series/qualification record must never become a required state inside ordinary Artifact Job publication.
