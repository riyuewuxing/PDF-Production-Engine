# ADR-013 — Teaching Demo Authority Provenance and Phase-B Fail-Closed Lock

- Status: **ACCEPTED**
- Date: 2026-09-08
- Scope: `teacher_teaching_demo_content_formation`
- Extends: `ADR-012-evidence-carrying-teaching-script-compiler.md`
- Supersedes: none; ADR-012 remains the canonical compiler/state-machine architecture decision

## Context

Mandatory post-write re-review after the original Gate-A reject repair found two additional authority problems.

First, an allow decision based on Python caller metadata is not a capability boundary. Module names, `__file__`, `co_filename`, function names, `sys.modules` entries and mutable module globals can be forged or replaced. A guard that tries to discover a "canonical caller" from those values can therefore recreate an alternate aggregate gate even when ordinary direct calls fail closed.

Second, a repository-local `GATE_B_ACTIVATION.yaml` containing `GATE_B_PASS`, an `INDEPENDENT_GATE_B_REVIEWER` string, a separation boolean, runner-name strings, current file hashes and a self-computed digest is still authored data. Those fields can establish byte integrity and declared intent, but they do not establish independent reviewer identity, semantic-judge producer provenance, calibrated runtime execution, or controller authority. Letting such a file open accepted mode would allow the implementation/content side to self-activate Phase B.

The existing independent Gate-A review had already stated the underlying boundary honestly: HUMAN/semantic role fields are not cryptographic proof of person/session identity. They are acceptable only when an actual independent controller/reviewer workflow supplies the role. RRA3 therefore must not pretend that additional repository strings solve provenance.

## Decision

### 1. Caller metadata is deny-only, never authority

The canonical acceptance capability remains `tools/check_teaching_demo_content.py#validate`.

For the historical internal-core aggregate `validate/main` surfaces, source path and function name may be used only as a conservative **deny rule**. They may never grant authority. A forged path/name can therefore only cause rejection.

The architecture facade must reject any stack containing the historical internal-core aggregate `validate/main` frame from `_teaching_demo_content_core.inc`, regardless of what module claims to be the canonical checker or what object appears in `sys.modules`.

The canonical checker's own aggregate stage collectors must be reachable only while the original canonical `validate` code object is executing with the canonical module globals. That code identity is bound once in a closure and must not be re-read from the mutable module-level `validate` name. Stage-collector wrappers capture the original guard rather than consulting a replaceable exported guard name.

This is defense-in-depth around internal implementation surfaces. It does not turn Python metadata into authentication; the primary architectural rule remains that no helper/internal module has independent acceptance semantics.

### 2. Phase A has no repository-local Gate-B activation capability

During Phase A, `require_independent=True` / accepted mode is globally fail-closed.

A repository-local `GATE_B_ACTIVATION.yaml` is explicitly **not** activation authority. If such a file appears before Phase B implements its controller/provenance contract, the canonical checker rejects it as repository self-activation.

Phase B may replace this lock only after:

1. a real semantic-judge/controller execution path exists;
2. Science/Evidence and Enactment/Student judge execution provenance is bound to the exact input set and exact runtime/controller identity;
3. the controller evidence cannot be created merely by filling repository role/separation/runner strings and recomputing hashes;
4. independent Gate B attacks false-PASS, stale-runtime, wrong-runner, wrong-input, fabricated-review and self-activation mutations;
5. downstream continues to enter only through the canonical accepted gate.

Until then, there is intentionally no data-only path that can make accepted mode PASS.

### 3. Semantic judge files carry verdict evidence, not producer identity

`SCIENCE_EVIDENCE_JUDGE.yaml` and `ENACTMENT_STUDENT_JUDGE.yaml` remain evidence-bound verdict payloads for Phase-A readiness and architecture testing. Exact bindings, verdict coverage, evidence refs and digests establish what the payload says about which bytes; they do **not** prove who or what produced it.

Therefore:

- `reviewer_role: SEMANTIC_JUDGE` and `implementation_and_judge_separate: true` are declarations, not producer provenance;
- a Phase-A readiness PASS must never be described as independently calibrated semantic execution;
- semantic-judge producer provenance is a Phase-B controller responsibility;
- accepted mode stays locked until that provenance path is implemented and independently Gate-B reviewed.

This containment is deliberate: Phase A can validate the evidence-carrying compiler contract without inventing fake cryptographic identity, while no fresh validation or PDF/downstream route can consume an unproven semantic producer as accepted authority.

## Required negative regressions

RRA3 must preserve reusable attacks for at least:

1. second `SourceFileLoader` internal-core aggregate invocation;
2. fake canonical module injected into `sys.modules` with canonical `__file__` and attacker-selected `core` globals;
3. filename/function-name lookalike caller;
4. replacement of the module-level canonical `validate` name;
5. replacement of the exported checker guard name;
6. direct checker stage-collector invocation;
7. direct enforcement aggregate invocation;
8. repository-local forged Gate-B activation containing plausible PASS/reviewer/separation/runner fields;
9. downstream prebuild attempt while Phase B controller is not implemented.

All such paths must fail closed or remain blocked from accepted/downstream authority.

## Phase boundaries

- Round1 and Round2 first-complete packages, scores and REJECT decisions remain immutable historical evidence.
- Phase B remains blocked until a **new independent Gate A review** accepts the final RRA3 bytes.
- Fresh topics remain blocked until Phase B/Gate B permits them.
- PDF/downstream remains blocked until the protected content-acceptance path is genuinely open.
- The implementer may record static closure and regression design, but may not self-sign independent Gate A or Gate B PASS.
- If no exact repository checkout shell is available, selftest status must remain `NOT_EXECUTED_NO_REPOSITORY_SHELL`; static review is not runtime PASS.

## Consequences

The architecture intentionally prefers a hard temporary lock over a convenient self-attested activation file. This delays accepted-mode execution until Phase B supplies the missing controller/provenance capability, but it removes an entire class of documentary self-activation bypasses and keeps the authority boundary truthful.

ADR-012 remains authoritative for the compiler, state machine, evidence model and single-gate architecture. ADR-013 is the accepted addendum governing authority provenance, caller-metadata handling and the Phase-A-to-Phase-B activation boundary.
