# ADR-014 — Teaching Demo Capability Removal and First-Full-Exposure Semantics

- Status: **ACCEPTED**
- Date: 2026-09-09
- Scope: `teacher_teaching_demo_content_formation`
- Extends: `ADR-012-evidence-carrying-teaching-script-compiler.md`
- Supersedes in part: `ADR-013-teaching-demo-authority-provenance-and-phase-b-lock.md`

## Context

The independent Gate A review of the RRA3 bytes rejected two assumptions that
survived the prior hardening.

First, ADR-013 correctly rejected caller metadata as an *allow-side*
authentication mechanism, but still permitted source path / function name
metadata as a deny-only tripwire around historical aggregate surfaces. The
review demonstrated that this is not capability isolation. The same source can
be compiled with an attacker-selected `co_filename`, so a deny rule that
recognizes the aggregate by path/name can fail to recognize semantically
identical code. In addition, checker stage collectors protected by a decorator
still retained the undecorated aggregate function inside the wrapper closure;
Python introspection can recover and call that function directly.

Second, the resource state machine split two protections incorrectly. The
machine visibility validator rejected `RESOURCE_SHOW visibility: FULL` only
before or at `STUDENT_RESPONSE`, while the verified-formation causality check
looked only at `RESOURCE_REVEAL`. A sequence could therefore perform a safe show,
obtain the response, fully expose the answer through a second `RESOURCE_SHOW`,
form the knowledge later, and finally add a compliant `RESOURCE_REVEAL`. Each
split validator could pass even though the answer had already been exposed.

These are architecture failures, not fixture-specific defects.

## Decision

### 1. Acceptance isolation is capability removal, not introspection policy

The only complete Teaching Demo Content readiness/accepted composition is
`tools/check_teaching_demo_content.py#validate`.

No internal/helper module may contain a second complete or acceptance-like
aggregate. Specifically:

- `tools/_teaching_demo_content_core.inc` is a primitive library only and must
  not define `validate` or `main` aggregate/CLI symbols;
- `tools/teaching_demo_content_enforcement.py` must not expose an aggregate
  `validate_case` surface, even if that surface merely returns a fail-closed
  diagnostic;
- the canonical checker must not hide stage aggregates behind decorators,
  closure guards, stack checks, code-object identity checks, module identity,
  source path, function names, or caller metadata;
- mature deterministic and architecture validators remain callable primitives,
  but complete decision composition is written directly in canonical
  `validate`.

The architecture no longer treats metadata-based deny guards as an isolation
mechanism. If a helper capability is dangerous when called directly, remove or
decompose the capability instead of attempting to recognize its caller.

This supersedes **only** the ADR-013 premise that caller/path/function metadata
may safely protect historical aggregate surfaces on a deny-only basis. ADR-013
remains authoritative for:

- the Phase-A accepted-mode global lock;
- the prohibition on repository-local Gate-B self-activation;
- the distinction between semantic verdict payload binding and producer
  identity/provenance;
- Phase-B responsibility for a real semantic-judge/controller provenance path.

### 2. Required P0 negative regressions prove absence, not guard success

The canonical selftest source must preserve at least these RRA4 attacks:

1. inspect the loaded internal core and assert aggregate `validate/main` symbols
   are absent;
2. read the exact internal-core source, compile/execute it under an attacker-
   selected alternate `co_filename`, and assert aggregate `validate/main`
   symbols remain absent;
3. assert the enforcement helper has no aggregate `validate_case` symbol;
4. assert the checker no longer exports the historical `_run_core_primitives`,
   `_validate_freeze_review_acceptance`, `_guard_stage_collector`,
   `_canonical_validate_context_allowed`, or `_make_canonical_context_guard`
   surfaces;
5. assert canonical `validate` itself is not a closure containing a recoverable
   hidden stage aggregate.

The security claim is therefore structural: the alternate acceptance-like
capability is absent.

### 3. Answer-bearing full exposure is an explicit event transition

For a resource with non-empty `answer_bearing_information_ids` and
`use_mode: discovery|scaffold`:

- pre-response `RESOURCE_SHOW` must remain `SAFE`, `MASKED`, or `CROPPED`;
- **every** `RESOURCE_SHOW visibility: FULL` is forbidden, before or after the
  student response;
- the only event type that may create full answer exposure is
  `RESOURCE_REVEAL`;
- machine enforcement must derive `first_full_exposure` across *all* resource
  events, treating both a `RESOURCE_SHOW FULL` and a `RESOURCE_REVEAL` as a full
  exposure candidate;
- the earliest candidate must be a `RESOURCE_REVEAL`;
- for every answer-bearing knowledge id,
  `verified_first_release.ordinal < first_full_exposure.ordinal` must hold;
- the existing requirement for an actual `STUDENT_RESPONSE` and an explicit
  reveal after that response remains in force.

This prevents split-validator gaps: a later compliant reveal cannot erase an
earlier full exposure.

### 4. Required P1-05 mutant

The reusable regression suite must include the exact attack:

`safe/masked RESOURCE_SHOW -> STUDENT_RESPONSE -> RESOURCE_SHOW FULL -> verified formation -> RESOURCE_REVEAL`

It must be rejected independently by:

- the machine visibility primitive because answer-bearing `RESOURCE_SHOW FULL`
  is forbidden; and
- the semantic-dependent causality primitive because the derived
  `first_full_exposure` is not a `RESOURCE_REVEAL` and/or occurs before verified
  formation.

## Phase and evidence boundaries

- The previous independent RRA3 Gate A result remains `GATE_A_REJECT` for the
  reviewed bytes.
- RRA4 implementer repair is not a Gate A PASS.
- Round1/Round2 first-complete packages, scores and REJECT decisions remain
  immutable.
- Process calibration remains `NOT_CALIBRATED`.
- Phase B, fresh validation and PDF/downstream remain blocked until a new
  independent Gate A accepts the final repaired bytes.
- If no exact repository checkout shell is available, selftest remains
  `NOT_EXECUTED_NO_REPOSITORY_SHELL`; Git read-back/static inspection is not
  runtime PASS.

## Consequences

This ADR deliberately prefers a simpler authority surface over increasingly
clever Python guards. The canonical checker becomes easier to review: full
composition exists in one function, while helper files expose only reusable
primitives. Resource exposure receives the same treatment: full answer
visibility is represented by one explicit transition, and causality checks the
first actual exposure rather than trusting the existence of a later compliant
event.
