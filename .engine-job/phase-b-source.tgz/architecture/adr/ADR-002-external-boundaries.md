# ADR-002 — External Boundaries

Status: ACCEPTED

Only two architecture-level external systems are recognized:

- Recruitment Intelligence → emits `Validated Opportunity Package`.
- `riyuewuxing/PDF-Production-Engine` → stateless mechanical resource execution.

`qiuzhidaren` does not rebuild Recruitment Intelligence. The Engine never owns business state, candidate facts, project PAT, HUMAN acceptance, or private-repo writeback. ChatGPT/session is the orchestration bridge.

Supersedes: internal Position Research as a live recruitment engine.
