# ADR-008 — Git Authority Target

Status: ACCEPTED

During this migration, no merge/PR/force is performed without user authorization. The migration branch is a review candidate, not a release by itself.

After explicit release approval, `main` becomes the single long-lived Git authority. Feature/fix branches are short-lived; accepted releases are tagged. Documentation must not rely indefinitely on a stale default branch plus a hidden long-lived authority branch.
