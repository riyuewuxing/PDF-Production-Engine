# ADR-012 — Evidence-Carrying Teaching Script Compiler

Status: **ACCEPTED**

Date: 2026-09-07

Amended after independent Gate A REJECT: 2026-09-08

Supersedes: the Teaching Demo Content enforcement assumption that prose rules plus author-authored semantic sidecars are sufficient to establish readiness. This ADR does **not** supersede ADR-009's Process-as-Product principle; it makes that principle enforceable for Teaching Demo Content.

## Context

Round 1 and Round 2 established a reusable process failure: the repository already contained many correct teaching rules, yet an implementer could satisfy schema, anchor, hash, path and arithmetic checks while the final trial script failed to enact the evidence or timing claimed in sidecars. Round 2 produced a concrete example: a sidecar could claim the proportional evidence needed for a ratio definition even when the final classroom script had not actually presented that proportional relation. Author-written `PASS` fields therefore cannot be treated as independent facts.

The first independent Gate A review found two further instances of the same architectural root cause and **REJECTED** Phase A:

1. a historical internal core still exposed a weaker aggregate acceptance path that could be invoked through Python import/`SourceFileLoader` even though the canonical CLI was stricter;
2. `event.releases:[K1]` was author-authored hidden metadata that could be promoted directly into `SCRIPT_FACTS.first_release`, allowing the author to manufacture a formation timestamp even when the visible sentence did not semantically establish K1.

The project remains `Process as Product`. The repair must improve the reusable production route rather than polish rejected historical packages.

## Decision

Teaching Demo Content adopts an **Evidence-Carrying Teaching Script Compiler** architecture:

```text
source / task / verified reference evidence
→ Lesson Evidence IR
→ Typed Script Event Stream
→ natural-language user content
→ machine-derived SCRIPT_FACTS release claims
→ Deterministic Gate
→ Science/Evidence Judge verifies release semantics and other science claims
→ machine derives verified_first_release
→ hard board/resource causality consumes verified_first_release only
→ Enactment/Student Judge
→ content-addressed Freeze
→ Independent HUMAN
```

The existing canonical paths remain the only runtime authority:

- `production/process/teaching-demo-content/PROCESS.md`
- `production/contracts/teaching-demo-content.yaml`
- `tools/check_teaching_demo_content.py`

Helper/internal modules may exist only as libraries/primitives used by the canonical checker. **Only the canonical checker may compose readiness/accepted decisions.** An internal module may not expose an effective second CLI, importable aggregate gate, alternate acceptance route, or independent lifecycle. Direct execution, `SourceFileLoader` aggregate invocation, and `check_teaching_demo_content.core.validate(...)`-style bypasses must all fail closed.

## Requirements and enforcement

Every HARD requirement must have a stable `REQ-*` ID and a traceable record containing its authority source, subject, enforcement class, enforcer, required evidence, deterministic failure code or semantic verdict requirement, gate effect, and historical probe where applicable.

Allowed enforcement classes are exactly:

- `MACHINE_DETERMINISTIC`
- `SEMANTIC_JUDGE`
- `HUMAN_ONLY`
- `AUTHOR_SELF_CHECK`

`AUTHOR_SELF_CHECK` can provide risk signals only. A HARD requirement whose only enforcer is author self-attestation is an architecture failure. Every `MACHINE_DETERMINISTIC + HARD` requirement must additionally resolve to a current executable validator/runner and negative probe; a requirement registry that merely names an enforcer is insufficient.

## Actual facts and verified knowledge release

Facts about what visibly occurred in the classroom simulation must be derived from the final typed event stream/rendered product, not copied from planning sidecars. `SCRIPT_FACTS` contains machine-determinable facts such as event order, resource display, student responses, teacher scaffolds, board additions, practice/homework, formula oralization, spoken timing coverage, and **release claims bound to exact visible spans**.

A release claim is not itself proof that the visible span semantically establishes the claimed knowledge. Nonempty bare `event.releases` may not create a hard formation fact. A formation claim must follow this bridge:

```text
final visible event text
→ {knowledge_id, visible_span} release claim
→ machine proves same-event exact-span binding
→ Science/Evidence Judge returns evidence-bound PASS/FAIL/UNKNOWN for that claim
→ PASS-only machine-derived verified_first_release
```

`FAIL` or `UNKNOWN` is blocking. `verified_first_release` is a derived runtime view, not an author-editable artifact. Board timing and answer-resource reveal-after-formation checks may consume **only** `verified_first_release`; they may not consume author metadata or an unverified `first_release` field.

A planning assertion may be compared with machine/verified facts, but it cannot overwrite them.

## State machine

The canonical Teaching Demo Content controller uses the following ordered states:

```text
SOURCE_LOCKED
→ EVIDENCE_READY
→ IR_READY
→ SCRIPT_BUILT
→ SCRIPT_FACTS_DERIVED
→ MACHINE_GATED
→ SEMANTIC_JUDGED
→ SUBMISSION_FROZEN
→ HUMAN_ACCEPTED
```

Only declared adjacent transitions are valid. In particular:

- `SCRIPT_BUILT → SUBMISSION_FROZEN` is forbidden;
- author PASS cannot produce `MACHINE_GATED`;
- machine PASS cannot produce `HUMAN_ACCEPTED`;
- any blocking semantic `FAIL` or `UNKNOWN` prevents freeze;
- board/resource causality dependent on knowledge formation cannot pass before release semantic verification;
- any bound byte change invalidates prior machine, semantic and freeze evidence as applicable.

## Semantic judges

Two separate semantic judge contracts are required:

1. **Science / Evidence Judge** — evidence actually entered the lesson, observation/inference separation, claim strength, conditions/boundaries, student-response reachability, and per-knowledge release-claim semantic entailment.
2. **Enactment / Student Judge** — answer leakage, scaffolded-vs-independent honesty, cognitive interaction, actual resource/board/practice enactment, residual formula oralization, and timing coverage.

Each blocking verdict is `PASS | FAIL | UNKNOWN` and must include exact evidence references. Per-release verification must bind the actual event and exact visible text span. Missing evidence references make the verdict invalid. Blocking `UNKNOWN` is fail-closed.

## Reference selection

Reference learning changes from “pick at least one related case” to structural candidate comparison. Each new topic compares at least two candidates (three recommended), records a structural fingerprint, selection rationale, transfer mapping, and current CASE receipt SHA-256. Machine checks verify real canonical CASE identity/current bytes and comparison completeness; semantic/HUMAN review judges whether the chosen match is genuinely strong.

## Work packets

Each state receives a minimal phase-specific Work Packet containing current main SHA, current state, required output schema, relevant REQ IDs, exact source/reference bindings, allowed writes, forbidden writes, expected evidence, and next gate. The workflow must not rely on a model remembering the entire repository rule set from a long prompt.

## Evaluation before expansion

No fresh random topic or PDF work is allowed until the architecture has passed independent Gate A and an eval harness built from immutable Round 1/2 negative gold, HUMAN-reviewed positive gold, semantic mutants, state/property invariants, stale-evidence attacks and judge calibration. P0/P1 known mutants must be killed at 100%, including:

- external-loader / exposed-core aggregate-gate bypasses;
- unchanged visible text with false early bare `releases:[K1]` followed by premature board/reveal;
- structurally valid visible-span release claim whose sentence does not actually establish K1.

Positive gold must not be rejected by an “always fail” strategy.

## Consequences

- Round 1/2 frozen packages, scores and REJECT outcomes remain immutable historical evidence.
- Phase A implementation/re-review does not mean independent Gate A PASS.
- Phase A / Phase B engineering PASS does not mean `CALIBRATED`.
- Fresh two-topic validation remains separately authorized and independently HUMAN-reviewed.
- PDF/downstream remains blocked until content acceptance under the canonical process.
- New failures should be represented as reusable requirement/eval probes rather than one-off topic patches.
- Every substantive write is followed by the mandatory post-write independent re-review before the next gate handoff is refreshed.
