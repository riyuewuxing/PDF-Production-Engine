# ADR-011 — Reuse Fingerprint vs Audit Snapshot Identity

Status: ACCEPTED

## Context

ADR-010 introduced a durable Repository Snapshot and stated that the normal Artifact input fingerprint includes the snapshot binding. During implementation review, that creates an efficiency defect: the snapshot audit record includes the exact `source_commit`, so an unrelated commit would change the snapshot record hash even when every execution-relevant byte is identical.

The Artifact Job already binds Module Contract bytes, builder bytes, runtime identity and every execution-relevant input byte directly. Re-hashing the snapshot audit record into the same reuse fingerprint is therefore redundant and couples cache invalidation to Git history rather than to actual execution dependencies.

Generated `input_plan` files have the same issue: they intentionally contain audit metadata such as `source_commit` and the full snapshot record. Their exact bytes must remain bound for audit, but they are not an additional executable dependency once all files they enumerate are independently hash-bound.

## Decision

Artifact reuse identity and repository audit identity are separate concerns:

1. `input_fingerprint` is derived only from execution-relevant bytes: Module Contract binding, builder binding, runtime identity and execution-relevant input bindings.
2. `input_plan` remains an exact hash-bound Artifact input record but is excluded from the reusable fingerprint by contract.
3. Repository Snapshot remains mandatory for new jobs and is bound exactly through `build_provenance.source_snapshot_binding`.
4. `dependency_identity_sha256` remains the stable equality/cache-index identity for the repository dependency set and is recorded/verified, but it is not double-counted inside `input_fingerprint` because the same dependency bytes are already present directly in that fingerprint.
5. `snapshot_identity_sha256` and exact `source_commit` remain audit identities only and never invalidate reuse by themselves.

Thus two jobs may share the same `input_fingerprint` across different commits only when every execution-relevant binding and runtime identity is unchanged. Their snapshot audit records still differ and preserve the exact commit used by each execution.

## Consequences

- Unrelated Git commits do not destroy warm-path cache/reuse.
- Actual dependency byte changes still change `input_fingerprint` and invalidate reuse.
- Audit records remain exact and immutable rather than being weakened to improve efficiency.
- The project keeps one content-addressed execution identity and a separate durable history identity instead of conflating them.

## Relationship to ADR-010

ADR-011 supersedes only ADR-010's statement that the normal input fingerprint includes the snapshot binding. All other ADR-010 decisions remain in force: durable Repository Snapshot, exact source commit, live verification, historical verification, no retroactive backfill, and a credential-free stateless Engine boundary.
