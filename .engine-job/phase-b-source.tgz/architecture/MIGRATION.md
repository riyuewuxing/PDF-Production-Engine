# Architecture Foundation v1 — Migration Record

Source branch: `sol/architecture-foundation-v1`

Base: `5289cf7171b4c9d80c6ce8cd5986e6c701d34581`

Release source head: `dcc6a44da4d11bdc1b2c8a31d29ae8678e3e7ed1`

Release state: **RELEASED TO `main` / MAIN CANONICAL**.

`main` was fast-forwarded from its old bootstrap head to the release source head without force and without a PR. `main` is now the single long-lived Git authority; future feature/fix work uses short-lived branches.

## Project essence frozen at closure

The primary project product is the reusable AI-operable production process, not a small set of artifacts polished until they pass. Artifacts remain real user deliverables and process-validation samples. Model strength controls the semantic quality ceiling; architecture provides a portable quality floor through explicit authorities, Module Contracts, a Golden Path, deterministic gates, provenance, append-only execution facts, bounded feedback loops, and final HUMAN review.

A process-evaluation case targets one complete generation/render/review cycle and stops after the third failed full cycle. Repeated rejection must produce failure classification and reusable process learning instead of an unbounded artifact-polishing loop. Wall-clock time is measured but is not a standalone hard gate.

This is frozen in `ADR-009-process-as-product-and-agent-portability.md`, the efficiency policy, and System Qualification contract.

## Migrated

- Modular Monolith + Domain/Application/Artifact/Adapters foundation.
- External Recruitment Intelligence and stateless PDF-Production-Engine boundaries.
- Unified seven-state Artifact Pipeline.
- Append-only Execution Ledger with lifecycle projection and derived efficiency facts.
- Content-addressed provenance and repository-relative path/hash guards.
- Delivery Acceptance separated from System Qualification.
- Single authority per concern and explicit module/tool lifecycle taxonomy.
- Process-as-Product / agent portability / Golden Path / bounded feedback loop.
- Position Research live acquisition retired; Written Exam and Resume kept deferred; legacy Teaching Demo governance compatibility-only.
- Private GitHub-hosted Actions removed from normal production dependency.
- Historical accepted product hashes and the failed mechanical-energy experiment preserved unchanged.

## Release verification

- Pre-release migration branch was a fast-forward descendant of the frozen experiment head.
- Before integration, `main` was an ancestor of the release branch: source was 1295 commits ahead / 0 behind, with merge base equal to old `main`.
- `main` fast-forward integration completed with `force=false`.
- No PR was created for the integration.
- Core foundation selftests had previously passed in an isolated local Python environment for initializer, Artifact Job checker, Execution Ledger checker, Artifact Job manager, and Python compilation.
- Final release-state metadata/checker edits were statically reviewed through the GitHub connector; no repository-native CI PASS is claimed because private hosted Actions remain unavailable/forbidden as a normal dependency.

## Next development gate

Architecture Foundation v1 is closed. The next active engineering work is Teaching Demo / 逐字稿 process development. That work must optimize the reusable Golden Path rather than polish one sample indefinitely. System Qualification remains separate and requires explicit user start.
