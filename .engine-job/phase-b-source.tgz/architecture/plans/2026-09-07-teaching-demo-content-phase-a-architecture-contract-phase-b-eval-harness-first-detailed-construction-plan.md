# 2026-09-07｜Teaching Demo Content｜Phase A Architecture Contract + Phase B Eval Harness First｜详细施工计划

> **角色：SUPPORTING ARCHITECTURE / CONSTRUCTION PLAN（非运行 authority）**
>
> GitHub `main` 仍是最终 authority。当前唯一运行入口仍是 `production/process/teaching-demo-content/PROCESS.md`，唯一合同仍是 `production/contracts/teaching-demo-content.yaml`，唯一 checker 入口仍是 `tools/check_teaching_demo_content.py`。本文件不得被当作第二套 PROCESS、第二套合同、第二个 checker 或第二条逐字稿工作线。

- 日期：2026-09-07
- 决策角色：总策划
- 施工对象：求职达人 → 教师招聘 → 教师面试 → 试讲 → Teaching Demo Content / 逐字稿内容形成
- 起始 authority：`main@70d022186ae8782436550e2efa77335b32baf514`
- 当前事实：Round 2《电场强度》77（2 类 hard fail）、《动量定理》87（0 hard fail），两题首次冻结包均 REJECT，流程仍 `NOT_CALIBRATED`。
- 本次路线：任何新题、PDF 或下游启动前，先完成 **Phase A 架构契约** 与 **Phase B Eval Harness First**。

---

## 0. 总策划架构决策

### 0.1 停止“继续堆规则 + 作者自签 PASS”的补丁路线

Round 1 / Round 2 已经证明：当前系统有大量正确规则，但实现者能够在 sidecar 中声明规则已兑现，而最终逐字稿没有真正兑现；当前 checker 又主要检查结构、anchor、字段、哈希和算术，因此会出现 **结构 PASS / 内容 REJECT**。

后续禁止再采用：

`发现一类错误 → PROCESS 再加几条 prose → checker 再查几个字段 → 作者自写 PASS → 继续下一题`

作为主修复方法。

### 0.2 目标架构：Evidence-Carrying Teaching Script Compiler

```text
教材/任务/参考证据
→ Lesson Evidence IR
→ Typed Script Event Stream
→ 自然语言逐字稿/五个用户内容块
→ 从最终成品反向导出 SCRIPT_FACTS
→ Deterministic Gate
→ Science/Evidence Judge
→ Enactment/Student Judge
→ Freeze
→ Independent HUMAN
```

原则：**Agent autonomy at the edges; deterministic workflow at the center.** 模型负责专业判断和自然语言创作；状态迁移、硬约束、事实导出、提交资格和不可绕过 gate 由系统控制。

### 0.3 两阶段边界

- Phase A 回答：系统认什么是事实；每条 HARD requirement 谁负责验证；什么证据能解锁状态。
- Phase B 回答：新架构能否抓住“字段、hash、anchor 都合法，但正文实际上错误”的作弊型失败。
- Phase A 未 PASS，不进入 Phase B。
- Phase B 未 PASS，不进入 canonical migration / fresh random validation / PDF。

---

## 1. 外部研究如何转化为施工约束

第二轮调研采用并映射以下成熟实践：

1. **预定义 workflow 优先于自由 Agent**：对固定顺序、严格步骤和重复执行任务，中央流程使用 deterministic/sequential workflow，而不是让模型自行编排。
2. **Requirements Verification Matrix**：每个强制 requirement 有唯一 ID、来源、验证方法和证据。
3. **Policy decision / enforcement 分离**：作者声明不能等于 acceptance；controller 在状态边界实施 tripwire。
4. **code/model/human grader 分层**：确定性事实用 code grader；开放语义用 semantic judge；最终教学质量保留 HUMAN；semantic judge 允许 `UNKNOWN`，且 UNKNOWN 不等于 PASS。
5. **Eval first**：真实失败优先进入 regression corpus；下一轮功能扩展前先证明 grader 能识别旧失败。
6. **Mutation + property testing**：主动注入合法结构但语义错误的 mutant，检查 gate 是否真正有检错能力。
7. **Evidence-Centered Design**：明确 claim、可观察 evidence、student task、可允许回答和 formation 之间的因果关系。
8. **最小高信号上下文**：每个阶段给工程师 phase-specific Work Packet，而不是依赖超长规则上下文的持续记忆。

---

# PHASE A｜Architecture Contract

## A0. 目标与不做事项

### 目标

1. 每个 HARD requirement 有稳定 `REQ-*` ID；
2. 每个 requirement 有唯一 enforcement owner；
3. 每个 gate 只接受可验证 evidence；
4. author self-check 永远不能单独解锁下一状态；
5. 最终逐字稿实际发生的事实由系统反向导出，而不是作者自报；
6. 保持 `main` 单线、唯一 PROCESS / contract / checker。

### 不做

- 不返修 Round 2 两个首次冻结包；
- 不改写 77/87 与 REJECT；
- 不抽新题；
- 不做 PDF；
- 不创建 PROCESS-v2、contract copy、alternate checker、dated runtime route 或新内容 branch。

## A1. Requirement Registry + Traceability Matrix

把当前 contract / PROCESS / Round1+2 HUMAN failure 中的强制规则统一编成稳定 ID，至少按域分组：

- `REQ-SCI-*`：科学证据与结论强度；
- `REQ-STU-*`：学生当前信息、回答可达性、支架边界；
- `REQ-INT-*`：互动链；
- `REQ-RES-*`：资源展示/遮盖/答案释放；
- `REQ-BRD-*`：板书因果与时序；
- `REQ-PRC-*`：练习/作业完整性；
- `REQ-TIM-*`：口说、公式口读、动作、连续 timing；
- `REQ-REF-*`：购买范例结构匹配与迁移；
- `REQ-FRZ-*`：freeze / byte binding；
- `REQ-STA-*`：状态机与禁止跳转；
- `REQ-REV-*`：grader / HUMAN acceptance。

每条 requirement 至少记录：

```yaml
requirement_id:
authority_source:
subject:
enforcement_class:
enforcer:
evidence_required:
failure_code:
gate_effect:
historical_probe:
```

强制：

- HARD requirement 不得只有 `AUTHOR_SELF_CHECK`；
- `SEMANTIC_JUDGE` / `HUMAN_ONLY` 必须诚实承认不是 deterministic；
- 任何没有 enforcement owner 的 HARD requirement → Phase A FAIL。

## A2. 统一 Enforcement Classes

固定四类：

1. `MACHINE_DETERMINISTIC`：精确文本/事件覆盖、状态迁移、hash、路径、集合、算术、anchor、唯一性、顺序等。
2. `SEMANTIC_JUDGE`：结论是否强于证据、学生回答是否由当前信息可达、教师是否事实上给出答案等开放语义。
3. `HUMAN_ONLY`：整体教学质量、自然度、专业判断、最终评分。
4. `AUTHOR_SELF_CHECK`：仅作为作者风险提示，无 gate 权力。

当前 `science_red_team: PASS`、`student_state_simulation: PASS`、`enactment_board_dry_run: PASS` 在未来 canonical migration 时降级为 author assertion；作者写 PASS 不得成为 machine acceptance 证据。

## A3. Lesson Evidence IR

每个知识形成单元至少表示：

```yaml
knowledge_id:
claim:
claim_strength:
source_evidence_ids: []
prior_student_knowledge_ids: []
visible_evidence_before_task: []
resource_state_before_task: []
student_task:
permissible_response:
forbidden_response_requires_future_info: []
scaffold_level:
teacher_scaffold_boundary:
formation_claim:
formation_requires: []
board_after_formation: []
practice_links: []
```

不变量：

- `formation_claim` 强度不得超过 `visible_evidence + prior knowledge + permitted scaffold`；
- independent transfer 的 prompt/resource/board 不得包含被评价答案的关键操作或结论；
- evidence 只存在于 sidecar 而未进入实际 classroom event 时，不计入 `visible_evidence_before_task`。

Round 2《电场强度》必须成为直接架构 probe：如果最终课堂只出现“q 变，F 也变”，但没有真实呈现比例关系，系统不能合法推出“F/q 稳定”的 formation claim。

## A4. Typed Script Event Stream

最终用户视图仍是自然中文；内部执行层采用 typed events。最小事件集合：

- `SPEAK`
- `FORMULA_ORALIZE`
- `ASK`
- `INVITE`
- `WAIT`
- `STUDENT_RESPONSE`
- `PARAPHRASE`
- `FEEDBACK`
- `SCAFFOLD`
- `RESOURCE_SHOW`
- `RESOURCE_HIDE_OR_MASK`
- `BOARD_ADD`
- `PRACTICE`
- `TRANSITION`
- `CLOSE`

每个 event 有稳定 `event_id`、cycle、知识状态、用户可见文本/动作和 timing 属性。event stream 是内部生产/验证结构；renderer/serializer 生成自然中文，不把 `event_id/case_id/gate_id` 泄漏到候选人产品。

## A5. SCRIPT_FACTS 必须从最终产品反向导出

禁止接受“作者说展示了资源，所以算展示”。只有 final event stream 中实际存在 `RESOURCE_SHOW`，SCRIPT_FACTS 才能记录资源已展示。

自动导出至少包括：

- 各 cycle 实际互动事件顺序；
- 各知识点第一次在口说/资源/板书哪个通道释放；
- 学生任务前实际可见信息；
- 学生实际预设回应；
- 教师在学生回答前后实际说了什么；
- 实际板书增量；
- 实际练习/作业集合；
- 公式是否有口读事件；
- final spoken text timing coverage 是否 100%；
- speech segment 是否对应最终原文而不是摘要。

然后比较：

```text
PLANNED_IR_FACTS <-> SCRIPT_FACTS_ACTUAL
```

差异进入 deterministic gate 或 semantic judge；作者不能用另一份 sidecar 覆盖差异。

## A6. State Machine + Gate Controller

建议状态：

```text
SOURCE_LOCKED
→ EVIDENCE_READY
→ IR_READY
→ SCRIPT_BUILT
→ SCRIPT_FACTS_DERIVED
→ MACHINE_GATED
→ SEMANTIC_JUDGED
→ SUBMISSION_FROZEN
→ HUMAN_ACCEPTED
```

关键约束：

- `SCRIPT_BUILT → SCRIPT_FACTS_DERIVED` 必须由系统从最终事件/文本派生；
- `SCRIPT_FACTS_DERIVED → MACHINE_GATED` 要求 deterministic HARD requirements 全 PASS；
- `MACHINE_GATED → SEMANTIC_JUDGED` 要求两个语义 judge 均有 evidence-backed verdict；
- `SEMANTIC_JUDGED → SUBMISSION_FROZEN` 不得存在 blocking FAIL/UNKNOWN；
- `SUBMISSION_FROZEN → HUMAN_ACCEPTED` 只有 independent HUMAN 可执行。

Tripwire 必须阻止：

- `SCRIPT_BUILT → SUBMISSION_FROZEN`；
- `AUTHOR_SELF_CHECK_PASS → MACHINE_GATED`；
- `MACHINE_GATED → HUMAN_ACCEPTED`；
- stale digest 继续使用旧 judge verdict。

## A7. 两个独立 Semantic Judge Contract

### Science / Evidence Judge

只评：
- evidence 是否真实进入课堂；
- observation/inference 是否偷换；
- claim strength 是否越界；
- 条件/适用范围是否丢失；
- student response 是否需要未释放信息。

### Enactment / Student Judge

只评：
- 教师是否提前给关键答案；
- scaffolded vs independent 标注是否诚实；
- 互动链是否真正有认知作用；
- script/resource/board 的课堂动作是否兑现；
- 练习/作业是否完整；
- timing 文本是否真正对应全文。

统一输出：

```yaml
requirement_id:
verdict: PASS | FAIL | UNKNOWN
claim:
evidence_refs:
  - event_id / exact_text_span / source_id
reason:
confidence:
```

强制：无 evidence ref 的 verdict 无效；UNKNOWN 不得转 PASS；judge 不信任 author `decision: PASS`；HUMAN gold set 校准 judge；避免一个 judge 同时负责所有维度。

## A8. Phase-specific Work Packet

controller 每一步只提供最小高信号上下文：

```text
current main SHA
current state
current task/output schema
relevant REQ IDs (通常 5–10 个)
exact textbook/source refs
selected reference mechanisms
allowed writes
forbidden writes
expected evidence
next gate
```

禁止依赖“把全仓库规则和历史一次塞给工程师，然后期待长期记住”。

## A9. Reference Structural Fingerprint

把“至少选一个结构相关 CASE”升级成候选比较：每题至少比较 2 个，推荐 3 个。比较维度：lesson mechanism、evidence type、knowledge-formation pattern、student task type、resource interaction、misconception structure、ratio/definition/derivation/application 等推理模式、classroom enactment pattern。

机器至少验证“候选比较存在 + 选择理由 + transfer mapping”；semantic/HUMAN 判断匹配质量。

## A10. Content-addressed Gate Evidence

每次 gate evidence 绑定：main/source commit、canonical PROCESS/contract/checker digest、relevant IR/event/final-script digest、judge rubric/version、judge input digest、verdict digest。

任一 bound byte/digest 改变：previous machine gate、previous semantic judge、previous freeze 必须按适用范围变为 `STALE`，禁止继续沿用旧 verdict。

## A11. Phase A 计划修改范围（真正施工时）

只允许在唯一 `main` 上原地施工：

1. `production/process/teaching-demo-content/PROCESS.md`：把 prose/self-attestation 流程升级成显式状态机、fact derivation、judge 分层、Work Packet、结构参考选择。
2. `production/contracts/teaching-demo-content.yaml`：原地升级 contract，加入 stable requirement IDs、enforcement classes、IR/event/script-facts schema、gate map；仍是唯一合同。
3. `tools/check_teaching_demo_content.py`：仍是唯一 gate CLI；增加 deterministic derivation/state enforcement，不创建 alternate checker。
4. `production/process/teaching-demo-content/ENGINEERING_REGRESSION.yaml`：Phase B 后原地升级为完整回归证据。
5. `architecture/adr/ADR-0XX-...md`：新增 superseding architecture decision；ADR 是架构记录，不是第二运行入口。
6. `PLAN.md / STATUS.yaml / MEMORY.md / RECORDS.md`：按 Close-out Loop 同步。

若代码需要 helper，仅允许“无独立 CLI、无独立 gate authority 的纯库模块”，且 contract 必须明确唯一 checker entry 不变。

## A12. Phase A Acceptance Gate

全部满足才 PASS：

- [ ] 每个 HARD requirement 有稳定 ID、来源、enforcement owner、evidence、failure code、gate effect；
- [ ] `self-attestation-only hard requirement = 0`；
- [ ] 所有允许/禁止状态迁移明确；
- [ ] Lesson Evidence IR 能表达 Round2 比例关系证据不足问题；
- [ ] Script Event Stream 能表达互动/资源/板书/公式口读/练习/timing；
- [ ] SCRIPT_FACTS 从 final stream 自动导出，不接受作者代填 actual facts；
- [ ] semantic judge 有 exact evidence + PASS/FAIL/UNKNOWN；
- [ ] blocking UNKNOWN 不可推进；
- [ ] Work Packet 规则完成；
- [ ] reference candidate comparison 完成；
- [ ] Round1/Round2 frozen bytes 未改变；
- [ ] PDF/downstream 未启动；
- [ ] 没有第二 PROCESS/contract/checker/branch。

Phase A PASS 只表示架构契约达到施工验收，不表示 Teaching Demo Content 已 CALIBRATED。

---

# PHASE B｜Eval Harness First

## B0. 目标

在任何 fresh topic 前，用真实历史失败 + semantic mutants 攻击 Phase A 设计。唯一核心问题：

> 当工程师把字段、author PASS、hash、anchor、算术全部做合法，但最终逐字稿实际没兑现时，新系统能否稳定 REJECT？

## B1. Gold Regression Corpus

永久只读引用负例：

- Round1 `acceleration-description-v1` 首次失败；
- Round1 `faraday-induction-law-v1` 首次失败；
- Round2 `electric-field-strength-v1` 首次失败；
- Round2 `impulse-momentum-theorem-v1` 首次失败中独立审查指出的 timing/可执行性缺陷。

不得为了让 harness 通过而修改原冻结包。

另建立 HUMAN 审核过的最小正例 Gold，证明 evidence→student response→formation 因果真实、scaffolded/independent 诚实、资源/板书/练习/timing 能从 final events 反向重建，且 judge 应 PASS 的情况不会被误杀。

## B2. Semantic Mutant Suite（最低 15，建议 20）

要求 mutant 尽量保持 YAML/schema/anchor/hash 等机械条件合法：

| ID | 缺陷 | 预期 |
|---|---|---|
| M01 | 比例关系只在 sidecar/IR 声称，final script 未呈现却得出比值稳定 | REJECT |
| M02 | 教师在 independent transfer 前说出关键操作/答案 | REJECT |
| M03 | student response 依赖尚未展示的信息 | REJECT |
| M04 | conclusion 强于当时实际 evidence | REJECT |
| M05 | Resource Map 声明资源进入课堂，但 final events 无 `RESOURCE_SHOW` | REJECT |
| M06 | answer-bearing resource 在学生任务前已显示 | REJECT |
| M07 | Board Timeline 声明 delta，但 final events 无对应 `BOARD_ADD` | REJECT |
| M08 | `spoken_equivalent` 用一句摘要冒充 60–90 秒真实全文 | REJECT |
| M09 | timing segments 有正文 gap/overlap/未 100% 覆盖 final spoken text | REJECT |
| M10 | 公式只有符号，没有 `FORMULA_ORALIZE` | REJECT |
| M11 | final script 出现课后练习/作业，inventory 未登记 | REJECT |
| M12 | inventory 声明 complete 后，final script 追加隐藏练习 | REJECT |
| M13 | semantic judge 返回 UNKNOWN，却被 controller 当 PASS | REJECT |
| M14 | judge/freeze digest 对应旧字节，正文已变化 | REJECT |
| M15 | reference selection 只挑一个候选，未完成结构候选比较 | REJECT |

建议扩展：

- M16：互动 anchor 都存在，但学生回答与 teacher paraphrase 语义不一致；
- M17：feedback 只有“很好”，无认知承接；
- M18：RESOURCE_SHOW 发生，但展示版本不含声明的关键 evidence；
- M19：board 在 formation 前通过其他路径泄露结论；
- M20：各 segment 秒数相加正确，但实际字数/语速与声明区间明显不相符。

## B3. Property / State Tests

至少建立这些不变量：

1. 没有 `SCRIPT_FACTS_DERIVED` 永远不能进入 `MACHINE_GATED`；
2. 任一 blocking requirement FAIL，后继状态不可达；
3. 任一 blocking semantic verdict UNKNOWN，freeze 不可达；
4. final script 任一字节变化，旧 facts/judge/freeze 失效；
5. final event stream 序列化后，spoken coverage 必须完整可逆映射；
6. `derived_from_final practice set == declared_inventory`；
7. final board == 实际 `BOARD_ADD` 累积；
8. information release first occurrence 由 actual event 序列计算；
9. state machine 不接受未声明 transition；
10. author PASS 字段变化不能改变 machine-derived facts。

Property-based generator 随机扰动 event 顺序、删除事件、移动资源展示、改变知识形成时点，寻找手写 mutant 未覆盖的组合。

## B4. Grader Calibration

Deterministic grader：0 随机性，稳定 failure code + exact location。

Semantic judge：至少用 HUMAN 标注 gold set 校准 PASS / FAIL / UNKNOWN，报告记录 agreement/confusion matrix、false-pass、false-reject、UNKNOWN、各 rule family 表现。

P0 hard fail 优先降低 false PASS，但不能靠“一律 FAIL”刷 mutation kill；必须用平衡正例约束。

## B5. Eval Harness Trial 记录

每个 trial 至少保留：fixture/source identity、canonical contract/checker digest、mutant id/description、input IR、final event stream、rendered final script、SCRIPT_FACTS、machine verdicts、semantic judge input/output、expected verdict、actual verdict、failure code、reproducibility metadata。

Harness 不得读取历史 case 最终 HUMAN 分数后硬编码答案；必须根据当前 requirement 和 actual facts 抓缺陷。

## B6. Mutation Score + Acceptance Threshold

```text
Semantic Mutation Score = killed valid semantic mutants / all valid semantic mutants
```

Phase B gate：

- P0/P1 已知 semantic mutants：**100% killed**；
- Round1/Round2 已确认 failure mechanism：对应 probe 必须全部捕获；
- curated positive Gold：**0 false rejection**，除非 HUMAN 明确裁定 fixture 本身错误；
- stale digest/state bypass/property tests：100% PASS；
- blocking `UNKNOWN` 不得进入 PASS；
- 每个失败可定位到 Rule ID + evidence；
- model judge 多次 trial 必须保留稳定度和分歧，不得 cherry-pick；
- `ENGINEERING_REGRESSION.yaml` 原地记录最终 harness 证据，并仍明确 `PASS_ENGINEERING_ONLY`，不得声称 process calibrated。

## B7. Phase B 失败策略

任一条件失败：不抽新题、不修历史冻结包、不启动 PDF；回到 Phase A 对 requirement/enforcement/facts/judge contract 原地修正；之后重跑**全部** regression + mutation suite，而非只重跑刚失败 probe。

## B8. Phase B PASS 后的唯一解锁

只解锁：

`ELIGIBLE_FOR_PHASE_C_CANONICAL_MIGRATION / FRESH_VALIDATION_PREPARATION`

不自动解锁：`CALIBRATED`、新随机题、PDF、Artifact Pipeline。

下一轮 fresh two-topic validation 仍需用户/总策划授权，并继续遵守首次完整包、两题都 ≥92、每维过线、hard fail=0 的标准。

---

## 2. 两阶段工程交付清单

### Phase A

- [ ] Requirement → Enforcement → Evidence → Gate Matrix
- [ ] stable Rule IDs
- [ ] Lesson Evidence IR
- [ ] Typed Script Event Stream
- [ ] SCRIPT_FACTS derivation contract
- [ ] explicit state machine / forbidden transitions
- [ ] Science/Evidence Judge contract
- [ ] Enactment/Student Judge contract
- [ ] Work Packet contract
- [ ] Reference Structural Fingerprint / candidate comparison
- [ ] content-addressed gate evidence policy
- [ ] superseding ADR
- [ ] canonical PROCESS/contract/checker in-place implementation
- [ ] Close-out PLAN/STATUS/MEMORY/RECORDS

### Phase B

- [ ] immutable historical failure corpus bindings
- [ ] curated positive Gold fixtures
- [ ] M01–M15 minimum semantic mutants（推荐 M01–M20）
- [ ] property/state invariant tests
- [ ] deterministic grader report
- [ ] semantic judge calibration report
- [ ] mutation score report
- [ ] full regression rerun evidence
- [ ] `ENGINEERING_REGRESSION.yaml` in-place update
- [ ] exact Git readback/digest evidence
- [ ] Close-out PLAN/STATUS/MEMORY/RECORDS

---

## 3. 工程师执行纪律

1. 每次开始先跑 GitHub Refresh Loop；`main` 最新 HEAD 为 authority。
2. 不读历史分支当当前入口。
3. 不开新 branch/copy/v2/dated runtime route。
4. Phase A + B 作为一次完整工程批次；内部可以自测，但不要求每一小步找总策划批准。
5. 每阶段结束必须 read-back 自己实际写入的 GitHub 字节。
6. code gate 能真实运行命令时记录 command/exit/stdout；不能运行时如实标注，不得把 logic replay 冒充 shell runtime。
7. HUMAN 与 semantic judge verdict 不得由实现者伪造。
8. Round2 首次冻结包不可改。
9. 不允许为了让 regression 过而弱化 HARD requirement。
10. 新文件必须证明不是第二 runtime authority；能原地升级就原地升级。

---

## 4. 总策划验收

### Gate A｜Architecture Contract Review

重点：是否还有 hard rule 只靠模型记忆/作者自签；actual facts 是否从 final product 反向产生；状态能否真实禁止跳过；semantic/human 边界是否诚实；Round2 root cause 是否成为架构可表达的失败，而非只写一条注释。

### Gate B｜Eval Harness Review

重点：字段合法的作弊 mutant 能否被抓；正例是否误杀；mutation score 是否达标；judge 是否提供 evidence；是否读取完整 trial/final script，而不是只看最终 PASS 数字。

只有 Gate A + Gate B 都 PASS，才讨论 Phase C。

---

## 5. 当前 gate 精化

本计划入库后仍保持：

- `status: ROUND2_REJECTED_PROCESS_NOT_CALIBRATED`
- `process_calibration: NOT_CALIBRATED`

但当前 gate 精化为：

`EXECUTE_PHASE_A_ARCHITECTURE_CONTRACT_AND_PHASE_B_EVAL_HARNESS_BEFORE_CANONICAL_MIGRATION`

下一步不是新题，也不是直接在现有 checker 上继续堆零散 if，而是按本计划执行 Phase A → Phase B。

---

## 6. 2026-09-07 外部调研来源

- Anthropic, *Building Effective AI Agents*
- Anthropic, *Effective context engineering for AI agents*
- Anthropic, *Demystifying evals for AI agents* (2026-01-09)
- Google Cloud Architecture Center, *Choose a design pattern for your agentic AI system*
- Open Policy Agent documentation / philosophy / integration
- NASA Systems Engineering Handbook, Requirements Verification Matrix
- OpenAI Agents SDK, Guardrails
- ETS, Evidence-Centered Design research
- Hypothesis, Property-based testing documentation
- PIT, Mutation Testing / Basic Concepts
- Liu et al., *Lost in the Middle: How Language Models Use Long Contexts*, TACL 2024
- Jiang et al., *FollowBench*, ACL 2024

---

## 7. 结束条件

Phase A 与 Phase B 完成前：

- 两个 Round2 首次结果永久保持 REJECT；
- Teaching Demo Content 继续 `NOT_CALIBRATED`；
- 不自动抽第三题/新一轮题；
- 不启动 PDF；
- 不恢复任何旧 branch/旧路线；
- 不把现有 F1–F6 `PASS_ENGINEERING_ONLY` 当作新架构已通过。

成功标准不是“工程师说完成”，而是：**规则的执行权从模型记忆和作者自签迁移到可追踪 requirement、actual facts、状态 gate 和能够被 mutation 攻击验证的 eval harness。**
